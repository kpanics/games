"""The site's icon from the logo's wings (her cursed_logo.gif, its first frame): the wings cut out, on the site's own
dark (#09090d) in a rounded square, so they read on a light tab bar as on a dark one.

    python favicon.py [LOGO]   ->  dist/favicon.ico (16, 32, 48), dist/icon-192.png, dist/apple-touch-icon.png
"""
import os, sys
from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
DIST = os.path.join(HERE, 'dist')
LOGO = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.expanduser('~'), 'Desktop', 'cursed_logo.gif')
DARK = (9, 9, 13, 255)


def wings():
    im = Image.open(LOGO)
    im.seek(0)
    rgba = im.convert('RGBA')
    # The picture's own dark goes (its black is not the site's): how bright a pixel is, is how much of it shows; and
    # only near the wings themselves (the animation's specks, alone in the dark, go too).
    lum = rgba.convert('L')
    near = lum.filter(ImageFilter.GaussianBlur(7)).point(lambda v: 255 if v > 40 else 0).filter(ImageFilter.MaxFilter(9))
    alpha = lum.point(lambda v: 0 if v < 22 else 255 if v > 96 else round((v - 22) / 74 * 255))
    alpha = ImageChops.multiply(alpha, near)
    rgba.putalpha(alpha)
    l, t, r, b = alpha.point(lambda v: 255 if v > 60 else 0).getbbox()
    pad = 4
    w, h = rgba.size
    box = (max(0, l - pad), max(0, t - pad), min(w, r + pad), min(h, b + pad))
    return rgba.crop(box)


def icon(size, w):
    out = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    mask = Image.new('L', (size * 4, size * 4), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, size * 4 - 1, size * 4 - 1), radius=size * 4 * 0.22, fill=255)
    out.paste(Image.new('RGBA', (size, size), DARK), (0, 0), mask.resize((size, size), Image.LANCZOS))
    # The wings as big as the square lets them, a margin round them.
    room = size * (0.84 if size <= 32 else 0.76)
    k = room / max(w.size)
    small = w.resize((max(1, round(w.width * k)), max(1, round(w.height * k))), Image.LANCZOS)
    if size <= 32:
        # Tiny: brighter, so the feathers do not go grey.
        small = ImageEnhance.Brightness(small).enhance(1.25)
    out.alpha_composite(small, ((size - small.width) // 2, (size - small.height) // 2))
    return out


w = wings()
os.makedirs(DIST, exist_ok=True)
icons = [icon(s, w) for s in (16, 32, 48)]
icons[2].save(os.path.join(DIST, 'favicon.ico'), sizes=[(16, 16), (32, 32), (48, 48)], append_images=icons[:2])
icon(192, w).save(os.path.join(DIST, 'icon-192.png'))
icon(180, w).save(os.path.join(DIST, 'apple-touch-icon.png'))
print('ok', w.size)
