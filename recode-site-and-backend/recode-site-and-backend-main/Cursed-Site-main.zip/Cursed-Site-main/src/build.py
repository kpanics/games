"""build.py: the site for cursedclient.xyz made out of the approved preview (preview.html, read from the artifact).

What changes against the preview:
- no invitations anywhere (registration is open), no word of a private client; the line under CURSED says
  "New era of Minecraft clients";
- the preview's own switch (the PREVIEW bar, stepping through screens with the arrows) is gone;
- Terms and Privacy are one short page of Rules;
- the music (site.js) and its button;
- the pictures are files of their own (img/), the fonts are ours (fonts/), the code is a file (app.js): nothing from
  another site, and the Content-Security-Policy can forbid inline scripts.
Out: dist/.
"""
import base64
import os
import re
import shutil
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
DIST = os.path.join(HERE, 'dist')
STUB = HERE  # site.js and music/ live next to this file
FONTS = os.environ.get('CURSED_FONTS', os.path.join(HERE, '..', '..', 'Cursed', 'native', 'assets', 'fonts'))

src = open(os.path.join(HERE, 'preview.html'), encoding='utf-8').read()
shutil.rmtree(DIST, ignore_errors=True)
for d in ['img', 'fonts', 'music']:
    os.makedirs(os.path.join(DIST, d))

def swap(text, a, b, count=1):
    n = text.count(a)
    assert n == count, (a[:90], n)
    return text.replace(a, b)


# ---------------------------------------------------------------- the parts of the preview
style = re.search(r'<title>.*?</title>\s*<link[^>]*>\s*<style>(.*?)</style>', src, re.S).group(1)
# Rules for what is gone (the invitation block and its code box).
style, n = re.subn(r'\n\.invite-scene \{[^}]*\}|\n\.code-in[^{]*\{[^}]*\}', '', style)
assert n == 5, n
# The line under CURSED a little to the right (her edit), as far on every width as the wordmark is wide there.
style = swap(style, 'margin: calc(min(57vw, 940px) * -0.07) 0 0 .2em;', 'margin: calc(min(57vw, 940px) * -0.07) 0 0 calc(.2em + min(57vw, 940px) * 0.016);')
style = swap(style, '  .news li { white-space: normal; }\n', '  .news li { white-space: normal; }\n  .subline { margin-left: calc(.2em + min(96vw, 760px) * 0.016); }\n')
# The first screen is the whole window at any height (it stopped at 1100 px, and on her 1440p screen the water ended on
# a line with black under it).
style = swap(style, '.hero { position: relative; margin-top: -104px; min-height: min(100svh, 1100px);', '.hero { position: relative; margin-top: -104px; min-height: 100svh;')
# The CURSED fallback hides as soon as the title has a WebGL canvas, not when its first frame shows (it blinked between).
style = swap(style, '.wordmark.lit + .fallback { display: none; }', '.wordmark.gl + .fallback { display: none; }')
shaders = ''.join(m.group(0) for m in re.finditer(r'<script id="frag-[a-z]+" type="x-shader/x-fragment">.*?</script>', src, re.S))
app_open = [m for m in re.finditer(r'<script>', src)][0]
js = src[app_open.end():src.index('</script>', app_open.end())]


# ---------------------------------------------------------------- the pictures, as files
def picture(m):
    name, kind, data = m.group(1), m.group(2), m.group(3)
    ext = {'jpeg': 'jpg', 'png': 'png', 'webp': 'webp'}[kind]
    path = f'img/{name}.{ext}'
    open(os.path.join(DIST, path), 'wb').write(base64.b64decode(data))
    return f'"{name}": "/{path}"'


js, n = re.subn(r'"([a-z0-9-]+)": "data:image/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)"', picture, js)
assert n > 30, n
assert 'data:image' not in js, 'a picture left inside the code'

# ---------------------------------------------------------------- home: no invitations, the new line
js = swap(js, '<p class="subline">A private Minecraft ${GAME} client</p>', '<p class="subline">New era of Minecraft clients</p>')
js = swap(js, '''        : state.openReg ? `<span class="st cream">Open registration until ${OPEN_UNTIL}</span><a class="w menu lead" href="#/register">Register</a><a class="w menu" href="#/signin">Sign in</a>`
        : `<a class="w menu lead" href="#/register">I have an invite</a><a class="w menu" href="#/signin">Sign in</a>`}</div>''',
          '''        : `<a class="w menu lead" href="#/register">Register</a><a class="w menu" href="#/signin">Sign in</a>`}</div>''')
a = js.index("    </section>` : state.openReg ? `<section class=\"invite-scene\">")
b = js.index("    </section>`}`;\n}", a)
js = js[:a] + "    </section>` : ''}`;\n}" + js[b + len("    </section>`}`;\n}"):]

# Her edits of 26.09 evening: the second screen (the eyes and "Like nothing else") and the version under the menu gone.
a = js.index('    <section class="scene">\n      <div class="say"><h2 class="big">Like nothing else</h2>')
b = js.index('</section>', a) + len('</section>')
js = js[:a] + js[b:].lstrip('\n')
js = swap(js, '\n        <div class="news"><span class="v">${CHANGELOG.version}</span><span class="ash">${CHANGELOG.state}</span></div>', '')

# ---------------------------------------------------------------- the door: open registration, the eyes open as the form fills
js = swap(js, "      ${state.openReg ? `<p class=\"st cream\">Open registration until ${OPEN_UNTIL} · no invite needed</p>` : ''}\n", '')
js = swap(js, '''        ${state.openReg ? '' : `<div><label class="lab" for="invite">Invitation code</label><input class="in code" id="invite" autocomplete="off" spellcheck="false" placeholder="CRSD-XXXXXXXX-XXXXXXXX-XXXXXXXX" maxlength="31" value="${esc(state.invite)}"><p class="hint" id="invite-h"></p></div>`}\n''', '')
js = swap(js, '<span>I accept the <a href="#/docs/terms">Terms</a> and the <a href="#/docs/privacy">Privacy Policy</a>.</span>',
          '<span>I accept the <a href="#/docs/rules">Rules</a>.</span>')
js = swap(js, '''<canvas id="fx-eyes" ${state.openReg ? 'data-open="1"' : ''} aria-hidden="true"></canvas>''', '<canvas id="fx-eyes" aria-hidden="true"></canvas>')
js = swap(js, '''      <p class="hint">${state.openReg ? `No account? Registration is open until ${OPEN_UNTIL}.` : 'No account? You need an invite.'} <a class="w small" href="#/register" style="margin-left:10px">${state.openReg ? 'Register' : 'I have one'}</a></p></div>''',
          '''      <p class="hint">No account? <a class="w small" href="#/register" style="margin-left:10px">Register</a></p></div>''')
js = swap(js, 'if (door && state.eyes && !eyes.dataset.open) syncInvite();', 'if (door && state.eyes && !eyes.dataset.open) syncForm();')
a = js.index('// An invitation code types itself into shape')
b = js.index('const solidBar = ')
js = js[:a] + '''// The eyes on the door crack open as the form fills and open wide once all of it is right.
function formDone() {
  const login = document.getElementById('login'), email = document.getElementById('email'), pass = document.getElementById('pass'), rules = document.getElementById('t-terms');
  if (!login) return [0, 4];
  return [[/^[A-Za-z0-9_]{3,16}$/.test(login.value), email.value.includes('@'), pass.value.length >= 10, rules.checked].filter(Boolean).length, 4];
}
function syncForm() {
  if (!state.eyes) return;
  const [n, all] = formDone(), whole = n === all;
  state.eyes.setOpen(whole ? 1 : (n / all) * 0.16, whole ? 0.75 : 0.25);
}
function wireRegister() {
  if (!document.getElementById('reg')) return;
  const login = document.getElementById('login'), loginH = document.getElementById('login-h');
  const pass = document.getElementById('pass'), passH = document.getElementById('pass-h'), email = document.getElementById('email'), go = document.getElementById('reg-go');
  const terms = document.getElementById('t-terms');
  const check = () => { const [n, all] = formDone(); go.disabled = n !== all; syncForm(); };
  login.addEventListener('input', () => {
    const ok = /^[A-Za-z0-9_]{3,16}$/.test(login.value);
    loginH.className = 'hint ' + (login.value && !ok ? 'bad' : '');
    loginH.textContent = '3–16: a–z, 0–9, _';
    check();
  });
  pass.addEventListener('input', () => {
    const ok = pass.value.length >= 10;
    passH.className = 'hint ' + (ok ? 'ok' : '');
    passH.textContent = !pass.value || ok ? '10+ characters' : `${10 - pass.value.length} more`;
    check();
  });
  [terms, email].forEach((el) => el.addEventListener('input', check));
}

''' + js[b:]
js = swap(js, '  wireCode();\n  wireRegister();\n', '  wireRegister();\n')

# ---------------------------------------------------------------- the shell: no preview switch, Rules in the foot
a = js.index('// --------------------------------------------------------------------------------- shell and routing')
b = js.index('function shell(inner) {')
js = js[:a] + '// --------------------------------------------------------------------------------- shell and routing\n' + js[b:]
js = swap(js, '  const at = screenAt();\n', '')
js = swap(js, '''`<a class="w small" href="#/signin">Sign in</a><a class="w small lead" href="#/register">${state.openReg ? 'Register' : 'I have an invite'}</a>`''',
          '''`<a class="w small" href="#/signin">Sign in</a><a class="w small lead" href="#/register">Register</a>`''')
js = swap(js, '<a href="#/docs/terms">Terms</a><a href="#/docs/privacy">Privacy</a></span></footer>', '<a href="#/docs/rules">Rules</a></span></footer>')
a = js.index('    <div class="pv"><button id="pv-toggle"')
b = js.index("</div>` : ''}</div>`;\n}", a)
js = js[:a] + js[b + len("</div>` : ''}</div>"):]
js = js.replace("</footer>\n`;\n}", "</footer>`;\n}")
for line in ["  on('#pv-toggle', 'click', () => { state.pvOpen = !state.pvOpen; render(true); });\n",
             "  on('[data-as]', 'click', (b) => { state.role = b.dataset.as; state.trial = false; render(true); });\n",
             "  on('[data-reg]', 'click', (b) => { state.openReg = b.dataset.reg === 'open'; render(true); });\n",
             "  on('[data-screen]', 'click', (a, e) => { e.preventDefault(); goScreen(Number(a.dataset.screen)); });\n"]:
    js = swap(js, line, '')
a = js.index("window.addEventListener('keydown', (e) => {")
b = js.index('render();', a)
js = js[:a] + js[b:]

# ---------------------------------------------------------------- the dashboard and moderation: no invitations
js = swap(js, ", ['Invited by', state.openReg ? '—' : m.invitedBy]", '')
js = swap(js, "['Invited by', '—'], ", '')
js = swap(js, "const t = ['invites', 'keys', 'registration', 'giveaways'].includes(tab) ? tab : 'reports';", "const t = ['keys', 'giveaways'].includes(tab) ? tab : 'reports';")
a = js.index('  const invites = `<div class="block"><p class="sentence">')
b = js.index('  const giveaways = `', a)
js = js[:a] + js[b:]
js = swap(js, '<option>an invite</option>', '')
js = swap(js, '''<a class="w ${t === 'invites' ? 'on' : ''}" href="#/admin/invites">Invitations</a>''', '')
js = swap(js, '''<a class="w ${t === 'registration' ? 'on' : ''}" href="#/admin/registration">Registration</a>''', '')
js = swap(js, '${{ reports, invites, keys, registration, giveaways }[t]}', '${{ reports, keys, giveaways }[t]}')
js = swap(js, "  ['Launch week', '15 Sep 2026', 'invite × 20', 'random subscribers', '30 Sep 2026', '11 of 20', 'Running'],\n", '')
js = swap(js, "  { what: 'An invite', from: 'Launch week', until: '30 Sep 2026', kind: 'invite', code: 'CRSD-T6WQ3MZK-8HVD2RXP-N4CY7FGJ' },\n", '')
a = js.index('const INVITES = [')
b = js.index('];\n', a) + 3
js = js[:a] + js[b:]
js = swap(js, "invitedBy: 'NeKiT' }", '}')
a = js.index('const REG_WINDOWS = [')
b = js.index('];\n', a) + 3
js = js[:a] + js[b:]

js = swap(js, ' Unused invites of NeKiT, who invited them, cancelled.', '')
js = swap(js, " invite: '',", '')
js = swap(js, "<b>${g.kind === 'invite' ? `<span class=\"mono cream\">${g.code}</span>` : g.what}</b>", '<b>${g.what}</b>')
js = swap(js, "${g.kind === 'invite' ? 'valid until' : 'claim by'} ${g.until}", 'claim by ${g.until}')
js = swap(js, "${g.kind === 'invite' ? `<button class=\"w small\" data-copy=\"${g.code}\">Copy</button>` : state.claimed ?", '${state.claimed ?')

# ---------------------------------------------------------------- the living pictures: made once, kept
# The living pictures live as long as the page (her bug of 26.09: a white flash on every click to Register, Sign in or
# Rules). A click used to lose the WebGL contexts of the screen it left and make new ones, compiling the shaders again
# on the spot: the page froze for 0.4 s (4 s the first time on the door) with the old canvases already emptied. Now a
# picture is made once and kept: a screen that comes back gets the same canvas (its context, its compiled program, its
# last frame) in place of the new empty one. Shaders compile in parallel where the browser can, so the page never waits
# on them; a canvas shows once its first frame is drawn; the door's eyes are compiled ahead while the first screen is up.
js = swap(js, '  const live = new Set();\n', '  const live = new Set();\n  const kept = new Map();      // the pictures made so far, by name: each lives as long as the page\n')
js = swap(js, '    for (const fx of live) if (fx.visible) fx.frame(t);\n', '    for (const fx of live) if (fx.visible && (fx.ready || fx.settle())) fx.frame(t);\n')
a = js.index('  // One full-frame fragment shader on one canvas. Draws only while the canvas is on screen.\n  function stage(')
b = js.index("  // ---- the eclipse: the main menu's sky")
js = js[:a] + '''  // One full-frame fragment shader on one canvas. Draws only while the canvas is on screen, and not before its program
  // is compiled: in parallel where the browser can (KHR_parallel_shader_compile), so nothing waits on it.
  function stage(canvas, fragId, names, maxDpr) {
    const gl = canvas.getContext('webgl2', { antialias: false, alpha: false, powerPreference: 'high-performance' });
    if (!gl) return null;
    const par = gl.getExtension('KHR_parallel_shader_compile');
    const program = gl.createProgram();
    const shaders = [[gl.VERTEX_SHADER, VERTEX], [gl.FRAGMENT_SHADER, document.getElementById(fragId).textContent.trim()]].map(([type, text]) => {
      const s = gl.createShader(type); gl.shaderSource(s, text); gl.compileShader(s); gl.attachShader(program, s); return s;
    });
    gl.linkProgram(program);
    const U = {};
    const fx = { gl, U, canvas, visible: true, ready: false, shown: false, dpr: 1, W: 1, H: 1, frame() {} };
    canvas.classList.add('gl');
    fx.settle = () => {
      if (fx.dead || (par && !gl.getProgramParameter(program, par.COMPLETION_STATUS_KHR))) return false;
      if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
        console.warn(fragId, shaders.map((s) => gl.getShaderInfoLog(s)).join(' ') + gl.getProgramInfoLog(program));
        fx.drop();
        return false;
      }
      gl.useProgram(program);
      gl.bindVertexArray(gl.createVertexArray());
      for (const n of names) U[n] = gl.getUniformLocation(program, n);
      return (fx.ready = true);
    };
    // Sized only while it is in the page (one put aside keeps its size and its last frame), and only when the size
    // really changes: setting it, even to the same, wipes the picture.
    fx.resize = () => {
      const r = canvas.getBoundingClientRect();
      if (!canvas.isConnected || !r.width || !r.height) return;
      fx.dpr = Math.min(window.devicePixelRatio || 1, maxDpr || 2);
      const w = Math.max(1, Math.round(r.width * fx.dpr)), h = Math.max(1, Math.round(r.height * fx.dpr));
      if (canvas.width !== w) canvas.width = w;
      if (canvas.height !== h) canvas.height = h;
      fx.W = w; fx.H = h;
    };
    new ResizeObserver(fx.resize).observe(canvas);
    new IntersectionObserver(([e]) => { fx.visible = e.isIntersecting; if (fx.visible && fx.onshow) fx.onshow(); wake(); }, { threshold: 0.05 }).observe(canvas);
    fx.draw = () => {
      gl.viewport(0, 0, fx.W, fx.H); gl.drawArrays(gl.TRIANGLES, 0, 3);
      if (!fx.shown) { fx.shown = true; requestAnimationFrame(() => { canvas.classList.add('lit'); if (fx.onlit) fx.onlit(); }); }
    };
    // Broken (the program did not build) or lost (the video card was reset): out of the kept pictures, the fallback
    // shows, and a lost one on screen is made anew once the card is back.
    fx.drop = () => { fx.dead = true; live.delete(fx); if (kept.get(fx.key) === fx) kept.delete(fx.key); canvas.classList.remove('gl', 'lit'); };
    canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); fx.drop(); });
    canvas.addEventListener('webglcontextrestored', () => { if (canvas.isConnected) render(true); });
    fx.resize();
    return fx;
  }

''' + js[b:]
js = swap(js, '''  const stopAll = () => { for (const fx of [...live]) fx.stop(); };
  return { eclipse, wordmark, eyes, stopAll };''', '''  // Where a screen has a picture's canvas, the kept one takes its place, or the picture is made on it the first time.
  function place(spot, key, make, opt) {
    if (!spot) return null;
    let fx = kept.get(key);
    if (fx) {
      const own = ['gl', 'lit'].filter((c) => fx.canvas.classList.contains(c));
      fx.canvas.className = spot.className; own.forEach((c) => fx.canvas.classList.add(c));
      fx.canvas.id = spot.id; fx.canvas.setAttribute('aria-hidden', 'true');
      spot.replaceWith(fx.canvas);
      fx.visible = true;
      fx.resize();
      if (fx.again) fx.again(opt || {});
      if (fx.ready) fx.frame(now());      // a fresh frame before the page shows, not the one it was left with
    } else {
      fx = make(spot);
      if (!fx) return null;
      fx.key = key; kept.set(key, fx);
    }
    live.add(fx); wake();
    return fx;
  }
  // Made ahead on a canvas not yet in the page, so its shader is compiled by the time its screen comes.
  function warm(key, make) {
    if (kept.has(key)) return;
    const fx = make(document.createElement('canvas'));
    if (fx) { fx.key = key; kept.set(key, fx); }
  }
  // Leaving a screen: its pictures stop drawing and keep all the rest.
  const pauseAll = () => live.clear();
  return { eclipse, wordmark, eyes, place, warm, pauseAll };''')
js = swap(js, '  FX.stopAll();\n', '  FX.pauseAll();\n')
# The title arrives with its first frame (not when it was made: the shader may still be compiling), and again every
# time the first screen comes back.
js = swap(js, 'const st = { burst: null, reveal: reduce ? null : { start: now(), tick: -1 },', 'const st = { burst: null, reveal: reduce ? null : { start: -1, tick: -1 },')
js = swap(js, '      let env = 0;\n      if (st.reveal) {', '      let env = 0;\n      if (st.reveal && st.reveal.start < 0) st.reveal.start = t;\n      if (st.reveal) {')
js = swap(js, '    fx.burst = startBurst;\n', '''    fx.burst = startBurst;
    fx.again = () => { if (reduce) return; st.reveal = { start: -1, tick: -1 }; st.burst = null; st.shake = [0, 0]; };
''')
# The same eyes on the next door go to how open that door wants them (at once, if they were never on screen).
js = swap(js, '    fx.blink = () => { st.blinkAt = now(); };\n', '''    fx.blink = () => { st.blinkAt = now(); };
    fx.again = (o) => {
      opt = o;
      if (fx.shown) fx.setOpen(opt.open || 0); else { st.open = st.from = st.to = opt.open || 0; }
      fx.onshow = opt.openOnShow ? () => { if (st.to < 1) setTimeout(() => fx.setOpen(1), 350); } : null;
    };
''')
a = js.index('// The living pictures of whichever screen is up.\nfunction light() {')
b = js.index('\nfunction wire() {', a)
js = js[:a] + '''// The living pictures of whichever screen is up (each made once and kept: see FX).
const DOOR_EYES = { open: 0, scale: 0.25, y: 0.5 };
const glitchBrand = (dur) => { document.querySelectorAll('.brand').forEach((b) => { b.classList.add('glitch'); setTimeout(() => b.classList.remove('glitch'), dur * 1000); }); };
const PICTURES = { eclipse: (c) => FX.eclipse(c), word: (c) => FX.wordmark(c, glitchBrand), 'door-eyes': (c, opt) => FX.eyes(c, opt || { ...DOOR_EYES }) };
function light() {
  const sky = FX.place(document.getElementById('fx-eclipse'), 'eclipse', PICTURES.eclipse);
  const word = FX.place(document.getElementById('fx-word'), 'word', PICTURES.word);
  // A first visit compiles the eclipse for a few seconds: the title waits for it, and arrives with it.
  if (sky && word && !sky.shown) sky.onlit = () => { if (word.again) word.again(); };
  const eyes = document.getElementById('fx-eyes');
  state.eyes = null;
  if (eyes) {
    const door = eyes.closest('.door');
    const opt = door ? { ...DOOR_EYES, open: eyes.dataset.open ? 1 : 0 } : { open: 0, openOnShow: true, scale: 0.40 };
    state.eyes = FX.place(eyes, door ? 'door-eyes' : 'eyes', (c) => (door ? PICTURES['door-eyes'](c, opt) : FX.eyes(c, opt)), opt);
    if (door && state.eyes && !opt.open) syncForm();
  }
  // The pictures of the other screens compile ahead (the eclipse takes some 3 s cold, the eyes 4), so a click to them
  // shows them at once; only once this screen's own run steadily (on a slow machine, after its quality has settled).
  if (!state.signedIn) setTimeout(() => { for (const key in PICTURES) FX.warm(key, PICTURES[key]); }, 300);
}
''' + js[b:]

# ---------------------------------------------------------------- the pictures follow the machine
# The pictures cost what the machine can give (27.09: a friend's computer lagged; on the RTX 4060 the eclipse takes
# 1 ms a frame at 1080p, a laptop's built-in graphics some 30–40 times that). At most 60 frames a second on any screen;
# each picture renders at its density × Q.q and is stretched to its place, Q.q stepping down while drawn frames come
# late and creeping back once they come on time (never past a step that was too much); a weak video card by name starts
# lower; no picture renders more pixels than its budget; the other screens' shaders compile while the page is idle.
js = swap(js, '''  function tick() {
    raf = 0;
    const t = now();
    for (const fx of live) if (fx.visible && (fx.ready || fx.settle())) fx.frame(t);
    if (live.size && !document.hidden) raf = requestAnimationFrame(tick);
  }''', '''  const FRAME = 1000 / 60;
  const Q = { q: 1, cap: 1, named: false, last: 0, acc: 0, drawn: -1, ema: FRAME, frames: 0, late: 0, hold: 0, then: null };
  function quality(q) {
    q = Math.max(0.4, Math.min(Q.cap, q));
    if (Math.abs(q - Q.q) < 0.01) return;
    Q.q = q; Q.frames = 0; Q.late = 0; Q.ema = FRAME;
    for (const fx of kept.values()) fx.resize();
  }
  // How late the drawn frames come: 20 late ones in a row and the pictures get coarser; four seconds on time and
  // finer again, up to just under the step that was too much.
  function pace(ms) {
    const gap = Q.drawn >= 0 ? ms - Q.drawn : -1;
    Q.drawn = ms;
    if (gap < 0 || gap > 250) return;                 // the first frame, a hidden tab, a stall: not the video card
    if (ms < Q.hold) { Q.frames = 0; Q.late = 0; return; }
    Q.ema += (gap - Q.ema) * 0.1;
    Q.late = Q.ema > 24 ? Q.late + 1 : 0;
    if (++Q.frames < 45) return;
    if (Q.late > 20) { Q.cap = Math.min(Q.cap, Q.q); quality(Q.q * 0.82); }
    else if (Q.frames > 240 && Q.ema < 18.5 && Q.q < Q.cap * 0.92) quality(Math.min(Q.cap * 0.92, Q.q * 1.08));
    else if (Q.then && Q.frames > 240 && !Q.late) { const f = Q.then; Q.then = null; (window.requestIdleCallback || setTimeout)(f); }
  }
  // Something to do once the frames have come on time for four seconds (the machine has shown what it can).
  const steady = (f) => { Q.then = f; };
  function tick(ms) {
    raf = 0;
    if (live.size && !document.hidden) raf = requestAnimationFrame(tick);
    const gap = Q.last ? Math.min(ms - Q.last, 100) : FRAME;
    Q.last = ms;
    Q.acc += gap;
    if (Q.acc < FRAME - 1) return;                    // a faster screen: this refresh goes by
    Q.acc = Math.max(0, Math.min(Q.acc - FRAME, FRAME));
    const t = now();
    let drew = false;
    for (const fx of live) if (fx.visible && (fx.ready || fx.settle())) { fx.frame(t); drew = true; }
    if (drew) pace(ms); else Q.drawn = -1;
  }''')
js = swap(js, '  function stage(canvas, fragId, names, maxDpr) {\n', '  function stage(canvas, fragId, names, maxDpr, budget) {\n')
js = swap(js, '''    const par = gl.getExtension('KHR_parallel_shader_compile');\n''', '''    const par = gl.getExtension('KHR_parallel_shader_compile');
    if (!Q.named) {
      Q.named = true;
      const info = gl.getExtension('WEBGL_debug_renderer_info');
      const card = info ? String(gl.getParameter(info.UNMASKED_RENDERER_WEBGL)) : '';
      if (/Intel(?!.*Arc)|Mali|Adreno|PowerVR|SwiftShader|llvmpipe|Basic Render/i.test(card)) Q.q = 0.6;
    }
''')
js = swap(js, '''      fx.dpr = Math.min(window.devicePixelRatio || 1, maxDpr || 2);
      const w = Math.max(1, Math.round(r.width * fx.dpr)), h = Math.max(1, Math.round(r.height * fx.dpr));''', '''      let d = Math.min(window.devicePixelRatio || 1, maxDpr || 2) * Q.q;
      const most = (budget || 2.5e6) / (r.width * r.height);
      if (d * d > most) d = Math.sqrt(most);
      fx.dpr = d;
      const w = Math.max(1, Math.round(r.width * d)), h = Math.max(1, Math.round(r.height * d));''')
js = swap(js, "stage(canvas, 'frag-eclipse', ['uRes', 'uTime', 'uDpr', 'uBurst', 'uSeed', 'uReveal'], 1.5);", "stage(canvas, 'frag-eclipse', ['uRes', 'uTime', 'uDpr', 'uBurst', 'uSeed', 'uReveal'], 1, 3.7e6);")
js = swap(js, "stage(canvas, 'frag-glitch', names, 2);", "stage(canvas, 'frag-glitch', names, 2, 1.2e6);")
js = swap(js, "stage(canvas, 'frag-eyes', names, 2);", "stage(canvas, 'frag-eyes', names, 2, 2.2e6);")
# Compiling ahead loads the machine for a few seconds: meanwhile late frames don't count against the quality.
js = swap(js, '''    const fx = make(document.createElement('canvas'));
    if (fx) { fx.key = key; kept.set(key, fx); }''', '''    Q.hold = performance.now() + 6000;
    const fx = make(document.createElement('canvas'));
    if (fx) { fx.key = key; kept.set(key, fx); }''')
js = swap(js, "  if (!state.signedIn) setTimeout(() => { for (const key in PICTURES) FX.warm(key, PICTURES[key]); }, 300);",
          "  if (!state.signedIn) FX.steady(() => { for (const key in PICTURES) FX.warm(key, PICTURES[key]); });")
js = swap(js, "  return { eclipse, wordmark, eyes, place, warm, pauseAll };", "  return { eclipse, wordmark, eyes, place, warm, pauseAll, steady, Q };")

# ---------------------------------------------------------------- the accounts: real, through /api
# The accounts are real (27.09): registration, sign-in, sign-out and a new password go to cursed-api behind /api
# (site/server). Kept of a person: login, UID, e-mail, the password's hash, the day of registration. While registration
# is closed, https://cursedclient.xyz/#/register/<key> registers with a one-time key.
js = swap(js, "const me = () => ME[state.role] || ME.member;", "const me = () => (state.user ? { name: state.user.login, uid: state.user.uid } : ME[state.role] || ME.member);")
js = swap(js, '''        <div class="acts" style="margin-top:8px"><button class="w menu lead" id="reg-go" type="submit" disabled>Create account</button><a class="w" href="#/signin">Sign in</a></div>
      </form>''', '''        <div class="acts" style="margin-top:8px"><button class="w menu lead" id="reg-go" type="submit" disabled>Create account</button><a class="w" href="#/signin">Sign in</a></div>
        <p class="hint" id="reg-msg" role="status"></p>
      </form>''')
js = swap(js, '''        <div class="acts" style="margin-top:8px"><button class="w menu lead" type="submit">Sign in</button><a class="w" href="#/signin">I forgot it</a></div>
      </form>''', '''        <div class="acts" style="margin-top:8px"><button class="w menu lead" type="submit">Sign in</button><a class="w" href="#/signin">I forgot it</a></div>
        <p class="hint" id="signin-msg" role="status"></p>
      </form>''')
# The account block: what the server keeps, the e-mail half hidden (a dashboard ends up on streams); a new password
# and signing out work, the rest of the account's buttons come with e-mail codes.
js = swap(js, '''        <div class="block"><h2 class="sec">Account</h2>${kv([['Login', 'Lunuca'], ['E-mail', 'lu••••@••••.com'], ['News by e-mail', '<span class="st off">off</span>']])}
          <div class="acts"><button class="w small">Change password</button><button class="w small">Change e-mail</button><button class="w small bad">Delete the account</button></div></div>''',
          '''        <div class="block"><h2 class="sec">Account</h2>${kv(account())}
          <div class="acts"><button class="w small ${state.pwOpen ? 'on' : ''}" id="pw-open">Change password</button><button class="w small" id="signout">Sign out</button></div>${state.pwOpen ? pwForm() : ''}</div>''')
js = swap(js, "<span class=\"gap\"></span>${link('admin', 'Moderation', 'admin/reports')}</nav>`;",
          "${state.user && state.user.admin ? `<span class=\"gap\"></span>${link('admin', 'Moderation', 'admin/reports')}` : ''}</nav>`;")
js = swap(js, "const kv = (rows) =>", '''// ---- the accounts: cursed-api behind /api ----------------------------------------------------------------------
const when = (s) => new Date(s * 1000).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
const masked = (e) => { const [l, d] = String(e || '').split('@'); return l && d ? l.slice(0, 2) + '••••@' + d : '—'; };
const account = () => { const u = state.user; return u ? [['Login', `<span translate="no">${esc(u.login)}</span>`], ['UID', `<span class="num">${u.uid}</span>`], ['E-mail', `<span translate="no">${esc(masked(u.email))}</span>`], ['Member since', when(u.since)]] : [['Login', '—']]; };
const pwForm = () => `<form class="form" id="pw" style="margin-top:24px;max-width:420px">
          <div><label class="lab" for="pw-cur">Current password</label><input class="in" id="pw-cur" type="password" autocomplete="current-password"></div>
          <div><label class="lab" for="pw-new">New password</label><input class="in" id="pw-new" type="password" autocomplete="new-password"><p class="hint">10+ characters. Every other device gets signed out.</p></div>
          <div class="acts"><button class="w lead" type="submit">Save</button></div><p class="hint" id="pw-msg" role="status"></p></form>`;
const SAY = {
  login: 'Login: 3–16 of a–z, 0–9 and _.', email: 'That e-mail doesn’t look right.', password: 'Password: 10 characters or more.',
  'login-taken': 'That login is taken.', 'email-taken': 'That e-mail already has an account.', closed: 'Registration is closed.',
  wrong: 'Wrong login or password.', wait: 'Too many wrong tries. Wait a quarter of an hour.', slow: 'Too many tries. Wait a minute.',
  offline: 'No connection. Try again.', busy: 'Something went wrong. Try again.', 'signed-out': 'You were signed out. Sign in again.',
};
// One call to the server. Its answers are JSON; nginx's own page (too many tries) is not, and counts as "slow".
async function api(path, body) {
  let r;
  try {
    r = await fetch('/api/' + path, body === undefined ? { credentials: 'same-origin', cache: 'no-store' }
      : { method: 'POST', credentials: 'same-origin', cache: 'no-store', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  } catch (e) { return { ok: false, error: 'offline' }; }
  let data = {};
  try { data = await r.json(); } catch (e) { /* not JSON */ }
  return r.ok ? { ok: true, data } : { ok: false, status: r.status, error: data.error || (r.status === 429 ? 'slow' : 'busy') };
}
// Whether this browser was signed in last time (the session cookie itself can't be read here): if it was, the first
// screen waits for the server's answer, so a member never sees the guest's page first.
const hinted = () => { try { return localStorage.getItem('cursed.in') === '1'; } catch (e) { return false; } };
const hint = (on) => { try { if (on) localStorage.setItem('cursed.in', '1'); else localStorage.removeItem('cursed.in'); } catch (e) { /* not kept */ } };
function signIn(u) { state.user = u; state.role = 'member'; hint(true); }
function signOut() { state.user = null; state.role = 'guest'; state.pwOpen = false; hint(false); }
// The door's forms: register, or sign in; on a wrong answer the eyes blink and say why.
async function enter(f) {
  const reg = f.id === 'reg', go = f.querySelector('button[type="submit"]'), msg = document.getElementById(reg ? 'reg-msg' : 'signin-msg');
  const val = (id) => document.getElementById(id).value;
  go.disabled = true; msg.textContent = ''; msg.className = 'hint';
  const r = reg ? await api('register', { login: val('login').trim(), email: val('email').trim(), password: val('pass'), key: state.route === 'register' ? state.arg : '' })
    : await api('login', { login: val('s-login').trim(), password: val('s-pass') });
  if (!r.ok) {
    go.disabled = false;
    msg.textContent = SAY[r.error] || SAY.busy; msg.className = 'hint bad';
    if (state.eyes) state.eyes.blink();
    return;
  }
  const who = await api('me');
  signIn(who.ok ? who.data : r.data);
  const target = '#/' + (reg || !state.back ? 'dashboard/overview' : state.back);
  state.back = '';
  if (location.hash === target) render(); else location.hash = target;
}
async function newPassword(f) {
  const msg = document.getElementById('pw-msg'), go = f.querySelector('button[type="submit"]');
  go.disabled = true; msg.textContent = ''; msg.className = 'hint';
  const r = await api('password', { current: document.getElementById('pw-cur').value, new: document.getElementById('pw-new').value });
  go.disabled = false;
  if (r.ok) {
    state.pwOpen = false;
    const open = document.getElementById('pw-open'); if (open) open.classList.remove('on');
    f.outerHTML = '<p class="hint ok" style="margin-top:24px">Password changed. Every other device is signed out.</p>';
    return;
  }
  if (r.error === 'signed-out') { signOut(); location.hash = '#/signin'; return; }
  msg.textContent = r.error === 'wrong' ? 'The current password is wrong.' : SAY[r.error] || SAY.busy; msg.className = 'hint bad';
}
const kv = (rows) =>''')
js = swap(js, '''  on('form', 'submit', (f, e) => {
    e.preventDefault();
    state.role = f.id === 'reg' ? 'new' : 'member';
    const target = '#/' + (f.id === 'reg' || !state.back ? 'dashboard/overview' : state.back);
    state.back = '';
    if (location.hash === target) render(); else location.hash = target;
  });''', '''  on('form#reg, form#signin', 'submit', (f, e) => { e.preventDefault(); enter(f); });
  on('form#pw', 'submit', (f, e) => { e.preventDefault(); newPassword(f); });
  on('#pw-open', 'click', () => { state.pwOpen = !state.pwOpen; render(true); });
  on('#signout', 'click', async () => { await api('logout', {}); signOut(); location.hash = '#/home'; });''')
# Moderation is hers alone (UID 1); anyone else there goes to their dashboard.
js = swap(js, "  state.jump = false;\n", "  state.jump = false;\n  if (route === 'admin' && state.signedIn && !(state.user && state.user.admin)) { location.hash = '#/dashboard/overview'; return; }\n")
js = js.rstrip()
assert js.endswith("window.addEventListener('hashchange', () => render());\nrender();"), repr(js[-60:])
js = js[:-len('render();')] + '''(async () => {
  const first = hinted();
  if (!first) render();
  const r = await api('me');
  if (r.ok) signIn(r.data); else if (r.error !== 'offline') signOut();
  if (first || r.ok) render(true);
})();
'''

# ---------------------------------------------------------------- a free client: nothing of the paid idea
# The client is free (her word of 27.09): everything of the paid idea goes — prices and checkout, subscriptions, keys,
# the free day, deleting accounts that never paid, giveaways of days, "posting after the first payment", the binding
# to a computer. The market and the forum: to look and to write, an account; every account can do everything but
# moderate (hers, UID 0).
a = js.index('// Plans. `was` is the regular price')
b = js.index('// Who the preview can be.')
js = js[:a] + js[b:]
js, n = re.subn(r"// Who the preview can be\.[^\n]*\nconst ME = \{[^\n]*\n", "// Who the header shows when nobody is signed in (it never is: the members' pages need an account).\nconst ME = { member: { name: 'Lunuca', uid: 0 } };\n", js)
assert n == 1, n
a = js.index('const GIVEAWAYS = [')
b = js.index('];\n', js.index('const GIFTS = [', a)) + 3
js = js[:a] + js[b:]
a = js.index("  { kind: 'Chargeback',")
b = js.index("  { kind: 'Flagged by the server'", a)
js = js[:a] + js[b:]
js = swap(js, ' trial: false, claimed: false,', '')

a = js.index('// What each screen asks of whoever opens it:')
b = js.index("const paid = () => state.role === 'member';\n") + len("const paid = () => state.role === 'member';\n")
js = js[:a] + '''// What each screen asks of whoever opens it: nothing, or an account. Moderation is hers alone (see render).
const MEMBERS_ONLY = new Set(['market', 'pack', 'look', 'author', 'forum', 'dashboard', 'upload', 'admin']);
const need = (route) => (MEMBERS_ONLY.has(route) ? 'member' : 'guest');
const RANK = { guest: 0, member: 1 };
const me = () => (state.user ? { name: state.user.login, uid: state.user.uid } : ME.member);
''' + js[b:]
js = swap(js, "\n    else { location.hash = '#/dashboard/subscription'; return; }", '')

js = swap(js, '''<a class="w menu lead" href="${paid() ? href(it) : '#/dashboard/subscription'}">Use it</a><a class="w menu" href="${paid() ? href(it) : '#/dashboard/subscription'}">Try on</a></div>
        <p class="hint">${paid() ? 'Opens in Cursed. Try-on reverts when you leave.' : 'Needs a subscription.'}</p>''',
          '''<a class="w menu lead" href="${href(it)}">Use it</a><a class="w menu" href="${href(it)}">Try on</a></div>
        <p class="hint">Opens in Cursed. Try-on reverts when you leave.</p>''')

a = js.index("  if (!paid()) return `<nav class=\"rail\"")
js = js[:a] + js[js.index('\n', a) + 1:]
js = swap(js, "${link('overview', 'Overview')}${link('subscription', 'Subscription')}${link('packs', 'My packs')}", "${link('overview', 'Overview')}${link('packs', 'My packs')}")

a = js.index('// Somebody who registered and never paid')
b = js.index('function dashOverview() {')
js = js[:a] + js[b:]
a = js.index('  if (!paid()) return `<h1 class="sr">Overview</h1>')
b = js.index('  const worn = ', a)
js = js[:a] + js[b:]
# Where "This computer" was, what the account wears: the two side by side.
a = js.index('        <div class="block"><h2 class="sec">This computer</h2>')
b = js.index('      </div>\n      <div class="block"><h2 class="sec">In use</h2>', a)
c = js.index('<p class="hint">Follows your account.</p></div>\n', b) + len('<p class="hint">Follows your account.</p></div>\n')
inuse = js[b + len('      </div>\n'):c]
js = js[:a] + inuse.replace('      <div class="block">', '        <div class="block">', 1) + '      </div>\n' + js[c:]
js = swap(js, 'const body = { overview: dashOverview, subscription: dashSubscription, packs: dashPacks,', 'const body = { overview: dashOverview, packs: dashPacks,')

a = js.index('const rub = (n) =>')
a = js.rindex('\n// ', 0, a) + 1
b = js.index('// ---', js.index('function dashSubscription()'))
js = js[:a] + js[b:]

js = swap(js, '''${paid() ? '<button class="w lead">New thread</button>' : '<span class="st off">Posting opens with your first subscription</span>'}''', '<button class="w lead">New thread</button>')

js = swap(js, "  const t = ['keys', 'giveaways'].includes(tab) ? tab : 'reports';\n", "  const t = 'reports';\n")
a = js.index("  const tone = { Used: 'off', Activated: 'off'")
js = js[:a] + js[js.index('\n', js.index('  const date = (id, value, label)', a)) + 1:]
a = js.index('  const giveaways = `<div class="block">')
b = js.index("  return `<div class=\"dash\">${rail('admin')}", a)
js = js[:a] + js[b:]
js = swap(js, '''<a class="w ${t === 'keys' ? 'on' : ''}" href="#/admin/keys">Keys</a><a class="w ${t === 'giveaways' ? 'on' : ''}" href="#/admin/giveaways">Giveaways</a>''', '')
js = swap(js, '${{ reports, keys, giveaways }[t]}', '${reports}')

js = swap(js, " + nav('pricing', 'Pricing')", '')
js = swap(js, '<a href="#/pricing">Pricing</a>', '')
js = swap(js, ', pricing: viewPricing, checkout: viewCheckout };', ' };')
for handler in ["  on('#trial', 'click', () => { state.trial = true; render(true); });\n",
                "  on('#claim', 'click', () => { state.claimed = true; render(true); });\n",
                "  on('[data-method]', 'click', (b) => { state.method = b.dataset.method; render(true); });\n"]:
    js = swap(js, handler, '')
style, n = re.subn(r'\n\s*\.plans?[\s.:][^{]*\{[^}]*\}', '', style)
assert n >= 10, n
style = re.sub(r'\n@media[^{]*\{\s*\}', '', style)  # the narrow-screen rules of the plans, left empty

# ---------------------------------------------------------------- the market: real, through /api
# The market is real (27.09): its screens ask cursed-api (site/server, README "The market") and nothing made up is
# left in them. Replaced whole: the cards, the shop window, a pack's page (and its editor), uploading, my packs, an
# author's page, moderation, the dashboard's rail and the events. Gone with the made-up data: looks, access codes,
# statistics, the preview's pictures.


def between(js, start, end):
    a = js.index(start)
    b = js.index(end, a + len(start))
    return a, b


def replace_span(js, start, end, new):
    a, b = between(js, start, end)
    return js[:a] + new + js[b:]


# The made-up data (and its pictures) out; the words the market uses in.
js = replace_span(js, 'const IMG = {', 'const FORUM = [', r'''// The words of the market: what a pack can change (as the server reads it), resolutions, versions.
const RES = ['16x', '32x', '64x', '128x+'];
const CHANGE_NAMES = {
  blocks: 'Blocks', items: 'Items', gui: 'Interface', sounds: 'Sounds', fonts: 'Fonts', ctm: 'Connected textures', emissive: 'Emissive textures',
  entities: 'Mobs', armor: 'Armour', sky: 'Sky', particles: 'Particles', models: 'Models', cem: 'Entity models', cit: 'Custom items',
  animated: 'Animations', languages: 'Languages', texts: 'Texts', shaders: 'Core shaders', effects: 'Effect icons', paintings: 'Paintings',
  maps: 'Maps', colours: 'Colours',
};
const MAIN_CHANGES = ['blocks', 'items', 'gui', 'sounds', 'fonts', 'ctm', 'emissive', 'entities'];

''')
js = swap(js, "const item = (id) => ITEMS.find((it) => it.id === id);\n", '')
js = swap(js, "const href = (it) => `#/${it.type === 'look' ? 'look' : 'pack'}/${it.id}`;\n", '')
js = swap(js, "const pic = (name, small) => IMG[name + (small ? '-s' : '')] || IMG[name] || '';\n", '')
js = swap(js, "const kind = (it) => (it.type === 'pack' ? it.res : typeName[it.type]);\n", '')

# ---- the cards and the shop window
js = replace_span(js, 'function card(it) {', '// ------------------------------------------------------------------------------------------------ home', r'''// ---- asking the server: what it said, by what was asked; asked again after 20 s. A screen shows what it has and
// asks for the rest; the answer draws the screen again if it is still up.
const got = new Map();
function ask(path) {
  let c = got.get(path);
  if (!c || (!c.pending && performance.now() - c.at > 20000)) {
    const route = location.hash;
    const pending = api(path).then((r) => {
      got.set(path, { at: performance.now(), ok: r.ok, data: r.data, error: r.error, status: r.status });
      if (location.hash === route) render(true);
    });
    c = { ...(c || {}), pending };
    got.set(path, c);
  }
  return c;
}
const forget = (...prefixes) => { for (const k of [...got.keys()]) if (prefixes.some((p) => k.startsWith(p))) got.delete(k); };
const waiting = (c) => c.data === undefined && !c.error;

const mb = (n) => (n >= 1e6 ? (n / 1e6).toFixed(n >= 1e7 ? 0 : 1) + ' MB' : Math.max(1, Math.round((n || 0) / 1e3)) + ' KB');
const ago = (s) => {
  const d = Math.max(0, Date.now() / 1000 - s);
  if (d < 3600) return Math.max(1, Math.round(d / 60)) + ' min ago';
  if (d < 86400) return Math.round(d / 3600) + ' h ago';
  if (d < 86400 * 30) return Math.round(d / 86400) + ' d ago';
  return new Date(s * 1000).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
};
const users = (n) => `${fmt(n)} ${n === 1 ? 'user' : 'users'}`;
const packHref = (p) => `#/pack/${p.slug}`;
const packKind = (p) => (p.kind === 'shaderpack' ? 'Shader' : (p.tags && p.tags.resolution) || 'Resource pack');
const versionsShort = (v) => (/newer than/.test(v) ? 'newer versions' : v);

// A pack's picture: its cover, else its own icon (pack.png, kept pixel-sharp), else its first letter.
function cover(p, big) {
  if (p.cover) return `<img src="${big ? p.cover.big : p.cover.small}" alt="" loading="lazy">`;
  return `<span class="tile">${p.icon ? `<img src="${p.icon}" alt="">` : `<b>${esc(p.title.slice(0, 1))}</b>`}</span>`;
}
function card(p) {
  const g = p.kind === 'resourcepack' && p.tags && p.tags.game;
  const other = g && g.fits === false ? `<span class="ash">${g.versions ? 'for ' + esc(versionsShort(g.versions)) : 'another version'}</span>` : '';
  return `<a class="card" href="${packHref(p)}">${cover(p)}
    <div class="body"><div class="t">${esc(p.title)}</div>
    <div class="m"><span class="k">${packKind(p)}</span><span>${esc(p.author.login)}</span><span class="num">${users(p.users)}</span>${other}</div></div></a>`;
}
const ghosts = (n) => `<div class="grid">${'<div class="card ghost"><span class="tile"></span><div class="body"><div class="t">&nbsp;</div><div class="m">&nbsp;</div></div></div>'.repeat(n)}</div>`;
const trouble = (c) => `<div class="empty">${c.status === 404 ? 'Not found.' : SAY[c.error] || SAY.busy}</div>`;

''')

# The home page's market: the three packs members take most this week.
js = swap(js, "  const three = ['ashfall', 'moonwake', 'glass-harbor'].map(item).map(card).join('');\n",
          "  const top = state.signedIn ? ask('market') : null, three = top && top.ok ? top.data.items.slice(0, 3) : [];\n")
js = swap(js, '''    ${state.signedIn ? `<section class="market-scene">''', '''    ${three.length ? `<section class="market-scene">''')
js = swap(js, '''      <div class="islands">${three}</div>''', '''      <div class="islands">${three.map(card).join('')}</div>''')

js = replace_span(js, 'function marketList() {', '// ------------------------------------------------------------------------------------------- pack page', r'''// The shop window: kinds, resolutions, only-for-this-game, words, order, pages. The first pack of the plain view
// (nothing chosen, nothing searched) is shown big.
function viewMarket() {
  const s = state.m;
  const qs = new URLSearchParams();
  if (s.kind) qs.set('kind', s.kind);
  if (s.res && s.kind !== 'shaderpack') qs.set('res', s.res);
  if (s.fits) qs.set('fits', '1');
  if (s.sort !== 'trending') qs.set('sort', s.sort);
  if (state.qLive) qs.set('q', state.qLive);
  if (s.page > 1) qs.set('page', s.page);
  const c = ask('market' + (qs.toString() ? '?' + qs : ''));
  const tab = (id, name) => `<button class="w ${s.kind === id ? 'on' : ''}" data-kind="${id}">${name}</button>`;
  let body;
  if (waiting(c)) body = ghosts(6);
  else if (!c.ok) body = trouble(c);
  else {
    const { items, total, per_page: per } = c.data;
    const plain = !s.kind && !s.res && !s.fits && !state.qLive && s.sort === 'trending' && s.page === 1;
    const first = plain && items[0] && items[0].cover ? items[0] : null, rest = first ? items.slice(1) : items;
    const pages = Math.ceil(total / per);
    body = (first ? `<a class="feature" href="${packHref(first)}">${cover(first, true)}
          <div class="say"><span class="st cream">${first.users ? 'Most taken this week' : 'Newest'}</span><h2 class="big">${esc(first.title)}</h2>${first.blurb ? `<p class="lede">${esc(first.blurb)}</p>` : ''}
          <div class="card"><div class="m" style="margin:0"><span class="k">${packKind(first)}</span><span translate="no">${esc(first.author.login)}</span><span class="num">${users(first.users)}</span></div></div></div></a>` : '')
      + (rest.length ? `<div class="grid">${rest.map(card).join('')}</div>` : first ? ''
        : `<div class="empty">${plain ? 'Nothing here yet.' : 'Nothing found.'}<a class="w small" href="#/upload" style="margin-left:18px">Upload a pack</a></div>`)
      + (pages > 1 ? `<div class="acts pager">${s.page > 1 ? `<button class="w" data-page="${s.page - 1}">Back</button>` : ''}<span class="ash num">${s.page} of ${pages}</span>${s.page < pages ? `<button class="w" data-page="${s.page + 1}">More</button>` : ''}</div>` : '');
  }
  return `<h1 class="sr">Market</h1>
    <div class="tabs" role="tablist">${tab('', 'Everything')}${tab('resourcepack', 'Resource packs')}${tab('shaderpack', 'Shaders')}
      <span class="right">${s.kind !== 'shaderpack' ? RES.map((r) => `<button class="${s.res === r ? 'on' : ''}" data-res="${r}">${r}</button>`).join('') : ''}<button class="${s.fits ? 'on' : ''}" data-fits="1">For ${GAME}</button></span></div>
    <div class="market"><div>
      <div class="tools">
        <div style="flex:1"><label class="sr" for="q">Search</label><input class="in" id="q" type="search" placeholder="Search" value="${esc(state.q)}"></div>
        <div style="flex:none;width:200px"><label class="sr" for="sort">Order</label><select class="in" id="sort">
          ${[['trending', 'Trending'], ['users', 'Most used'], ['new', 'Newest'], ['updated', 'Recently updated'], ['name', 'By name']].map(([v, n]) => `<option value="${v}" ${s.sort === v ? 'selected' : ''}>${n}</option>`).join('')}</select></div>
        <a class="w lead" href="#/upload" style="flex:none">Upload</a>
      </div>
      ${body}
    </div></div>`;
}

''')

# ---- a pack's page, and its editor
js = replace_span(js, 'function shotsOf(it) {', 'function viewLook(id) {', r'''// A pack's page: its pictures, what it is and changes (read from its files), its versions, the archive's numbers.
// Its author edits it or adds a version; she can hide it (the author is told why).
function viewPack(arg) {
  const [slug, sub] = String(arg || '').split('/');
  if (sub === 'edit') return viewEdit(slug);
  const c = ask('packs/' + encodeURIComponent(slug));
  if (waiting(c)) return `<section class="pk"><div class="say"><div class="crumb"><a href="#/market">Market</a></div><h1 class="giant ghost-t">&nbsp;</h1></div><div class="stage"><span class="tile big ghost"></span></div></section>`;
  if (!c.ok) return `<div class="page-head"><h1 class="giant">Not found</h1><p class="ash">This pack is gone, private, or never was.</p><div><a class="w" href="#/market">Back to the market</a></div></div>`;
  const p = c.data, f = p.facts || {}, shader = p.kind === 'shaderpack', g = f.game || {};
  const shots = p.pictures, n = Math.min(state.shot, Math.max(shots.length - 1, 0));
  const stage = shots.length
    ? `<img src="${shots[n].big}" alt="">${shots[n].caption ? `<p class="cap">${esc(shots[n].caption)}</p>` : ''}
      ${shots.length > 1 ? `<div class="thumbs">${shots.map((s, i) => `<button class="${i === n ? 'on' : ''}" data-shot="${i}" aria-label="Picture ${i + 1}"><img src="${s.small}" alt=""></button>`).join('')}</div>` : ''}`
    : `<span class="tile big">${p.icon ? `<img src="${p.icon}" alt="">` : ''}</span>`;
  const status = p.state === 'hidden' ? `<span class="st cream">Hidden by moderation${p.hidden_why ? ': ' + esc(p.hidden_why) : ''}</span>`
    : p.state === 'draft' ? '<span class="st warn">Draft: only you see it</span>' : p.visibility === 'private' ? '<span class="st warn">Private</span>' : '';
  const hiding = state.hiding === p.slug;
  const mod = p.moderator && !p.mine ? (p.state === 'hidden' ? `<button class="w menu" data-unhide="${p.slug}">Unhide</button>` : hiding ? '' : `<button class="w menu" data-hide="${p.slug}">Hide</button>`) : '';
  const present = new Set(f.changes || []);
  const changes = shader
    ? `<ul class="changes">${(f.features || []).map((x) => `<li class="y">${esc(x)}</li>`).join('') || '<li>Nothing it names</li>'}</ul>`
    : `<ul class="changes">${[...MAIN_CHANGES, ...[...present].filter((x) => !MAIN_CHANGES.includes(x))].map((x) => `<li class="${present.has(x) ? 'y' : ''}">${CHANGE_NAMES[x] || esc(x)}</li>`).join('')}</ul>`;
  const rows = [['Files', `<span class="num">${fmt(f.files || 0)}</span>`], ['Unpacked', mb(f.unpacked)], ['Download', mb(p.size)]];
  if (shader) rows.push(['Programs', `<span class="num">${f.programs || 0}</span>`], ['Options', `<span class="num">${f.options || 0}</span>`],
    ['Worlds', (f.dimensions || []).join(', ') || '—'], ['Profiles', `<span translate="no">${esc((f.profiles || []).join(', ')) || '—'}</span>`], ['Languages', `<span translate="no">${esc((f.languages || []).join(', ')) || '—'}</span>`]);
  else rows.push(['Resolution', f.resolution || '—'], ['Textures', `<span class="num">${fmt(f.textures || 0)}</span>`], ['Sounds', `<span class="num">${f.sounds || 0}</span>`],
    ['Game', g.versions ? `${esc(g.versions)}${g.fits ? '' : ' <span class="ash">(not ' + GAME + ')</span>'}` : '<span class="ash">unreadable</span>']);
  return `<section class="pk">
      <div class="say">
        <div class="crumb"><a href="#/market">Market</a> / ${shader ? 'Shaders' : 'Resource packs'}</div>
        <h1 class="giant ${p.title.length > 22 ? 'long' : ''}">${esc(p.title)}</h1>
        <div class="by"><a href="#/author/${encodeURIComponent(p.author.login)}" translate="no">${head(p.author.login, 24)} ${esc(p.author.login)}</a><span class="cream">${packKind(p)}</span>${!shader && g.fits === false ? `<span class="st warn">${g.versions ? 'made for ' + esc(versionsShort(g.versions)) : 'another version'}</span>` : ''}${status}</div>
        <p class="facts num">${users(p.users)} · v${esc(p.version || '—')}, ${ago(p.released || p.updated)} · ${mb(p.size)}</p>
        ${p.blurb ? `<p class="lede">${esc(p.blurb)}</p>` : ''}
        <div class="acts" style="margin-top:10px"><a class="w menu lead" href="/api/packs/${p.slug}/download" download>Download</a>${mod}</div>
        ${p.mine ? `<div class="acts own"><a class="w small" href="#/pack/${p.slug}/edit">Edit</a><a class="w small" href="#/upload/${p.slug}">New version</a></div>` : ''}
        ${hiding ? `<div class="form hide-form"><input class="in" id="hide-why" maxlength="200" placeholder="Why (its author sees this)"><div class="acts"><button class="w small lead" data-hide-go="${p.slug}">Hide it</button><button class="w small" data-hide-no="1">Keep it</button></div></div>` : ''}
        <p class="hint">${shader ? 'A shader pack: it goes in shaderpacks.' : 'A resource pack: it goes in resourcepacks.'}</p>
      </div>
      <div class="stage">${stage}</div>
    </section>
    <div class="cols">
      <div class="stack">
        ${p.about ? `<div class="block prose"><h2 class="sec">About</h2><div>${p.about.split(/\n{2,}/).map((t) => `<p>${esc(t).replace(/\n/g, '<br>')}</p>`).join('')}</div></div>` : ''}
        <div class="block"><h2 class="sec">Versions</h2><div class="rows ver">${p.versions.map((v) => `<div><a class="v" href="/api/packs/${p.slug}/download?v=${encodeURIComponent(v.number)}" download title="Download ${esc(v.number)}">${esc(v.number)}</a><span>${esc(v.changelog) || '<span class="ash">—</span>'}</span><span class="d">${ago(v.created)}</span></div>`).join('')}</div></div>
        ${p.mine ? checkNotes(f) : ''}
      </div>
      <div class="stack">
        <div class="block"><h2 class="sec">${shader ? 'What it does' : 'What it changes'}</h2>${changes}<p class="hint">Read from its files.</p></div>
        <div class="block"><h2 class="sec">In the archive</h2>${kv(rows)}</div>
      </div>
    </div>`;
}

// What the check did to its latest version, for its author: fixed, left out, worth knowing.
function checkNotes(f) {
  const fixed = f.fixed || [], dropped = Object.entries(f.dropped || {}), warn = f.warnings || [];
  if (!fixed.length && !dropped.length && !warn.length) return '';
  const left = dropped.reduce((s, [, d]) => s + d.count, 0);
  return `<div class="block"><h2 class="sec">The check</h2><ul class="found">
      ${fixed.map((x) => `<li><span class="yes">✓</span><span>Fixed: ${esc(x)}</span></li>`).join('')}
      ${dropped.length ? `<li><span class="note">!</span><span>Left out ${left} ${left === 1 ? 'file' : 'files'}: ${dropped.map(([why, d]) => `${esc(why)} (${d.count})`).join(', ')}.
        <br><span class="ash">${dropped.flatMap(([, d]) => d.some).slice(0, 6).map(esc).join(' · ')}</span></span></li>` : ''}
      ${warn.map((x) => `<li><span class="note">!</span><span>${esc(x.charAt(0).toUpperCase() + x.slice(1))}</span></li>`).join('')}
    </ul><p class="hint">Only you see this.</p></div>`;
}

// Its author's editor: the words, who sees it, published or not, the pictures, and taking it down.
function viewEdit(slug) {
  const c = ask('packs/' + encodeURIComponent(slug));
  if (waiting(c)) return '<div class="page-head"><h1 class="giant ghost-t">&nbsp;</h1></div>';
  if (!c.ok || !c.data.mine) return `<div class="page-head"><h1 class="giant">Not yours</h1><div><a class="w" href="#/dashboard/packs">My packs</a></div></div>`;
  const p = c.data;
  if (!state.edit || state.edit.slug !== slug) state.edit = { slug, title: p.title, blurb: p.blurb, about: p.about, visibility: p.visibility, state: p.state === 'hidden' ? null : p.state, msg: '', bad: false, sure: false };
  const e = state.edit;
  const pick = (field, v, name) => `<button class="w menu ${e[field] === v ? 'on' : ''}" data-set="${field}" data-v="${v}">${name}</button>`;
  return `<div class="dash">${rail('packs')}<div>
    <div class="crumb"><a href="${packHref(p)}">${esc(p.title)}</a> / Edit</div>
    <h1 class="sr">Edit ${esc(p.title)}</h1>
    <div class="sections">
      <div class="block"><h2 class="sec">Words</h2><div class="form" style="max-width:720px">
        <div><label class="lab" for="e-title">Name</label><input class="in" id="e-title" data-e="title" maxlength="48" value="${esc(e.title)}"></div>
        <div><label class="lab" for="e-blurb">One line about it</label><input class="in" id="e-blurb" data-e="blurb" maxlength="120" value="${esc(e.blurb)}"></div>
        <div><label class="lab" for="e-about">About</label><textarea class="in" id="e-about" data-e="about" maxlength="4000" rows="7">${esc(e.about)}</textarea></div></div></div>
      <div class="two">
        <div class="block"><h2 class="sec">Who sees it</h2><div class="choice"><div class="acts">${pick('visibility', 'public', 'Public')}${pick('visibility', 'private', 'Private')}</div>
          <p>${e.visibility === 'public' ? 'In the market, for every member.' : 'Only you. Access codes come later.'}</p></div></div>
        <div class="block"><h2 class="sec">Published</h2><div class="choice"><div class="acts">${p.state === 'hidden' ? '<span class="st cream">Hidden by moderation</span>' : pick('state', 'published', 'Yes') + pick('state', 'draft', 'Draft')}</div>
          <p>${p.state === 'hidden' ? esc(p.hidden_why || 'Only moderation can bring it back.') : e.state === 'published' ? 'Out, for whoever may see it.' : 'Kept to yourself until you publish it.'}</p></div></div>
      </div>
      <div class="block"><div class="acts"><button class="w menu lead" id="e-save">Save</button><a class="w menu" href="${packHref(p)}">Back to the page</a></div>
        <p class="hint ${e.bad ? 'bad' : 'ok'}" id="e-msg" role="status">${esc(e.msg)}</p></div>
      <div class="block"><h2 class="sec">Pictures</h2><div class="shots-up">
        ${p.pictures.map((s) => `<div class="shot"><img src="${s.small}" alt=""><span class="shot-acts">${p.cover && p.cover.big === s.big ? '<span class="st cream">Cover</span>' : `<button class="w small" data-cover="${s.id}">Make cover</button>`}<button class="w small" data-unpic="${s.id}">Remove</button></span></div>`).join('')}
        ${p.pictures.length < 12 ? `<label class="add">Add pictures<input type="file" id="e-pics" accept="image/png,image/jpeg,image/webp" multiple hidden></label>` : ''}</div>
        <p class="hint" id="e-pic-msg">PNG, JPEG or WebP, up to 12 MB each, at least 320 px on the short side; up to 12. The first is the cover unless you choose one.</p></div>
      <div class="block"><h2 class="sec">Take it down</h2>
        <div class="acts">${e.sure ? `<button class="w menu" id="e-delete-yes">Delete it for good</button><button class="w menu" id="e-delete-no">Keep it</button>` : '<button class="w menu" id="e-delete">Delete the pack</button>'}</div>
        <p class="hint">${e.sure ? 'It leaves the market at once; its files go after 30 days.' : 'Every version goes with it.'}</p></div>
    </div></div></div>`;
}

''')

js = replace_span(js, 'function viewLook(id) {', 'function viewAuthor(name) {', '')
js = replace_span(js, 'function viewAuthor(name) {', '// ------------------------------------------------------------------------------------------ the door', r'''// An author's page: what they published, most taken first.
function viewAuthor(login) {
  const c = ask('market?author=' + encodeURIComponent(login) + '&sort=users');
  const items = c.ok ? c.data.items : [], total = items.reduce((s, p) => s + p.users, 0);
  const uid = items[0] ? items[0].author.uid : null, name = items[0] ? items[0].author.login : login;
  return `<div class="page-head" style="flex-direction:row;align-items:center;gap:clamp(20px,3vw,44px);flex-wrap:wrap">${head(name, 112)}
      <div style="display:flex;flex-direction:column;gap:10px"><h1 class="giant">${esc(name)}</h1>
      <p class="ash num">${uid !== null ? `UID ${uid} · ` : ''}${c.ok ? `${L(`${c.data.total} published`, `${c.data.total} ${plural(c.data.total, 'пак', 'пака', 'паков')}`)} · ${users(total)}` : '&nbsp;'}</p></div></div>
    <div class="wrap" style="margin-top:20px">${waiting(c) ? ghosts(3) : !c.ok ? trouble(c) : items.length ? `<div class="grid">${items.map(card).join('')}</div>` : '<div class="empty">Nothing published yet.</div>'}</div>`;
}

''')

# ---- the dashboard: the rail, the overview's packs, my packs; codes and statistics gone
js = replace_span(js, 'function rail(active) {', 'const when = (s) =>', r'''function rail(active) {
  const link = (id, name, to) => `<a class="w ${active === id ? 'on' : ''}" href="#/${to || 'dashboard/' + id}">${name}</a>`;
  return `<nav class="rail" aria-label="Dashboard">${link('overview', 'Overview')}${link('packs', 'My packs')}
    <span class="gap"></span>${link('upload', 'Upload', 'upload')}${link('page', 'My page', 'author/' + encodeURIComponent(me().name))}${state.user && state.user.admin ? `<span class="gap"></span>${link('admin', 'Moderation', 'admin/new')}` : ''}</nav>`;
}
''')
js = swap(js, "  const worn = [item('cursed-default'), item('moonwake')];\n", '')
a, b = between(js, '        <div class="block"><h2 class="sec">In use</h2>', '    </div>`;\n}')
js = js[:a] + r'''        <div class="block"><h2 class="sec">Your packs</h2>${yourPacks()}</div>
      </div>
''' + js[b:]
js = replace_span(js, 'function dashPacks() {', 'function viewDashboard(tab) {', r'''// A few of mine, for the overview.
function yourPacks() {
  const c = ask('me/packs');
  if (waiting(c)) return '<div class="rows"><div>&nbsp;</div></div>';
  if (!c.ok) return trouble(c);
  const items = c.data.items;
  if (!items.length) return '<p class="ash">Nothing uploaded yet.</p><div class="acts"><a class="w lead" href="#/upload">Upload a pack</a></div>';
  return `<div class="rows mine">${items.slice(0, 5).map((p) => `<a href="${packHref(p)}"><b>${esc(p.title)}</b>${stateOf(p)}<span class="d num">${users(p.users)}</span></a>`).join('')}</div>
    <div class="acts">${items.length > 5 ? '<a class="w small" href="#/dashboard/packs">All of them</a>' : ''}<a class="w small" href="#/upload">Upload a pack</a></div>`;
}
const stateOf = (p) => (p.state === 'hidden' ? '<span class="st cream">Hidden</span>' : p.state === 'draft' ? '<span class="st warn">Draft</span>' : p.visibility === 'private' ? '<span class="st warn">Private</span>' : '<span class="st ok">Published</span>');
function dashPacks() {
  const c = ask('me/packs');
  if (waiting(c)) return `<h1 class="sr">My packs</h1><div class="sections">${ghosts(3)}</div>`;
  if (!c.ok) return trouble(c);
  const items = c.data.items;
  if (!items.length) return '<h1 class="sr">My packs</h1><div class="sections"><div class="block"><p class="lede">Nothing uploaded yet.</p><div class="acts"><a class="w lead" href="#/upload">Upload a pack</a></div></div></div>';
  return `<h1 class="sr">My packs</h1><div class="sections"><div class="block"><div class="scroll-x"><table><thead><tr><th>Pack</th><th>Kind</th><th>Version</th><th>State</th><th class="r">Users</th><th></th></tr></thead><tbody>
      ${items.map((p) => `<tr><td><a href="${packHref(p)}"><b>${esc(p.title)}</b></a></td><td class="ash">${packKind(p)}</td><td class="mono">${esc(p.version || '—')}</td><td>${stateOf(p)}</td><td class="r num">${fmt(p.users)}</td>
        <td class="acts-c"><a class="w small" href="#/upload/${p.slug}">New version</a><a class="w small" href="#/pack/${p.slug}/edit">Edit</a></td></tr>`).join('')}
    </tbody></table></div><div class="acts"><a class="w lead" href="#/upload">Upload a pack</a></div></div></div>`;
}
''')
js = swap(js, "  const body = { overview: dashOverview, packs: dashPacks, codes: dashCodes, stats: dashStats }[tab] || dashOverview;",
          "  const body = { overview: dashOverview, packs: dashPacks }[tab] || dashOverview;")

# ---- uploading
js = replace_span(js, 'function viewUpload() {', '// ------------------------------------------------------------------------------ forum, moderation, documents', r'''// Uploading: a .zip in 8 MB pieces (a broken connection resumes, even after a reload, from where the server says it
// is), the server's check read out in words, the details, pictures, publishing. With a pack's slug: its next version.
const UP = { phase: 'pick', target: '', file: null, id: '', size: 0, sent: 0, result: null, error: '', fields: {}, pics: [], msg: '', bad: false, stop: false };
const upKey = 'cursed.upload';
function resetUpload(target) {
  UP.pics.forEach((x) => URL.revokeObjectURL(x.url));
  Object.assign(UP, { phase: 'pick', target, file: null, id: '', size: 0, sent: 0, result: null, error: '', fields: {}, pics: [], msg: '', bad: false, stop: true });
}
const nextNumber = (v) => { const m = String(v || '').match(/^(.*?)(\d+)(\D*)$/); return m ? m[1] + (Number(m[2]) + 1) + m[3] : '1.1'; };
function upProgress() {
  const bar = document.getElementById('up-bar'), text = document.getElementById('up-state');
  if (bar) bar.style.transform = `scaleX(${UP.size ? UP.sent / UP.size : 0})`;
  if (text && UP.phase === 'sending') text.innerHTML = `Sending · <span class="num">${Math.floor((100 * UP.sent) / (UP.size || 1))}%</span> of ${mb(UP.size)}`;
}
async function upSend(file) {
  resetUpload(UP.target);
  Object.assign(UP, { file, size: file.size, phase: 'sending', stop: false });
  const refuse = (message) => { Object.assign(UP, { phase: 'refused', result: { message } }); render(true); };
  if (file.size > 250 * 1024 * 1024) return refuse('The archive is bigger than 250 MB.');
  const head4 = new Uint8Array(await file.slice(0, 4).arrayBuffer());
  if (head4[0] !== 0x50 || head4[1] !== 0x4b) return refuse('This isn’t a zip archive.');
  render(true);
  // The same file as last time, not finished: go on from where the server is.
  let saved = null;
  try { saved = JSON.parse(localStorage.getItem(upKey) || 'null'); } catch (e) { saved = null; }
  if (saved && saved.name === file.name && saved.size === file.size && saved.modified === file.lastModified) {
    const s = await api('uploads/' + saved.id);
    if (s.ok && s.data.state === 'receiving') Object.assign(UP, { id: saved.id, sent: s.data.received });
  }
  let chunk = 8 * 1024 * 1024;
  if (!UP.id) {
    const r = await api('uploads', { name: file.name, size: file.size });
    if (!r.ok) return refuse(r.message || SAY[r.error] || SAY.busy);
    Object.assign(UP, { id: r.data.id, sent: 0 });
    chunk = r.data.chunk;
    try { localStorage.setItem(upKey, JSON.stringify({ id: UP.id, name: file.name, size: file.size, modified: file.lastModified })); } catch (e) { /* not kept */ }
  }
  upProgress();
  let tries = 0;
  while (UP.sent < UP.size) {
    if (UP.stop || UP.file !== file) return;
    let res;
    try {
      res = await fetch(`/api/uploads/${UP.id}?at=${UP.sent}`, { method: 'PUT', credentials: 'same-origin', headers: { 'Content-Type': 'application/octet-stream' }, body: file.slice(UP.sent, Math.min(UP.size, UP.sent + chunk)) });
    } catch (e) {
      res = null;
    }
    let data = {};
    try { data = res ? await res.json() : {}; } catch (e) { /* not JSON */ }
    if (res && res.ok) {
      UP.sent = data.received;
      tries = 0;
      upProgress();
      continue;
    }
    if (res && res.status === 409 && typeof data.received === 'number') { UP.sent = data.received; continue; }
    if (res && res.status < 500 && res.status !== 429) return refuse(data.message || SAY[data.error] || SAY.busy);
    if (++tries > 6) return refuse(SAY.offline);
    await new Promise((ok) => setTimeout(ok, 800 * tries));
  }
  try { localStorage.removeItem(upKey); } catch (e) { /* nothing */ }
  UP.phase = 'checking';
  render(true);
  while (UP.phase === 'checking' && UP.file === file) {
    await new Promise((ok) => setTimeout(ok, 700));
    const s = await api('uploads/' + UP.id);
    if (!s.ok || (s.data.state !== 'ready' && s.data.state !== 'refused')) continue;
    UP.result = s.data.result;
    UP.phase = s.data.state;
    if (UP.phase === 'ready') {
      const pack = UP.target && got.get('packs/' + encodeURIComponent(UP.target));
      const last = pack && pack.ok ? pack.data.version : '';
      // "Ashfall v1.4.zip": the name without its version, the version into its field.
      const named = String(UP.result.title).match(/^(.*?)[\s_-]+v(\d+(?:\.\d+){0,3}[a-z]?)$/i);
      UP.fields = { title: named ? named[1] : UP.result.title, blurb: '', about: '', number: UP.target ? nextNumber(last) : named ? named[2] : '1.0', changelog: '', visibility: 'public', mine: false };
    }
    render(true);
  }
}
function upFound(r) {
  const f = r.facts, g = f.game || {}, shader = r.kind === 'shaderpack';
  const li = (ok, text) => `<li><span class="${ok ? 'yes' : 'note'}">${ok ? '✓' : '!'}</span><span>${text}</span></li>`;
  const dropped = Object.entries(f.dropped || {}), left = dropped.reduce((s, [, d]) => s + d.count, 0);
  const what = shader ? (f.features || []).join(', ') : (f.changes || []).map((x) => (CHANGE_NAMES[x] || x).toLowerCase()).join(', ');
  const lines = [li(true, `${shader ? 'A shader pack' : 'A resource pack'} · safe · <span class="num">${fmt(f.files)}</span> files, ${mb(f.unpacked)} unpacked`)];
  if (!shader) lines.push(g.fits ? li(true, `Built for ${GAME}`) : li(false, g.versions ? `Made for ${esc(g.versions)}: ${GAME} will call it another version` : 'pack.mcmeta doesn’t say its versions the way the game wants'));
  if (what || f.resolution) lines.push(li(true, `${f.resolution ? `<b>${f.resolution}</b>` : ''}${f.resolution && what ? ' · ' : ''}${esc(what)}${shader && f.options ? ` · <span class="num">${f.options}</span> options` : ''}`));
  (f.fixed || []).forEach((x) => lines.push(li(true, 'Fixed: ' + esc(x))));
  if (left) lines.push(li(false, `Left out ${left} ${left === 1 ? 'file' : 'files'}: ${dropped.map(([why, d]) => `${esc(why)} (${d.count})`).join(', ')}`));
  (f.warnings || []).filter((x) => !/^made for|doesn't say its versions/.test(x)).forEach((x) => lines.push(li(false, esc(x.charAt(0).toUpperCase() + x.slice(1)))));
  return `<ul class="found">${lines.join('')}</ul><p class="hint">Read from the file. The market keeps a clean copy of it.</p>`;
}
function viewUpload(arg) {
  const target = arg || '';
  if (UP.target !== target && UP.phase !== 'sending' && UP.phase !== 'checking') resetUpload(target);
  const t = target ? ask('packs/' + encodeURIComponent(target)) : null, pack = t && t.ok ? t.data : null;
  if (t && !waiting(t) && (!t.ok || !t.data.mine)) return `<div class="dash">${rail('upload')}<div><div class="empty">That pack isn’t yours.</div></div></div>`;
  const at = { pick: 0, sending: 0, checking: 1, refused: 1, ready: 2, publishing: 3 }[UP.phase];
  const steps = ['File', 'Checked', 'Details', 'Publish'].map((s, i) => `<span class="${i < at ? 'done' : i === at ? 'now' : ''}">${s}</span>`).join('');
  const r = UP.result, fl = UP.fields, file = UP.file;
  let body;
  if (UP.phase === 'pick') {
    body = `<div class="block"><h2 class="sec">The file</h2>
      <label class="drop" id="up-drop"><input type="file" id="up-file" accept=".zip,application/zip,application/x-zip-compressed" hidden>
        <span class="big">Drop a .zip here</span><span class="ash">or <span class="w small lead">choose a file</span> · up to 250 MB</span></label>
      <p class="hint">A resource pack or a shader pack. The site checks every file in it, leaves out what the game never reads and keeps a clean copy.</p></div>`;
  } else if (UP.phase === 'sending' || UP.phase === 'checking') {
    body = `<div class="block"><h2 class="sec">The file</h2>
      <div class="file"><span class="mono">${esc(file.name)}</span><span class="ash">${mb(UP.size)}</span>${UP.phase === 'sending' ? '<button class="w small" id="up-cancel">Cancel</button>' : ''}</div>
      <div class="meter ${UP.phase === 'checking' ? 'busy' : ''}"><i id="up-bar"></i></div>
      <p class="hint" id="up-state">${UP.phase === 'checking' ? 'Checking every file in it…' : ''}</p></div>`;
  } else if (UP.phase === 'refused') {
    body = `<div class="block"><h2 class="sec">The file</h2>${file ? `<div class="file"><span class="mono">${esc(file.name)}</span></div>` : ''}
      <ul class="found"><li><span class="note">✕</span><span>${esc(r.message.charAt(0).toUpperCase() + r.message.slice(1))}${r.path ? `<br><span class="mono ash">${esc(r.path)}</span>` : ''}</span></li></ul>
      <div class="acts"><button class="w lead" id="up-again">Choose another file</button></div></div>`;
  } else {
    const wrongKind = pack && r.kind !== pack.kind;
    const pics = UP.pics.map((x, i) => `<div class="shot"><img src="${x.url}" alt=""><span class="shot-acts"><button class="w small" data-unpick="${i}">Remove</button></span></div>`).join('');
    body = `<div class="two">
        <div class="block"><h2 class="sec">The file</h2><div class="file"><span class="mono">${esc(file.name)}</span><span class="ash">${mb(r.size)} clean</span><button class="w small" id="up-again">Replace</button></div>${upFound(r)}</div>
        ${pack ? `<div class="block"><h2 class="sec">The pack</h2>${kv([['Name', esc(pack.title)], ['Now', 'v' + esc(pack.version || '—')], ['Kind', packKind(pack)]])}</div>`
          : `<div class="block"><h2 class="sec">Who sees it</h2><div class="choice"><div class="acts"><button class="w menu ${fl.visibility === 'public' ? 'on' : ''}" data-upvis="public">Public</button><button class="w menu ${fl.visibility === 'private' ? 'on' : ''}" data-upvis="private">Private</button></div>
            <p>${fl.visibility === 'public' ? 'In the market, for every member.' : 'Only you. Access codes come later.'}</p></div></div>`}
      </div>
      ${wrongKind ? `<div class="block"><ul class="found"><li><span class="note">✕</span><span>${L(`This is ${r.kind === 'shaderpack' ? 'a shader pack' : 'a resource pack'}, and <span translate="no">${esc(pack.title)}</span> is ${pack.kind === 'shaderpack' ? 'a shader pack' : 'a resource pack'}: a new version has to be the same kind.`, `Это ${r.kind === 'shaderpack' ? 'шейдерпак' : 'ресурспак'}, а <span translate="no">${esc(pack.title)}</span> — ${pack.kind === 'shaderpack' ? 'шейдерпак' : 'ресурспак'}: новая версия должна быть того же типа.`)}</span></li></ul></div>` : `
      <div class="block"><h2 class="sec">Details</h2><div class="form" style="max-width:720px">
        ${pack ? '' : `<div><label class="lab" for="u-title">Name</label><input class="in" id="u-title" data-f="title" maxlength="48" value="${esc(fl.title)}"></div>
        <div><label class="lab" for="u-blurb">One line about it</label><input class="in" id="u-blurb" data-f="blurb" maxlength="120" value="${esc(fl.blurb)}"></div>
        <div><label class="lab" for="u-about">About</label><textarea class="in" id="u-about" data-f="about" maxlength="4000" rows="5">${esc(fl.about)}</textarea></div>`}
        <div><label class="lab" for="u-number">Version</label><input class="in mono" id="u-number" data-f="number" maxlength="16" value="${esc(fl.number)}"></div>
        <div><label class="lab" for="u-log">${pack ? 'What changed' : 'Notes on this version'}</label><textarea class="in" id="u-log" data-f="changelog" maxlength="2000" rows="3">${esc(fl.changelog)}</textarea></div></div></div>
      ${pack ? '' : `<div class="block"><h2 class="sec">Pictures</h2><div class="shots-up">${pics}${UP.pics.length < 12 ? `<label class="add">Add pictures<input type="file" id="up-pics" accept="image/png,image/jpeg,image/webp" multiple hidden></label>` : ''}</div>
        <p class="hint">Screenshots from the game. The first is the cover.</p></div>`}
      <div class="block"><label class="tick"><input type="checkbox" id="up-mine" ${fl.mine ? 'checked' : ''}><span>It’s mine, or I hold the rights to it.</span></label>
        <div class="acts" style="margin-top:14px">${UP.phase === 'publishing' ? '<span class="st cream">Publishing…</span>'
          : `<button class="w menu lead" id="up-publish">Publish${pack ? ' ' + esc(fl.number) : ''}</button>${pack ? '' : '<button class="w menu" id="up-draft">Save as a draft</button>'}`}</div>
        <p class="hint ${UP.bad ? 'bad' : ''}" id="up-msg" role="status">${esc(UP.msg)}</p></div>`}`;
  }
  return `<div class="dash">${rail('upload')}<div>
    <h1 class="sr">Upload</h1>${pack ? `<div class="crumb"><a href="${packHref(pack)}">${esc(pack.title)}</a> / New version</div>` : ''}
    <div class="steps" style="margin-top:${pack ? 18 : 0}px">${steps}</div>
    <div class="sections">${body}</div></div></div>`;
}
async function upPublish(draft) {
  const fl = UP.fields, say = (m) => { UP.msg = m; UP.bad = true; render(true); };
  if (!fl.mine) return say('Tick the box first: only what is yours may go up.');
  UP.phase = 'publishing';
  UP.msg = '';
  render(true);
  const r = UP.target
    ? await api(`packs/${encodeURIComponent(UP.target)}/versions`, { upload: UP.id, number: fl.number, changelog: fl.changelog })
    : await api('packs', { upload: UP.id, title: fl.title, blurb: fl.blurb, about: fl.about, visibility: fl.visibility, number: fl.number, changelog: fl.changelog, publish: !draft });
  if (!r.ok) {
    UP.phase = 'ready';
    return say(r.message || SAY[r.error] || SAY.busy);
  }
  const slug = r.data.slug;
  for (let i = 0; i < UP.pics.length; i++) {
    UP.msg = `Adding pictures: ${i + 1} of ${UP.pics.length}`;
    UP.bad = false;
    const m = document.getElementById('up-msg');
    if (m) m.textContent = UP.msg;
    try { await fetch(`/api/packs/${slug}/pictures`, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/octet-stream' }, body: UP.pics[i].file }); } catch (e) { /* the pack is up; a picture can be added later */ }
  }
  forget('market', 'packs/', 'me/');
  resetUpload('');
  location.hash = '#/pack/' + slug;
}

''')

# ---- moderation: the newest packs, and the hidden ones
js = replace_span(js, 'function viewAdmin(tab) {', 'function viewDocs(which) {', r'''function viewAdmin(tab) {
  const t = tab === 'hidden' ? 'hidden' : 'new';
  const c = ask(t === 'hidden' ? 'market?state=hidden' : 'market?sort=new');
  const hidden = ask('market?state=hidden'), n = hidden.ok ? hidden.data.total : 0;
  return `<div class="dash">${rail('admin')}<div><h1 class="sr">Moderation</h1><p class="sub">Only you see this. Hide a pack from its page: its author is told why.</p>
    <div class="acts" style="margin-top:22px"><a class="w ${t === 'new' ? 'on' : ''}" href="#/admin/new">Newest</a><a class="w ${t === 'hidden' ? 'on' : ''}" href="#/admin/hidden">Hidden · ${n}</a></div>
    <div class="sections">${waiting(c) ? ghosts(3) : !c.ok ? trouble(c) : c.data.items.length ? `<div class="grid">${c.data.items.map(card).join('')}</div>` : `<div class="empty">${t === 'hidden' ? 'Nothing hidden.' : 'Nothing in the market yet.'}</div>`}</div></div></div>`;
}
''')

# ---- the events of every screen
js = replace_span(js, 'function wire() {', '// The eyes on the door crack open', r'''let searchTimer = 0;
function wire() {
  const on = (sel, ev, fn) => $app.querySelectorAll(sel).forEach((el) => el.addEventListener(ev, (e) => fn(el, e)));
  const m = state.m, go = () => { m.page = 1; render(true); };
  on('[data-copy]', 'click', (b) => { try { navigator.clipboard.writeText(b.dataset.copy); } catch (e) {} b.textContent = 'Copied'; });
  on('[data-jump]', 'click', (a, e) => { e.preventDefault(); const el = document.getElementById(a.dataset.jump); if (el) el.scrollIntoView(); });
  // The shop window.
  on('[data-kind]', 'click', (b) => { m.kind = b.dataset.kind; go(); });
  on('[data-res]', 'click', (b) => { m.res = m.res === b.dataset.res ? '' : b.dataset.res; go(); });
  on('[data-fits]', 'click', () => { m.fits = !m.fits; go(); });
  on('[data-page]', 'click', (b) => { m.page = Number(b.dataset.page); render(true); window.scrollTo({ top: 0 }); });
  on('#sort', 'change', (s) => { m.sort = s.value; go(); });
  on('#q', 'input', (q) => {
    state.q = q.value;
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => { state.qLive = state.q.trim(); go(); }, 320);
  });
  // A pack's page.
  on('[data-shot]', 'click', (b) => { state.shot = Number(b.dataset.shot); render(true); });
  on('[data-hide]', 'click', (b) => { state.hiding = b.dataset.hide; render(true); const i = document.getElementById('hide-why'); if (i) i.focus(); });
  on('[data-hide-no]', 'click', () => { state.hiding = ''; render(true); });
  on('[data-hide-go]', 'click', async (b) => {
    const why = (document.getElementById('hide-why') || {}).value || '';
    await api(`packs/${b.dataset.hideGo}/hide`, { why });
    state.hiding = '';
    forget('market', 'packs/');
    render(true);
  });
  on('[data-unhide]', 'click', async (b) => { await api(`packs/${b.dataset.unhide}/unhide`, {}); forget('market', 'packs/'); render(true); });
  // Its editor.
  const e = state.edit;
  on('[data-e]', 'input', (el) => { e[el.dataset.e] = el.value; });
  on('[data-set]', 'click', (b) => { e[b.dataset.set] = b.dataset.v; render(true); });
  on('#e-save', 'click', async () => {
    const r = await api(`packs/${e.slug}`, { title: e.title, blurb: e.blurb, about: e.about, visibility: e.visibility, ...(e.state ? { state: e.state } : {}) }, 'PATCH');
    Object.assign(e, r.ok ? { msg: 'Saved.', bad: false } : { msg: r.message || SAY[r.error] || SAY.busy, bad: true });
    if (r.ok) { forget('market', 'packs/', 'me/'); got.set('packs/' + encodeURIComponent(e.slug), { at: performance.now(), ok: true, data: r.data }); }
    render(true);
  });
  on('#e-pics', 'change', async (input) => {
    const msg = document.getElementById('e-pic-msg'), files = [...input.files];
    for (let i = 0; i < files.length; i++) {
      if (msg) msg.textContent = `Adding pictures: ${i + 1} of ${files.length}`;
      const res = await fetch(`/api/packs/${e.slug}/pictures`, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/octet-stream' }, body: files[i] }).catch(() => null);
      if (!res || !res.ok) {
        let d = {};
        try { d = await res.json(); } catch (x) { /* not JSON */ }
        if (msg) { msg.textContent = `${files[i].name}: ${d.message || SAY[d.error] || SAY.busy}`; msg.className = 'hint bad'; }
        break;
      }
    }
    forget('packs/', 'market', 'me/');
    render(true);
  });
  on('[data-cover]', 'click', async (b) => { await api(`packs/${e.slug}/pictures`, { cover: Number(b.dataset.cover) }, 'PATCH'); forget('packs/', 'market', 'me/'); render(true); });
  on('[data-unpic]', 'click', async (b) => { await api(`packs/${e.slug}/pictures/${b.dataset.unpic}`, null, 'DELETE'); forget('packs/', 'market', 'me/'); render(true); });
  on('#e-delete', 'click', () => { e.sure = true; render(true); });
  on('#e-delete-no', 'click', () => { e.sure = false; render(true); });
  on('#e-delete-yes', 'click', async () => { await api(`packs/${e.slug}`, null, 'DELETE'); forget('packs/', 'market', 'me/'); state.edit = null; location.hash = '#/dashboard/packs'; });
  // Uploading.
  const drop = document.getElementById('up-drop');
  if (drop) {
    ['dragenter', 'dragover'].forEach((t) => drop.addEventListener(t, (ev) => { ev.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach((t) => drop.addEventListener(t, () => drop.classList.remove('over')));
    drop.addEventListener('drop', (ev) => { ev.preventDefault(); const f = ev.dataTransfer.files[0]; if (f) upSend(f); });
  }
  on('#up-file', 'change', (input) => { if (input.files[0]) upSend(input.files[0]); });
  on('#up-cancel', 'click', () => { UP.stop = true; if (UP.id) api(`uploads/${UP.id}`, null, 'DELETE'); try { localStorage.removeItem(upKey); } catch (x) { /* nothing */ } resetUpload(UP.target); render(true); });
  on('#up-again', 'click', () => { resetUpload(UP.target); render(true); });
  on('[data-f]', 'input', (el) => { UP.fields[el.dataset.f] = el.value; });
  on('#up-mine', 'change', (el) => { UP.fields.mine = el.checked; });
  on('[data-upvis]', 'click', (b) => { UP.fields.visibility = b.dataset.upvis; render(true); });
  on('#up-pics', 'change', (input) => {
    for (const f of [...input.files].slice(0, 12 - UP.pics.length)) UP.pics.push({ file: f, url: URL.createObjectURL(f) });
    render(true);
  });
  on('[data-unpick]', 'click', (b) => { const [x] = UP.pics.splice(Number(b.dataset.unpick), 1); if (x) URL.revokeObjectURL(x.url); render(true); });
  on('#up-publish', 'click', () => upPublish(false));
  on('#up-draft', 'click', () => upPublish(true));
  if (UP.phase === 'sending') upProgress();
  // The account.
  on('form#reg, form#signin', 'submit', (f, ev) => { ev.preventDefault(); enter(f); });
  on('form#pw', 'submit', (f, ev) => { ev.preventDefault(); newPassword(f); });
  on('#pw-open', 'click', () => { state.pwOpen = !state.pwOpen; render(true); });
  on('#signout', 'click', async () => { await api('logout', {}); signOut(); got.clear(); location.hash = '#/home'; });
  wireRegister();
}

''')

# The made-up reports went with the rest of the made-up data.
a = js.index('const REPORTS = [')
js = js[:a] + js[js.index('\n];\n', a) + 4:]

# The state the market keeps; looks gone from the routes; the one chart gone; the focused field kept across a redraw.
js = swap(js, "  type: 'all', res: new Set(), changes: new Set(), onlyCurrent: false, sort: 'trending', q: '',",
          "  m: { kind: '', res: '', fits: false, sort: 'trending', page: 1 }, q: '', qLive: '', hiding: '', edit: null,")
js = swap(js, "const MEMBERS_ONLY = new Set(['market', 'pack', 'look', 'author', 'forum', 'dashboard', 'upload', 'admin']);",
          "const MEMBERS_ONLY = new Set(['market', 'pack', 'author', 'forum', 'dashboard', 'upload', 'admin']);")
js = swap(js, "  const views = { home: viewHome, market: viewMarket, pack: viewPack, look: viewLook, author: viewAuthor,",
          "  const views = { home: viewHome, market: viewMarket, pack: viewPack, author: viewAuthor,")
js = swap(js, "  const spark = document.getElementById('spark'); if (spark) drawSpark(spark, SPARK);\n", '')
js = swap(js, "  FX.pauseAll();\n  $app.innerHTML = shell(", '''  // The field being typed in keeps its focus and caret through a redraw (a search's answer arrives mid-word).
  const was = document.activeElement, keep = was && was.id && $app.contains(was) ? [was.id, was.selectionStart, was.selectionEnd] : null;
  FX.pauseAll();
  $app.innerHTML = shell(''')
js = swap(js, "  wire();\n  light();\n  solidBar();\n}", '''  wire();
  light();
  solidBar();
  if (keep) {
    const el = document.getElementById(keep[0]);
    if (el) { el.focus({ preventScroll: true }); try { el.setSelectionRange(keep[1], keep[2]); } catch (e) { /* not a text field */ } }
  }
}''')
# Errors from the server carry words; calls can be PATCH and DELETE.
js = swap(js, "async function api(path, body) {", "async function api(path, body, method) {")
js = swap(js, "    r = await fetch('/api/' + path, body === undefined ? { credentials: 'same-origin', cache: 'no-store' }\n      : { method: 'POST', credentials: 'same-origin', cache: 'no-store', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });",
          "    r = await fetch('/api/' + path, body === undefined && !method ? { credentials: 'same-origin', cache: 'no-store' }\n      : { method: method || 'POST', credentials: 'same-origin', cache: 'no-store', headers: { 'Content-Type': 'application/json' }, body: body === null ? undefined : JSON.stringify(body) });")
js = swap(js, "  return r.ok ? { ok: true, data } : { ok: false, status: r.status, error: data.error || (r.status === 429 ? 'slow' : 'busy') };",
          "  return r.ok ? { ok: true, data } : { ok: false, status: r.status, error: data.error || (r.status === 429 ? 'slow' : 'busy'), message: data.message };")
# Leaving mid-upload asks first.
js = swap(js, "window.addEventListener('hashchange', () => render());", '''window.addEventListener('hashchange', () => render());
window.addEventListener('beforeunload', (e) => { if (UP.phase === 'sending') { e.preventDefault(); e.returnValue = ''; } });''')

market_css = r'''
/* The market: a pack without pictures shows its own icon, pixel-sharp, on the site's dark; a card still coming breathes. */
.tile { display: grid; place-items: center; width: 100%; aspect-ratio: 4 / 3; background: var(--line); transition: transform .5s var(--ease), filter .3s; }
.tile img { width: 34%; aspect-ratio: 1; image-rendering: pixelated; }
.tile b { font: 800 clamp(40px, 5vw, 80px)/1 var(--display); color: var(--dim); }
.tile.big img { width: 28%; }
.card:hover .tile { transform: translateY(-8px) scale(1.03); filter: brightness(1.15); }
.card:hover .tile img { transform: none; filter: none; }
.pk .stage .tile img { width: 28%; aspect-ratio: 1; object-fit: contain; }
.ghost .tile, .ghost .t, .ghost .m, .ghost-t, .tile.ghost { animation: breathe 1.6s ease-in-out infinite; }
.ghost .t, .ghost .m, .ghost-t { background: var(--line); color: transparent; max-width: 60%; margin-inline: auto; }
@keyframes breathe { 50% { opacity: .45; } }
.pager { justify-content: center; align-items: baseline; margin-top: clamp(30px, 5vh, 60px); }
.feature .tile { aspect-ratio: 4 / 3; }
/* Uploading: a field to drop a file on (no frame: the words are the target), a line that fills as it goes. */
.drop { display: flex; flex-direction: column; gap: 12px; padding: clamp(40px, 8vh, 96px) 0; cursor: pointer; transition: padding .35s var(--ease), background-color .25s; }
.drop .big { transition: color .2s, letter-spacing .35s var(--ease); color: var(--dim); }
.drop:hover .big, .drop.over .big { color: var(--glow); }
.drop.over { background: var(--line); padding-left: clamp(18px, 3vw, 40px); }
.drop.over .big { letter-spacing: .05em; }
.meter { position: relative; height: 1px; background: var(--line); overflow: hidden; margin-top: 6px; }
.meter i { position: absolute; inset: 0; background: var(--cream); transform: scaleX(0); transform-origin: left; transition: transform .3s var(--ease); }
.meter.busy i { transform: none; width: 30%; animation: sweep 1.3s var(--ease) infinite; }
@keyframes sweep { from { left: -30%; } to { left: 100%; } }
.shots-up .shot { position: relative; }
.shots-up .shot img { width: 100%; aspect-ratio: 4 / 3; object-fit: cover; }
.shots-up .shot-acts { position: absolute; left: 0; right: 0; bottom: 0; display: flex; gap: 16px; justify-content: center; padding: 10px 0 8px; background: linear-gradient(transparent, rgba(4,3,3,.9)); opacity: 0; transition: opacity .2s; }
.shots-up .shot:hover .shot-acts, .shots-up .shot:focus-within .shot-acts { opacity: 1; }
.shots-up label.add { cursor: pointer; }
.rows.mine > a { grid-template-columns: minmax(0, 1fr) auto auto; transition: color .18s; }
.rows.mine > a:hover b { color: var(--cream); }
.hide-form { max-width: 440px; gap: 10px; }
textarea.in { resize: vertical; line-height: 1.55; }
.pk .say .giant { overflow-wrap: anywhere; }
.pk .say .giant.long { font-size: clamp(26px, 3vw, 46px); }
.pk .acts.own { margin-top: -8px; }
@media (max-width: 980px) { .shots-up .shot-acts { opacity: 1; } }
'''

# ---------------------------------------------------------------- the forum: real, through /api
# The forum is real (27.09): cursed-api's /api/forum (site/server/src/forum.rs). The made-up threads, categories and
# faces go; moderation gets its reports; a pack page gets a way to report it.
for name in ('const FORUM = [', 'const THREADS = ['):
    a = js.index(name)
    js = js[:a] + js[js.index('\n];\n', a) + 4:]
a = js.index('const ONLINE = [')
js = js[:a] + js[js.index('\n', a) + 1:]
a = js.index('// Forum categories carry a colour')
js = js[:a] + js[js.index('\n', js.index('const CAT_COLOUR', a)) + 1:]

js = replace_span(js, 'function viewForum() {', 'function viewAdmin(tab) {', r'''// ---- the forum --------------------------------------------------------------------------------------------------
// The forum's screens are social/forum.js (03.10.2026); what the market's reports share with them stays here.
const sq = (colour) => `<i style="background:${colour || 'var(--dim)'}"></i>`;
const catOf = (cats, id) => (cats || []).find((c) => c.id === id) || { id, name: id, colour: 'var(--dim)' };
// A small question asked in place (why hide it, what is wrong with it), with its two answers.
const inlineAsk = (id, placeholder, yes, target, go) => `<div class="form hide-form"><input class="in" id="${id}" maxlength="200" placeholder="${placeholder}"><div class="acts"><button class="w small lead" data-${go}="${target}">${yes}</button><button class="w small" data-fask-no="1">Cancel</button></div></div>`;

''')

# Moderation: reports first.
js = replace_span(js, 'function viewAdmin(tab) {', 'function viewDocs(which) {', r'''// The first moderation: reports, and packs newest and hidden; tabs of the staff's panel now (social/admin.js).
function adminModeration(tab) {
  const t = ['reports', 'hidden', 'new'].includes(tab) ? tab : 'reports';
  const reports = ask('reports'), hidden = ask('market?state=hidden');
  const nr = reports.ok ? reports.data.items.length : 0, nh = hidden.ok ? hidden.data.total : 0;
  let body;
  if (t === 'reports') {
    body = waiting(reports) ? ghosts(2) : !reports.ok ? trouble(reports) : !reports.data.items.length ? '<div class="empty">No open reports.</div>'
      : `<div>${reports.data.items.map((r) => {
          const a = r.about || {}, gone = !a.title && !a.text;
          const link = r.kind === 'pack' ? (a.slug ? `#/pack/${a.slug}` : '') : a.thread ? `#/forum/t/${a.thread}` : '';
          const what = { post: 'A post', thread: 'A thread', pack: 'A pack' }[r.kind];
          return `<div class="report"><div><span class="st ${r.kind === 'pack' ? 'ok' : 'cream'}">${what}</span>
            <h3 translate="no">${gone ? '<span class="ash">Gone already</span>' : esc(a.title || '')}</h3>${a.text ? `<p translate="no">${esc(a.text)}</p>` : ''}
            <p class="ash when">By <span translate="no">${esc(a.author ? a.author.login : '—')}</span>. Reported by <span translate="no">${esc(r.by.login)}</span> · ${ago(r.created)}: “<span translate="no">${esc(r.why)}</span>”</p>
            ${state.rhide === r.id ? inlineAsk('r-why', 'Why (its author sees this)', 'Hide it', String(r.id), 'rhide-go') : ''}</div>
            <div class="acts">${link ? `<a class="w small" href="${link}">Open</a>` : ''}${gone ? '' : `<button class="w small" data-rhide="${r.id}">Hide it</button>`}<button class="w small" data-rdismiss="${r.id}">Dismiss</button></div></div>`;
        }).join('')}</div>`;
  } else {
    const c = t === 'hidden' ? hidden : ask('market?sort=new');
    body = waiting(c) ? ghosts(3) : !c.ok ? trouble(c) : c.data.items.length ? `<div class="grid">${c.data.items.map(card).join('')}</div>` : `<div class="empty">${t === 'hidden' ? 'Nothing hidden.' : 'Nothing in the market yet.'}</div>`;
  }
  const sub = t === 'reports' ? `<p class="hint">What you hide, its author is told why.</p>` : `<div class="acts"><a class="w small ${t === 'new' ? 'on' : ''}" href="#/admin/packs">Newest packs</a><a class="w small ${t === 'hidden' ? 'on' : ''}" href="#/admin/packs/hidden">Hidden packs · <span class="num">${nh}</span></a></div>`;
  const _nr = nr;
  return `${sub}<div class="sections">${body}</div>`;
}
''')
js = swap(js, "${state.user && state.user.admin ? `<span class=\"gap\"></span>${link('admin', 'Moderation', 'admin/new')}` : ''}", "${state.user && state.user.admin ? `<span class=\"gap\"></span>${link('admin', 'Moderation', 'admin/reports')}` : ''}")

# A pack page: members may report it.
js = swap(js, '''        ${p.mine ? `<div class="acts own"><a class="w small" href="#/pack/${p.slug}/edit">Edit</a><a class="w small" href="#/upload/${p.slug}">New version</a></div>` : ''}''',
          '''        ${p.mine ? `<div class="acts own"><a class="w small" href="#/pack/${p.slug}/edit">Edit</a><a class="w small" href="#/upload/${p.slug}">New version</a></div>`
          : p.state === 'published' ? `<div class="acts own">${state.freport && state.freport.kind === 'pack' && state.freport.id === p.id ? '' : `<button class="w small" data-freport="pack:${p.id}">Report</button>`}${state.fmsg && state.freport === null && state.fdone === 'pack:' + p.id ? `<span class="hint ok" style="margin:0">${esc(state.fmsg)}</span>` : ''}</div>
            ${state.freport && state.freport.kind === 'pack' && state.freport.id === p.id ? inlineAsk('f-report-why', 'What is wrong with it?', 'Report it', 'pack:' + p.id, 'freport-go') : ''}` : ''}''')

# The forum's state, and its events.
js = swap(js, "  m: { kind: '', res: '', fits: false, sort: 'trending', page: 1 }, q: '', qLive: '', hiding: '', edit: null,",
          "  m: { kind: '', res: '', fits: false, sort: 'trending', page: 1 }, q: '', qLive: '', hiding: '', edit: null,\n  fq: '', fqLive: '', fcat: '', fedit: 0, fedittext: '', freport: null, fhide: '', fdone: '', fmsg: '', freply: {}, frename: false, frenametext: '', fnew: { category: '', title: '', body: '', msg: '' }, rhide: 0,")
js = swap(js, '''  // The account.
  on('form#reg, form#signin', 'submit',''', r'''  // The forum.
  let forumTimer = 0;
  on('#fq', 'input', (q) => {
    state.fq = q.value;
    clearTimeout(forumTimer);
    forumTimer = setTimeout(() => { state.fqLive = state.fq.trim(); render(true); }, 320);
  });
  const threadId = () => Number(String(state.arg).split('/')[1]);
  const again = () => { forget('forum', 'reports'); render(true); };
  on('[data-fdel]', 'click', async (b) => {
    if (b.dataset.sure !== '1') { b.dataset.sure = '1'; b.textContent = 'Delete it?'; return; }
    const r = await api(`forum/posts/${b.dataset.fdel}`, null, 'DELETE');
    if (!r.ok && r.error === 'first') { state.fmsg = r.message; render(true); return; }
    forget('forum');
    const t = got.get(`forum/threads/${threadId()}`);
    render(true);
    if (t && !t.ok) location.hash = '#/forum';
  });
  on('[data-freport]', 'click', (b) => { const [kind, id] = b.dataset.freport.split(':'); state.freport = { kind, id: Number(id) }; state.fhide = ''; render(true); const i = document.getElementById('f-report-why'); if (i) i.focus(); });
  on('[data-fhide]', 'click', (b) => { state.fhide = b.dataset.fhide; state.freport = null; render(true); const i = document.getElementById('f-hide-why'); if (i) i.focus(); });
  on('[data-fask-no]', 'click', () => { state.freport = null; state.fhide = ''; state.rhide = 0; render(true); });
  on('[data-freport-go]', 'click', async (b) => {
    const [kind, id] = b.dataset.freportGo.split(':');
    const r = await api('reports', { kind, id: Number(id), why: (document.getElementById('f-report-why') || {}).value || '' });
    state.freport = null;
    state.fdone = kind + ':' + id;
    state.fmsg = r.ok ? 'Reported. Thank you.' : r.message || SAY[r.error] || SAY.busy;
    render(true);
  });
  on('[data-fhide-go]', 'click', async (b) => {
    const [kind, id] = b.dataset.fhideGo.split(':');
    await api(`forum/${kind === 'post' ? 'posts' : 'threads'}/${id}/hide`, { why: (document.getElementById('f-hide-why') || {}).value || '' });
    state.fhide = '';
    again();
  });
  on('[data-funhide]', 'click', async (b) => { const [kind, id] = b.dataset.funhide.split(':'); await api(`forum/${kind === 'post' ? 'posts' : 'threads'}/${id}/unhide`, {}); again(); });
  on('[data-fpin]', 'click', async (b) => { await api(`forum/threads/${threadId()}`, { pinned: b.dataset.fpin === '1' }, 'PATCH'); again(); });
  on('[data-flock]', 'click', async (b) => { await api(`forum/threads/${threadId()}`, { locked: b.dataset.flock === '1' }, 'PATCH'); again(); });
  on('#f-move', 'change', async (s) => { await api(`forum/threads/${threadId()}`, { category: s.value }, 'PATCH'); again(); });
  on('[data-frename]', 'click', () => {
    const [, t] = [...got.entries()].find(([k, v]) => k.startsWith(`forum/threads/${threadId()}`) && v.ok) || [];
    state.frename = true; state.frenametext = t ? t.data.title : '';
    render(true);
  });
  on('#f-title', 'input', (el) => { state.frenametext = el.value; });
  on('[data-frename-no]', 'click', () => { state.frename = false; render(true); });
  on('[data-frename-go]', 'click', async () => { const r = await api(`forum/threads/${threadId()}`, { title: state.frenametext }, 'PATCH'); if (r.ok) state.frename = false; again(); });
  // Moderation's reports.
  on('[data-rhide]', 'click', (b) => { state.rhide = Number(b.dataset.rhide); render(true); const i = document.getElementById('r-why'); if (i) i.focus(); });
  on('[data-rhide-go]', 'click', async (b) => { await api(`reports/${b.dataset.rhideGo}/close`, { action: 'hide', why: (document.getElementById('r-why') || {}).value || '' }); state.rhide = 0; forget('reports', 'market', 'packs/', 'forum'); render(true); });
  on('[data-rdismiss]', 'click', async (b) => { await api(`reports/${b.dataset.rdismiss}/close`, { action: 'dismiss' }); forget('reports'); render(true); });
  // The account.
  on('form#reg, form#signin', 'submit',''')

forum_css = r'''
/* The forum: one column of threads, a thread's posts, the reply under them. */
.forum-one { padding: 0 var(--gut); max-width: 1100px; }
.forum-head { padding: 0 var(--gut) 20px; display: flex; flex-direction: column; gap: 10px; }
.forum-head .big { display: flex; align-items: center; gap: 16px; }
.forum-head .big i { width: 12px; height: 12px; flex: none; }
.forum-tools { align-items: baseline; }
.forum-tools .in { width: clamp(160px, 18vw, 260px); font-size: 15px; padding: 4px 0; }
.topic.unread > span:not(.n) > b::before { content: ""; display: inline-block; width: 6px; height: 6px; background: var(--cream); margin-right: 10px; vertical-align: 3px; }
.topic .in-cat .st { margin-left: 8px; font-size: 12.5px; }
.thread { padding: clamp(30px, 5vh, 60px) var(--gut) 0; max-width: 1100px; display: flex; flex-direction: column; gap: 18px; }
.thread .by { display: flex; flex-wrap: wrap; gap: 8px 22px; font-size: 15px; }
.thread .by a { color: var(--glow); }
.thread-tools { align-items: baseline; gap: 10px 26px; }
.small-select { width: auto; font-size: 14px; padding: 2px 22px 2px 0; }
.posts { margin-top: 10px; }
.post .top a.num { margin-left: auto; color: var(--line); transition: color .15s; }
.post:hover .top a.num { color: var(--ash); }
.post.new { position: relative; }
.post.new::before { content: ""; position: absolute; left: -18px; top: 26px; width: 6px; height: 6px; background: var(--cream); }
.post-body { margin-top: 6px; }
.post-body p { max-width: 70ch; }
.post-body a { color: var(--glow); border-bottom: 1px solid var(--line); transition: border-color .15s; word-break: break-word; }
.post-body a:hover { border-bottom-color: var(--glow); }
.post-body code, .prose code { font-family: var(--mono); font-size: .92em; color: var(--cream); background: var(--line); padding: 1px 5px; }
.post-body blockquote { border-left: 2px solid var(--line); padding: 2px 0 2px 14px; margin: 10px 0; color: var(--ash); }
.post-acts { gap: 6px 20px; margin-top: 10px; opacity: 0; transition: opacity .2s; }
.post:hover .post-acts, .post:focus-within .post-acts { opacity: 1; }
.post-form { max-width: 760px; }
.reply-box { max-width: 760px; margin-top: 36px; }
@media (max-width: 980px) { .post-acts { opacity: 1; } .forum-tools .in { width: 100%; } .post.new::before { left: -10px; } }
'''

# ---------------------------------------------------------------- one short page of rules
a = js.index('// The documents, the way this niche writes them')
b = js.index('const OPEN_DECISIONS = [];')
js = js[:a] + '''// The rules: one short page in plain words (in place of Terms and Privacy).
const DOCS = {
  rules: {
    title: 'Rules', version: 'Last updated 26 / 09 / 2026',
    sections: [
      ['The client', ['Cursed comes as is: no promise that it always works or suits you, and no liability for what it breaks. You must be 14 or older.']],
      ['Your account', ['It’s yours alone: keep the password to yourself. An account that breaks these rules can be closed, and you’ll be told why.']],
      ['What you upload', ['What you upload stays yours. By uploading you let Cursed store it and give it to members — to everyone, or only to those with your access codes. Upload only what you made or may share. If something of yours was uploaded by someone else, write to .lunuca on Discord and it comes down.']],
      ['Not allowed', ['Cheats, adverts and stolen work — in the Market, on the forum, anywhere on the site.']],
      ['Changes', ['These rules may change; the date above changes with them.']],
    ],
  },
};
''' + js[b:]
js = swap(js, "const key = DOCS[which] ? which : 'terms', doc = DOCS[key];", "const key = DOCS[which] ? which : 'rules', doc = DOCS[key];")
js = swap(js, "doc: 'terms',", "doc: 'rules',")

# ---------------------------------------------------------------- two languages, English and Russian
# Two languages, as the client has (27.09, her word): English and Russian, switched in the header, remembered; a
# Russian browser starts in Russian. The screens are written in English; after each drawing, the words are put into
# Russian from i18n/ru.json (exact phrases) and a few patterns (phrases with numbers and names). What people wrote
# (titles, posts, logins) is marked translate="no" and never touched. Numbers are declined the Russian way.
import json as _json

_ru = _json.load(open(os.path.join(HERE, 'i18n', 'ru.json'), encoding='utf-8'))
_ru.pop('//', None)

js = swap(js, "// ---- asking the server:", r'''// ---- the language --------------------------------------------------------------------------------------------------
let LANG = (() => {
  try { const s = localStorage.getItem('cursed.lang'); if (s === 'ru' || s === 'en') return s; } catch (e) { /* no storage */ }
  return /^(ru|uk|be|kk)\b/i.test(navigator.language || '') ? 'ru' : 'en';
})();
const RU = ''' + _json.dumps(_ru, ensure_ascii=False, indent=0, sort_keys=True).replace('\n', ' ') + r''';
// Phrases with numbers and names in them.
const RU_RULES = [
  [/^(\d+) of (\d+)$/, (m, a, b) => `${a} из ${b}`],
  [/^For (\S+)$/, (m, v) => `Для ${v}`],
  [/^for (.+)$/, (m, v) => `для ${tr(v)}`],
  [/^made for (.+)$/, (m, v) => `сделан для ${tr(v)}`],
  [/^a version newer than (\S+) \(format (\d+)\)$/, (m, v, f) => `версии новее ${v} (формат ${f})`],
  [/^Publish (.+)$/, (m, v) => `Опубликовать ${v}`],
  [/^(\d+) more$/, (m, n) => `ещё ${n}`],
  [/^Adding pictures: (\d+) of (\d+)$/, (m, a, b) => `Добавляю картинки: ${a} из ${b}`],
  [/^(\S+) and newer$/, (m, v) => `${v} и новее`],
  [/^format (\d+)$/, (m, n) => `формат ${n}`],
  [/^formats (\d+)–(\d+)$/, (m, a, b) => `форматы ${a}–${b}`],
  [/^Hidden by moderation: (.+)$/, (m, why) => `Скрыто модерацией: ${why}`],
  [/^Picture (\d+)$/, (m, n) => `Картинка ${n}`],
  [/^Download (.+)$/, (m, v) => `Скачать ${v}`],
  [/^Edit (.+)$/, (m, v) => `Изменить ${v}`],
  [/^the picture doesn't decode \((.+)\)$/, (m, e) => `картинка не читается (${e})`],
  [/^the archive ends early or can't be read \((.+)\)$/, (m, e) => `архив обрывается или не читается (${e})`],
  [/^the clean copy couldn't be written \((.+)\)$/, (m, e) => `не удалось записать чистую копию (${e})`],
  [/^the pack was inside a folder \((.+)\)$/, (m, f) => `пак лежал внутри папки (${f})`],
  [/^made for (.+): Minecraft (\S+) will say it's for another version \(most of it usually still works\)$/, (m, v, g) => `сделан для ${tr(v)}: Minecraft ${g} скажет, что он для другой версии (обычно почти всё работает)`],
  [/^pack\.mcmeta doesn't say its versions the way (\S+) wants: (.+)$/, (m, g, why) => `pack.mcmeta указывает версии не так, как ждёт ${g}: ${why}`],
  [/^(\d+) textures over (\d+) px: (\d+) MB of the pack$/, (m, n, px, s) => `${n} ${plural(+n, 'текстура', 'текстуры', 'текстур')} больше ${px} px: ${s} МБ пака`],
  [/^(\d+) JSON files the game may not read: (.+)$/, (m, n, list) => `${n} ${plural(+n, 'JSON-файл', 'JSON-файла', 'JSON-файлов')}, которые игра может не прочитать: ${list}`],
  [/^the archive is bigger than (\d+) MB$/, (m, n) => `архив больше ${n} МБ`],
  [/^the pack is bigger than (\d+) MB unpacked$/, (m, n) => `пак больше ${n} МБ в распакованном виде`],
  [/^more than (\d+) files$/, (m, n) => `больше ${n} файлов`],
  [/^too many files \(the most is (\d+)\)$/, (m, n) => `слишком много файлов (не больше ${n})`],
  [/^(.+) inside the pack, named like something else$/, (m, w) => `${tr(w)} внутри пака под видом другого файла`],
  [/^up to (\d+) (uploads a day|uploads at once|packs|pictures)$/, (m, n, w) => `не больше ${n} ${{ 'uploads a day': 'загрузок в день', 'uploads at once': 'загрузок одновременно', packs: 'паков', pictures: 'картинок' }[w]}`],
  [/^a pack can be up to (\d+) MB$/, (m, n) => `пак — не больше ${n} МБ`],
  [/^(.+): (.+)$/, (m, a, b) => (RU[b] ? `${a}: ${RU[b]}` : m)],
];
function plural(n, one, few, many) {
  const a = Math.abs(n) % 100, b = a % 10;
  return a > 10 && a < 20 ? many : b > 1 && b < 5 ? few : b === 1 ? one : many;
}
const L = (en, ru) => (LANG === 'ru' ? ru : en);
function tr(s) {
  if (LANG !== 'ru' || !s) return s;
  if (RU[s] !== undefined) return RU[s];
  for (const [re, f] of RU_RULES) { const m = s.match(re); if (m) return f(...m); }
  return s;
}
const cap = (s) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : s);
// The words of a drawn screen into Russian: text, placeholders, labels. Not in [translate="no"], code or fields.
function translate(root) {
  if (LANG !== 'ru' || !root) return;
  const skip = (el) => el && el.closest('[translate="no"], script, style, textarea, code, .mono');
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const nodes = [];
  for (let n; (n = walker.nextNode());) nodes.push(n);
  for (const n of nodes) {
    const s = n.nodeValue, k = s.trim();
    if (!k || !/[A-Za-z]/.test(k) || skip(n.parentElement)) continue;
    const r = tr(k);
    if (r !== k) n.nodeValue = s.replace(k, r);
  }
  for (const el of [root, ...root.querySelectorAll('[placeholder], [aria-label], [title]')]) {
    if (!el.getAttribute || skip(el)) continue;
    for (const a of ['placeholder', 'aria-label', 'title']) { const v = el.getAttribute(a); if (v) { const r = tr(v); if (r !== v) el.setAttribute(a, r); } }
  }
}
function setLang(l) {
  LANG = l;
  try { localStorage.setItem('cursed.lang', l); } catch (e) { /* not kept */ }
  document.documentElement.lang = l;
  const sound = document.getElementById('sound');
  if (sound) sound.setAttribute('aria-label', L('Sound', 'Звук'));
  render(true);
  $app.animate([{ opacity: 0.35 }, { opacity: 1 }], { duration: 320, easing: 'cubic-bezier(.2, .7, .2, 1)' });
}

// ---- asking the server:''')

# The switch, in the header's corner.
js = swap(js, '''      <div class="who">${state.signedIn ?''', '''      <div class="who"><span class="lang" translate="no"><button class="w small ${LANG === 'en' ? 'on' : ''}" data-lang="en" aria-label="English">EN</button><button class="w small ${LANG === 'ru' ? 'on' : ''}" data-lang="ru" aria-label="Русский">RU</button></span>${state.signedIn ?''')
js = swap(js, '''  on('[data-copy]', 'click',''', '''  on('[data-lang]', 'click', (b) => { if (b.dataset.lang !== LANG) setLang(b.dataset.lang); });
  on('[data-copy]', 'click',''')
# After each drawing: the words.
js = swap(js, '''  wire();
  light();
  solidBar();
  if (keep) {''', '''  wire();
  light();
  solidBar();
  translate($app);
  if (keep) {''')

# Numbers, sizes, times and dates, the Russian way.
js = swap(js, "const fmt = (n) => (n >= 1000 ? (n / 1000).toFixed(n >= 10000 ? 0 : 1).replace(/\\.0$/, '') + 'k' : String(n));",
          "const fmt = (n) => (n >= 1000 ? (n / 1000).toFixed(n >= 10000 ? 0 : 1).replace(/\\.0$/, '').replace('.', LANG === 'ru' ? ',' : '.') + (LANG === 'ru' ? ' тыс.' : 'k') : String(n));")
js = swap(js, "const mb = (n) => (n >= 1e6 ? (n / 1e6).toFixed(n >= 1e7 ? 0 : 1) + ' MB' : Math.max(1, Math.round((n || 0) / 1e3)) + ' KB');",
          "const mb = (n) => { const s = n >= 1e6 ? (n / 1e6).toFixed(n >= 1e7 ? 0 : 1) + L(' MB', ' МБ') : Math.max(1, Math.round((n || 0) / 1e3)) + L(' KB', ' КБ'); return LANG === 'ru' ? s.replace('.', ',') : s; };")
js = swap(js, '''  if (d < 3600) return Math.max(1, Math.round(d / 60)) + ' min ago';
  if (d < 86400) return Math.round(d / 3600) + ' h ago';
  if (d < 86400 * 30) return Math.round(d / 86400) + ' d ago';
  return new Date(s * 1000).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });''', '''  if (d < 3600) return Math.max(1, Math.round(d / 60)) + L(' min ago', ' мин назад');
  if (d < 86400) return Math.round(d / 3600) + L(' h ago', ' ч назад');
  if (d < 86400 * 30) return Math.round(d / 86400) + L(' d ago', ' дн. назад');
  return new Date(s * 1000).toLocaleDateString(L('en-GB', 'ru-RU'), { day: 'numeric', month: 'short', year: 'numeric' });''')
js = swap(js, "const users = (n) => `${fmt(n)} ${n === 1 ? 'user' : 'users'}`;",
          "const users = (n) => `${fmt(n)} ${L(n === 1 ? 'user' : 'users', plural(n, 'пользователь', 'пользователя', 'пользователей'))}`;")
js = swap(js, "const when = (s) => new Date(s * 1000).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });",
          "const when = (s) => new Date(s * 1000).toLocaleDateString(L('en-GB', 'ru-RU'), { day: 'numeric', month: 'long', year: 'numeric' });")

# Phrases put together in the code: said in both languages where they are made.
js = swap(js, '''  const lines = [li(true, `${shader ? 'A shader pack' : 'A resource pack'} · safe · <span class="num">${fmt(f.files)}</span> files, ${mb(f.unpacked)} unpacked`)];''',
          '''  const lines = [li(true, L(`${shader ? 'A shader pack' : 'A resource pack'} · safe · <span class="num">${fmt(f.files)}</span> files, ${mb(f.unpacked)} unpacked`,
    `${shader ? 'Шейдерпак' : 'Ресурспак'} · безопасен · <span class="num">${fmt(f.files)}</span> ${plural(f.files, 'файл', 'файла', 'файлов')}, ${mb(f.unpacked)} в распакованном виде`))];''')
js = swap(js, '''  if (!shader) lines.push(g.fits ? li(true, `Built for ${GAME}`) : li(false, g.versions ? `Made for ${esc(g.versions)}: ${GAME} will call it another version` : 'pack.mcmeta doesn’t say its versions the way the game wants'));''',
          '''  if (!shader) lines.push(g.fits ? li(true, L(`Built for ${GAME}`, `Для ${GAME}`)) : li(false, g.versions ? L(`Made for ${esc(g.versions)}: ${GAME} will call it another version`, `Сделан для ${esc(tr(g.versions))}: ${GAME} назовёт его паком для другой версии`) : L('pack.mcmeta doesn’t say its versions the way the game wants', 'pack.mcmeta указывает версии не так, как ждёт игра')));''')
js = swap(js, "  const what = shader ? (f.features || []).join(', ') : (f.changes || []).map((x) => (CHANGE_NAMES[x] || x).toLowerCase()).join(', ');",
          "  const what = shader ? (f.features || []).map(tr).join(', ') : (f.changes || []).map((x) => tr(CHANGE_NAMES[x] || x).toLowerCase()).join(', ');")
js = swap(js, "${shader && f.options ? ` · <span class=\"num\">${f.options}</span> options` : ''}",
          "${shader && f.options ? ` · <span class=\"num\">${f.options}</span> ${L('options', plural(f.options, 'опция', 'опции', 'опций'))}` : ''}")
js = swap(js, "  (f.fixed || []).forEach((x) => lines.push(li(true, 'Fixed: ' + esc(x))));",
          "  (f.fixed || []).forEach((x) => lines.push(li(true, L('Fixed: ', 'Исправлено: ') + esc(tr(x)))));")
js = swap(js, "  if (left) lines.push(li(false, `Left out ${left} ${left === 1 ? 'file' : 'files'}: ${dropped.map(([why, d]) => `${esc(why)} (${d.count})`).join(', ')}`));",
          "  if (left) lines.push(li(false, `${L(`Left out ${left} ${left === 1 ? 'file' : 'files'}`, `Выкинуто ${left} ${plural(left, 'файл', 'файла', 'файлов')}`)}: ${dropped.map(([why, d]) => `${esc(tr(why))} (${d.count})`).join(', ')}`));")
js = swap(js, "  (f.warnings || []).filter((x) => !/^made for|doesn't say its versions/.test(x)).forEach((x) => lines.push(li(false, esc(x.charAt(0).toUpperCase() + x.slice(1)))));",
          "  (f.warnings || []).filter((x) => !/^made for|doesn't say its versions/.test(x)).forEach((x) => lines.push(li(false, esc(cap(tr(x))))));")
js = swap(js, '''      ${fixed.map((x) => `<li><span class="yes">✓</span><span>Fixed: ${esc(x)}</span></li>`).join('')}
      ${dropped.length ? `<li><span class="note">!</span><span>Left out ${left} ${left === 1 ? 'file' : 'files'}: ${dropped.map(([why, d]) => `${esc(why)} (${d.count})`).join(', ')}.''',
          '''      ${fixed.map((x) => `<li><span class="yes">✓</span><span>${L('Fixed: ', 'Исправлено: ')}${esc(tr(x))}</span></li>`).join('')}
      ${dropped.length ? `<li><span class="note">!</span><span>${L(`Left out ${left} ${left === 1 ? 'file' : 'files'}`, `Выкинуто ${left} ${plural(left, 'файл', 'файла', 'файлов')}`)}: ${dropped.map(([why, d]) => `${esc(tr(why))} (${d.count})`).join(', ')}.''')
js = swap(js, "      ${warn.map((x) => `<li><span class=\"note\">!</span><span>${esc(x.charAt(0).toUpperCase() + x.slice(1))}</span></li>`).join('')}",
          "      ${warn.map((x) => `<li><span class=\"note\">!</span><span>${esc(cap(tr(x)))}</span></li>`).join('')}")
js = swap(js, '''      <ul class="found"><li><span class="note">✕</span><span>${esc(r.message.charAt(0).toUpperCase() + r.message.slice(1))}''',
          '''      <ul class="found"><li><span class="note">✕</span><span>${esc(cap(tr(r.message)))}''')
js = swap(js, '''    ['Game', g.versions ? `${esc(g.versions)}${g.fits ? '' : ' <span class="ash">(not ' + GAME + ')</span>'}` : '<span class="ash">unreadable</span>']);''',
          '''    ['Game', g.versions ? `${esc(tr(g.versions))}${g.fits ? '' : ` <span class="ash">(${L('not', 'не')} ${GAME})</span>`}` : '<span class="ash">unreadable</span>']);''')
js = swap(js, "    ['Worlds', (f.dimensions || []).join(', ') || '—'],", "    ['Worlds', (f.dimensions || []).map(tr).join(', ') || '—'],")
js = swap(js, "  if (text && UP.phase === 'sending') text.innerHTML = `Sending · <span class=\"num\">${Math.floor((100 * UP.sent) / (UP.size || 1))}%</span> of ${mb(UP.size)}`;",
          "  if (text && UP.phase === 'sending') text.innerHTML = `${L('Sending', 'Отправка')} · <span class=\"num\">${Math.floor((100 * UP.sent) / (UP.size || 1))}%</span> ${L('of', 'из')} ${mb(UP.size)}`;")
js = swap(js, '''<span class="ash">${mb(r.size)} clean</span>''', '''<span class="ash">${mb(r.size)} ${L('clean', 'после проверки')}</span>''')
js = swap(js, "    if (m) m.textContent = UP.msg;", "    if (m) m.textContent = tr(UP.msg);")
js = swap(js, "      if (msg) msg.textContent = `Adding pictures: ${i + 1} of ${files.length}`;", "      if (msg) msg.textContent = tr(`Adding pictures: ${i + 1} of ${files.length}`);")
js = swap(js, "        if (msg) { msg.textContent = `${files[i].name}: ${d.message || SAY[d.error] || SAY.busy}`; msg.className = 'hint bad'; }",
          "        if (msg) { msg.textContent = `${files[i].name}: ${tr(d.message || SAY[d.error] || SAY.busy)}`; msg.className = 'hint bad'; }")
js = swap(js, "b.textContent = 'Copied';", "b.textContent = tr('Copied');")
js = swap(js, "    if (b.dataset.sure !== '1') { b.dataset.sure = '1'; b.textContent = 'Delete it?'; return; }", "    if (b.dataset.sure !== '1') { b.dataset.sure = '1'; b.textContent = tr('Delete it?'); return; }")
js = swap(js, "    msg.textContent = SAY[r.error] || SAY.busy; msg.className = 'hint bad';", "    msg.textContent = tr(SAY[r.error] || SAY.busy); msg.className = 'hint bad';")
js = swap(js, "  msg.textContent = r.error === 'wrong' ? 'The current password is wrong.' : SAY[r.error] || SAY.busy; msg.className = 'hint bad';",
          "  msg.textContent = tr(r.error === 'wrong' ? 'The current password is wrong.' : SAY[r.error] || SAY.busy); msg.className = 'hint bad';")
js = swap(js, "    loginH.textContent = '3–16: a–z, 0–9, _';", "    loginH.textContent = tr('3–16: a–z, 0–9, _');")
js = swap(js, "    passH.textContent = !pass.value || ok ? '10+ characters' : `${10 - pass.value.length} more`;", "    passH.textContent = tr(!pass.value || ok ? '10+ characters' : `${10 - pass.value.length} more`);")
js = swap(js, '''            <p class="ash when">By <span translate="no">${esc(a.author ? a.author.login : '—')}</span>. Reported by <span translate="no">${esc(r.by.login)}</span> · ${ago(r.created)}: “<span translate="no">${esc(r.why)}</span>”</p>''',
          '''            <p class="ash when">${L('By', 'Автор:')} <span translate="no">${esc(a.author ? a.author.login : '—')}</span>. ${L('Reported by', 'Жалоба от')} <span translate="no">${esc(r.by.login)}</span> · ${ago(r.created)}: “<span translate="no">${esc(r.why)}</span>”</p>''')
js = swap(js, "    state.fmsg = r.ok ? 'Reported. Thank you.' : r.message || SAY[r.error] || SAY.busy;", "    state.fmsg = tr(r.ok ? 'Reported. Thank you.' : r.message || SAY[r.error] || SAY.busy);")

# What people wrote stays as it is.
for a, b in [
    ('<div class="body"><div class="t">${esc(p.title)}</div>', '<div class="body"><div class="t" translate="no">${esc(p.title)}</div>'),
    ('<div class="m"><span class="k">${packKind(p)}</span><span>${esc(p.author.login)}</span>', '<div class="m"><span class="k">${packKind(p)}</span><span translate="no">${esc(p.author.login)}</span>'),
    ('<h2 class="big">${esc(first.title)}</h2>${first.blurb ? `<p class="lede">${esc(first.blurb)}</p>` : \'\'}', '<h2 class="big" translate="no">${esc(first.title)}</h2>${first.blurb ? `<p class="lede" translate="no">${esc(first.blurb)}</p>` : \'\'}'),
    ('<h1 class="giant ${p.title.length > 22 ? \'long\' : \'\'}">${esc(p.title)}</h1>', '<h1 class="giant ${p.title.length > 22 ? \'long\' : \'\'}" translate="no">${esc(p.title)}</h1>'),
    ('${p.blurb ? `<p class="lede">${esc(p.blurb)}</p>` : \'\'}', '${p.blurb ? `<p class="lede" translate="no">${esc(p.blurb)}</p>` : \'\'}'),
    ('<div class="block prose"><h2 class="sec">About</h2><div>${p.about.split', '<div class="block prose"><h2 class="sec">About</h2><div translate="no">${p.about.split'),
    ('<span>${esc(v.changelog) || \'<span class="ash">—</span>\'}</span>', '<span translate="no">${esc(v.changelog) || \'<span class="ash">—</span>\'}</span>'),
    ('${shots[n].caption ? `<p class="cap">', '${shots[n].caption ? `<p class="cap" translate="no">'),
    ('<a href="${packHref(p)}"><b>${esc(p.title)}</b></a></td>', '<a href="${packHref(p)}"><b translate="no">${esc(p.title)}</b></a></td>'),
    ('<a href="${packHref(p)}"><b>${esc(p.title)}</b>${stateOf(p)}', '<a href="${packHref(p)}"><b translate="no">${esc(p.title)}</b>${stateOf(p)}'),
    ('<div style="display:flex;flex-direction:column;gap:10px"><h1 class="giant">${esc(name)}</h1>', '<div style="display:flex;flex-direction:column;gap:10px"><h1 class="giant" translate="no">${esc(name)}</h1>'),
    ('<div class="crumb"><a href="${packHref(p)}">${esc(p.title)}</a> / Edit</div>', '<div class="crumb"><a href="${packHref(p)}" translate="no">${esc(p.title)}</a> / Edit</div>'),
    ('${pack ? `<div class="crumb"><a href="${packHref(pack)}">${esc(pack.title)}</a> / New version</div>` : \'\'}', '${pack ? `<div class="crumb"><a href="${packHref(pack)}" translate="no">${esc(pack.title)}</a> / New version</div>` : \'\'}'),
    ('<span><b>${m.name}</b><span>UID ${m.uid}</span></span>', '<span translate="no"><b>${m.name}</b><span>UID ${m.uid}</span></span>'),
]:
    js = swap(js, a, b)
# The rules in Russian too.
js = swap(js, "  const key = DOCS[which] ? which : 'rules', doc = DOCS[key];", "  const key = DOCS[which] ? which : 'rules', doc = (LANG === 'ru' && DOCS_RU[key]) || DOCS[key];")
js = swap(js, "const DOCS = {", r'''const DOCS_RU = {
  rules: {
    title: 'Правила', version: 'Обновлено 27 / 09 / 2026',
    sections: [
      ['Клиент', ['Cursed даётся как есть: без обещаний, что он всегда работает или вам подходит, и без ответственности за то, что он сломает. Вам должно быть 14 лет или больше.']],
      ['Ваш аккаунт', ['Он только ваш: пароль никому не давайте. Аккаунт, нарушающий эти правила, могут закрыть, и вам скажут почему.']],
      ['Что вы загружаете', ['Загруженное остаётся вашим. Загружая, вы разрешаете Cursed хранить это и выдавать участникам — всем или только тем, у кого ваши коды доступа. Загружайте только то, что сделали сами или можете распространять. Если что-то ваше загрузил кто-то другой, напишите .lunuca в Discord, и это уберут.']],
      ['Нельзя', ['Читы, реклама и украденная работа — в маркете, на форуме, где угодно на сайте.']],
      ['Изменения', ['Эти правила могут меняться; дата выше меняется вместе с ними.']],
    ],
  },
};
const DOCS = {''')
js = swap(js, '''      <div class="text"><p class="status" style="margin-bottom:34px">${doc.version}</p>''', '''      <div class="text" translate="no"><p class="status" style="margin-bottom:34px">${doc.version}</p>''')
js = swap(js, "    <div class=\"tabs\" style=\"padding-bottom:30px\">${Object.entries(DOCS).map(([k, d]) => `<a class=\"w ${k === key ? 'on' : ''}\" href=\"#/docs/${k}\">${d.title}</a>`).join('')}</div>",
          "    <div class=\"tabs\" style=\"padding-bottom:30px\">${Object.entries(DOCS).map(([k, d]) => `<a class=\"w ${k === key ? 'on' : ''}\" href=\"#/docs/${k}\">${tr(d.title)}</a>`).join('')}</div>")
js = swap(js, "    <div class=\"legal\"><nav aria-label=\"Sections\">${doc.sections.map(", "    <div class=\"legal\"><nav aria-label=\"Sections\" translate=\"no\">${doc.sections.map(")
# The page's language and the sound button's label from the start.
js = swap(js, "(async () => {\n  const first = hinted();", "document.documentElement.lang = LANG;\nif (document.getElementById('sound')) document.getElementById('sound').setAttribute('aria-label', L('Sound', 'Звук'));\n(async () => {\n  const first = hinted();")

i18n_css = '''
/* The language switch: two words in the header's corner. */
.lang { display: inline-flex; gap: 12px; margin-right: clamp(10px, 2vw, 28px); }
.lang .w.small { font-size: 12px; letter-spacing: .12em; }
@media (max-width: 980px) { .lang { margin-right: 6px; gap: 8px; } }
'''

# ---------------------------------------------------------------- avatars: their own, even a moving GIF
# A member may put their own picture in place of the head drawn from their login (her word, 27.09): uploaded on the
# dashboard, made anew by the server (a square, a GIF stays a GIF), shown wherever they are — the header, the forum,
# the market — and in the game. Taken off, the head of their login comes back.
js = swap(js, "const head = (name, size) => `<canvas class=\"head\" data-head=\"${esc(name)}\" style=\"width:${size}px;height:${size}px\" aria-hidden=\"true\"></canvas>`;",
          """// Members' own avatars, as every answer of the server that names someone tells them (by login, lower case).
const AV = {};
// Whose avatar is the head of their skin (the client sent it): drawn pixel-sharp, and "back to the head" is not offered.
const AVSKIN = new Set();
function learnAv(v) {
  if (!v || typeof v !== 'object') return;
  if (Array.isArray(v)) { v.forEach(learnAv); return; }
  if (typeof v.login === 'string' && 'avatar' in v) {
    const k = v.login.toLowerCase();
    if (v.avatar && v.avatar.url) { AV[k] = v.avatar.url; if (v.avatar.skin) AVSKIN.add(k); else AVSKIN.delete(k); } else { delete AV[k]; AVSKIN.delete(k); }
  }
  for (const k in v) if (v[k] && typeof v[k] === 'object') learnAv(v[k]);
}
const head = (name, size) => {
  const k = String(name).toLowerCase(), u = AV[k];
  return u ? `<img class="head av${AVSKIN.has(k) ? ' skin' : ''}" src="${esc(u)}" data-login="${esc(name)}" alt="" decoding="async" style="width:${size}px;height:${size}px" aria-hidden="true">`
    : `<canvas class="head" data-head="${esc(name)}" style="width:${size}px;height:${size}px" aria-hidden="true"></canvas>`;
};""")
js = swap(js, "  return r.ok ? { ok: true, data } : { ok: false, status: r.status, error: data.error || (r.status === 429 ? 'slow' : 'busy'), message: data.message };",
          "  if (r.ok) learnAv(data);\n  return r.ok ? { ok: true, data } : { ok: false, status: r.status, error: data.error || (r.status === 429 ? 'slow' : 'busy'), message: data.message };")
js = swap(js, '''        <div class="block"><h2 class="sec">Your packs</h2>${yourPacks()}</div>
      </div>
    </div>`;
}''', '''        <div class="block"><h2 class="sec">Your packs</h2>${yourPacks()}</div>
      </div>
      ${avatarBlock()}
    </div>`;
}
// The avatar: theirs, or the head of their skin (the client sends it), or the head of their login; a new one dropped on
// it or chosen, or the skin's head back.
function avatarBlock() {
  const m = me(), k = String(m.name).toLowerCase(), own = !!AV[k] && !AVSKIN.has(k), busy = state.avBusy;
  return `<div class="block avatar-block ${busy ? 'busy' : ''}" id="av-drop"><h2 class="sec">Avatar</h2>
        <div class="av-row"><div class="av-big">${head(m.name, 112)}</div>
          <div class="av-say"><p class="hint">PNG, JPEG, WebP or GIF, up to 6 MB. It is cut square from the middle; a GIF stays animated, here and in the game.</p>
            <p class="hint">Until you choose your own, it is the head of your skin: the client sends it.</p>
            <div class="acts"><label class="w small lead" for="av-file">${busy ? 'Uploading…' : own ? 'Change' : 'Upload'}</label><input id="av-file" type="file" accept="image/png,image/jpeg,image/webp,image/gif" hidden>${own ? '<button class="w small" id="av-reset">Use the skin’s head again</button>' : ''}</div>
            <p class="hint" id="av-msg" role="status">${esc(state.avMsg || '')}</p></div></div></div>`;
}
async function sendAvatar(file) {
  if (!file || state.avBusy) return;
  if (file.size > 6 * 1024 * 1024) { state.avMsg = tr('That picture is over 6 MB.'); render(true); return; }
  state.avBusy = true; state.avMsg = ''; render(true);
  let r = null, data = {};
  try {
    r = await fetch('/api/avatar', { method: 'POST', credentials: 'same-origin', cache: 'no-store', headers: { 'Content-Type': file.type || 'application/octet-stream' }, body: file });
    try { data = await r.json(); } catch (e) { /* not JSON */ }
  } catch (e) { r = null; }
  state.avBusy = false;
  if (r && r.ok) {
    learnAv({ login: me().name, avatar: data.avatar });
    if (state.user) state.user.avatar = data.avatar;
    state.avMsg = '';
    forget('forum', 'market', 'packs', 'me/packs');
  } else if (r && r.status === 401) { signOut(); location.hash = '#/signin'; return; }
  else state.avMsg = r ? (data.error === 'picture' && data.message ? tr('Not taken:') + ' ' + tr(data.message) : r.status === 429 ? tr('Too many changes today. Try tomorrow.') : SAY.busy) : SAY.offline;
  render(true);
}
async function dropAvatar() {
  const r = await api('avatar', null, 'DELETE');
  // What is left is the skin's head (or none): the site says which.
  if (r.ok) { const left = r.data && r.data.avatar || null; learnAv({ login: me().name, avatar: left }); if (state.user) state.user.avatar = left; forget('forum', 'market', 'packs', 'me/packs'); }
  state.avMsg = r.ok ? '' : SAY[r.error] || SAY.busy;
  render(true);
}''')
js = swap(js, "  on('#signout', 'click', async () => { await api('logout', {}); signOut(); got.clear(); location.hash = '#/home'; });",
          """  on('#signout', 'click', async () => { await api('logout', {}); signOut(); got.clear(); location.hash = '#/home'; });
  on('#av-file', 'change', (i) => { const f = i.files && i.files[0]; i.value = ''; sendAvatar(f); });
  on('#av-reset', 'click', () => dropAvatar());
  on('#av-drop', 'dragover', (b, e) => { e.preventDefault(); b.classList.add('over'); });
  on('#av-drop', 'dragleave', (b) => b.classList.remove('over'));
  on('#av-drop', 'drop', (b, e) => { e.preventDefault(); b.classList.remove('over'); const f = e.dataTransfer && e.dataTransfer.files[0]; if (f) sendAvatar(f); });""")
avatar_css = r"""
/* Avatars: their own picture where the head of their login was; smooth, not pixel-sharp. The dashboard's block. */
.head.av { image-rendering: auto; object-fit: cover; display: inline-block; vertical-align: middle; }
.head.av.skin { image-rendering: pixelated; }
.avatar-block .av-row { display: flex; gap: clamp(18px, 3vw, 36px); align-items: center; flex-wrap: wrap; }
.avatar-block .av-big { flex: none; transition: transform .45s var(--ease), filter .3s; }
.avatar-block.over .av-big { transform: scale(1.06); filter: brightness(1.15); }
.avatar-block.busy .av-big { animation: av-breathe 1.2s var(--ease) infinite; }
.avatar-block .av-say { flex: 1; min-width: 220px; max-width: 520px; }
@keyframes av-breathe { 50% { filter: brightness(.7); transform: scale(.97); } }
"""
# ---------------------------------------------------------------- nothing of the old left behind
# ('invite' was here: the old invitation codes are gone; a group's invitation (03.10) is a word of its own now.)
for word in ['CRSD', 'rivate Minecraft', 'screenAt', 'goScreen', 'pvOpen ?', 'OPEN_UNTIL}', 'syncInvite', 'shapeCode',
             'paid()', 'subscri', 'Subscri', 'Pricing', 'pricing', '₽', 'trial', 'Chargeback', 'giveaway', 'GIFTS', 'KEY-', 'PLANS', 'This computer', 'binding', 'noSub', 'keyBox', 'refund', 'Refund',
             'ITEMS', 'ASHFALL', "item('", 'IMG[', 'viewLook', 'dashCodes', 'dashStats', 'REPORTS', 'MY_PACKS', 'SPARK', 'state.type', 'state.res', 'THREADS', 'ONLINE', 'CAT_COLOUR', 'const FORUM']:
    left = [m.start() for m in re.finditer(re.escape(word), js)]
    if left:
        ctx = js[max(0, left[0] - 80):left[0] + 80].replace('\n', ' ')
        print(f'  still there: {word!r} x{len(left)} … {ctx}')
# ---------------------------------------------------------------- the beta: its places, its bans (30.09)
# Registration takes as many as the beta has places (15, hers not counted): past that the server says "full". A banned
# account signs in nowhere, and is told why and until when.
js = swap(js, "  offline: 'No connection. Try again.', busy:", "  full: 'The beta is full.', banned: 'This account is banned.',\n  offline: 'No connection. Try again.', busy:")
js = swap(js, "error: data.error || (r.status === 429 ? 'slow' : 'busy'), message: data.message };", "error: data.error || (r.status === 429 ? 'slow' : 'busy'), message: data.message, reason: data.reason, until: data.until };")
js = swap(js, "    msg.textContent = tr(SAY[r.error] || SAY.busy); msg.className = 'hint bad';", """    msg.textContent = r.error === 'banned' ? bannedWords(r) : r.error === 'full' ? L('The beta is full: no places left.', 'Места в бете закончились.') : r.error === 'ip-limit' ? L('Too many accounts from this IP.', 'С этого IP создано слишком много аккаунтов.') : tr(SAY[r.error] || SAY.busy); msg.className = 'hint bad';""")
js = swap(js, "async function enter(f) {", """const bannedWords = (r) => L('This account is banned', 'Этот аккаунт забанен') + (r.reason ? ': ' + r.reason : '') + '. '
  + (r.until ? L('Until ', 'До ') + new Date(r.until * 1000).toLocaleString(L('en-GB', 'ru-RU'), { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }) + '.' : L('For good.', 'Навсегда.'));
async function enter(f) {""")

# ---------------------------------------------------------------- the loader for testers (01.10)
# A tester (and she) sees the loader's download above the account block; the server sends it only to them.
js = swap(js, """        <div class="block"><h2 class="sec">Account</h2>${kv(account())}""", """        ${state.user && state.user.tester ? `<div class="block"><h2 class="sec">Cursed</h2><p class="hint">For Windows 10 and 11.</p><div class="acts"><a class="w menu lead" href="/api/dist/loader" id="get-loader">Download Cursed</a></div></div>` : ''}
        <div class="block"><h2 class="sec">Account</h2>${kv(account())}""")

# ---------------------------------------------------------------- people: profiles, badges, notifications (02.10.2026)
# The new screens are files of their own (social/*.js, social.css), put into app.js just before its start, so the router
# knows them; what follows only hooks them in: the router's map, the bar (the bell, the way to one's profile), the
# dashboard's rail and pages, the sign-in and -out (the live line), and every person the forum draws (prefix, accent).
SOCIAL = os.path.join(STUB, 'social')
social_js = '\n'.join(open(os.path.join(SOCIAL, n), encoding='utf-8').read() for n in ['core.js', 'profile.js', 'settings.js', 'friends.js', 'configs.js', 'forum.js', 'forum3.js', 'forum4.js', 'support.js', 'admin.js'])
js = swap(js, "const solidBar = () => {", social_js + "\n\nconst solidBar = () => {")
js = swap(js, "forum: viewForum, admin: viewAdmin, docs: viewDocs, license: viewDocs };",
          "forum: viewForum, admin: viewAdmin, docs: viewDocs, license: viewDocs, u: viewProfile, notifications: viewNotifications, badges: viewBadges, friends: viewFriends, support: viewSupport, news: viewNews };")
js = swap(js, "author: viewAuthor, register:", "author: viewProfile, register:")
js = swap(js, "  wire();\n  light();", "  wire();\n  socialWire();\n  light();")
js = swap(js, "if (route === 'admin' && state.signedIn && !(state.user && state.user.admin)) {",
          "if (route === 'admin' && state.signedIn && !(state.user && (state.user.admin || (state.user.perms || []).includes('staff.panel')))) {")
js = swap(js, """<a class="me" href="#/dashboard/overview"><span translate="no"><b>${m.name}</b>""",
          """${bell()}<a class="me" href="#/u/${encodeURIComponent(m.name)}"><span translate="no"><b>${state.user && state.user.card ? pfx(state.user.card) : ''}${m.name}</b>""")
js = swap(js, """${link('page', 'My page', 'author/' + encodeURIComponent(me().name))}${state.user && state.user.admin ? `""",
          """${link('page', 'My page', 'u/' + encodeURIComponent(me().name))}<span class="gap"></span>${link('profile', 'Profile')}${link('configs', 'Configs')}${link('notify', 'Notifications')}${link('sessions', 'Sessions')}<span class="gap"></span>${link('support', 'Support', 'support')}${state.user && (state.user.admin || (state.user.perms || []).includes('staff.panel')) ? `""")
js = swap(js, "const body = { overview: dashOverview, packs: dashPacks }[tab] || dashOverview;",
          "const body = { overview: dashOverview, packs: dashPacks, profile: dashProfile, configs: dashConfigs, notify: dashNotify, sessions: dashSessions }[tab] || dashOverview;")
js = swap(js, "function signIn(u) { state.user = u; state.role = 'member'; hint(true); }",
          "function signIn(u) { state.user = u; state.role = 'member'; hint(true); setUnread(u.unread || 0); socialStart(); socialMeta(); }")
js = swap(js, "function signOut() { state.user = null; state.role = 'guest'; state.pwOpen = false; hint(false); }",
          "function signOut() { state.user = null; state.role = 'guest'; state.pwOpen = false; hint(false); socialStop(); }")
# The staff's panel: its link, and the news among the first links of the dashboard.
js = swap(js, "<span class=\"gap\"></span>${link('admin', 'Moderation', 'admin/reports')}", "<span class=\"gap\"></span>${link('admin', 'Staff', 'admin')}")
js = swap(js, "${link('overview', 'Overview')}${link('packs', 'My packs')}", "${link('overview', 'Overview')}${link('news', 'News', 'news')}${link('packs', 'My packs')}")
social_css = ''.join(open(os.path.join(SOCIAL, n), encoding='utf-8').read() for n in ['social.css', 'friends.css', 'forum.css', 'forum3.css', 'forum4.css', 'support.css', 'admin.css'])
# Friends in the bar, between the forum and the dashboard, with the count of unread messages.
js = swap(js, "nav('market', 'Market') + nav('forum', 'Forum') + nav('dashboard', 'Dashboard')", "nav('market', 'Market') + nav('forum', 'Forum') + navFriends() + nav('dashboard', 'Dashboard')")

# The pack's emoji, as the site shows them: whole (/e/), and small for lines of text (/e/s/, 48 px).
EMOJI_SRC = os.path.join(os.path.expanduser('~'), 'Cursed-Bot', 'assets', 'emoji')
os.makedirs(os.path.join(DIST, 'e', 's'), exist_ok=True)
from PIL import Image, ImageSequence
EMOJI_SHEETS = {}
for n in sorted(os.listdir(EMOJI_SRC)):
    if not n.endswith('.gif'):
        continue
    shutil.copy(os.path.join(EMOJI_SRC, n), os.path.join(DIST, 'e', n))
    im = Image.open(os.path.join(EMOJI_SRC, n))
    frames, times = [], []
    for f in ImageSequence.Iterator(im):
        frames.append(f.convert('RGBA').resize((48, 48), Image.LANCZOS))
        times.append(f.info.get('duration', im.info.get('duration', 60)))
    frames[0].save(os.path.join(DIST, 'e', 's', n), save_all=True, append_images=frames[1:], duration=times, loop=0, disposal=2, optimize=True)
    # For the client, which draws a moving picture from a sheet of its frames (as the avatars): 64 px, rows of eight.
    big = [f.convert('RGBA').resize((64, 64), Image.LANCZOS) for f in ImageSequence.Iterator(Image.open(os.path.join(EMOJI_SRC, n)))]
    cols = min(8, len(big))
    rows = (len(big) + cols - 1) // cols
    sheet = Image.new('RGBA', (cols * 64, rows * 64), (0, 0, 0, 0))
    for i, f in enumerate(big):
        sheet.paste(f, ((i % cols) * 64, (i // cols) * 64))
    os.makedirs(os.path.join(DIST, 'e', 'sheet'), exist_ok=True)
    sheet.save(os.path.join(DIST, 'e', 'sheet', n[:-4] + '.png'), optimize=True)
    EMOJI_SHEETS[n[:-4]] = {'sheet': f'/e/sheet/{n[:-4]}.png', 'frames': len(big), 'cols': cols, 'rows': rows, 'size': 64, 'delays': [max(20, int(d or 60)) for d in times]}
open(os.path.join(DIST, "e", "sheets.json"), "w", encoding="utf-8").write(_json.dumps(EMOJI_SHEETS, separators=(',', ':')))

# Text UIDs (03.10.2026): the member's text UID is shown wherever the number was; an admin gives themselves one in the
# account (the number stays theirs underneath).
for a, b in [
    ("const me = () => (state.user ? { name: state.user.login, uid: state.user.uid } : ME.member);",
     "const me = () => (state.user ? { name: state.user.login, uid: state.user.uid_text || state.user.uid } : ME.member);"),
    ("['UID', `<span class=\"num\">${u.uid}</span>`]", "['UID', uidCell(u)]"),
    ("const pwForm = () =>", """const uidCell = (u) => `<span class="num" translate="no">${esc(String(u.uid_text || u.uid))}</span>${u.uid_self ? ` <button class="w small ${state.uidOpen ? 'on' : ''}" id="uid-open" style="margin-left:10px">${L('Change', 'Сменить')}</button>` : ''}${u.uid_self && state.uidOpen ? uidForm(u) : ''}`;
const uidForm = (u) => `<form class="form" id="uid-form" style="margin-top:14px;max-width:420px">
          <div><input class="in" id="uid-text" maxlength="16" autocomplete="off" spellcheck="false" placeholder="${L('Text UID', 'Текстовый UID')}" value="${esc(u.uid_text || '')}">
          <p class="hint">${L(`2–16 Latin letters, digits, _ . -, with a letter. Empty: the number again (${u.uid}).`, `2–16 латинских букв, цифр, _ . -, хотя бы одна буква. Пусто — снова номер (${u.uid}).`)}</p></div>
          <div class="acts"><button class="w lead" type="submit">${L('Save', 'Сохранить')}</button></div><p class="hint" id="uid-msg" role="status"></p></form>`;
async function newTextUid(f) {
  const msg = document.getElementById('uid-msg'), go = f.querySelector('button[type="submit"]');
  go.disabled = true; msg.textContent = ''; msg.className = 'hint';
  const r = await api('me/uid', { text: document.getElementById('uid-text').value.trim() });
  go.disabled = false;
  if (r.ok) { state.user.uid_text = r.data.uid_text || null; if (state.user.card) state.user.card.uid_text = state.user.uid_text; state.uidOpen = false; render(true); return; }
  msg.textContent = r.error === 'taken' ? L('This UID is taken.', 'Этот UID занят.') : r.error === 'format' ? L('2–16 Latin letters, digits, _ . -, with a letter.', '2–16 латинских букв, цифр, _ . -, хотя бы одна буква.') : SAY[r.error] || SAY.busy;
  msg.className = 'hint bad';
}
const pwForm = () =>"""),
    ("  on('#pw-open', 'click', () => { state.pwOpen = !state.pwOpen; render(true); });\n  on('#signout', 'click', async () => { await api('logout', {}); signOut(); got.clear(); location.hash = '#/home'; });",
     "  on('#pw-open', 'click', () => { state.pwOpen = !state.pwOpen; render(true); });\n  on('#uid-open', 'click', () => { state.uidOpen = !state.uidOpen; render(true); });\n  on('form#uid-form', 'submit', (f, ev) => { ev.preventDefault(); newTextUid(f); });\n  on('#signout', 'click', async () => { await api('logout', {}); signOut(); got.clear(); location.hash = '#/home'; });"),
    ("const uid = items[0] ? items[0].author.uid : null,", "const uid = items[0] ? (items[0].author.uid_text || items[0].author.uid) : null,"),
]:
    js = swap(js, a, b)

# ---------------------------------------------------------------- referral links (09.10.2026)
# Media, partners and admins have links of their own (cursedclient.xyz/r/<code>; nginx sends it on to /?ref=<code>):
# their page is the dashboard's Referrals (social/refs.js, refs.css); a visitor's code is kept for 30 days and given
# with the registration, whose page shows the owner of a personal link.
js = swap(js, "const solidBar = () => {", open(os.path.join(SOCIAL, 'refs.js'), encoding='utf-8').read() + "\n\nconst solidBar = () => {")
social_css += open(os.path.join(SOCIAL, 'refs.css'), encoding='utf-8').read()
js = swap(js, "${link('page', 'My page', 'u/' + encodeURIComponent(me().name))}<span class=\"gap\"></span>",
          "${link('page', 'My page', 'u/' + encodeURIComponent(me().name))}${refsRail(link)}<span class=\"gap\"></span>")
js = swap(js, "function viewDashboard(tab) {\n",
          "function viewDashboard(tab) {\n  if (String(tab || '').split('/')[0] === 'refs') return `<div class=\"dash\">${rail('refs')}<div>${viewRefs(String(tab).split('/').slice(1).join('/'))}</div></div>`;\n")
js = swap(js, "  socialWire();\n  light();", "  socialWire();\n  refsWire();\n  light();")
js = swap(js, "key: state.route === 'register' ? state.arg : '' })", "key: state.route === 'register' ? state.arg : '', ref: refCode() })")
js = swap(js, "  const who = await api('me');\n  signIn(who.ok ? who.data : r.data);", "  if (reg) refDone();\n  const who = await api('me');\n  signIn(who.ok ? who.data : r.data);")
js = swap(js, '<div class="form-side"><h1 class="big">Register</h1>', '<div class="form-side"><h1 class="big">Register</h1>${refInvite()}')
js = swap(js, "(async () => {\n  const first = hinted();", "refCatch();\n(async () => {\n  const first = hinted();")

# An address that leads nowhere has a page of its own (forum 3.0, social/forum3.js), not the front page.
js = swap(js, "views[route] || viewHome", "views[route] || viewNotFound")
open(os.path.join(DIST, 'app.js'), 'w', encoding='utf-8', newline='\n').write(js)
if '/img/' not in js:
    shutil.rmtree(os.path.join(DIST, 'img'))  # the preview's made-up pictures: nothing shows them now

# ---------------------------------------------------------------- the fonts, ours
for n in ['Unbounded', 'Manrope']:
    shutil.copy(os.path.join(FONTS, f'{n}.ttf'), os.path.join(DIST, 'fonts', f'{n}.ttf'))
    shutil.copy(os.path.join(FONTS, f'OFL-{n}.txt'), os.path.join(DIST, 'fonts', f'OFL-{n}.txt'))
ua = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Safari/537.36'}
css = urllib.request.urlopen(urllib.request.Request('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500&display=swap', headers=ua), timeout=20).read().decode()
mono_faces = []
for subset, body in re.findall(r'/\* ([a-z-]+) \*/\s*@font-face \{(.*?)\}', css, re.S):
    if subset not in ('latin', 'cyrillic') or 'font-weight: 400' not in body:
        continue
    url = re.search(r'url\((.*?)\)', body).group(1)
    rng = re.search(r'unicode-range: (.*?);', body).group(1)
    name = f'JetBrainsMono-{subset}.woff2'
    open(os.path.join(DIST, 'fonts', name), 'wb').write(urllib.request.urlopen(urllib.request.Request(url, headers=ua), timeout=30).read())
    mono_faces.append(f'@font-face {{ font-family: "JetBrains Mono"; src: url("/fonts/{name}") format("woff2"); font-weight: 100 800; font-display: swap; unicode-range: {rng}; }}')
open(os.path.join(DIST, 'fonts', 'OFL-JetBrainsMono.txt'), 'w', encoding='utf-8').write(
    'JetBrains Mono — SIL Open Font License 1.1, https://github.com/JetBrains/JetBrainsMono/blob/master/OFL.txt\n')
assert len(mono_faces) == 2, mono_faces
faces = '\n'.join([
    '@font-face { font-family: "Unbounded"; src: url("/fonts/Unbounded.ttf") format("truetype"); font-weight: 200 900; font-display: swap; }',
    '@font-face { font-family: "Manrope"; src: url("/fonts/Manrope.ttf") format("truetype"); font-weight: 200 800; font-display: swap; }',
    *mono_faces,
])

# ---------------------------------------------------------------- the music
shutil.copy(os.path.join(STUB, 'music', 'air.m4a'), os.path.join(DIST, 'music', 'air.m4a'))
shutil.copy(os.path.join(STUB, 'site.js'), os.path.join(DIST, 'site.js'))
sound_css = '''
/* A living picture shows once its first frame is drawn; the title only once the eclipse behind it is there. */
.hero:has(> canvas.sky:not(.lit)) .wordmark.lit { opacity: 0; }
canvas.sky, canvas.eyes, .eye-side canvas { opacity: 0; transition: opacity .3s; }
.hero > canvas.sky { transition-duration: 1.2s; }
canvas.sky.lit, canvas.eyes.lit, .eye-side canvas.lit { opacity: 1; }
/* The eclipse sinks into the dark at its foot instead of ending on a line: a gradient laid over its lowest part
   (a mask on the whole moving canvas cost the video card a second full-screen pass every frame). */
.hero::after { content: ""; position: absolute; left: 0; right: 0; bottom: 0; height: 14%; z-index: -1; pointer-events: none;
  background: linear-gradient(rgba(4,3,3,0), rgba(4,3,3,.4) 57%, rgba(4,3,3,.82) 86%, var(--ink)); }
/* The browser's own parts dark too: its light scrollbar was the only white left on the site. */
:root { color-scheme: dark; scrollbar-color: #2B2C3D var(--ink); }
/* The sound: bars in the corner, dancing to the music while it plays, resting low when it is off. */
#sound { position: fixed; z-index: 40; right: max(22px, env(safe-area-inset-right)); bottom: max(22px, env(safe-area-inset-bottom)); display: flex; align-items: flex-end; gap: 3px; height: 22px; padding: 8px; margin: -8px; border: 0; background: none; cursor: pointer; -webkit-tap-highlight-color: transparent; }
#sound i { display: block; width: 3px; height: 100%; border-radius: 2px; background: var(--ash); transform-origin: 50% 100%; transform: scaleY(0.18); transition: background-color .35s; }
#sound:hover i, #sound.on i { background: var(--glow); }
'''

sound_css += market_css + forum_css + i18n_css + avatar_css + social_css

page = f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="color-scheme" content="dark">
<title>Cursed</title>
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="192x192" href="/icon-192.png">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<style>
{faces}
</style>
<style>{style}{sound_css}</style>
</head>
<body>
<div id="app"></div>
{shaders}
<button id="sound" type="button" aria-label="Sound" aria-pressed="false"><i></i><i></i><i></i><i></i><i></i></button>
<script src="/app.js" defer></script>
<script src="/site.js" defer></script>
</body>
</html>
'''
open(os.path.join(DIST, 'index.html'), 'w', encoding='utf-8', newline='\n').write(page)
total = sum(os.path.getsize(os.path.join(r, f)) for r, _, fs in os.walk(DIST) for f in fs)
print('built', len(os.listdir(os.path.join(DIST, 'img'))) if os.path.isdir(os.path.join(DIST, 'img')) else 0, 'pictures; app.js', os.path.getsize(os.path.join(DIST, 'app.js')), 'B; all', total, 'B')
