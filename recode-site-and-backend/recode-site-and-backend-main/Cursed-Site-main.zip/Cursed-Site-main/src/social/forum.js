// ================================================================================================ the forum (03.10.2026)
// The forum's second floor (site/server/src/forum2.rs): bugs with their status (and "fixed in build N"), ideas voted
// for, questions with the answer marked; posts with formatting, pictures pasted or dropped in, YouTube cards, the
// pack's emoji as reactions, the history of edits; threads followed; @logins offered while they are typed; drafts kept
// in this browser; staff warn and mute. These screens replace the first forum's (build.py keeps of it only what the
// market's reports share).

const FO = { filter: {}, sort: {}, react: 0, hist: 0, history: null, staff: '', staffWhy: '', staffMin: 60, preview: {}, mention: null, uploaded: {}, uploading: 0, pic: null, edit: 0, editText: '', msg: '', bad: false, drafts: {} };
try { FO.drafts = JSON.parse(localStorage.getItem('cursed.forum.drafts') || '{}') || {}; } catch (e) { FO.drafts = {}; }
let foKeep = 0;
/** A draft of this browser's: read (no value), or kept (an empty one forgotten). */
function foDraft(key, value) {
  if (value === undefined) return FO.drafts[key] || '';
  if (value) FO.drafts[key] = value; else delete FO.drafts[key];
  clearTimeout(foKeep);
  foKeep = setTimeout(() => { try { localStorage.setItem('cursed.forum.drafts', JSON.stringify(FO.drafts)); } catch (e) { /* not kept */ } }, 300);
  return value;
}

// ---- statuses

const BUG_ST = { new: ['New', 'Новый'], confirmed: ['Confirmed', 'Подтверждён'], fixed: ['Fixed', 'Исправлен'], wontfix: ['Won’t be fixed', 'Не будет исправлен'], duplicate: ['Duplicate', 'Дубликат'] };
const IDEA_ST = { open: ['Open', 'Открыта'], planned: ['Planned', 'В планах'], doing: ['In the works', 'В работе'], done: ['Done', 'Сделано'], declined: ['Declined', 'Отклонена'] };
const stOf = (cat) => (cat === 'bugs' ? BUG_ST : cat === 'ideas' ? IDEA_ST : {});
const stTone = (s) => ({ confirmed: 'cream', planned: 'cream', doing: 'cream', fixed: 'ok', done: 'ok', solved: 'ok', wontfix: 'warn', declined: 'warn' })[s] || 'dim';
function stChip(t) {
  if (!t.status || t.status === 'open') return '';
  let s = stOf(t.category)[t.status] ? L(...stOf(t.category)[t.status]) : t.status === 'solved' ? L('Solved', 'Решено') : '';
  if (t.category === 'bugs' && t.status === 'fixed') s = t.fixed_in ? L(`Fixed in build ${t.fixed_in}`, `Исправлен в сборке ${t.fixed_in}`) : L('Fixed: comes with the next build', 'Исправлен: войдёт в следующую сборку');
  return s ? `<span class="st ${stTone(t.status)}">${s}</span>` : '';
}
const votesWord = (n) => L(`${n} ${n === 1 ? 'vote' : 'votes'}`, `${n} ${plural(n, 'голос', 'голоса', 'голосов')}`);

// ---- a post, drawn

const YT_ID = /(?:youtube\.com\/(?:watch\?(?:[^\s&]*&(?:amp;)?)*v=|shorts\/|embed\/)|youtu\.be\/)([A-Za-z0-9_-]{11})(?![A-Za-z0-9_-])/g;
/** A post as its author typed it, drawn: paragraphs, quotes, **bold**, *italic*, ||spoilers||, `code` and ``` blocks,
 *  links, @logins, pictures on lines of their own, YouTube cards under it. Escaped first: nothing typed becomes HTML. */
function prose(text, post) {
  const pics = Object.assign({}, FO.uploaded, (post && post.pictures) || {});
  const kept = [];
  const keep = (html) => `\u0001${kept.push(html) - 1}\u0002`;
  const inline = (s) => {
    s = s.replace(/`([^`\n]+)`/g, (m, c) => keep(`<code>${c}</code>`));
    s = s.replace(/\bhttps?:\/\/[^\s<\u0001\u0002]+[^\s<.,;:!?)\]'"\u0001\u0002]/g, (u) => keep(`<a href="${u}" target="_blank" rel="noopener nofollow ugc">${u}</a>`));
    s = s.replace(/(^|[\s(])@([A-Za-z0-9_]{3,16})\b/g, (m, pre, who) => `${pre}${keep(`<a class="at" href="${profHref(who)}">@${who}</a>`)}`);
    s = s.replace(/\|\|(.+?)\|\|/g, (m, x) => `<span class="spoiler" tabindex="0" role="button" aria-label="${L('Spoiler', 'Спойлер')}">${x}</span>`);
    s = s.replace(/\*\*(?!\s)(.+?)\*\*/g, '<b>$1</b>');
    s = s.replace(/(^|[^*\w])\*(?![\s*])(.+?)\*(?!\w)/g, '$1<i>$2</i>');
    return s;
  };
  const out = [];
  esc(text).split(/```(?:[a-z0-9+-]*\n)?([\s\S]*?)```/).forEach((part, i) => {
    if (i % 2) { out.push(`<pre><code>${part.replace(/\n$/, '')}</code></pre>`); return; }
    for (const block of part.split(/\n{2,}/)) {
      let para = [], quote = [];
      const flushP = () => { if (para.length) out.push(`<p>${para.join('<br>')}</p>`); para = []; };
      const flushQ = () => { if (quote.length) out.push(`<blockquote>${quote.join('<br>')}</blockquote>`); quote = []; };
      for (const l of block.split('\n')) {
        const pic = l.trim().match(/^\[img:([0-9a-f]{16})\]$/);
        if (pic) {
          flushP(); flushQ();
          const p = pics[pic[1]];
          out.push(p ? `<button class="fo-pic" data-fo-pic="${esc(p.url)}" aria-label="${L('Open the picture', 'Открыть картинку')}"><img src="${esc(p.url)}"${p.thumb ? ` srcset="${esc(p.thumb)} 480w, ${esc(p.url)} ${p.w}w" sizes="(max-width: 700px) 90vw, 620px"` : ''} alt="" loading="lazy" style="aspect-ratio:${p.w}/${p.h}"></button>` : `<p class="ash fo-pic-gone">${L('A picture', 'Картинка')}</p>`);
        } else if (l.startsWith('&gt;')) { flushP(); quote.push(inline(l.replace(/^&gt; ?/, ''))); } else { flushQ(); para.push(inline(l)); }
      }
      flushP(); flushQ();
    }
  });
  let html = out.join('');
  for (let k = 0; k < 3 && /\u0001\d+\u0002/.test(html); k++) html = html.replace(/\u0001(\d+)\u0002/g, (m, n) => kept[n]);
  const cards = post && post.cards ? [...new Set([...String(text).matchAll(YT_ID)].map((m) => m[1]))].filter((v) => post.cards[v]) : [];
  return html + cards.map((v) => { const c = post.cards[v]; return `<a class="fo-card" href="https://www.youtube.com/watch?v=${v}" target="_blank" rel="noopener nofollow">${c.thumb ? `<img src="${esc(c.thumb)}" alt="" loading="lazy">` : ''}<span><b>${esc(c.title)}</b><span class="ash">${esc(c.author)}${c.author ? ' · ' : ''}YouTube</span></span></a>`; }).join('');
}

// ---- the editor: a box with its tools, the @ list, the preview

const QUOTE_ICON = '<path d="M5 7h5v5c0 2.8-1.6 4.6-4.5 5.5M14 7h5v5c0 2.8-1.6 4.6-4.5 5.5"/>';
const SPOILER_ICON = '<path d="M2.5 12s3.5-6.5 9.5-6.5S21.5 12 21.5 12s-3.5 6.5-9.5 6.5S2.5 12 2.5 12Z"/><path d="m4 4 16 16"/>';
function editor(id, value, rows, placeholder) {
  const tool = (act, label, inner) => `<button type="button" class="fo-tool" data-fo-tool="${act}" data-for="${id}" title="${label}" aria-label="${label}">${inner}</button>`;
  const on = FO.preview[id];
  return `<div class="fo-editor ${on ? 'previewing' : ''}" data-editor="${id}">
    <div class="fo-tools">${tool('bold', L('Bold', 'Жирный'), '<b>B</b>')}${tool('italic', L('Italic', 'Курсив'), '<i>I</i>')}${tool('spoiler', L('Spoiler', 'Спойлер'), frIcon(SPOILER_ICON))}${tool('code', L('Code', 'Код'), '<span class="mono">&lt;/&gt;</span>')}${tool('quote', L('Quote', 'Цитата'), frIcon(QUOTE_ICON))}${tool('picture', L('A picture', 'Картинка'), frIcon(ICON_PICTURE))}
      <span class="gap"></span><button type="button" class="fo-tool fo-prev" data-fo-preview="${id}">${on ? L('Write', 'Писать') : L('Preview', 'Как будет')}</button></div>
    <textarea class="in" id="${id}" rows="${rows}" maxlength="10000" placeholder="${esc(placeholder || L('**Bold**, *italic*, ||spoiler||, `code`, > quote, @login. Paste or drop a picture.', '**Жирный**, *курсив*, ||спойлер||, `код`, > цитата, @логин. Картинку можно вставить или перетащить.'))}">${esc(value)}</textarea>
    ${on ? `<div class="fo-preview prose post-body" translate="no">${prose(value) || `<p class="ash">${L('Nothing yet.', 'Пока пусто.')}</p>`}</div>` : ''}
    <div class="fo-mention" role="listbox" hidden></div><p class="hint fo-up" role="status"></p>
  </div>`;
}

// ---- the list of threads

function topicRow(t, cats, rowStyle) {
  const c = catOf(cats, t.category);
  const marks = `${stChip(t)}${t.category === 'ideas' ? `<span class="st cream">${votesWord(t.votes || 0)}</span>` : ''}${t.pinned ? '<span class="st cream">Pinned</span>' : ''}${t.locked ? '<span class="st warn">Closed</span>' : ''}${t.state === 'hidden' ? '<span class="st cream">Hidden</span>' : ''}`;
  const last = t.last && t.last.by && t.replies > 0 ? `<span class="last-by">${head(t.last.by.login, 18)}<span class="u-link" data-u="${esc(t.last.by.login)}" translate="no">${esc(t.last.by.login)}</span></span>` : '';
  // Its category's colour (forum 4.0: the line at its edge when hovered), with its turn to come in.
  const turn = /style="([^"]*)"/.exec(rowStyle || '');
  const style = ` style="--c:${esc(c.colour || '#BFC0E7')};${turn ? turn[1] : ''}"`;
  return `<a class="topic ${t.unread ? 'unread' : ''}" href="#/forum/t/${t.id}"${style}>${head(t.author.login, 40)}<span><b translate="no">${esc(t.title)}</b>
      <span class="in-cat">${sq(c.colour)}<span>${esc(c.name)}</span> · ${pfx(t.author)}<span class="u-link" data-u="${esc(t.author.login)}" translate="no"${t.author.accent ? ` style="color:${esc(t.author.accent)}"` : ''}>${esc(t.author.login)}</span>${marks}</span></span>
      <span class="n num"><b>${t.replies}</b><span class="when">${last}${ago(t.last.at)}</span></span></a>`;
}
function forumTabs(active) {
  const tab = (id, name, to) => `<a class="w ${active === id ? 'on' : ''}" href="#/forum${to}">${name}</a>`;
  return `<div class="tabs" style="padding-bottom:26px">${tab('index', 'Categories', '')}${tab('latest', 'Latest', '/latest')}
    <span class="right forum-tools"><label class="sr" for="fq">Search the forum</label><input class="in" id="fq" type="search" placeholder="Search the forum" value="${esc(state.fq)}"><a class="w lead" href="#/forum/new${state.fcat ? '/' + state.fcat : ''}">New thread</a></span></div>`;
}
const FILTERS = {
  bugs: [['', 'All', 'Все'], ...Object.entries(BUG_ST).map(([k, v]) => [k, ...v])],
  ideas: [['', 'All', 'Все'], ...Object.entries(IDEA_ST).map(([k, v]) => [k, ...v])],
  help: [['', 'All', 'Все'], ['unsolved', 'Waiting for an answer', 'Ждут ответа'], ['solved', 'Solved', 'Решённые']],
};
const SORTS = [['top', 'Most votes', 'Больше голосов'], ['new', 'Newest', 'Новые'], ['', 'Active', 'Активные']];

function viewForum(arg) {
  const [part, x, y] = String(arg || '').split('/');
  if (part === 't') return viewThread(Number(x), Number(y) || 0);
  if (part === 'new') return viewNewThread(x || '');
  state.fcat = part === 'c' ? x : '';
  const front = ask('forum');
  const cats = front.ok ? front.data.categories : [];
  const el = f3Enter('forum/' + String(arg || ''));
  const list = (c, none) => (waiting(c) ? '<div class="rows"><div>&nbsp;</div></div>' : !c.ok ? trouble(c) : c.data.items.length ? c.data.items.map((t, i) => topicRow(t, cats, f3Row(i, el))).join('') : `<div class="empty">${none}</div>`);
  if (state.fqLive) {
    const c = ask('forum/threads?q=' + encodeURIComponent(state.fqLive));
    return `<h1 class="sr">Forum</h1>${forumTabs('search')}<div class="forum-one">${list(c, 'Nothing found.')}</div>`;
  }
  if (part === 'c' || part === 'latest') {
    const page = Number(part === 'c' ? y : x) || 1;
    const status = part === 'c' ? FO.filter[x] || '' : '', sort = part === 'c' && x === 'ideas' ? (FO.sort.ideas === undefined ? 'top' : FO.sort.ideas) : '';
    const c = ask(`forum/threads?${part === 'c' ? 'cat=' + encodeURIComponent(x) + '&' : ''}page=${page}${status ? '&status=' + status : ''}${sort ? '&sort=' + sort : ''}`);
    const cat = part === 'c' ? catOf(cats, x) : null;
    const pages = c.ok ? Math.ceil(c.data.total / c.data.per_page) : 1;
    const base = part === 'c' ? `#/forum/c/${x}/` : '#/forum/latest/';
    const filters = cat && FILTERS[x] ? `<div class="acts fo-filter">${FILTERS[x].map(([k, en, ru]) => `<button class="w small ${status === k ? 'on' : ''}" data-fo-filter="${x}:${k}">${L(en, ru)}</button>`).join('')}
        ${x === 'ideas' ? `<span class="gap"></span>${SORTS.map(([k, en, ru]) => `<button class="w small ${sort === k ? 'on' : ''}" data-fo-sort="${k}">${L(en, ru)}</button>`).join('')}` : ''}</div>` : '';
    return `<h1 class="sr">${cat ? esc(cat.name) : 'Latest'}</h1>${forumTabs(part === 'c' ? 'cat' : 'latest')}
      ${cat ? f4CatHead(cat, filters, el) : ''}
      <div class="forum-one${f3Cls(el)}">${list(c, status ? L('Nothing with this status.', 'С таким статусом ничего нет.') : 'No threads yet.')}
      ${pages > 1 ? `<div class="acts pager">${page > 1 ? `<a class="w" href="${base}${page - 1}">Back</a>` : ''}<span class="ash num">${page} of ${pages}</span>${page < pages ? `<a class="w" href="${base}${page + 1}">More</a>` : ''}</div>` : ''}</div>`;
  }
  if (waiting(front)) return `<h1 class="sr">Forum</h1>${forumTabs('index')}<div class="forum"><div class="rows"><div>&nbsp;</div></div><div></div></div>`;
  if (!front.ok) return trouble(front);
  const f = front.data;
  const threads = f.categories.reduce((n, c) => n + (c.threads || 0), 0), posts = f.categories.reduce((n, c) => n + (c.posts || 0), 0);
  const lastOf = (id) => f.latest.find((t) => t.category === id);
  // Forum 4.0: the scene over it, its categories as cards, the latest under them (social/forum4.js).
  return `<h1 class="sr">Forum</h1>${f4Hero(f, threads, posts, el)}${forumTabs('index')}
    <div class="f4-cats${f3Cls(el)}">${f.categories.map((c, i) => f4Cat(c, lastOf(c.id), i, el)).join('')}</div>
    <div class="f4-latest${f3Cls(el)}"><div class="colhead"><span>Latest</span><span>Replies</span></div>
      ${f.latest.length ? f.latest.map((t, i) => topicRow(t, f.categories, f3Row(i + 3, el))).join('') : '<div class="empty" style="padding:40px 0">Nothing yet. Start the first thread.</div>'}</div>`;
}

// ---- a thread

/** The thread on screen, as last answered. */
function foThread() {
  const id = Number(String(state.arg).split('/')[1]);
  const [, t] = [...got.entries()].find(([k, v]) => (k === `forum/threads/${id}` || k.startsWith(`forum/threads/${id}?`)) && v.ok) || [];
  return t ? t.data : null;
}

function foPost(t, p, n, mod, mineThread) {
  const me_ = state.user && state.user.uid;
  const editing = FO.edit === p.id, first = n === 1, answer = t.solution === p.id;
  const reporting = state.freport && state.freport.kind === 'post' && state.freport.id === p.id, hiding = state.fhide === 'post:' + p.id;
  let body;
  if (p.state === 'deleted') body = '<p class="ash">Taken back by its author.</p>';
  else if (p.state === 'hidden' && !p.body) body = '<p class="ash">Hidden by moderation.</p>';
  else if (editing) body = `<div class="form post-form">${editor('fo-edit', FO.editText, 6)}<div class="acts"><button class="w small lead" data-fo-save="${p.id}" data-submit-for="fo-edit">Save</button><button class="w small" data-fo-cancel="1">Cancel</button></div></div>`;
  else body = `${p.state === 'hidden' ? `<p class="st cream">Hidden by moderation${p.hidden_why ? ': ' + esc(p.hidden_why) : ''}</p>` : ''}<div class="prose post-body" translate="no">${prose(p.body, p)}</div>`;
  const reacts = (p.reactions || []).map((r) => `<button class="fr-react ${r.uids.includes(me_) ? 'on' : ''}" data-fo-react="${p.id}:${esc(r.emoji)}">${emo(r.emoji, 20)}<span class="num">${r.uids.length}</span></button>`).join('');
  const picker = FO.react === p.id ? `<div class="fr-picker">${(SOC.meta ? SOC.meta.emoji : []).map((e) => `<button data-fo-react="${p.id}:${esc(e)}">${emo(e, 26)}</button>`).join('')}</div>` : '';
  const canAnswer = t.category === 'help' && !first && (mineThread || mod) && p.state === 'shown';
  const acts = p.state === 'shown' && !editing ? [
    !t.locked || mod ? `<button class="w small" data-fo-quote="${p.id}">Reply</button>` : '',
    `<button class="w small fo-react-open" data-fo-react-open="${p.id}" title="${L('React', 'Реакция')}" aria-label="${L('React', 'Реакция')}">${emo('c_heart', 16)}</button>`,
    canAnswer ? `<button class="w small" data-fo-answer="${answer ? 0 : p.id}">${answer ? L('Not the answer', 'Это не ответ') : L('This is the answer', 'Это ответ')}</button>` : '',
    p.mine ? `<button class="w small" data-fo-edit="${p.id}">Edit</button><button class="w small" data-fdel="${p.id}">Delete</button>` : `<button class="w small" data-freport="post:${p.id}">Report</button>`,
    mod && !p.mine ? `<button class="w small" data-fhide="post:${p.id}">Hide</button><button class="w small" data-fo-staff="warn:${p.id}">${L('Warn', 'Предупредить')}</button><button class="w small" data-fo-staff="mute:${p.id}">${L('Mute', 'Мут')}</button>` : '',
  ].join('') : mod && p.state === 'hidden' ? `<button class="w small" data-funhide="post:${p.id}">Unhide</button>` : '';
  let inline = reporting ? inlineAsk('f-report-why', 'What is wrong with it?', 'Report it', 'post:' + p.id, 'freport-go') : hiding ? inlineAsk('f-hide-why', 'Why (its author sees this)', 'Hide it', 'post:' + p.id, 'fhide-go') : '';
  const [staffKind, staffPost] = FO.staff.split(':');
  if (Number(staffPost) === p.id) {
    inline = `<div class="form hide-form fo-staff"><input class="in" id="fo-staff-why" maxlength="300" placeholder="${staffKind === 'warn' ? L('What for (they see this)', 'За что (человек это увидит)') : L('Why (they see this)', 'Почему (человек это увидит)')}" value="${esc(FO.staffWhy)}">
      ${staffKind === 'mute' ? `<select class="in small-select" id="fo-staff-min" aria-label="${L('For how long', 'На сколько')}">${[[60, '1 hour', '1 час'], [360, '6 hours', '6 часов'], [1440, '1 day', '1 день'], [4320, '3 days', '3 дня'], [10080, '7 days', '7 дней'], [43200, '30 days', '30 дней']].map(([m, en, ru]) => `<option value="${m}" ${FO.staffMin === m ? 'selected' : ''}>${L(en, ru)}</option>`).join('')}</select>` : ''}
      <div class="acts"><button class="w small lead" data-fo-staff-go="${esc(p.author.login)}">${staffKind === 'warn' ? L('Warn', 'Предупредить') : L('Mute on the forum', 'Замутить на форуме')}</button><button class="w small" data-fo-staff-no="1">Cancel</button></div></div>`;
  }
  const edited = p.edited ? (p.mine || mod) && p.edits ? `<button class="fo-edited" data-fo-hist="${p.id}" title="${esc(new Date(p.edited * 1000).toLocaleString())}">${L('edited', 'изменено')}</button>` : `<span title="${esc(new Date(p.edited * 1000).toLocaleString())}">${L('edited', 'изменено')}</span>` : '';
  const hist = FO.hist === p.id ? `<div class="fo-hist">${!FO.history ? `<p class="ash">${L('Loading…', 'Загрузка…')}</p>` : FO.history.map((v) => `<div class="fo-ver"><span class="ash">${L('Before', 'До')} · ${esc(new Date(v.at * 1000).toLocaleString())}</span><div class="prose post-body" translate="no">${prose(v.body, p)}</div></div>`).join('') || `<p class="ash">${L('No earlier versions.', 'Других версий нет.')}</p>`}</div>` : '';
  return `<div class="review post ${p.new ? 'new' : ''} ${answer ? 'answer' : ''} ${first ? 'op' : ''}" id="p${p.id}"${FO.rowStyle ? FO.rowStyle(n) : ''}>${head(p.author.login, 48)}<div>
      <div class="top">${nm(p.author, { status: true })}<span>${ago(p.created)}</span>${edited}${answer ? `<span class="st ok">${L('The answer', 'Ответ')}</span>` : ''}<a class="num" href="#/forum/t/${t.id}/${t.page}" data-jump="p${p.id}">#${n}</a></div>
      ${body}${reacts ? `<div class="fr-reacts">${reacts}</div>` : ''}${picker}<div class="acts post-acts">${acts}</div>${inline}${hist}</div></div>`;
}

function viewThread(id, page) {
  const c = ask(`forum/threads/${id}${page ? '?page=' + page : ''}`);
  const front = ask('forum'), cats = front.ok ? front.data.categories : [];
  if (waiting(c)) return `<div class="thread"><div class="crumb"><a href="#/forum">Forum</a></div><h1 class="big ghost-t">&nbsp;</h1></div>`;
  if (!c.ok) return `<div class="page-head"><h1 class="giant">Not found</h1><p class="ash">This thread is gone, hidden, or never was.</p><div><a class="w" href="#/forum">The forum</a></div></div>`;
  const t = c.data, cat = catOf(cats, t.category), mod = t.moderator, mineThread = state.user && t.author.uid === state.user.uid;
  const el = f3Enter('thread/' + t.id + '/' + t.page);
  FO.rowStyle = (n) => f3Row(n - (t.page - 1) * 30 - 1, el);
  const posts = t.posts.map((p, i) => foPost(t, p, (t.page - 1) * 30 + i + 1, mod, mineThread)).join('');
  FO.rowStyle = null;
  // Who took part (on this page), most posts first; the thread's author leads.
  const took = new Map();
  for (const p of t.posts) if (p.author && p.state !== 'deleted') { const k = p.author.login; const v = took.get(k) || { who: p.author, n: 0 }; v.n++; took.set(k, v); }
  const people = [...took.values()].sort((a, b) => (b.who.login === t.author.login) - (a.who.login === t.author.login) || b.n - a.n);
  const more = ask(`forum/threads?cat=${encodeURIComponent(t.category)}&page=1`);
  const others = more.ok ? more.data.items.filter((x) => x.id !== t.id).slice(0, 5) : [];
  const lastPost = t.posts.length ? t.posts[t.posts.length - 1].id : 0;
  const toLast = t.page < t.pages ? `#/forum/t/${t.id}/${t.pages}` : '';
  const side = `<aside class="th-side${f3Cls(el)}">
      <div class="side-block"><h3 class="side-h">${L('Started by', 'Автор темы')}</h3>
        <a class="side-author" href="${profHref(t.author.login)}" data-u="${esc(t.author.login)}">${head(t.author.login, 56)}<span>${pfx(t.author)}<b translate="no"${t.author.accent ? ` style="color:${esc(t.author.accent)}"` : ''}>${esc(t.author.login)}</b><span class="ash num">${ago(t.created)}</span></span></a></div>
      <div class="side-block side-facts"><div><b class="num">${t.replies}</b><span>${L(t.replies === 1 ? 'reply' : 'replies', plural(t.replies, 'ответ', 'ответа', 'ответов'))}</span></div>
        ${t.category === 'ideas' ? `<div><b class="num">${t.votes}</b><span>${L(t.votes === 1 ? 'vote' : 'votes', plural(t.votes, 'голос', 'голоса', 'голосов'))}</span></div>` : ''}
        <div><b class="num">${took.size}</b><span>${L(took.size === 1 ? 'member here' : 'members here', plural(took.size, 'участник', 'участника', 'участников'))}</span></div></div>
      ${people.length ? `<div class="side-block"><h3 class="side-h">${L('Took part', 'Участвуют')}</h3><div class="side-people">${people.slice(0, 12).map((v) => `<a href="${profHref(v.who.login)}" data-u="${esc(v.who.login)}" title="${esc(v.who.login)}">${head(v.who.login, 36)}<span class="num">${v.n}</span></a>`).join('')}</div></div>` : ''}
      ${others.length ? `<div class="side-block"><h3 class="side-h">${L('More in', 'Ещё в разделе')} <span>${esc(cat.name)}</span></h3>${others.map((x) => `<a class="side-topic" href="#/forum/t/${x.id}">${head(x.author.login, 22)}<span><b translate="no">${esc(x.title)}</b><span class="ash num">${x.replies} · ${ago(x.last.at)}</span></span></a>`).join('')}</div>` : ''}
    </aside>`;
  const pager = t.pages > 1 ? `<div class="acts pager">${t.page > 1 ? `<a class="w" href="#/forum/t/${t.id}/${t.page - 1}">Back</a>` : ''}<span class="ash num">${t.page} of ${t.pages}</span>${t.page < t.pages ? `<a class="w" href="#/forum/t/${t.id}/${t.page + 1}">More</a>` : ''}</div>` : '';
  const hidingThread = state.fhide === 'thread:' + t.id, reportingThread = state.freport && state.freport.kind === 'thread' && state.freport.id === t.id;
  const states = stOf(t.category);
  const own = [
    t.category === 'ideas' ? `<button class="w small ${t.voted ? 'on' : 'lead'}" data-fo-vote="1">${t.voted ? L('Voted', 'Голос отдан') : L('Vote for it', 'Голосовать')} · <span class="num">${t.votes}</span></button>` : '',
    `<button class="w small ${t.following ? 'on' : ''}" data-fo-follow="${t.following ? 0 : 1}" title="${t.following ? L('You hear of every reply. Click to stop.', 'Вы узнаёте о каждом ответе. Нажмите, чтобы отписаться.') : L('Hear of every reply', 'Узнавать о каждом ответе')}">${t.following ? L('Following', 'Вы подписаны') : L('Follow', 'Подписаться')}</button>`,
    mineThread || mod ? `<button class="w small" data-frename="1">Rename</button>` : '',
    !mineThread && !mod ? `<button class="w small" data-freport="thread:${t.id}">Report</button>` : '',
  ].join('');
  const staff = mod ? `${Object.keys(states).length ? `<label class="sr" for="fo-status">${L('Status', 'Статус')}</label><select class="in small-select" id="fo-status">${Object.entries(states).map(([k, v]) => `<option value="${k}" ${k === t.status ? 'selected' : ''}>${L(...v)}</option>`).join('')}</select>` : ''}
      <button class="w small" data-fpin="${t.pinned ? 0 : 1}">${t.pinned ? 'Unpin' : 'Pin'}</button><button class="w small" data-flock="${t.locked ? 0 : 1}">${t.locked ? 'Open' : 'Close'}</button>
      <label class="sr" for="f-move">Move to</label><select class="in small-select" id="f-move">${cats.map((x) => `<option value="${x.id}" ${x.id === t.category ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select>
      ${t.state === 'hidden' ? '<button class="w small" data-funhide="thread:' + t.id + '">Unhide</button>' : `<button class="w small" data-fhide="thread:${t.id}">Hide</button>`}` : '';
  const replyKey = 't:' + t.id;
  const chips = `${stChip(t)}${t.pinned ? '<span class="st cream">Pinned</span>' : ''}${t.locked ? '<span class="st warn">Closed</span>' : ''}${t.state === 'hidden' ? `<span class="st cream">Hidden by moderation${t.hidden_why ? ': ' + esc(t.hidden_why) : ''}</span>` : ''}`;
  return `<div class="thread-wrap"><div class="thread${f3Cls(el)}">
      <div class="crumb"><a href="#/forum">Forum</a> / <a href="#/forum/c/${cat.id}">${esc(cat.name)}</a></div>
      ${state.frename ? `<div class="form" style="max-width:760px"><input class="in" id="f-title" maxlength="120" value="${esc(state.frenametext)}"><div class="acts"><button class="w small lead" data-frename-go="1">Save</button><button class="w small" data-frename-no="1">Cancel</button></div></div>`
        : `<h1 class="big" translate="no">${esc(t.title)}</h1>`}
      <div class="by">${chips ? `<span>${chips}</span>` : ''}
        <span class="ash">${L('Started by', 'Автор —')} ${nm(t.author)} · ${ago(t.created)} · <span class="num">${t.replies}</span> ${L(t.replies === 1 ? 'reply' : 'replies', plural(t.replies, 'ответ', 'ответа', 'ответов'))}</span>
        ${t.replies > 2 ? `<a class="w small to-last" href="${toLast || '#/forum/t/' + t.id + '/' + t.page}" ${toLast ? '' : ` data-jump="p${lastPost}"`}>${L('To the last reply', 'К последнему ответу')}</a>` : ''}</div>
      <div class="acts thread-tools">${own}</div>
      ${staff ? `<div class="acts thread-tools fo-staff-tools"><span class="ash">${L('Staff', 'Персонал')}</span>${staff}</div>` : ''}
      ${hidingThread ? inlineAsk('f-hide-why', 'Why (its author sees this)', 'Hide it', 'thread:' + t.id, 'fhide-go') : ''}
      ${reportingThread ? inlineAsk('f-report-why', 'What is wrong with it?', 'Report it', 'thread:' + t.id, 'freport-go') : ''}
      ${state.fmsg && !state.freport ? `<p class="hint ${FO.bad ? 'bad' : 'ok'}">${esc(state.fmsg)}</p>` : ''}
      ${pager}<div class="posts">${posts}</div>${pager}
      ${t.locked && !mod ? '<p class="st warn" style="margin-top:28px">This thread is closed.</p>'
        : `<div class="form reply-box"><label class="lab" for="fo-reply">Your reply</label>${editor('fo-reply', foDraft(replyKey), 5)}
          <div class="acts"><button class="w menu lead" data-fo-post="${t.id}" data-submit-for="fo-reply">Post</button></div><p class="hint ${FO.bad ? 'bad' : ''}" id="f-msg" role="status">${esc(FO.msg)}</p></div>`}
      ${FO.pic ? `<div class="lightbox" id="fo-lightbox"><img src="${esc(FO.pic)}" alt=""><button class="w small lb-close" id="fo-lb-close">Close</button></div>` : ''}
    </div>${side}</div>`;
}

function viewNewThread(cat) {
  const front = ask('forum');
  const cats = front.ok ? front.data.categories.filter((c) => !c.closed || (state.user && (state.user.admin || (state.user.perms || []).includes('announce')))) : [];
  let category = foDraft('n:cat') || cat;
  if (cat && cat !== category) category = foDraft('n:cat', cat);
  if (!cats.some((c) => c.id === category) && cats[0]) category = cats.find((c) => c.id === 'help') ? 'help' : cats[0].id;
  const about = { bugs: L('What happens, what you expected, how to make it happen again. A screenshot helps. You hear when it is fixed.', 'Что происходит, чего вы ждали, как это повторить. Скриншот помогает. Когда исправят — придёт уведомление.'), ideas: L('One idea per thread: others vote for it.', 'Одна идея — одна тема: за неё голосуют.'), help: L('Ask: whoever answers best gets the answer marked.', 'Спрашивайте: лучший ответ можно отметить.') }[category] || '';
  return `<div class="thread"><div class="crumb"><a href="#/forum">Forum</a> / New thread</div><h1 class="big">New thread</h1>
    <div class="form" style="max-width:760px;margin-top:28px">
      <div><label class="lab" for="n-cat">Category</label><select class="in" id="n-cat" data-fo-n="cat">${cats.map((c) => `<option value="${c.id}" ${c.id === category ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select>${about ? `<p class="hint">${about}</p>` : ''}</div>
      <div><label class="lab" for="n-title">Title</label><input class="in" id="n-title" data-fo-n="title" maxlength="120" value="${esc(foDraft('n:title'))}"></div>
      <div><label class="lab" for="n-body">Text</label>${editor('n-body', foDraft('n:body'), 9)}</div>
      <div class="acts"><button class="w menu lead" id="fo-start" data-cat="${esc(category)}" data-submit-for="n-body">Post</button><a class="w menu" href="#/forum">Cancel</a></div>
      <p class="hint bad" id="n-msg" role="status">${esc(FO.msg)}</p></div></div>`;
}

// ---- what the forum says when it refuses

function foFault(r) {
  if (r.error === 'muted' && r.until) {
    const until = new Date(r.until * 1000).toLocaleString(LANG === 'ru' ? 'ru-RU' : 'en-GB', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' });
    const why = String(r.message || '').replace(/^.*?: /, '');
    return L(`You can’t post on the forum until ${until}: ${why}`, `Писать на форуме нельзя до ${until}: ${why}`);
  }
  if (r.error === 'slow') return L('Too fast: a post every 8 seconds, a thread every 30.', 'Слишком быстро: пост раз в 8 секунд, тема раз в 30.');
  if (r.error === 'locked') return L('This thread is closed.', 'Тема закрыта.');
  if (r.error === 'pictures') return L('Ten pictures in a post at most.', 'Не больше десяти картинок в посте.');
  if (r.error === 'quota') return L('Your uploads take all of your 300 MB: remove some in your profile first.', 'Ваши загрузки заняли все 300 МБ: сначала удалите что-нибудь в профиле.');
  return tr(r.message || SAY[r.error] || SAY.busy);
}

// ---- the editor at work

/** Text put into a box at its caret (or around what is selected), kept as its draft, the box left as it was. */
function foInsert(box, before, after, wholeLines) {
  if (!box) return;
  const a = box.selectionStart, b = box.selectionEnd, v = box.value;
  let sel = v.slice(a, b), start = a, end = b;
  if (wholeLines) {
    start = v.lastIndexOf('\n', a - 1) + 1;
    end = b === a ? (v.indexOf('\n', b) < 0 ? v.length : v.indexOf('\n', b)) : b;
    sel = v.slice(start, end);
    const quoted = sel.split('\n').map((l) => '> ' + l).join('\n');
    box.value = v.slice(0, start) + quoted + v.slice(end);
    box.setSelectionRange(start, start + quoted.length);
  } else {
    box.value = v.slice(0, start) + before + sel + after + v.slice(end);
    box.setSelectionRange(start + before.length, start + before.length + sel.length);
  }
  box.focus();
  box.dispatchEvent(new Event('input', { bubbles: true }));
}

/** A picture uploaded for a post: its token put in at the caret of the box it is for. */
async function foUpload(boxId, file) {
  const box = document.getElementById(boxId);
  if (!box || !file || !/^image\//.test(file.type || '')) return;
  const say = box.closest('.fo-editor') && box.closest('.fo-editor').querySelector('.fo-up');
  FO.uploading++;
  if (say) { say.textContent = L('Uploading the picture…', 'Загрузка картинки…'); say.className = 'hint fo-up'; }
  let r = null, data = {};
  try {
    r = await fetch('/api/forum/pictures' + (boxId.startsWith('tk-') ? '?for=ticket' : ''), { method: 'POST', credentials: 'same-origin', cache: 'no-store', headers: { 'Content-Type': file.type || 'application/octet-stream' }, body: file });
    try { data = await r.json(); } catch (e) { /* not JSON */ }
  } catch (e) { r = null; }
  FO.uploading--;
  const now = document.getElementById(boxId) || box;
  if (r && r.ok && data.picture) {
    FO.uploaded[data.picture.id] = data.picture;
    const v = now.value, at = now.selectionStart;
    const pre = at > 0 && v[at - 1] !== '\n' ? '\n' : '', post = v[at] === '\n' ? '' : '\n';
    now.setSelectionRange(at, at);
    foInsert(now, `${pre}[img:${data.picture.id}]${post}`, '');
    if (say) say.textContent = '';
  } else if (say) {
    say.textContent = r ? foFault({ error: data.error || (r.status === 429 ? 'slow' : 'busy'), message: data.message, until: data.until }) : SAY.offline;
    say.className = 'hint fo-up bad';
  }
}

/** The @ list under a box: logins starting with what is typed after the @ before its caret. */
let foFindTimer = 0;
function foMention(box) {
  const list = box.closest('.fo-editor') && box.closest('.fo-editor').querySelector('.fo-mention');
  if (!list) return;
  const m = box.value.slice(0, box.selectionStart).match(/(^|[\s(])@([A-Za-z0-9_]{1,16})$/);
  if (!m) { list.hidden = true; FO.mention = null; return; }
  const q = m[2];
  clearTimeout(foFindTimer);
  foFindTimer = setTimeout(async () => {
    const r = await api('people/find?q=' + encodeURIComponent(q));
    if (!r.ok || !r.data.people.length || box.value.slice(0, box.selectionStart).match(/@([A-Za-z0-9_]{1,16})$/)?.[1] !== q) { list.hidden = true; FO.mention = null; return; }
    FO.mention = { box: box.id, q, people: r.data.people, sel: 0 };
    foMentionDraw(list);
  }, 140);
}
function foMentionDraw(list) {
  const m = FO.mention;
  list.innerHTML = m.people.map((p, i) => `<button type="button" class="${i === m.sel ? 'on' : ''}" data-fo-at="${esc(p.login)}" role="option">${head(p.login, 22)}${pfx(p)}<b translate="no">${esc(p.login)}</b></button>`).join('');
  list.hidden = false;
  list.querySelectorAll('canvas[data-head]').forEach(drawHead);
  list.querySelectorAll('[data-fo-at]').forEach((b) => b.addEventListener('mousedown', (e) => { e.preventDefault(); foMentionPick(b.dataset.foAt); }));
}
function foMentionPick(login) {
  const m = FO.mention, box = m && document.getElementById(m.box);
  if (!box) return;
  const at = box.selectionStart, from = at - m.q.length, v = box.value;
  box.value = v.slice(0, from) + login + ' ' + v.slice(at);
  box.setSelectionRange(from + login.length + 1, from + login.length + 1);
  box.focus();
  box.dispatchEvent(new Event('input', { bubbles: true }));
  FO.mention = null;
  const list = box.closest('.fo-editor').querySelector('.fo-mention');
  if (list) list.hidden = true;
}

/** Selected words of a post quoted into the reply. */
function foQuote(login, text) {
  const t = foThread();
  if (!t) return;
  const key = 't:' + t.id;
  const quoted = text.trim().slice(0, 600).split('\n').map((l) => '> ' + l).join('\n');
  foDraft(key, `${foDraft(key) ? foDraft(key).replace(/\s*$/, '\n\n') : ''}> @${login}\n${quoted}\n\n`);
  render(true);
  const box = document.getElementById('fo-reply');
  if (box) { box.focus(); box.setSelectionRange(box.value.length, box.value.length); box.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
}

/** The editors of the screen at work: the @ list, Ctrl+B/I, Ctrl+Enter (its box's button), pictures pasted and
 *  dropped, the tools, the preview. The forum's and the tickets'. */
function foEditorsWire(on) {
  on('.fo-editor textarea', 'input', (el) => foMention(el));
  on('.fo-editor textarea', 'click', (el) => foMention(el));
  on('.fo-editor textarea', 'blur', (el) => setTimeout(() => { const l = el.closest('.fo-editor') && el.closest('.fo-editor').querySelector('.fo-mention'); if (l) l.hidden = true; FO.mention = null; }, 120));
  on('.fo-editor textarea', 'keydown', (el, e) => {
    const m = FO.mention;
    if (m && m.box === el.id) {
      const list = el.closest('.fo-editor').querySelector('.fo-mention');
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); m.sel = (m.sel + (e.key === 'ArrowDown' ? 1 : m.people.length - 1)) % m.people.length; foMentionDraw(list); return; }
      if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); foMentionPick(m.people[m.sel].login); return; }
      if (e.key === 'Escape') { list.hidden = true; FO.mention = null; return; }
    }
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && (e.key === 'b' || e.key === 'i')) { e.preventDefault(); foInsert(el, e.key === 'b' ? '**' : '*', e.key === 'b' ? '**' : '*'); }
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); const go = $app.querySelector(`[data-submit-for="${el.id}"]`); if (go) go.click(); }
  });
  on('.fo-editor textarea', 'paste', (el, e) => {
    const files = [...((e.clipboardData && e.clipboardData.files) || [])].filter((f) => /^image\//.test(f.type));
    if (!files.length) return;
    e.preventDefault();
    files.slice(0, 10).forEach((f) => foUpload(el.id, f));
  });
  on('.fo-editor', 'dragover', (el, e) => { if ([...e.dataTransfer.types].includes('Files')) { e.preventDefault(); el.classList.add('drop'); } });
  on('.fo-editor', 'dragleave', (el, e) => { if (!el.contains(e.relatedTarget)) el.classList.remove('drop'); });
  on('.fo-editor', 'drop', (el, e) => {
    const files = [...(e.dataTransfer.files || [])].filter((f) => /^image\//.test(f.type));
    el.classList.remove('drop');
    if (!files.length) return;
    e.preventDefault();
    files.slice(0, 10).forEach((f) => foUpload(el.dataset.editor, f));
  });
  on('[data-fo-tool]', 'mousedown', (b, e) => e.preventDefault());
  on('[data-fo-tool]', 'click', (b) => {
    const box = document.getElementById(b.dataset.for);
    if (!box) return;
    const sel = box.value.slice(box.selectionStart, box.selectionEnd);
    switch (b.dataset.foTool) {
      case 'bold': foInsert(box, '**', '**'); break;
      case 'italic': foInsert(box, '*', '*'); break;
      case 'spoiler': foInsert(box, '||', '||'); break;
      case 'code': if (sel.includes('\n')) foInsert(box, '```\n', '\n```'); else foInsert(box, '`', '`'); break;
      case 'quote': foInsert(box, '', '', true); break;
      case 'picture': {
        const pick = document.createElement('input');
        pick.type = 'file'; pick.accept = 'image/png,image/jpeg,image/webp,image/gif'; pick.multiple = true;
        pick.addEventListener('change', () => [...pick.files].slice(0, 10).forEach((f) => foUpload(box.id, f)));
        pick.click();
        break;
      }
    }
  });
  on('[data-fo-preview]', 'click', (b) => { FO.preview[b.dataset.foPreview] = !FO.preview[b.dataset.foPreview]; render(true); });
}

function forumWire() {
  if (state.route !== 'forum') return;
  const on = (sel, ev, fn) => $app.querySelectorAll(sel).forEach((el) => el.addEventListener(ev, (e) => fn(el, e)));
  const again = () => { forget('forum', 'reports'); render(true); };
  const said = (r, ok) => { FO.bad = !r.ok; FO.msg = r.ok ? ok || '' : foFault(r); };
  // Filters of a category.
  on('[data-fo-filter]', 'click', (b) => { const [cat, k] = b.dataset.foFilter.split(':'); FO.filter[cat] = k; render(true); });
  on('[data-fo-sort]', 'click', (b) => { FO.sort.ideas = b.dataset.foSort; render(true); });
  // The editors: drafts kept, the tools, pictures pasted and dropped, the @ list, the preview.
  on('#fo-reply', 'input', (el) => { const t = foThread(); if (t) foDraft('t:' + t.id, el.value); });
  on('#fo-edit', 'input', (el) => { FO.editText = el.value; });
  on('#n-body', 'input', (el) => { foDraft('n:body', el.value); });
  on('[data-fo-n]', 'input', (el) => { foDraft('n:' + el.dataset.foN, el.value); });
  on('[data-fo-n]', 'change', (el) => { foDraft('n:' + el.dataset.foN, el.value); if (el.dataset.foN === 'cat') render(true); });
  foEditorsWire(on);
  // Spoilers open on a click; pictures open large.
  on('.spoiler', 'click', (s) => s.classList.add('shown'));
  on('.spoiler', 'keydown', (s, e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); s.classList.add('shown'); } });
  on('[data-fo-pic]', 'click', (b) => { FO.pic = b.dataset.foPic; render(true); });
  on('#fo-lb-close', 'click', () => { FO.pic = null; render(true); });
  on('#fo-lightbox', 'click', (el, e) => { if (e.target === el) { FO.pic = null; render(true); } });
  // Posting.
  on('[data-fo-post]', 'click', async (b) => {
    if (FO.uploading) return;
    const id = Number(b.dataset.foPost), body = foDraft('t:' + id);
    b.disabled = true;
    const r = await api(`forum/threads/${id}/posts`, { body });
    if (!r.ok) { said(r); b.disabled = false; render(true); return; }
    foDraft('t:' + id, ''); FO.msg = ''; FO.preview['fo-reply'] = false;
    forget('forum');
    const to = `#/forum/t/${id}/${r.data.page}`;
    if (location.hash === to) render(true); else location.hash = to;
    setTimeout(() => { const el = document.getElementById('p' + r.data.id); if (el) el.scrollIntoView({ block: 'center' }); }, 400);
  });
  on('#fo-start', 'click', async (b) => {
    if (FO.uploading) return;
    b.disabled = true;
    const r = await api('forum/threads', { category: b.dataset.cat, title: foDraft('n:title'), body: foDraft('n:body') });
    if (!r.ok) { said(r); b.disabled = false; render(true); return; }
    foDraft('n:title', ''); foDraft('n:body', ''); foDraft('n:cat', ''); FO.msg = ''; FO.preview['n-body'] = false;
    forget('forum');
    location.hash = `#/forum/t/${r.data.id}`;
  });
  // A post: quoted (all of it, or the words selected in it), edited, its history, reactions, the answer.
  on('[data-fo-quote]', 'click', (b) => {
    const t = foThread(), p = t && t.posts.find((x) => x.id === Number(b.dataset.foQuote));
    if (!p) return;
    const el = document.getElementById('p' + p.id), s = window.getSelection(), picked = s && !s.isCollapsed && el && el.contains(s.anchorNode) ? s.toString() : '';
    foQuote(p.author.login, picked || p.body.split('\n').filter((l) => !l.startsWith('>') && !/^\[img:/.test(l.trim())).join('\n').trim().slice(0, 400));
  });
  on('[data-fo-edit]', 'click', (b) => { const t = foThread(), p = t && t.posts.find((x) => x.id === Number(b.dataset.foEdit)); FO.edit = Number(b.dataset.foEdit); FO.editText = p ? p.body : ''; render(true); const box = document.getElementById('fo-edit'); if (box) { box.focus(); box.setSelectionRange(box.value.length, box.value.length); } });
  on('[data-fo-cancel]', 'click', () => { FO.edit = 0; render(true); });
  on('[data-fo-save]', 'click', async (b) => { if (FO.uploading) return; const r = await api(`forum/posts/${b.dataset.foSave}`, { body: FO.editText }, 'PATCH'); if (r.ok) { FO.edit = 0; FO.msg = ''; } else said(r); FO.hist = 0; again(); });
  on('[data-fo-hist]', 'click', async (b) => {
    const id = Number(b.dataset.foHist);
    if (FO.hist === id) { FO.hist = 0; render(true); return; }
    FO.hist = id; FO.history = null; render(true);
    const r = await api(`forum/posts/${id}/history`);
    if (FO.hist === id) { FO.history = r.ok ? r.data.versions : []; render(true); }
  });
  on('[data-fo-react-open]', 'click', (b) => { const id = Number(b.dataset.foReactOpen); FO.react = FO.react === id ? 0 : id; render(true); });
  on('[data-fo-react]', 'click', async (b) => {
    const [id, e] = b.dataset.foReact.split(':');
    FO.react = 0;
    const r = await api(`forum/posts/${id}/react`, { emoji: e });
    const t = foThread(), p = t && t.posts.find((x) => x.id === Number(id));
    if (r.ok && p) p.reactions = r.data.reactions;
    render(true);
  });
  on('[data-fo-answer]', 'click', async (b) => { const t = foThread(); const post = Number(b.dataset.foAnswer); const r = await api(`forum/threads/${t.id}/solution`, { post: post || null }); said(r, post ? L('Marked as the answer: the question is solved.', 'Отмечено как ответ: вопрос решён.') : ''); again(); });
  // The thread: votes, following, its status.
  on('[data-fo-vote]', 'click', async () => { const t = foThread(); const r = await api(`forum/threads/${t.id}/vote`, {}); if (r.ok) { t.votes = r.data.votes; t.voted = r.data.voted; } else said(r); forget('forum/threads?'); render(true); });
  on('[data-fo-follow]', 'click', async (b) => { const t = foThread(); const r = await api(`forum/threads/${t.id}/follow`, { on: b.dataset.foFollow === '1' }); if (r.ok) t.following = r.data.following; render(true); });
  on('#fo-status', 'change', async (s) => { const t = foThread(); const r = await api(`forum/threads/${t.id}/status`, { status: s.value }); said(r, L('Status changed: its author is told.', 'Статус изменён: автор получит уведомление.')); again(); });
  // Staff: a warning, a mute.
  on('[data-fo-staff]', 'click', (b) => { FO.staff = FO.staff === b.dataset.foStaff ? '' : b.dataset.foStaff; FO.staffWhy = ''; render(true); const i = document.getElementById('fo-staff-why'); if (i) i.focus(); });
  on('#fo-staff-why', 'input', (i) => { FO.staffWhy = i.value; });
  on('#fo-staff-min', 'change', (s) => { FO.staffMin = Number(s.value); });
  on('[data-fo-staff-no]', 'click', () => { FO.staff = ''; render(true); });
  on('[data-fo-staff-go]', 'click', async (b) => {
    const kind = FO.staff.split(':')[0], login = b.dataset.foStaffGo;
    const r = kind === 'warn' ? await api('staff/warn', { login, why: FO.staffWhy }) : await api('staff/mute', { login, minutes: FO.staffMin, why: FO.staffWhy });
    said(r, kind === 'warn' ? L(`${login} is warned (${r.data && r.data.warnings} in all).`, `${login}: предупреждение выдано (всего: ${r.data && r.data.warnings}).`) : L(`${login} can’t post on the forum for now.`, `${login} пока не может писать на форуме.`));
    if (r.ok) FO.staff = '';
    state.fmsg = FO.msg; FO.msg = '';
    render(true);
  });
}

// Selected words of a post: a small "Quote" offered by them.
document.addEventListener('mouseup', (e) => {
  if (state.route !== 'forum') return;
  setTimeout(() => {
    let tip = document.getElementById('fo-quote-tip');
    const s = window.getSelection(), body = s && !s.isCollapsed && s.anchorNode && s.anchorNode.parentElement && s.anchorNode.parentElement.closest('.post .post-body');
    if (!body || !s.toString().trim() || e.target.closest('#fo-quote-tip')) { if (tip && !e.target.closest('#fo-quote-tip')) tip.remove(); return; }
    const post = body.closest('.post'), rect = s.getRangeAt(0).getBoundingClientRect();
    if (!tip) { tip = document.createElement('button'); tip.id = 'fo-quote-tip'; tip.className = 'w small lead'; document.body.appendChild(tip); }
    tip.textContent = L('Quote', 'Цитировать');
    tip.style.left = `${Math.max(8, rect.left + rect.width / 2 + window.scrollX - 44)}px`;
    tip.style.top = `${rect.top + window.scrollY - 40}px`;
    const text = s.toString(), t = foThread(), p = t && t.posts.find((x) => 'p' + x.id === post.id);
    tip.onclick = () => { tip.remove(); if (p) foQuote(p.author.login, text); };
  }, 0);
});
