// ================================================================================================ forum 3.0 (07.10.2026)
// Her word: "the forum still looks raw, and members' profiles are awkward to get to — make it ten times better". What
// this adds to every screen of people: a member's card over any avatar or name held under the pointer (a click on it
// goes to the profile, even inside a thread's row); the screens coming in as the client's own do (each row in turn,
// once a screen: the redraws that follow each answer of the server do not start it again); a thread's side (its
// author, who took part, more of its category), the way up and the way to its last reply; a page for an address that
// leads nowhere.

// ---- a screen comes in once

const F3 = { key: '', at: 0 };
/** Whether the screen `key` is still coming in, and how far in it is (ms): a style for its rows, empty once it is in. */
function f3Enter(key) {
  const now = performance.now();
  if (key !== F3.key) { F3.key = key; F3.at = now; }
  return now - F3.at;
}
/** The style of the `i`th row of a screen `elapsed` ms in: its turn, minus the time gone (a redraw goes on, not over). */
const f3Row = (i, elapsed) => (elapsed > 900 || matchMedia('(prefers-reduced-motion: reduce)').matches ? '' : ` style="animation-delay:${Math.min(i, 14) * 38 - elapsed}ms"`);
const f3Cls = (elapsed) => (elapsed > 900 ? '' : ' f3-in');

// ---- a member's card

const HC = { cache: new Map(), el: null, login: '', anchor: null, show: 0, hide: 0 };

/** The member an element under the pointer stands for (an avatar, a name), or null. */
function hcWho(target) {
  if (!(target instanceof Element)) return null;
  const a = target.closest('[data-u], .who-name, img.head[data-login], canvas.head[data-head]');
  if (!a || a.closest('.hcard, .prof-av, .av-big, .site-head, header')) return null;
  let login = a.dataset.u || a.dataset.login || a.dataset.head || '';
  if (!login && a.classList.contains('who-name')) {
    const m = /#\/u\/([^/?#]+)/.exec(a.getAttribute('href') || '');
    login = m ? decodeURIComponent(m[1]) : '';
  }
  return login ? { el: a, login } : null;
}

function hcData(login) {
  const k = login.toLowerCase();
  let c = HC.cache.get(k);
  if (!c) {
    c = api('u/' + encodeURIComponent(login)).then((r) => {
      if (!r.ok) HC.cache.delete(k);
      else learnAv(r.data);
      return r;
    });
    HC.cache.set(k, c);
  }
  return c;
}

function hcHtml(p) {
  const who = p.person, pres = p.presence || {}, acc = who.accent || '#BFC0E7';
  const stats = [[p.stats.posts, L('posts', plural(p.stats.posts, 'пост', 'поста', 'постов'))], [p.stats.threads, L('threads', plural(p.stats.threads, 'тема', 'темы', 'тем'))]];
  if (p.stats.hours !== null && p.stats.hours !== undefined) stats.push([p.stats.hours, L('hours in Cursed', plural(p.stats.hours, 'час в Cursed', 'часа в Cursed', 'часов в Cursed'))]);
  const where = pres.online ? `<p class="hc-where">${dot(pres.online)}<span>${pres.online === 'game' ? tr('In the game') : tr('On the site')}</span>${pres.server ? `<span class="ash" translate="no">· ${esc(pres.server)}</span>` : ''}</p>` : '';
  const self = p.viewer && p.viewer.self;
  return `<div class="hc-top theme-${esc(p.theme || 'eclipse')}">${p.banner ? `<img src="${esc(p.banner.url)}" alt="" decoding="async" onerror="this.remove()">` : ''}</div>
    <div class="hc-body" style="--acc:${esc(acc)}">
      <div class="hc-av">${head(who.login, 64)}${dot(pres.online)}</div>
      <p class="hc-pre">${pfx(who)}<span class="ash num" translate="no">UID ${esc(String(who.uid_text || who.uid))}</span></p>
      <p class="hc-name" translate="no">${esc(who.login)}</p>
      ${who.status ? `<p class="status">${emo(who.status.emoji, 18)}<span translate="no">${esc(who.status.text || '')}</span></p>` : ''}
      ${where}
      <div class="hc-stats">${stats.map(([n, w]) => `<div><b class="num">${fmt(n || 0)}</b><span>${w}</span></div>`).join('')}</div>
      <p class="ash hc-since">${L('With Cursed since', 'В Cursed с')} ${when(p.since)}</p>
      <div class="acts"><a class="w small lead" href="${profHref(who.login)}">${L('Profile', 'Профиль')}</a>${self ? '' : `<a class="w small" href="${profHref(who.login)}" data-hc-write="1">${L('Message', 'Написать')}</a>`}</div>
    </div>`;
}

function hcPlace() {
  const el = HC.el, a = HC.anchor;
  if (!el || !a || !a.isConnected) return;
  const r = a.getBoundingClientRect(), w = el.offsetWidth, h = el.offsetHeight, m = 10;
  let x = r.left + r.width / 2 - w / 2;
  x = Math.max(m, Math.min(window.innerWidth - w - m, x));
  let y = r.bottom + 10;
  const up = y + h > window.innerHeight - m && r.top - 10 - h > m;
  if (up) y = r.top - 10 - h;
  el.style.left = Math.round(x + window.scrollX) + 'px';
  el.style.top = Math.round(y + window.scrollY) + 'px';
  el.classList.toggle('up', up);
}

async function hcOpen(anchor, login) {
  HC.login = login; HC.anchor = anchor;
  const r = await hcData(login);
  if (HC.login !== login || !anchor.isConnected || !r.ok) return;
  if (!HC.el) {
    HC.el = document.createElement('div');
    HC.el.className = 'hcard';
    HC.el.setAttribute('role', 'dialog');
    HC.el.addEventListener('mouseenter', () => clearTimeout(HC.hide));
    HC.el.addEventListener('mouseleave', () => hcLater());
    document.body.appendChild(HC.el);
  }
  HC.el.innerHTML = hcHtml(r.data);
  HC.el.style.setProperty('--acc', r.data.person.accent || '#BFC0E7');
  HC.el.querySelectorAll('canvas[data-head]').forEach(drawHead);
  HC.el.classList.remove('on');
  hcPlace();
  // The next frame: from its first place to its shown one, eased.
  requestAnimationFrame(() => HC.el && HC.el.classList.add('on'));
}

function hcClose() {
  clearTimeout(HC.show); clearTimeout(HC.hide);
  HC.login = ''; HC.anchor = null;
  if (HC.el) HC.el.classList.remove('on');
}
function hcLater() {
  clearTimeout(HC.hide);
  HC.hide = setTimeout(hcClose, 240);
}

// Only where a pointer hovers (a finger's tap goes to the profile instead).
if (matchMedia('(hover: hover)').matches) {
  document.addEventListener('mouseover', (e) => {
    const w = hcWho(e.target);
    if (!w) return;
    clearTimeout(HC.hide);
    if (HC.login === w.login && HC.anchor === w.el) return;
    clearTimeout(HC.show);
    HC.show = setTimeout(() => hcOpen(w.el, w.login), HC.el && HC.el.classList.contains('on') ? 60 : 380);
  });
  document.addEventListener('mouseout', (e) => {
    const w = hcWho(e.target);
    if (!w) return;
    clearTimeout(HC.show);
    if (HC.el && HC.el.contains(e.relatedTarget)) return;
    hcLater();
  });
  window.addEventListener('scroll', () => { if (HC.el && HC.el.classList.contains('on')) hcPlace(); }, { passive: true });
}
window.addEventListener('hashchange', hcClose);

// A member's avatar or name inside a row that is itself a link (a thread's): their profile, not the thread.
document.addEventListener('click', (e) => {
  const u = e.target instanceof Element ? e.target.closest('a.topic [data-u], a.topic .head, a.cat [data-u]') : null;
  if (!u) return;
  const login = u.dataset.u || u.dataset.login || u.dataset.head;
  if (!login) return;
  e.preventDefault();
  e.stopPropagation();
  location.hash = profHref(login);
}, true);

// ---- the way up, and to a thread's last reply

let f3UpShown = false;
window.addEventListener('scroll', () => {
  const show = window.scrollY > 900;
  if (show === f3UpShown) return;
  f3UpShown = show;
  let b = document.getElementById('f3-up');
  if (!b) {
    b = document.createElement('button');
    b.id = 'f3-up';
    b.className = 'f3-up';
    b.setAttribute('aria-label', L('Up', 'Наверх'));
    b.innerHTML = '<i></i>';
    b.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
    document.body.appendChild(b);
  }
  b.classList.toggle('on', show);
}, { passive: true });

// ---- an address that leads nowhere

function viewNotFound() {
  return `<div class="nf">
      <p class="nf-code num">404</p>
      <h1 class="giant">${L('Nothing here', 'Здесь ничего нет')}</h1>
      <p class="ash">${L('This address leads nowhere: mistyped, or the page is gone.', 'По этому адресу ничего нет: опечатка, или страница ушла.')}</p>
      <div class="acts"><a class="w lead" href="#/">${L('Home', 'На главную')}</a><a class="w" href="#/forum">${L('The forum', 'Форум')}</a><a class="w" href="#/market">${L('The market', 'Маркет')}</a><button class="w" onclick="history.back()">${L('Back', 'Назад')}</button></div>
    </div>`;
}
