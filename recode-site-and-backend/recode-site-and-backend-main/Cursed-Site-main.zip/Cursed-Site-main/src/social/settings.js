// ---- the dashboard's new pages: the profile as its member dresses it, the notifications they want, their sessions

const PRIV = [['online', 'Show when I am online'], ['listening', 'Show what I listen to in the client'], ['server', 'Show the server I play on'], ['hours', 'Show my hours in Cursed']];

/** The draft of the profile being edited: made from the profile once, kept while the page is up. */
function draft(p) {
  if (!state.pe || state.pe.of !== p.person.uid) {
    state.pe = {
      of: p.person.uid, about: p.about || '', status_text: p.status_text || '', status_emoji: p.status_emoji || '', accent: p.accent || '', theme: p.theme || 'eclipse',
      socials: { ...(p.socials || {}) }, privacy: { ...(p.privacy || {}) }, prefix: p.prefix_choice || 'auto', showcase: [...(p.showcase || [])], msg: '', bad: false, busy: '',
    };
  }
  return state.pe;
}

function dashProfile() {
  const c = ask('u/' + encodeURIComponent(me().name)), cat = ask('badges');
  if (waiting(c)) return `<h1 class="sr">Profile</h1><div class="sections">${ghosts(2)}</div>`;
  if (!c.ok) return trouble(c);
  const p = c.data, d = draft(p), roles = (SOC.meta ? SOC.meta.roles : []).filter((r) => (p.roles || []).includes(r.id));
  const defs = cat.ok ? cat.data.badges : [], mine = p.badges.map((b) => [defs.find((x) => x.id === b.id), b]).filter(([x]) => x);
  const busy = (k) => d.busy === k;
  const pick = (name, on, label, extra) => `<button class="w small ${on ? 'on' : ''}" ${name} ${extra || ''}>${label}</button>`;
  return `<h1 class="sr">Profile</h1><div class="sections pe" style="--acc:${esc(d.accent || '#BFC0E7')}">
    <div class="block pe-look">
      <h2 class="sec">Look</h2>
      <div class="pe-banner theme-${esc(d.theme)} ${p.banner ? 'has' : ''}" id="banner-drop">${p.banner ? `<img src="${esc(p.banner.url)}" alt="">` : ''}
        <span class="pe-name" translate="no">${head(me().name, 64)}<b style="color:var(--acc)">${esc(me().name)}</b></span></div>
      <p class="hint">A banner: PNG, JPEG, WebP or GIF up to 12 MB, cut to 3:1 from the middle (1500×500). A GIF stays animated, here and in the game.</p>
      <div class="acts"><label class="w small lead" for="banner-file">${busy('banner') ? 'Uploading…' : p.banner ? 'Change the banner' : 'Upload a banner'}</label><input id="banner-file" type="file" accept="image/png,image/jpeg,image/webp,image/gif" hidden>${p.banner ? '<button class="w small" id="banner-drop-it">Remove it</button>' : ''}</div>
      <p class="lab">Backdrop <span class="ash">(shown where there is no banner)</span></p>
      <div class="acts themes">${Object.keys(THEME_NAMES).map((t) => `<button class="theme-chip theme-${t} ${d.theme === t ? 'on' : ''}" data-theme="${t}" title="${esc(L(...THEME_NAMES[t]))}"><span>${L(...THEME_NAMES[t])}</span></button>`).join('')}</div>
      <p class="lab">Accent <span class="ash">(your name, your music, your marks)</span></p>
      <div class="acts swatches">${ACCENTS.map((a) => `<button class="sw ${d.accent.toUpperCase() === a ? 'on' : ''}" data-accent="${a}" style="--c:${a}" aria-label="${a}"></button>`).join('')}
        <label class="sw-own"><span class="sr">Your own colour</span><input class="in mono" id="accent-own" maxlength="7" placeholder="#RRGGBB" value="${esc(ACCENTS.includes(d.accent.toUpperCase()) ? '' : d.accent)}"></label>
        <button class="w small ${d.accent ? '' : 'on'}" data-accent="">The site’s own</button></div>
    </div>

    <div class="block">
      <h2 class="sec">Status</h2>
      <div class="pe-status"><input class="in" id="status-text" maxlength="60" placeholder="Looking for a team, AFK, streaming…" value="${esc(d.status_text)}"></div>
      <div class="emoji-pick">${['', ...(SOC.meta ? SOC.meta.emoji : [])].map((e) => `<button class="${d.status_emoji === e ? 'on' : ''}" data-status-emoji="${esc(e)}" title="${esc(e || tr('None'))}">${e ? emo(e, 28) : '<span class="none">—</span>'}</button>`).join('')}</div>
    </div>

    <div class="block">
      <h2 class="sec">About</h2>
      <textarea class="in" id="about" maxlength="1000" rows="5" placeholder="Who you are, what you play, what you make.">${esc(d.about)}</textarea>
      <p class="hint num"><span id="about-n">${d.about.length}</span> / 1000</p>
    </div>

    <div class="block">
      <h2 class="sec">Music</h2>
      ${p.music ? `<div class="pe-music"><p class="hint">${p.music.kind === 'soundcloud' ? `SoundCloud: <a href="${esc(p.music.url)}" target="_blank" rel="noopener noreferrer" translate="no">${esc(p.music.url)}</a>` : L('Your own MP3', 'Свой MP3') + ` · <span class="num">${Math.round((p.music.ms || 0) / 1000)} ${L('s', 'с')}</span>`}</p>
        <div class="two-in"><input class="in" id="music-title" maxlength="80" placeholder="Song title" value="${esc(p.music.title || '')}"><input class="in" id="music-artist" maxlength="80" placeholder="Artist" value="${esc(p.music.artist || '')}"></div>
        <div class="acts"><button class="w small" id="music-names">Save the names</button><button class="w small" id="music-drop">Remove the song</button></div></div>` : '<p class="ash">No song on your profile.</p>'}
      <div class="acts"><label class="w small lead" for="music-file">${busy('music') ? 'Uploading…' : 'Upload an MP3'}</label><input id="music-file" type="file" accept="audio/mpeg,.mp3" hidden></div>
      <p class="hint">Up to 10 MB and 10 minutes. Its title and artist come from its tags. Or a SoundCloud track:</p>
      <div class="two-in"><input class="in" id="sc-url" placeholder="https://soundcloud.com/artist/track"><button class="w small" id="sc-set">Use it</button></div>
    </div>

    <div class="block">
      <h2 class="sec">Prefix</h2>
      <div class="acts">${pick('data-prefix="auto"', d.prefix === 'auto', 'Highest role')}${pick('data-prefix="none"', d.prefix === 'none', 'None')}${roles.map((r) => pick(`data-prefix="${esc(r.id)}"`, d.prefix === r.id, `<span class="pfx" style="--c:${esc(r.colour)}" translate="no">${esc(r.prefix)}</span>`)).join('')}</div>
      ${roles.length ? '' : '<p class="ash">You hold no role with a prefix yet.</p>'}
    </div>

    ${mine.length ? `<div class="block">
      <h2 class="sec">Showcase <span class="ash num">${d.showcase.length} / 6</span></h2>
      <p class="hint">The badges shown first on your profile. Pick up to six.</p>
      <div class="bdgs pe-show">${mine.map(([b, m]) => badgeTile(b, m).replace('class="badge', `class="bdg ${d.showcase.includes(b.id) ? 'picked' : ''}`).replace('data-badge=', 'data-show=')).join('')}</div>
    </div>` : ''}

    <div class="block">
      <h2 class="sec">Links</h2>
      <div class="nets-edit">${Object.keys(NETS).map((id) => `<label class="net-in">${netMark(id)}<span class="sr">${NETS[id][0]}</span><input class="in" data-net="${id}" placeholder="${esc(NETS[id][0])}" value="${esc(d.socials[id] || '')}" translate="no"></label>`).join('')}</div>
      <p class="hint">A name or an address: @name, t.me/name, youtube.com/@name. An empty one is not shown.</p>
    </div>

    <div class="block">
      <h2 class="sec">Privacy</h2>
      <div class="ticks">${PRIV.map(([k, w]) => `<label class="tick"><input type="checkbox" data-priv="${k}" ${d.privacy[k] ? 'checked' : ''}><span>${w}</span></label>`).join('')}</div>
      <p class="lab">Who may write to you</p>
      <div class="acts">${[['all', 'Everyone'], ['friends', 'Friends'], ['none', 'Nobody']].map(([k, w]) => pick(`data-dm="${k}"`, (d.privacy.dm || 'friends') === k, w)).join('')}</div>
    </div>

    <div class="block">
      <h2 class="sec">Screenshots <span class="ash num">${p.shots.length}</span></h2>
      <div class="acts"><label class="w small lead" for="shot-file">${busy('shot') ? 'Uploading…' : 'Add screenshots'}</label><input id="shot-file" type="file" accept="image/png,image/jpeg,image/webp" multiple hidden></div>
      ${p.shots.length ? `<div class="shots edit">${p.shots.map((s) => `<span class="shot-t"><img src="${esc(s.thumb)}" alt="" loading="lazy"><button class="w small" data-shot-drop="${esc(s.id)}">Remove</button></span>`).join('')}</div>` : ''}
    </div>

    <div class="pe-save"><button class="w menu lead" id="pe-save">Save</button><a class="w" href="#/u/${encodeURIComponent(me().name)}">See my profile</a><span class="hint ${d.bad ? 'bad' : 'ok'}" id="pe-msg" role="status">${esc(d.msg)}</span></div>
  </div>`;
}

function dashNotify() {
  const c = ask('me/notify');
  if (waiting(c)) return `<h1 class="sr">Notifications</h1><div class="sections">${ghosts(1)}</div>`;
  if (!c.ok) return trouble(c);
  const box = (k, ch) => `<input type="checkbox" data-np="${esc(k.kind)}:${ch}" ${k[ch] ? 'checked' : ''} aria-label="${esc(ch)}">`;
  return `<h1 class="sr">Notifications</h1><div class="sections"><div class="block">
    <h2 class="sec">What you hear of, and where</h2>
    <p class="hint">On the site — the bell and a note in the corner. In the game — a note in its corner. Windows — a notification of Windows while the game is not in front.</p>
    <div class="scroll-x"><table class="np"><thead><tr><th></th><th>Site</th><th>Game</th><th>Windows</th></tr></thead><tbody>
      ${c.data.kinds.map((k) => `<tr><td>${esc(L(k.en, k.ru))}</td><td>${box(k, 'site')}</td><td>${box(k, 'game')}</td><td>${box(k, 'push')}</td></tr>`).join('')}
    </tbody></table></div><p class="hint" id="np-msg" role="status"></p></div></div>`;
}

function dashSessions() {
  const c = ask('me/sessions');
  if (waiting(c)) return `<h1 class="sr">Sessions</h1><div class="sections">${ghosts(1)}</div>`;
  if (!c.ok) return trouble(c);
  const kind = (k) => ({ web: L('Site', 'Сайт'), loader: L('Loader', 'Лоудер'), client: L('Game', 'Игра') }[k] || k);
  const list = c.data.sessions;
  return `<h1 class="sr">Sessions</h1><div class="sections"><div class="block">
    <h2 class="sec">Where you are signed in</h2>
    <div class="rows sessions">${list.map((s) => `<div><b translate="no">${esc(s.label)}</b><span class="st ${s.current ? 'cream' : 'ok'}">${s.current ? L('This one', 'Этот') : kind(s.kind)}</span>
      <span class="d ash">${L('last used', 'был')} ${ago(s.seen)} · ${L('since', 'с')} ${when(s.created)}</span>${s.current ? '' : `<button class="w small" data-end="${esc(s.id)}">Sign out</button>`}</div>`).join('')}</div>
    ${list.length > 1 ? '<div class="acts" style="margin-top:22px"><button class="w lead" id="end-others">Sign out everywhere else</button></div>' : ''}
    <p class="hint" id="end-msg" role="status"></p></div>${dashDevice()}</div>`;
}

// ---- uploads of the profile (raw bodies, as the avatar)

async function sendRaw(path, file, kind) {
  const d = state.pe;
  if (d) { d.busy = kind; d.msg = ''; d.bad = false; }
  render(true);
  let r = null, data = {};
  try {
    r = await fetch('/api/' + path, { method: 'POST', credentials: 'same-origin', cache: 'no-store', headers: { 'Content-Type': file.type || 'application/octet-stream' }, body: file });
    try { data = await r.json(); } catch (e) { /* not JSON */ }
  } catch (e) { r = null; }
  if (d) d.busy = '';
  if (r && r.status === 401) { signOut(); location.hash = '#/signin'; return false; }
  if (!(r && r.ok) && d) { d.msg = r ? (data.message ? tr('Not taken:') + ' ' + tr(data.message) : r.status === 429 ? tr('Too many uploads. Wait a while.') : SAY.busy) : SAY.offline; d.bad = true; }
  forget('u/');
  render(true);
  return !!(r && r.ok);
}

async function saveProfile() {
  const d = state.pe;
  if (!d) return;
  const own = document.getElementById('accent-own');
  if (own && own.value.trim()) d.accent = own.value.trim();
  const r = await api('me/profile', { about: d.about, status_text: d.status_text, status_emoji: d.status_emoji, accent: d.accent, theme: d.theme, socials: d.socials, privacy: d.privacy, prefix: d.prefix, showcase: d.showcase }, 'PATCH');
  d.bad = !r.ok;
  d.msg = r.ok ? tr('Saved.') : r.message ? tr(r.message) : SAY[r.error] || SAY.busy;
  if (r.ok) { forget('u/', 'forum', 'me'); const m = await api('me'); if (m.ok) signIn(m.data); }
  render(true);
}

// ---- what the people's screens do (wired after the app's own)

function socialWire() {
  const on = (sel, ev, fn) => $app.querySelectorAll(sel).forEach((el) => el.addEventListener(ev, (e) => fn(el, e)));
  // The notifications.
  on('#notes-all', 'click', async () => { const r = await api('notifications/read', { all: true }); if (r.ok) { setUnread(0); forget('notifications'); SOC.notesMore = null; render(true); } });
  on('[data-note]', 'click', (a) => { api('notifications/read', { ids: [Number(a.dataset.note)] }); forget('notifications'); });
  on('#notes-more', 'click', async () => {
    const c = got.get('notifications'), all = (c && c.ok ? c.data.items : []).concat(SOC.notesMore || []);
    const r = await api('notifications?before=' + all[all.length - 1].id);
    if (r.ok) { SOC.notesMore = (SOC.notesMore || []).concat(r.data.items); SOC.notesMoreLeft = r.data.more; render(true); }
  });
  // The badges.
  on('[data-badge]', 'click', (b) => { state.badgeOpen = state.badgeOpen === b.dataset.badge ? '' : b.dataset.badge; render(true); });
  // The profile.
  on('[data-play]', 'click', (b) => playMusic(b));
  on('[data-shot-open]', 'click', (b) => { state.shotOpen = Number(b.dataset.shotOpen); render(true); });
  on('#lb-close', 'click', () => { state.shotOpen = undefined; render(true); });
  on('#lightbox', 'click', (el, e) => { if (e.target === el) { state.shotOpen = undefined; render(true); } });
  on('[data-shot-step]', 'click', (b) => { state.shotOpen += Number(b.dataset.shotStep); render(true); });
  on('[data-give-role]', 'click', async (b) => {
    const login = decodeURIComponent(state.arg.split('/')[0]), on_ = !b.classList.contains('on');
    const r = await api('staff/roles', { login, role: b.dataset.giveRole, on: on_ });
    const msg = document.getElementById('role-msg');
    if (r.ok) { forget('u/'); render(true); } else if (msg) { msg.textContent = r.error === 'not-yours' ? tr('That role is not yours to give.') : tr(r.message || SAY[r.error] || SAY.busy); msg.className = 'hint bad'; }
  });
  // The profile's editor.
  const d = state.pe;
  if (d) {
    on('[data-theme]', 'click', (b) => { d.theme = b.dataset.theme; render(true); });
    on('[data-accent]', 'click', (b) => { d.accent = b.dataset.accent; render(true); });
    on('#accent-own', 'change', (i) => { if (/^#[0-9a-f]{6}$/i.test(i.value.trim())) { d.accent = i.value.trim().toUpperCase(); render(true); } });
    on('[data-status-emoji]', 'click', (b) => { d.status_emoji = b.dataset.statusEmoji; render(true); });
    on('#status-text', 'input', (i) => { d.status_text = i.value; });
    on('#about', 'input', (t) => { d.about = t.value; const n = document.getElementById('about-n'); if (n) n.textContent = t.value.length; });
    on('[data-prefix]', 'click', (b) => { d.prefix = b.dataset.prefix; render(true); });
    on('[data-show]', 'click', (b) => {
      const id = b.dataset.show, i = d.showcase.indexOf(id);
      if (i >= 0) d.showcase.splice(i, 1); else if (d.showcase.length < 6) d.showcase.push(id);
      render(true);
    });
    on('[data-net]', 'input', (i) => { d.socials[i.dataset.net] = i.value; });
    on('[data-priv]', 'change', (i) => { d.privacy[i.dataset.priv] = i.checked; });
    on('[data-dm]', 'click', (b) => { d.privacy.dm = b.dataset.dm; render(true); });
    on('#pe-save', 'click', saveProfile);
    on('#banner-file', 'change', (i) => { if (i.files[0]) sendRaw('me/banner', i.files[0], 'banner'); });
    on('#banner-drop-it', 'click', async () => { await api('me/banner', null, 'DELETE'); forget('u/'); render(true); });
    on('#banner-drop', 'dragover', (el, e) => { e.preventDefault(); el.classList.add('over'); });
    on('#banner-drop', 'dragleave', (el) => el.classList.remove('over'));
    on('#banner-drop', 'drop', (el, e) => { e.preventDefault(); el.classList.remove('over'); const f = e.dataTransfer.files[0]; if (f) sendRaw('me/banner', f, 'banner'); });
    on('#music-file', 'change', (i) => { if (i.files[0]) sendRaw('me/music', i.files[0], 'music'); });
    on('#music-names', 'click', async () => {
      const r = await api('me/music', { title: document.getElementById('music-title').value, artist: document.getElementById('music-artist').value }, 'PATCH');
      d.msg = r.ok ? tr('Saved.') : tr(r.message || SAY.busy); d.bad = !r.ok; forget('u/'); render(true);
    });
    on('#music-drop', 'click', async () => { await api('me/music', null, 'DELETE'); forget('u/'); render(true); });
    on('#sc-set', 'click', async () => {
      const r = await api('me/music', { soundcloud: document.getElementById('sc-url').value }, 'PATCH');
      d.msg = r.ok ? tr('Saved.') : tr(r.message || SAY.busy); d.bad = !r.ok; forget('u/'); render(true);
    });
    on('#shot-file', 'change', async (i) => { for (const f of [...i.files]) { if (!(await sendRaw('me/shots', f, 'shot'))) break; } });
    on('[data-shot-drop]', 'click', async (b) => { await api('me/shots/' + b.dataset.shotDrop, null, 'DELETE'); forget('u/'); render(true); });
  }
  // The notifications wanted.
  on('[data-np]', 'change', async (i) => {
    const [kind, ch] = i.dataset.np.split(':');
    const r = await api('me/notify', { [kind]: { [ch]: i.checked } }, 'PUT');
    const msg = document.getElementById('np-msg'); if (msg) { msg.textContent = tr(r.ok ? 'Saved.' : SAY.busy); msg.className = 'hint ' + (r.ok ? 'ok' : 'bad'); }
    forget('me/notify');
  });
  // The sessions.
  on('[data-end]', 'click', async (b) => { await api('me/sessions/' + b.dataset.end, null, 'DELETE'); forget('me/sessions'); render(true); });
  on('#end-others', 'click', async () => {
    const r = await api('me/sessions/others', {});
    forget('me/sessions'); render(true);
    const msg = document.getElementById('end-msg'); if (msg && r.ok) { msg.textContent = tr('Signed out everywhere else.'); msg.className = 'hint ok'; }
  });
  friendsWire();
  configsWire();
  forumWire();
  supportWire();
  deviceWire();
  adminWire();
}

/** What the people's screens need of the server before they draw (the roles, the emoji). */
async function socialMeta() {
  if (SOC.meta) return;
  const r = await api('people/meta');
  if (r.ok) { SOC.meta = r.data; if (state.route === 'dashboard' || state.route === 'u') render(true); }
}
