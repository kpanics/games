// ================================================================================================ the staff's panel (03.10.2026)
// site/server/src/admin.rs: the summary, reports and packs (the first moderation, build.py's adminModeration), members,
// crashes by cause, announcements, her switches, roles, the journal. Each tab for those whose roles allow it.

MEMBERS_ONLY.add('news');
const AD = { q: '', qLive: '', days: 7, open: '', msg: '', bad: false, note: '', banWhy: '', banFor: '7d', uid: '', sure: '', pin: { address: '', name: '' }, news: { title: '', body: '', site: true, forum: true, game: true, discord: true, everyone: false, telegram: true }, jAction: '', jActor: '' };
const adPerms = () => (state.user && state.user.perms) || [];
const adCan = (p) => !!(state.user && (state.user.admin || adPerms().includes(p)));
const adTabs = () => [
  ['summary', 'Summary', 'Сводка', adCan('staff.panel')],
  ['reports', 'Reports', 'Жалобы', adCan('reports.handle')],
  ['users', 'Members', 'Участники', adCan('users.view')],
  ['crashes', 'Crashes', 'Вылеты', adCan('users.view')],
  ['news', 'Announcements', 'Объявления', adCan('announce')],
  ['switches', 'Switches', 'Переключатели', !!(state.user && state.user.admin)],
  ['packs', 'Packs', 'Паки', adCan('market.moderate')],
  ['roles', 'Roles', 'Роли', adCan('staff.panel')],
  ['journal', 'Journal', 'Журнал', adCan('audit.view')],
].filter((t) => t[3]);
const adLen = (s) => ({ '1h': L('an hour', 'час'), '1d': L('a day', 'сутки'), '7d': L('a week', 'неделя'), '30d': L('a month', 'месяц'), '': L('for good', 'навсегда') }[s] || s);
const adWhen = (s) => (s ? new Date(s * 1000).toLocaleString(LANG === 'ru' ? 'ru-RU' : 'en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—');
const adNum = (n, label) => `<div class="ad-num"><b class="num">${fmt(n || 0)}</b><span class="ash">${label}</span></div>`;

function viewAdmin(arg) {
  const [tab0, x] = String(arg || '').split('/');
  const tabs = adTabs();
  const tab = tab0 === 'user' ? 'users' : tabs.some((t) => t[0] === tab0) ? tab0 : (tabs[0] || ['summary'])[0];
  let body;
  if (tab0 === 'user' && x) body = adUser(decodeURIComponent(x));
  else body = { summary: adSummary, reports: () => adminModeration('reports'), packs: () => adminModeration(x === 'hidden' ? 'hidden' : 'new'), users: adUsers, crashes: adCrashes, news: adNews, switches: adSwitches, roles: adRoles, journal: adJournal }[tab]();
  return `<div class="dash">${rail('admin')}<div><h1 class="sr">${L('Staff', 'Персонал')}</h1>
    <div class="acts ad-tabs">${tabs.map((t) => `<a class="w ${t[0] === tab ? 'on' : ''}" href="#/admin/${t[0]}">${L(t[1], t[2])}</a>`).join('')}</div>
    <div class="ad-body">${body}</div>
    <p class="hint ${AD.bad ? 'bad' : 'ok'}" id="ad-msg" role="status">${esc(AD.msg)}</p></div></div>`;
}

function adSummary() {
  const c = ask('admin/summary');
  if (waiting(c)) return ghosts(1);
  if (!c.ok) return trouble(c);
  const d = c.data;
  const builds = d.builds.length ? d.builds.map((b) => `<span class="st ${b.current ? 'ok' : 'cream'}">${b.build ? L('build ', 'сборка ') + b.build : L('unknown build', 'сборка ?')} · <span class="num">${b.people}</span></span>`).join('') : `<span class="ash">${L('Nobody in the game now.', 'Сейчас в игре никого.')}</span>`;
  return `<div class="ad-grid">
      ${adNum(d.accounts, L('accounts', 'аккаунтов'))}${adNum(d.new_day, L('new today', 'новых за сутки'))}${adNum(d.new_week, L('new this week', 'за неделю'))}
      ${adNum(d.online.game, L('in the game now', 'сейчас в игре'))}${adNum(d.online.site, L('on the site now', 'сейчас на сайте'))}${adNum(d.bans, L('banned', 'забанено'))}
    </div>
    <div class="block"><h2 class="sec">${L('Builds in the game', 'Сборки в игре')}${d.current_build ? ` <span class="ash">· ${L('current', 'текущая')} ${d.current_build}</span>` : ''}</h2><div class="acts ad-builds">${builds}</div></div>
    <div class="block"><h2 class="sec">${L('Registration', 'Регистрация')}</h2><p>${d.registration === 'open' ? L('Open', 'Открыта') : L('Closed', 'Закрыта')} · <span class="num">${d.taken} / ${d.limit}</span> ${L('places taken', 'мест занято')}</p></div>
    <div class="ad-grid">
      <a class="ad-num" href="#/support">${'<b class="num">' + fmt(d.tickets.open) + '</b>'}<span class="ash">${L('tickets open', 'тикетов открыто')}</span></a>
      ${adNum(d.tickets.unassigned, L('tickets nobody’s', 'тикетов ничьих'))}${adNum(d.tickets.waiting, L('waiting for authors', 'ждут авторов'))}
      <a class="ad-num" href="#/admin/reports"><b class="num">${fmt(d.reports)}</b><span class="ash">${L('reports', 'жалоб')}</span></a>
      ${adNum(d.chat_reports, L('reports of messages', 'жалоб на сообщения'))}
      <a class="ad-num" href="#/admin/crashes"><b class="num">${fmt(d.crashes_day)}</b><span class="ash">${L('crashes today', 'вылетов за сутки')} · ${fmt(d.crashes_week)} ${L('this week', 'за неделю')}</span></a>
    </div>`;
}

function adUsers() {
  const c = ask('admin/users' + (AD.qLive ? '?q=' + encodeURIComponent(AD.qLive) : ''));
  const rows = waiting(c) ? '<div class="rows"><div>&nbsp;</div></div>' : !c.ok ? trouble(c) : c.data.items.length ? c.data.items.map((u) => `<a class="tk-row" href="#/admin/user/${encodeURIComponent(u.login)}">${head(u.login, 36)}
      <span class="tk-main"><b translate="no">${pfx(u.card)}${esc(u.login)}</b><span class="ash">UID <span class="num" translate="no">${esc(String((u.card && u.card.uid_text) || u.uid))}</span> · ${L('since', 'с')} ${when(u.since)}${u.seen ? ` · ${L('seen', 'был(а)')} ${ago(u.seen)}` : ''}${u.crashes ? ` · ${L('crashes', 'вылетов')} ${u.crashes}` : ''}</span></span>
      ${u.ban ? `<span class="st warn">${L('Banned', 'Бан')}</span>` : u.online ? `<span class="st ok">${L('Online', 'В сети')}</span>` : ''}</a>`).join('') : `<div class="empty">${L('Nobody found.', 'Никого не нашлось.')}</div>`;
  return `<div class="fr-invite ad-search"><input class="in" id="ad-q" type="search" placeholder="${L('Login, #UID or e-mail', 'Логин, #UID или почта')}" value="${esc(AD.q)}"></div><div class="tk-list">${rows}</div>`;
}

function adUser(login) {
  const c = ask('admin/users/' + encodeURIComponent(login));
  if (waiting(c)) return ghosts(1);
  if (!c.ok) return trouble(c);
  const u = c.data, owner = state.user && state.user.admin;
  const kv = (k, v) => `<div><span class="ash">${k}</span><span>${v}</span></div>`;
  const section = (title, inner) => (inner ? `<div class="block"><h2 class="sec">${title}</h2>${inner}</div>` : '');
  const ban = u.ban ? `<p class="st warn">${L('Banned', 'Забанен(а)')}: <span translate="no">${esc(u.ban.reason)}</span> · ${u.ban.until ? L('until ', 'до ') + adWhen(u.ban.until) : L('for good', 'навсегда')}</p>` : '';
  const actions = `<div class="acts ad-acts">
      ${adCan('users.ban') ? (u.ban ? `<button class="w small" data-ad-unban="1">${L('Lift the ban', 'Снять бан')}</button>` : `<span class="ad-ban"><input class="in" id="ad-ban-why" maxlength="200" placeholder="${L('Why (they see it)', 'Причина (человек увидит)')}" value="${esc(AD.banWhy)}">
        <select class="in small-select" id="ad-ban-for">${['1h', '1d', '7d', '30d', ''].map((k) => `<option value="${k}" ${AD.banFor === k ? 'selected' : ''}>${adLen(k)}</option>`).join('')}</select><button class="w small" data-ad-ban="1">${L('Ban', 'Забанить')}</button></span>`) : ''}
      ${adCan('users.device') && u.device ? `<button class="w small" data-ad-device="1">${AD.sure === 'device' ? L('Free it?', 'Сбросить?') : L('Free the computer', 'Сбросить привязку')}</button>` : ''}
      ${owner ? `<span class="ad-uid"><input class="in num" id="ad-uid" maxlength="16" autocomplete="off" spellcheck="false" placeholder="${L('UID or text', 'UID или текст')}" title="${L('A number moves the account; text is shown instead of it; a dash brings the number back.', 'Число переносит аккаунт; текст показывается вместо номера; прочерк возвращает номер.')}" value="${esc(AD.uid)}" style="max-width:150px"><button class="w small" data-ad-uid="1">${L('Give this UID', 'Сменить UID')}</button></span>` : ''}
      ${owner ? `<button class="w small bad" data-ad-delete="1">${AD.sure === 'delete' ? L('Delete for good?', 'Удалить насовсем?') : L('Delete the account', 'Удалить аккаунт')}</button>` : ''}
    </div>`;
  return `<div class="crumb"><a href="#/admin/users">${L('Members', 'Участники')}</a> / <span translate="no">${esc(u.login)}</span></div>
    <div class="ad-user-head">${head(u.login, 64)}<div><h2 class="big" translate="no">${pfx(u.card)}${esc(u.login)}</h2>
      <p class="ash">UID <span class="num" translate="no">${esc(String((u.card && u.card.uid_text) || u.uid))}</span>${u.card && u.card.uid_text ? ` <span class="num">(${u.uid})</span>` : ''} · ${L('since', 'с')} ${when(u.since)}${u.email ? ` · <span translate="no">${esc(u.email)}</span>` : ''} · <a href="${profHref(u.login)}">${L('Profile', 'Профиль')}</a></p></div></div>
    ${ban}${u.mute ? `<p class="st cream">${L('Muted on the forum until', 'Мут на форуме до')} ${adWhen(u.mute.until)}: <span translate="no">${esc(u.mute.why)}</span></p>` : ''}
    ${actions}
    <div class="block"><div class="kv ad-kv">
      ${kv(L('Roles', 'Роли'), esc((u.roles || []).join(', ') || '—'))}
      ${kv(L('Computer', 'Компьютер'), u.device ? `${L('bound', 'привязан')} ${when(u.device.bound)} · ${ago(u.device.seen)}` : L('none', 'нет'))}
      ${kv(L('Online', 'В сети'), u.online ? L('now', 'сейчас') : u.seen ? ago(u.seen) : '—')}
      ${kv(L('Sessions', 'Входов'), u.sessions)}${kv(L('Posts', 'Постов'), u.posts)}${kv(L('Hours in the game', 'Часов в игре'), u.game_hours)}
      ${kv(L('Tester', 'Тестер'), u.tester ? L('yes', 'да') : L('no', 'нет'))}
    </div></div>
    ${section(L('The staff’s notes', 'Заметки персонала'), `<div class="fr-invite"><input class="in" id="ad-note" maxlength="2000" placeholder="${L('Something to remember about them', 'Что стоит помнить о человеке')}" value="${esc(AD.note)}"><button class="w small" data-ad-note="1">${L('Keep', 'Сохранить')}</button></div>
      ${u.notes.map((n) => `<p class="ad-line"><span translate="no">${esc(n.text)}</span> <span class="ash">— ${esc(n.by && n.by.login || '?')}, ${ago(n.at)}</span></p>`).join('')}`)}
    ${section(L('Warnings', 'Предупреждения'), u.warnings.map((w) => `<p class="ad-line"><span translate="no">${esc(w.why)}</span> <span class="ash">— ${esc(w.by && w.by.login || '?')}, ${ago(w.at)}</span></p>`).join(''))}
    ${section(L('Bans', 'Баны'), (u.bans || []).map((b) => `<p class="ad-line"><span translate="no">${esc(b.reason)}</span> <span class="ash">— ${esc(b.by)}, ${adWhen(b.at)}${b.until ? ' → ' + adWhen(b.until) : ''}${b.lifted ? ` · ${L('lifted', 'снят')} ${adWhen(b.lifted)}` : ''}</span></p>`).join(''))}
    ${section(L('Tickets', 'Тикеты'), u.tickets.map((t) => `<p class="ad-line"><a href="#/support/t/${t.id}" translate="no">${esc(t.title)}</a> <span class="ash">· ${t.state} · ${ago(t.updated)}</span></p>`).join(''))}
    ${section(L('Crashes', 'Вылеты'), u.crash_list.map((k) => `<p class="ad-line"><a href="/api/admin/crashes/${k.id}" target="_blank" rel="noopener">${esc(k.cause)}</a> <span class="ash">· ${k.build ? L('build ', 'сборка ') + k.build + ' · ' : ''}${ago(k.at)}</span></p>`).join(''))}
    ${section(L('What the staff did', 'Что делал персонал'), u.history.map((h) => `<p class="ad-line"><b>${esc(h.action)}</b> <span class="ash">— ${esc(h.by && h.by.login || '?')}, ${ago(h.at)}</span></p>`).join(''))}`;
}

function adCrashes() {
  const c = ask(`admin/crashes?days=${AD.days}`);
  const days = [1, 7, 30, 90].map((d) => `<button class="w small ${AD.days === d ? 'on' : ''}" data-ad-days="${d}">${d === 1 ? L('a day', 'сутки') : d + L(' days', ' дн.')}</button>`).join('');
  if (waiting(c)) return `<div class="acts">${days}</div>${ghosts(1)}`;
  if (!c.ok) return trouble(c);
  const g = c.data.groups;
  return `<div class="acts">${days}<span class="gap"></span><span class="ash">${L('crashes', 'вылетов')}: <span class="num">${c.data.total}</span></span></div>
    <div class="tk-list">${g.length ? g.map((x, i) => `<div class="ad-crash"><button class="ad-crash-head" data-ad-open="${i}"><b class="num">${x.count}</b><span class="tk-main"><b translate="no">${esc(x.cause)}</b>
        <span class="ash">${x.people} ${L('people', 'чел.')} · ${x.builds.length ? L('builds ', 'сборки ') + x.builds.join(', ') : L('build ?', 'сборка ?')} · ${ago(x.last)}</span>
        ${x.gpus.length ? `<span class="ash" translate="no">${esc(x.gpus.join(' · '))}</span>` : ''}</span></button>
        ${AD.open === String(i) ? `<div class="acts ad-crash-list">${x.crashes.map((id) => `<a class="w small" href="/api/admin/crashes/${id}" target="_blank" rel="noopener">#${id}</a>`).join('')}</div>` : ''}</div>`).join('') : `<div class="empty">${L('No crashes. Good.', 'Вылетов нет.')}</div>`}</div>`;
}

function adNews() {
  const n = AD.news, c = ask('admin/announcements');
  const box = (k, en, ru) => `<label class="tk-check"><input type="checkbox" data-ad-to="${k}" ${n[k] ? 'checked' : ''}> ${L(en, ru)}</label>`;
  const list = !c.ok ? '' : c.data.items.map((a) => `<div class="ad-line ad-news-row"><b translate="no">${esc(a.title)}</b> <span class="ash">· ${adWhen(a.at)} · ${esc(a.by && a.by.login || '')}</span>
      <span class="ad-where">${[a.targets.site && L('site', 'сайт'), a.targets.forum && (a.thread ? `<a href="#/forum/t/${a.thread}">${L('forum', 'форум')}</a>` : L('forum', 'форум')), a.targets.game && L('game', 'игра'),
        a.targets.discord && (a.discord_at ? 'Discord ✓' : L('Discord: the bot has not taken it yet', 'Discord: бот ещё не взял')), a.targets.telegram && (a.telegram_at ? 'Telegram ✓' : L('Telegram: waiting for the bot', 'Telegram: ждёт бота'))].filter(Boolean).join(' · ')}${a.error ? ` · <span class="bad">${esc(a.error)}</span>` : ''}</span></div>`).join('');
  return `<div class="form" style="max-width:760px">
      <div><label class="lab" for="ad-n-title">${L('Title', 'Заголовок')}</label><input class="in" id="ad-n-title" maxlength="120" value="${esc(n.title)}"></div>
      <div><label class="lab" for="ad-n-body">${L('Text', 'Текст')}</label>${editor('ad-n-body', n.body, 8)}</div>
      <div class="acts ad-to">${box('site', 'The site’s news', 'Новости сайта')}${box('forum', 'The forum’s announcements', 'Форум: объявления')}${box('game', 'Everyone in the client (a notification)', 'Всем в клиенте (уведомление)')}
        ${box('discord', 'Three Discord servers', 'Три Discord-сервера')}${n.discord ? box('everyone', '…with @everyone', '…с @everyone') : ''}${box('telegram', 'Telegram (to you, to forward)', 'Telegram (тебе, переслать)')}</div>
      <div class="acts"><button class="w menu lead" id="ad-announce" data-submit-for="ad-n-body">${L('Announce', 'Опубликовать')}</button></div></div>
    <div class="block" style="margin-top:34px"><h2 class="sec">${L('Announced', 'Опубликованные')}</h2>${list || `<p class="ash">${L('Nothing yet.', 'Пока ничего.')}</p>`}</div>`;
}

function adSwitches() {
  const reg = ask('admin/switch/registration'), pins = ask('admin/pinned'), builds = ask('admin/builds');
  const r = reg.ok ? reg.data : null;
  return `<div class="block"><h2 class="sec">${L('Registration', 'Регистрация')}</h2>${r ? `<p>${r.state === 'open' ? L('Open', 'Открыта') : L('Closed', 'Закрыта')} · <span class="num">${r.taken} / ${r.limit}</span></p>
      <div class="acts"><button class="w small" data-ad-reg="${r.state === 'open' ? 'closed' : 'open'}">${r.state === 'open' ? L('Close', 'Закрыть') : L('Open', 'Открыть')}</button>
      <span class="fr-invite"><input class="in num" id="ad-limit" type="number" min="0" value="${r.limit}" style="max-width:110px"><button class="w small" data-ad-limit="1">${L('Set the limit', 'Поставить лимит')}</button></span></div>` : trouble(reg)}</div>
    <div class="block"><h2 class="sec">${L('Partners pinned in the client’s servers', 'Партнёры наверху списка серверов')}</h2>
      ${pins.ok ? pins.data.items.filter((p) => !p.gone).map((p) => `<p class="ad-line"><b translate="no">${esc(p.name)}</b> <span class="ash" translate="no">${esc(p.address)}</span> <button class="w small" data-ad-unpin="${esc(p.address)}">${L('Unpin', 'Убрать')}</button></p>`).join('') || `<p class="ash">${L('None.', 'Нет.')}</p>` : ''}
      <div class="fr-invite"><input class="in" id="ad-pin-address" placeholder="mc.server.net" value="${esc(AD.pin.address)}"><input class="in" id="ad-pin-name" placeholder="${L('Its name', 'Название')}" value="${esc(AD.pin.name)}"><button class="w small" data-ad-pin="1">${L('Pin', 'Закрепить')}</button></div>
      <p class="hint">${L('It reaches every player with the blocklist, within a quarter of an hour.', 'Доходит до всех игроков вместе с чёрным списком, в течение четверти часа.')}</p></div>
    <div class="block"><h2 class="sec">${L('Builds', 'Сборки')}</h2>${builds.ok ? builds.data.items.map((b) => `<p class="ad-line">${b.current ? '<span class="st ok">' + L('current', 'текущая') + '</span> ' : ''}<b>${L('build', 'сборка')} ${b.build}</b> <span class="ash">· ${esc(b.version)} · ${adWhen(b.at)} · ${b.files} ${L('files', 'файлов')} · ${mb(b.bytes)}</span></p>`).join('') || `<p class="ash">${L('None yet.', 'Пока нет.')}</p>` : ''}
      ${builds.ok && builds.data.items.length > 1 ? `<div class="acts"><button class="w small bad" data-ad-rollback="1">${AD.sure === 'rollback' ? L('Roll back for everyone?', 'Откатить у всех?') : L('Roll back to the build before', 'Откатить на прошлую сборку')}</button></div>` : ''}
      <p class="hint">${L('New builds are published from the computer (tools/Release.java), after the list of changes is agreed.', 'Новые сборки выкладываются с компьютера (tools/Release.java), после согласования списка изменений.')}</p></div>`;
}

function adRoles() {
  const c = ask('admin/roles');
  if (waiting(c)) return ghosts(1);
  if (!c.ok) return trouble(c);
  const roles = c.data.roles.filter((r) => r.staff || ['media', 'partner'].includes(r.id));
  const has = (r, p) => r.perms.includes('*') || r.perms.includes(p);
  return `<div class="scroll-x"><table class="np ad-roles"><thead><tr><th></th>${roles.map((r) => `<th><span class="pfx" style="--c:${esc(r.colour)}">${esc(r.prefix)}</span></th>`).join('')}</tr></thead><tbody>
      ${c.data.perms.map((p) => `<tr><td translate="no">${esc(p)}</td>${roles.map((r) => `<td>${has(r, p) ? '<span class="cream">●</span>' : '<span class="ash">·</span>'}</td>`).join('')}</tr>`).join('')}
    </tbody></table></div>
    ${roles.map((r) => `<div class="block"><h2 class="sec"><span class="pfx" style="--c:${esc(r.colour)}">${esc(r.prefix)}</span> ${L(r.en, r.ru)} <span class="ash num">${r.id === 'creator' ? 1 : r.count}</span></h2>
      <p>${r.people.map((p) => nm(p)).join(' · ') || `<span class="ash">${L('Nobody.', 'Никого.')}</span>`}</p></div>`).join('')}
    <p class="hint">${L('Roles are given on a member’s profile.', 'Роли выдаются на странице профиля участника.')}</p>`;
}

function adJournal() {
  const q = [AD.jAction && 'action=' + encodeURIComponent(AD.jAction), AD.jActor && 'actor=' + encodeURIComponent(AD.jActor)].filter(Boolean).join('&');
  const c = ask('admin/journal' + (q ? '?' + q : ''));
  const rows = waiting(c) ? '<div class="rows"><div>&nbsp;</div></div>' : !c.ok ? trouble(c) : c.data.items.map((x) => `<p class="ad-line"><span class="ash">${adWhen(x.at)}</span> ${nm(x.by)} <b translate="no">${esc(x.action)}</b>
      ${x.person ? nm(x.person) : x.target ? `<span class="ash" translate="no">${esc(x.target)}</span>` : ''}${x.details && (x.details.reason || x.details.why || x.details.title) ? ` <span class="ash" translate="no">· ${esc(x.details.reason || x.details.why || x.details.title)}</span>` : ''}</p>`).join('') || `<p class="ash">${L('Nothing.', 'Пусто.')}</p>`;
  return `<div class="fr-invite ad-search"><input class="in" id="ad-j-action" placeholder="${L('Action: user., forum., ticket.…', 'Действие: user., forum., ticket.…')}" value="${esc(AD.jAction)}"><input class="in" id="ad-j-actor" placeholder="${L('Who: a login', 'Кто: логин')}" value="${esc(AD.jActor)}"><button class="w small" id="ad-j-go">${L('Show', 'Показать')}</button></div><div class="ad-journal">${rows}</div>`;
}

// The site's news (what was announced for it).
function viewNews() {
  const c = ask('news');
  const items = waiting(c) ? ghosts(1) : !c.ok ? trouble(c) : c.data.items.map((a) => `<article class="ad-article"><p class="ash">${when(a.at)}</p><h2 class="big" translate="no">${esc(a.title)}</h2>
      <div class="prose post-body" translate="no">${prose(a.body)}</div>${a.thread ? `<div class="acts"><a class="w small" href="#/forum/t/${a.thread}">${L('Discuss on the forum', 'Обсудить на форуме')}</a></div>` : ''}</article>`).join('') || `<div class="empty">${L('No news yet.', 'Новостей пока нет.')}</div>`;
  return `<div class="page-head"><h1 class="giant">${L('News', 'Новости')}</h1></div><div class="ad-news">${items}</div>`;
}

function adminWire() {
  if (state.route !== 'admin' && state.route !== 'news') return;
  const on = (sel, ev, fn) => $app.querySelectorAll(sel).forEach((el) => el.addEventListener(ev, (e) => fn(el, e)));
  const login = () => decodeURIComponent(String(state.arg).split('/')[1] || '');
  const said = (r, ok) => { AD.bad = !r.ok; AD.msg = r.ok ? ok || '' : tr(r.message || SAY[r.error] || (r.error === 'owner' ? 'Only she may.' : r.error === 'staff' ? 'Your role does not allow it.' : SAY.busy)); };
  const again = (...p) => { forget(...p); render(true); };
  foEditorsWire(on);
  let timer = 0;
  on('#ad-q', 'input', (el) => { AD.q = el.value; clearTimeout(timer); timer = setTimeout(() => { AD.qLive = AD.q.trim(); render(true); }, 300); });
  on('#ad-note', 'input', (el) => { AD.note = el.value; });
  on('#ad-ban-why', 'input', (el) => { AD.banWhy = el.value; });
  on('#ad-ban-for', 'change', (el) => { AD.banFor = el.value; });
  on('#ad-uid', 'input', (el) => { AD.uid = el.value; });
  on('[data-ad-note]', 'click', async () => { const r = await api(`admin/users/${encodeURIComponent(login())}/notes`, { text: AD.note }); if (r.ok) AD.note = ''; said(r); again('admin/users'); });
  on('[data-ad-ban]', 'click', async () => { const r = await api(`admin/users/${encodeURIComponent(login())}/ban`, { reason: AD.banWhy, length: AD.banFor }); if (r.ok) AD.banWhy = ''; said(r, L('Banned: it works from their next start.', 'Забанен(а): действует со следующего запуска.')); again('admin/users'); });
  on('[data-ad-unban]', 'click', async () => { const r = await api(`admin/users/${encodeURIComponent(login())}/ban`, null, 'DELETE'); said(r, L('The ban is lifted.', 'Бан снят.')); again('admin/users'); });
  on('[data-ad-device]', 'click', async () => {
    if (AD.sure !== 'device') { AD.sure = 'device'; render(true); return; }
    AD.sure = '';
    const r = await api(`admin/users/${encodeURIComponent(login())}/device`, {}); said(r, L('Freed.', 'Привязка сброшена.')); again('admin/users');
  });
  on('[data-ad-uid]', 'click', async () => { const v = AD.uid.trim(), text = !/^\d+$/.test(v); const r = await api(`admin/users/${encodeURIComponent(login())}/uid`, text ? { text: v === '-' ? '' : v } : { to: Number(v) }); if (r.ok) AD.uid = ''; said(r, r.ok ? (text ? L(`UID ${r.data.from} is shown as ${r.data.uid_text || r.data.from}.`, `UID ${r.data.from} теперь показывается как ${r.data.uid_text || r.data.from}.`) : L(`UID ${r.data.from} → ${r.data.to}.`, `UID ${r.data.from} → ${r.data.to}.`)) : ''); again('admin/users', 'u/'); });
  on('[data-ad-delete]', 'click', async () => {
    if (AD.sure !== 'delete') { AD.sure = 'delete'; render(true); return; }
    AD.sure = '';
    const r = await api(`admin/users/${encodeURIComponent(login())}`, null, 'DELETE'); said(r, L('Deleted: the place is free.', 'Удалён: место свободно.'));
    forget('admin/users'); if (r.ok) location.hash = '#/admin/users'; else render(true);
  });
  on('[data-ad-days]', 'click', (b) => { AD.days = Number(b.dataset.adDays); AD.open = ''; render(true); });
  on('[data-ad-open]', 'click', (b) => { AD.open = AD.open === b.dataset.adOpen ? '' : b.dataset.adOpen; render(true); });
  on('#ad-n-title', 'input', (el) => { AD.news.title = el.value; });
  on('#ad-n-body', 'input', (el) => { AD.news.body = el.value; });
  on('[data-ad-to]', 'change', (el) => { AD.news[el.dataset.adTo] = el.checked; if (el.dataset.adTo === 'discord') render(true); });
  on('#ad-announce', 'click', async (b) => {
    if (AD.sure !== 'announce') { AD.sure = 'announce'; b.textContent = L('Send it everywhere checked?', 'Отправить везде, где отмечено?'); return; }
    AD.sure = '';
    const n = AD.news;
    const r = await api('admin/announcements', { title: n.title, body: n.body, site: n.site, forum: n.forum, game: n.game, discord: n.discord, everyone: n.everyone, telegram: n.telegram });
    if (r.ok) { n.title = ''; n.body = ''; }
    said(r, L('Announced. The bot takes Discord and Telegram within a minute.', 'Опубликовано. Discord и Telegram бот заберёт в течение минуты.'));
    again('admin/announcements', 'news', 'forum');
  });
  on('[data-ad-reg]', 'click', async (b) => { const r = await api('admin/switch/registration', { state: b.dataset.adReg }); said(r); again('admin/'); });
  on('[data-ad-limit]', 'click', async () => { const r = await api('admin/switch/registration', { limit: Number((document.getElementById('ad-limit') || {}).value) }); said(r); again('admin/'); });
  on('#ad-pin-address', 'input', (el) => { AD.pin.address = el.value; });
  on('#ad-pin-name', 'input', (el) => { AD.pin.name = el.value; });
  on('[data-ad-pin]', 'click', async () => { const r = await api('admin/pinned', AD.pin); if (r.ok) AD.pin = { address: '', name: '' }; said(r, L('Pinned.', 'Закреплён.')); again('admin/pinned'); });
  on('[data-ad-unpin]', 'click', async (b) => { const r = await api(`admin/pinned/${encodeURIComponent(b.dataset.adUnpin)}`, null, 'DELETE'); said(r); again('admin/pinned'); });
  on('[data-ad-rollback]', 'click', async () => {
    if (AD.sure !== 'rollback') { AD.sure = 'rollback'; render(true); return; }
    AD.sure = '';
    const r = await api('admin/builds/rollback', { channel: 'beta' }); said(r, r.ok ? L(`Everyone is on build ${r.data.build} again.`, `Все снова на сборке ${r.data.build}.`) : ''); again('admin/builds');
  });
  on('#ad-j-action', 'input', (el) => { AD.jAction = el.value; });
  on('#ad-j-actor', 'input', (el) => { AD.jActor = el.value; });
  on('#ad-j-go', 'click', () => render(true));
}
