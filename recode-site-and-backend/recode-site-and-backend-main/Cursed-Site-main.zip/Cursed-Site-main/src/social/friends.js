// ================================================================================================ friends (03.10.2026)
// Friends and conversations (#/friends): the list of conversations and the invitations to groups on the left; on the
// right the one open (#/friends/c/<id>), the friends and their requests (#/friends/people), a new group
// (#/friends/new), a group's link (#/friends/join/<code>). An open conversation lives in FR.chat and is changed in
// place by the live line: a message is added without drawing the page again, so what is being typed stays as it is.

const FR = { chat: null, unread: 0, typingAt: 0, rec: null, ng: null, add: '', addMsg: '', panel: false, react: 0, del: 0, report: 0, reportWhy: '', pic: null, plays: null };
MEMBERS_ONLY.add('friends');

/** At the sign-in: how many messages wait unread (the bar's count). */
function frStart() {
  api('chats').then((r) => { if (r.ok) { got.set('chats', { at: performance.now(), ok: true, data: r.data }); frUnread(r.data.unread); } });
}
function frUnread(n) {
  FR.unread = Math.max(0, n | 0);
  document.querySelectorAll('.nav-fr .nb').forEach((b) => { b.textContent = FR.unread ? (FR.unread > 99 ? '99+' : FR.unread) : ''; });
}
const navFriends = () => `<a class="w nav-fr ${state.route === 'friends' && !state.gate ? 'on' : ''}" href="#/friends">Friends<span class="nb num">${FR.unread ? (FR.unread > 99 ? '99+' : FR.unread) : ''}</span></a>`;
const frHref = (id) => `#/friends/c/${id}`;
const mine = (m) => m && m.author && state.user && m.author.uid === state.user.uid;
/** A group's picture, or its first letter on the dark. */
const groupAv = (c, size) => (c.avatar && c.avatar.url ? `<img class="g-av" src="${esc(c.avatar.url)}" alt="" style="width:${size}px;height:${size}px" decoding="async">`
  : `<span class="g-av g-letter" style="width:${size}px;height:${size}px;font-size:${Math.round(size * 0.42)}px" translate="no">${esc((c.title || '?').slice(0, 1).toUpperCase())}</span>`);
const chatAv = (c, size) => (c.kind === 'dm' && c.other ? `<span class="c-av">${head(c.other.login, size)}${dot(c.other.presence && c.other.presence.online)}</span>` : groupAv(c, size));
const chatName = (c) => (c.kind === 'dm' && c.other ? `${pfx(c.other)}<b translate="no"${c.other.accent ? ` style="color:${esc(c.other.accent)}"` : ''}>${esc(c.other.login)}</b>` : `<b translate="no">${esc(c.title)}</b>`);
/** A time of a message: the hour today, the day before that. */
const clock = (s) => {
  const d = new Date(s * 1000), now = new Date();
  return d.toDateString() === now.toDateString() ? d.toLocaleTimeString(L('en-GB', 'ru-RU'), { hour: '2-digit', minute: '2-digit' })
    : d.toLocaleDateString(L('en-GB', 'ru-RU'), { day: 'numeric', month: 'short' });
};
const dayOf = (s) => new Date(s * 1000).toDateString();
const dayWords = (s) => {
  const d = new Date(s * 1000), today = new Date(), y = new Date(Date.now() - 86400000);
  if (d.toDateString() === today.toDateString()) return L('Today', 'Сегодня');
  if (d.toDateString() === y.toDateString()) return L('Yesterday', 'Вчера');
  return d.toLocaleDateString(L('en-GB', 'ru-RU'), { day: 'numeric', month: 'long', year: d.getFullYear() === today.getFullYear() ? undefined : 'numeric' });
};
/** Small marks of the composer, drawn in the site's own line (the pack's emoji have no microphone). */
const frIcon = (d) => `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
const ICON_PICTURE = '<rect x="3" y="5" width="18" height="14" rx="3"/><circle cx="9" cy="10" r="1.6"/><path d="m4.5 17 5-5 4 4 2.5-2.5 3.5 3.5"/>';
const ICON_MIC = '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21M8.5 21h7"/>';
const secs = (ms) => { const s = Math.round((ms || 0) / 1000); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };

/** What a group's history says happened; with names, and without guessing anyone's gender in Russian. */
function sysWords(b) {
  if (!b) return '';
  const who = `<b translate="no">${esc(b.who || '')}</b>`, whom = `<b translate="no">${esc(b.whom || '')}</b>`, t = `<span translate="no">${L('“', '«')}${esc(b.title || '')}${L('”', '»')}</span>`;
  switch (b.what) {
    case 'created': return L(`${who} made the group ${t}`, `Группа ${t} создана · ${who}`);
    case 'joined': return L(`${who} joined${b.link ? ' by the link' : ''}`, `Новый участник: ${who}${b.link ? ' (по ссылке)' : ''}`);
    case 'left': return L(`${who} left`, `Выход из группы: ${who}`);
    case 'removed': return L(`${who} removed ${whom}`, `Исключение из группы: ${whom} · ${who}`);
    case 'title': return L(`${who} renamed the group ${t}`, `Новое название: ${t} · ${who}`);
    case 'avatar': return L(`${who} changed the group's picture`, `Новая картинка группы · ${who}`);
    case 'pinned': return L(`${who} pinned a message`, `Закреплено сообщение · ${who}`);
    case 'admin': return L(`${who} made ${whom} an admin`, `Новый админ: ${whom} · ${who}`);
    case 'unadmin': return L(`${who} took admin from ${whom}`, `Больше не админ: ${whom} · ${who}`);
    default: return '';
  }
}
/** A message's words: escaped, its addresses made links, its lines kept. */
function frText(s) {
  return esc(s).replace(/\bhttps?:\/\/[^\s<>"]+/g, (u) => `<a href="${u}" target="_blank" rel="noopener noreferrer nofollow">${u}</a>`).replace(/\n/g, '<br>');
}
/** A message in one line (the list, a quote, a note). */
const frBrief = (m) => (!m ? '' : m.deleted ? L('Message removed', 'Сообщение удалено') : m.kind === 'picture' ? L('Picture', 'Картинка') : m.kind === 'voice' ? L('Voice message', 'Голосовое')
  : m.kind === 'system' ? sysWords(m.system || m.body).replace(/<[^>]+>/g, '') : (m.text !== undefined ? m.text : m.body) || '');

// ---- the left: conversations and invitations

function frRail(list, sub, open) {
  const reqs = ask('friends'), incoming = reqs.ok ? reqs.data.incoming.length : 0;
  const tabs = `<div class="fr-tabs"><a class="w ${sub !== 'people' && sub !== 'new' ? 'on' : ''}" href="#/friends">Chats</a><a class="w ${sub === 'people' ? 'on' : ''}" href="#/friends/people">Friends${incoming ? `<span class="nb num">${incoming}</span>` : ''}</a>
    <a class="w small ${sub === 'new' ? 'on' : ''}" href="#/friends/new" title="New group">+ ${L('Group', 'Группа')}</a></div>`;
  if (waiting(list)) return tabs + '<div class="fr-list ghost-rows"><div></div><div></div><div></div></div>';
  if (!list.ok) return tabs + trouble(list);
  const inv = list.data.invites.map((i) => `<div class="fr-inv">${groupAv(i, 40)}<span class="fr-l"><span>${L(`${esc(i.by.login)} invites you`, `${esc(i.by.login)} зовёт вас`)}</span><b translate="no">${esc(i.title)}</b><span class="ash num">${i.members} ${L('in it', plural(i.members, 'участник', 'участника', 'участников'))}</span></span>
      <span class="acts"><button class="w small lead" data-inv-join="${i.chat}">Join</button><button class="w small" data-inv-no="${i.chat}">Decline</button></span></div>`).join('');
  const rows = list.data.chats.map((c) => {
    const last = c.last, own = last && state.user && last.uid === state.user.uid;
    const line = last ? `${own ? L('You: ', 'Вы: ') : c.kind === 'group' && last.author && last.kind !== 'system' ? `<span translate="no">${esc(last.author)}:</span> ` : ''}<span translate="no">${esc(frBrief(last))}</span>` : `<span class="ash">${L('No messages yet', 'Пока без сообщений')}</span>`;
    return `<a class="fr-row ${c.id === open ? 'on' : ''} ${c.unread ? 'unread' : ''}" href="${frHref(c.id)}">${chatAv(c, 44)}
      <span class="fr-l"><span class="fr-top">${chatName(c)}${c.muted ? '<span class="muted" title="Muted">·</span>' : ''}<span class="t num">${last ? clock(last.created) : ''}</span></span>
      <span class="fr-last">${line}</span></span>${c.unread ? `<span class="pill num">${c.unread > 99 ? '99+' : c.unread}</span>` : ''}</a>`;
  }).join('');
  return tabs + (inv ? `<div class="fr-invs">${inv}</div>` : '') + `<div class="fr-list">${rows || `<p class="empty-s ash">${L('No conversations yet. Write to a friend from their profile or from Friends.', 'Пока нет переписок. Напишите другу — из его профиля или во вкладке «Друзья».')}</p>`}</div>`;
}

// ---- the page

function viewFriends(arg) {
  const [sub, x] = String(arg || '').split('/');
  const list = ask('chats');
  const open = sub === 'c' ? Number(x) : 0;
  let main;
  if (open) main = frChat(open, list);
  else if (sub === 'people') main = frPeople();
  else if (sub === 'new') main = frNew();
  else if (sub === 'join') main = frJoin(x);
  else main = `<div class="fr-empty"><span class="big-emo">${emo('c_chat', 96)}</span><h1 class="big">Friends</h1><p class="ash">${L('Pick a conversation on the left, or start one with a friend.', 'Выберите переписку слева или начните новую с другом.')}</p>
      <div class="acts"><a class="w lead" href="#/friends/people">Friends</a><a class="w" href="#/friends/new">New group</a></div></div>`;
  if (!open) FR.chat = null;
  return `<h1 class="sr">Friends</h1><div class="fr ${open || sub ? 'deep' : ''} ${FR.panel && open ? 'with-panel' : ''}"><aside class="fr-rail">${frRail(list, sub, open)}</aside><section class="fr-main">${main}</section></div>`;
}

// ---- one conversation

function frLoad(id) {
  const ch = { id, messages: null, more: false, people: [], meta: null, draft: (FR.drafts && FR.drafts[id]) || '', reply: null, edit: null, stick: true, typing: {}, failed: false };
  FR.chat = ch;
  FR.panel = false;
  api(`chats/${id}`).then((r) => {
    if (FR.chat !== ch) return;
    if (!r.ok) { ch.failed = r.status || true; render(true); return; }
    ch.messages = r.data.messages; ch.more = r.data.more; ch.people = r.data.people; ch.meta = r.data.chat;
    frRead();
    render(true);
  });
}
/** What is open is read (while the page is in front). */
function frRead() {
  const ch = FR.chat;
  if (!ch || !ch.messages || !ch.messages.length || document.visibilityState !== 'visible') return;
  const top = ch.messages[ch.messages.length - 1].id;
  if (ch.meta && ch.meta.read_upto >= top) return;
  if (ch.meta) ch.meta.read_upto = top;
  api(`chats/${ch.id}/read`, { upto: top });
  const got_ = got.get('chats');
  if (got_ && got_.ok) { const c = got_.data.chats.find((x) => x.id === ch.id); if (c) c.unread = 0; }
}
document.addEventListener('visibilitychange', () => { if (state.route === 'friends') frRead(); });

function frChat(id, list) {
  if (!FR.chat || FR.chat.id !== id) frLoad(id);
  const ch = FR.chat;
  if (ch.failed) return `<div class="fr-empty"><h1 class="big">${ch.failed === 404 ? L('Not here', 'Не найдено') : L('Not loaded', 'Не загрузилось')}</h1><p class="ash">${ch.failed === 404 ? L('This conversation is gone, or you are not in it.', 'Этой переписки нет или вы в ней не состоите.') : SAY.busy}</p><a class="w" href="#/friends">Friends</a></div>`;
  const c = ch.meta || (list.ok && list.data.chats.find((x) => x.id === id));
  if (!c || !ch.messages) return '<div class="fr-chat"><div class="fr-head ghost-t">&nbsp;</div><div class="fr-msgs ghost-rows"><div></div><div></div><div></div></div></div>';
  const pres = c.other && c.other.presence;
  const sub = c.kind === 'dm' ? (pres && pres.online ? `${dot(pres.online)}<span>${pres.online === 'game' ? tr('In the game') : tr('On the site')}</span>${pres.listening ? `<span class="listening">${emo('c_play', 16)}<span translate="no">${esc(pres.listening.title)}</span></span>` : ''}` : (c.other && c.other.status ? statusOf(c.other.status) : ''))
    : `<span class="num">${c.members} ${L('members', plural(c.members, 'участник', 'участника', 'участников'))}</span>`;
  const headName = c.kind === 'dm' ? `<a href="${profHref(c.other.login)}" class="fr-hname">${chatName(c)}</a>` : `<button class="fr-hname" data-panel>${chatName(c)}</button>`;
  const pinned = c.pinned ? `<button class="fr-pin" data-jump-msg="${c.pinned.id}">${emo('c_wings', 18)}<span class="ash">${L('Pinned', 'Закреплено')}:</span><span translate="no">${esc(frBrief(c.pinned))}</span>${c.kind === 'dm' || c.role !== 'member' ? '<span class="x" data-unpin title="Unpin">×</span>' : ''}</button>` : '';
  const typing = Object.entries(ch.typing).filter(([, t]) => Date.now() - t.at < 5000).map(([, t]) => t.login);
  return `<div class="fr-chat">
    <div class="fr-head"><a class="w small fr-back" href="#/friends" aria-label="Back">‹</a>${chatAv(c, 40)}<span class="fr-l">${headName}<span class="fr-sub">${sub}</span></span>
      <span class="acts"><button class="w small" data-mute>${c.muted ? 'Unmute' : 'Mute'}</button>${c.kind === 'group' ? `<button class="w small ${FR.panel ? 'on' : ''}" data-panel>Members</button>` : ''}</span></div>
    ${pinned}
    <div class="fr-msgs" id="fr-msgs">${ch.more ? '<div class="fr-older"><button class="w small" id="fr-older">Older messages</button></div>' : ''}${frMsgs(ch, c)}</div>
    <div class="fr-typing" id="fr-typing">${typing.length ? `<span translate="no">${esc(typing.join(', '))}</span> ${L(typing.length > 1 ? 'are typing…' : 'is typing…', 'печатает…')}` : ''}</div>
    ${frComposer(ch, c)}
  </div>${FR.panel && c.kind === 'group' ? frPanel(ch, c) : ''}${FR.pic ? `<div class="lightbox" id="fr-lightbox"><img src="${esc(FR.pic)}" alt=""><button class="w small lb-close" id="fr-lb-close">Close</button></div>` : ''}`;
}

function frMsgs(ch, c) {
  let out = '', prev = null;
  const lastMine = [...ch.messages].reverse().find((m) => mine(m) && !m.deleted && m.kind !== 'system');
  for (const m of ch.messages) {
    if (!prev || dayOf(prev.created) !== dayOf(m.created)) out += `<div class="fr-day"><span>${dayWords(m.created)}</span></div>`;
    out += frMsg(m, prev, ch, c, lastMine && lastMine.id === m.id);
    prev = m;
  }
  return out || `<p class="empty-s ash">${L('Say hello.', 'Напишите первым.')}</p>`;
}

function frMsg(m, prev, ch, c, lastOwn) {
  if (m.kind === 'system') return `<div class="fr-sys" data-msg="${m.id}">${sysWords(m.body)}</div>`;
  const own = mine(m);
  const run = prev && prev.kind !== 'system' && prev.author && m.author && prev.author.uid === m.author.uid && m.created - prev.created < 300 && dayOf(prev.created) === dayOf(m.created) && !m.reply;
  const who = m.author || { login: '—' };
  let body;
  if (m.deleted) body = `<p class="fr-gone">${L('Message removed', 'Сообщение удалено')}</p>`;
  else if (m.kind === 'picture') body = `<button class="fr-picture" data-pic="${esc(m.media.gif || m.media.url)}"><img src="${esc(m.media.gif || m.media.thumb)}" alt="" loading="lazy" style="aspect-ratio:${m.media.w}/${m.media.h}"></button>`;
  else if (m.kind === 'voice') body = frVoice(m);
  else body = `<p class="fr-text" translate="no">${frText(m.body)}</p>`;
  const quote = m.reply ? `<button class="fr-quote" data-jump-msg="${m.reply.id}"><b translate="no">${esc(m.reply.author || '')}</b><span translate="no">${esc(frBrief(m.reply))}</span></button>` : '';
  const reacts = (m.reactions || []).map((r) => `<button class="fr-react ${state.user && r.uids.includes(state.user.uid) ? 'on' : ''}" data-react="${m.id}:${esc(r.emoji)}">${emo(r.emoji, 20)}<span class="num">${r.uids.length}</span></button>`).join('');
  const canPin = !m.deleted && (c.kind === 'dm' || c.role !== 'member');
  const canDel = !m.deleted && (own || (c.kind === 'group' && c.role !== 'member'));
  const tools = m.deleted ? '' : `<span class="fr-tools">
      <button data-reply="${m.id}" title="Reply">${L('Reply', 'Ответить')}</button><button data-react-open="${m.id}" title="React">${emo('c_heart', 16)}</button>
      ${own && m.kind === 'text' ? `<button data-edit="${m.id}">${L('Edit', 'Изменить')}</button>` : ''}${canPin ? `<button data-pin="${m.id}">${L('Pin', 'Закрепить')}</button>` : ''}
      ${canDel ? `<button data-del="${m.id}" class="${FR.del === m.id ? 'sure' : ''}">${FR.del === m.id ? L('Remove?', 'Удалить?') : L('Remove', 'Удалить')}</button>` : ''}${!own ? `<button data-report="${m.id}">${L('Report', 'Пожаловаться')}</button>` : ''}</span>`;
  const picker = FR.react === m.id ? `<div class="fr-picker">${(SOC.meta ? SOC.meta.emoji : []).map((e) => `<button data-react="${m.id}:${esc(e)}">${emo(e, 26)}</button>`).join('')}</div>` : '';
  const report = FR.report === m.id ? `<div class="fr-reporting"><input class="in" id="fr-report-why" maxlength="300" placeholder="What is wrong with it?" value="${esc(FR.reportWhy)}"><button class="w small lead" id="fr-report-go">Report</button><button class="w small" id="fr-report-no">Cancel</button></div>` : '';
  const read = lastOwn && c.kind === 'dm' && c.their_read >= m.id ? `<span class="fr-read">${L('Read', 'Прочитано')}</span>` : '';
  return `<div class="fr-msg ${own ? 'own' : ''} ${run ? 'run' : ''}" data-msg="${m.id}">
    ${run ? '<span class="fr-gap"></span>' : `<a class="fr-who" href="${profHref(who.login)}">${head(who.login, 36)}</a>`}
    <div class="fr-b">${run ? '' : `<div class="fr-name">${nm(who)}<span class="ash num">${clock(m.created)}</span></div>`}
      ${quote}${body}${m.edited && !m.deleted ? `<span class="fr-edited ash">${L('edited', 'изменено')}</span>` : ''}${reacts ? `<div class="fr-reacts">${reacts}</div>` : ''}${read}${picker}${report}</div>${tools}</div>`;
}

function frVoice(m) {
  const playing = FR.plays && FR.plays.id === m.id;
  return `<div class="fr-voice ${playing ? 'on' : ''}" data-voice="${m.id}"><button class="play" data-voice-play="${m.id}" data-src="${esc(m.media.url)}" aria-label="Play"><i></i></button>
    <span class="vbar"><i style="transform:scaleX(${playing ? FR.plays.at || 0 : 0})"></i></span><span class="num ash">${secs(m.media.ms)}</span></div>`;
}

function frComposer(ch, c) {
  if (c.kind === 'dm' && c.other && c.other.blocked) return '';
  const bar = ch.edit ? `<div class="fr-bar">${L('Editing', 'Правка')}<span class="ash" translate="no">${esc(ch.edit.body.slice(0, 80))}</span><button class="x" id="fr-bar-x" title="Cancel">×</button></div>`
    : ch.reply ? `<div class="fr-bar">${L('Reply to', 'Ответ')} <b translate="no">${esc(ch.reply.author || '')}</b><span class="ash" translate="no">${esc(frBrief(ch.reply))}</span><button class="x" id="fr-bar-x" title="Cancel">×</button></div>` : '';
  const rec = FR.rec && FR.rec.chat === ch.id;
  return `<div class="fr-compose ${rec ? 'rec' : ''}" id="fr-compose">${bar}
    <div class="fr-row-in">${rec ? `<span class="rec-dot"></span><span class="num" id="fr-rec-t">${secs(Date.now() - FR.rec.at)}</span><span class="ash">${L('Recording…', 'Запись…')}</span><span class="gap"></span><button class="w small" id="fr-rec-no">Cancel</button><button class="w small lead" id="fr-rec-go">Send</button>`
      : `<label class="fr-attach" title="Picture">${frIcon(ICON_PICTURE)}<input type="file" id="fr-file" accept="image/png,image/jpeg,image/webp,image/gif" hidden></label>
      <textarea class="in" id="fr-in" rows="1" maxlength="2000" placeholder="${c.kind === 'dm' ? L('Message', 'Сообщение') : L('Message the group', 'Сообщение группе')}">${esc(ch.draft)}</textarea>
      ${navigator.mediaDevices && window.MediaRecorder ? `<button class="fr-mic" id="fr-mic" title="Voice message">${frIcon(ICON_MIC)}</button>` : ''}<button class="w small lead" id="fr-send">Send</button>`}</div>
    <p class="hint" id="fr-msg" role="status"></p></div>`;
}

// ---- a group's members, invitations, link, name, picture

function frPanel(ch, c) {
  const manage = c.role !== 'member';
  const people = ch.people.map((p) => `<div class="fr-member">${head(p.login, 32)}<span class="fr-l">${nm(p)}<span class="ash">${p.role === 'owner' ? L('owner', 'владелец') : p.role === 'admin' ? L('admin', 'админ') : ''}</span></span>
      ${state.user && p.uid !== state.user.uid ? `<span class="acts">${c.role === 'owner' ? `<button class="w small" data-rank="${esc(p.login)}:${p.role === 'admin' ? 0 : 1}">${p.role === 'admin' ? L('Unadmin', 'Снять админа') : L('Admin', 'Сделать админом')}</button>` : ''}
        ${(c.role === 'owner' || (c.role === 'admin' && p.role === 'member')) ? `<button class="w small" data-kick="${esc(p.login)}">${L('Remove', 'Исключить')}</button>` : ''}</span>` : ''}</div>`).join('');
  const link = c.link ? `${location.origin}/#/friends/join/${c.link}` : '';
  return `<aside class="fr-panel"><h2 class="sec">Members <span class="ash num">${c.members}</span></h2>
    ${manage ? `<div class="fr-invite"><input class="in" id="fr-invite-in" placeholder="A friend's login"><button class="w small lead" id="fr-invite-go">Invite</button></div><p class="hint" id="fr-invite-msg" role="status"></p>` : ''}
    <div class="fr-members">${people}</div>
    ${manage ? `<h2 class="sec">Group</h2>
      <div class="fr-invite"><input class="in" id="fr-title-in" maxlength="40" value="${esc(c.title)}"><button class="w small" id="fr-title-go">Rename</button></div>
      <div class="acts"><label class="w small" for="fr-av-file">Picture</label><input type="file" id="fr-av-file" accept="image/png,image/jpeg,image/webp,image/gif" hidden></div>
      <p class="lab">Link</p>${link ? `<p class="mono fr-link" translate="no">${esc(link)}</p><div class="acts"><button class="w small" data-copy="${esc(link)}">Copy</button><button class="w small" id="fr-link-new">New link</button><button class="w small" id="fr-link-off">Turn off</button></div>`
        : '<div class="acts"><button class="w small" id="fr-link-new">Make a link</button></div>'}` : ''}
    <div class="acts fr-leave"><button class="w small bad" id="fr-leave">${FR.leaving ? L('Leave for good?', 'Точно выйти?') : L('Leave the group', 'Выйти из группы')}</button></div></aside>`;
}

// ---- friends and requests

function frPeople() {
  const c = ask('friends');
  if (waiting(c)) return `<div class="fr-people">${'<div class="ghost-rows"><div></div><div></div></div>'}</div>`;
  if (!c.ok) return trouble(c);
  const d = c.data;
  const person = (x, acts) => `<div class="fr-person">${head(x.person.login, 40)}<span class="fr-l">${nm(x.person, { status: true })}${x.presence && x.presence.online ? `<span class="fr-sub">${dot(x.presence.online)}<span>${x.presence.online === 'game' ? tr('In the game') : tr('On the site')}</span>${x.presence.listening ? `<span class="listening">${emo('c_play', 16)}<span translate="no">${esc(x.presence.listening.title)}</span></span>` : ''}${x.presence.server ? `<span class="ash" translate="no">· ${esc(x.presence.server)}</span>` : ''}</span>` : ''}</span><span class="acts">${acts}</span></div>`;
  const online = d.friends.filter((f) => f.presence && f.presence.online), away = d.friends.filter((f) => !(f.presence && f.presence.online));
  const fr = (f) => person(f, `<button class="w small lead" data-dm="${esc(f.person.login)}">Message</button><button class="w small ${FR.unfriend === f.person.login ? 'on' : ''}" data-remove-friend="${esc(f.person.login)}">${FR.unfriend === f.person.login ? L('Remove?', 'Удалить?') : L('Remove', 'Удалить')}</button>`);
  return `<div class="fr-people">
    <div class="block"><h2 class="sec">Add a friend</h2><div class="fr-invite"><input class="in" id="fr-add-in" placeholder="Their login on the site" value="${esc(FR.add)}"><button class="w small lead" id="fr-add-go">Send a request</button></div>
      <p class="hint ${FR.addBad ? 'bad' : 'ok'}" id="fr-add-msg" role="status">${esc(FR.addMsg)}</p></div>
    ${d.incoming.length ? `<div class="block"><h2 class="sec">Requests <span class="ash num">${d.incoming.length}</span></h2>${d.incoming.map((x) => person(x, `<button class="w small lead" data-accept="${esc(x.person.login)}">Accept</button><button class="w small" data-unfriend="${esc(x.person.login)}">Decline</button>`)).join('')}</div>` : ''}
    <div class="block"><h2 class="sec">Friends <span class="ash num">${d.friends.length}</span></h2>
      ${d.friends.length ? (online.length ? `<p class="lab">${L('Online', 'В сети')} · <span class="num">${online.length}</span></p>${online.map(fr).join('')}` : '') + (away.length ? `<p class="lab">${L('Away', 'Не в сети')} · <span class="num">${away.length}</span></p>${away.map(fr).join('')}` : '')
        : `<p class="ash">${L('No friends yet. Send a request by their login, or from their profile.', 'Друзей пока нет. Отправьте заявку по логину или из профиля.')}</p>`}</div>
    ${d.outgoing.length ? `<div class="block"><h2 class="sec">Sent <span class="ash num">${d.outgoing.length}</span></h2>${d.outgoing.map((x) => person(x, `<button class="w small" data-unfriend="${esc(x.person.login)}">Take back</button>`)).join('')}</div>` : ''}
    ${d.blocked.length ? `<div class="block"><h2 class="sec">Blocked <span class="ash num">${d.blocked.length}</span></h2>${d.blocked.map((x) => person(x, `<button class="w small" data-unblock="${esc(x.person.login)}">Unblock</button>`)).join('')}</div>` : ''}
  </div>`;
}

// ---- a new group, a group's link

function frNew() {
  const c = ask('friends');
  const ng = FR.ng || (FR.ng = { title: '', pick: [], msg: '' });
  const friends = c.ok ? c.data.friends : [];
  return `<div class="fr-people"><div class="block"><h2 class="sec">New group</h2>
    <div class="fr-invite"><input class="in" id="ng-title" maxlength="40" placeholder="Its name" value="${esc(ng.title)}"></div>
    <p class="lab">${L('Invite friends', 'Пригласить друзей')} <span class="ash num">${ng.pick.length} / 49</span></p>
    <div class="fr-picks">${friends.map((f) => `<button class="fr-pick ${ng.pick.includes(f.person.login) ? 'on' : ''}" data-ng-pick="${esc(f.person.login)}">${head(f.person.login, 32)}<span translate="no">${esc(f.person.login)}</span></button>`).join('') || `<p class="ash">${L('No friends to invite yet: a group can start with you alone and get a link.', 'Пока некого звать: группа может начаться с вас одного и получить ссылку.')}</p>`}</div>
    <div class="acts" style="margin-top:22px"><button class="w lead" id="ng-go">Make the group</button><a class="w" href="#/friends">Cancel</a></div><p class="hint bad" id="ng-msg" role="status">${esc(ng.msg)}</p></div></div>`;
}

function frJoin(code) {
  const c = ask('chats/link/' + encodeURIComponent(code || ''));
  if (waiting(c)) return '<div class="fr-empty ghost-t">&nbsp;</div>';
  if (!c.ok) return `<div class="fr-empty"><h1 class="big">${L('No such link', 'Ссылка не работает')}</h1><p class="ash">${L('It was turned off, or made anew.', 'Её выключили или заменили новой.')}</p><a class="w" href="#/friends">Friends</a></div>`;
  return `<div class="fr-empty">${groupAv(c.data, 96)}<h1 class="big" translate="no">${esc(c.data.title)}</h1><p class="ash num">${c.data.members} ${L('members', plural(c.data.members, 'участник', 'участника', 'участников'))}</p>
    <div class="acts">${c.data.in ? `<a class="w lead" href="${frHref(c.data.chat)}">Open</a>` : `<button class="w lead" data-link-join="${esc(code)}">Join</button>`}<a class="w" href="#/friends">Friends</a></div><p class="hint bad" id="join-msg" role="status"></p></div>`;
}

// ---- the live line's words for conversations and friends (core.js `heard` asks here first)

function frHeard(ev) {
  const ch = FR.chat, here = state.route === 'friends';
  switch (ev.t) {
    case 'friends': forget('friends'); if (here || state.route === 'u') render(true); return true;
    case 'chats': forget('chats'); if (here) render(true); return true;
    case 'config': case 'configs': case 'config_gone': case 'config_active':
      forget('configs'); if (state.route === 'dashboard' && state.arg.startsWith('configs')) render(true); return true;
    case 'presence': if (here) { forget('friends', 'chats'); render(true); } return false;
    case 'msg': {
      if (ev.unread !== undefined) frUnread(ev.unread);
      const open = ch && ch.id === ev.chat && ch.messages;
      if (open && !ch.messages.some((m) => m.id === ev.message.id)) {
        ch.messages.push(ev.message);
        if (ev.message.author) delete ch.typing[ev.message.author.uid];
        if (ch.meta) ch.meta.last = { ...ev.message, text: ev.message.body };
        frRead();
      }
      forget('chats');
      if (here) frRedraw(!open);
      if (ev.game && !(open && document.visibilityState === 'visible' && here)) {
        const m = ev.message;
        toast({ kind: 'message', actor: m.author, data: { chat: ev.chat, text: frBrief({ ...m, text: m.body }) }, id: 0 });
      }
      return true;
    }
    case 'msg_edit': case 'react': case 'msg_del': {
      if (ch && ch.id === ev.chat && ch.messages) {
        const m = ch.messages.find((x) => x.id === (ev.message ? ev.message.id : ev.id));
        if (m) {
          if (ev.t === 'msg_edit') Object.assign(m, ev.message);
          else if (ev.t === 'react') m.reactions = ev.reactions;
          else Object.assign(m, { deleted: true, body: null, media: null, reactions: [] });
        }
        if (here) frRedraw(false);
      }
      if (ev.t === 'msg_del') forget('chats');
      return true;
    }
    case 'read': {
      if (ev.unread !== undefined) frUnread(ev.unread);
      if (ch && ch.id === ev.chat && ch.meta && state.user && ev.uid !== state.user.uid) { ch.meta.their_read = Math.max(ch.meta.their_read || 0, ev.upto); if (here) frRedraw(false); }
      return true;
    }
    case 'typing': {
      if (ch && ch.id === ev.chat) { ch.typing[ev.uid] = { login: ev.login, at: Date.now() }; frTyping(); setTimeout(frTyping, 5200); }
      return true;
    }
    case 'chat': {
      if (ev.unread !== undefined) frUnread(ev.unread);
      if (ch && ch.id === ev.chat.id) ch.meta = ev.chat;
      forget('chats');
      if (here) render(true);
      return true;
    }
  }
  return false;
}

/** The open conversation drawn again where it changed: its messages (and the list), the composer left as it is. */
function frRedraw(listToo) {
  const ch = FR.chat, box = document.getElementById('fr-msgs');
  if (!box || !ch || !ch.messages) { render(true); return; }
  const c = ch.meta || {};
  const atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 80;
  box.innerHTML = (ch.more ? '<div class="fr-older"><button class="w small" id="fr-older">Older messages</button></div>' : '') + frMsgs(ch, c);
  box.querySelectorAll('canvas[data-head]').forEach(drawHead);
  translate(box);
  frWireMsgs(box);
  if (atBottom || ch.stick) box.scrollTop = box.scrollHeight;
  if (listToo) {
    const rail = document.querySelector('.fr-rail');
    if (rail) { rail.innerHTML = frRail(ask('chats'), 'c', ch.id); rail.querySelectorAll('canvas[data-head]').forEach(drawHead); translate(rail); frWireRail(rail); }
  }
}
function frTyping() {
  const ch = FR.chat, el = document.getElementById('fr-typing');
  if (!ch || !el) return;
  const t = Object.values(ch.typing).filter((x) => Date.now() - x.at < 5000).map((x) => x.login);
  el.innerHTML = t.length ? `<span translate="no">${esc(t.join(', '))}</span> ${L(t.length > 1 ? 'are typing…' : 'is typing…', 'печатает…')}` : '';
}

// ---- sending

async function frSend() {
  const ch = FR.chat, input = document.getElementById('fr-in');
  if (!ch || !input) return;
  const body = input.value.trim();
  if (!body) return;
  const msg = document.getElementById('fr-msg');
  let r;
  if (ch.edit) r = await api(`chats/${ch.id}/messages/${ch.edit.id}`, { body }, 'PATCH');
  else r = await api(`chats/${ch.id}/messages`, { body, reply_to: ch.reply ? ch.reply.id : null });
  if (!r.ok) { if (msg) { msg.textContent = frFault(r); msg.className = 'hint bad'; } return; }
  if (!ch.edit && r.data.message && !ch.messages.some((m) => m.id === r.data.message.id)) ch.messages.push(r.data.message);
  ch.draft = ''; ch.reply = null; ch.edit = null; ch.stick = true;
  if (FR.drafts) delete FR.drafts[ch.id];
  render(true);
  const i = document.getElementById('fr-in'); if (i) i.focus();
}
const frFault = (r) => (r.error === 'friends' ? L('They take messages from friends only.', 'Этот человек принимает сообщения только от друзей.') : r.error === 'closed' ? L('They take no messages.', 'Этот человек не принимает сообщения.')
  : r.error === 'blocked' ? L('One of you has blocked the other.', 'Один из вас заблокировал другого.') : r.error === 'slow' ? L('Too fast: wait a few seconds.', 'Слишком быстро: подождите пару секунд.') : tr(r.message || SAY[r.error] || SAY.busy));

/** A picture or a voice message sent as it is (the body is the file). */
async function frSendFile(path, blob, type) {
  const ch = FR.chat;
  if (!ch) return;
  const msg = document.getElementById('fr-msg');
  if (msg) { msg.textContent = L('Sending…', 'Отправка…'); msg.className = 'hint'; }
  let r = null, data = {};
  try {
    r = await fetch('/api/' + path, { method: 'POST', credentials: 'same-origin', cache: 'no-store', headers: { 'Content-Type': type || blob.type || 'application/octet-stream' }, body: blob });
    try { data = await r.json(); } catch (e) { /* not JSON */ }
  } catch (e) { r = null; }
  if (r && r.ok) {
    learnAv(data);
    if (data.message && !ch.messages.some((m) => m.id === data.message.id)) ch.messages.push(data.message);
    ch.reply = null; ch.stick = true;
    render(true);
  } else if (msg) { msg.textContent = r ? frFault({ error: data.error || (r.status === 429 ? 'slow' : 'busy'), message: data.message }) : SAY.offline; msg.className = 'hint bad'; }
}

/** A voice message: recorded with the browser's own recorder (Opus), three minutes at most, sent on "Send". */
async function frRecord() {
  const ch = FR.chat;
  if (!ch || FR.rec) return;
  let stream;
  try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); } catch (e) {
    const msg = document.getElementById('fr-msg'); if (msg) { msg.textContent = L('The browser gave no microphone.', 'Браузер не дал микрофон.'); msg.className = 'hint bad'; }
    return;
  }
  const type = ['audio/webm;codecs=opus', 'audio/ogg;codecs=opus', 'audio/webm'].find((t) => MediaRecorder.isTypeSupported(t)) || '';
  const rec = new MediaRecorder(stream, type ? { mimeType: type, audioBitsPerSecond: 32000 } : undefined);
  const parts = [];
  FR.rec = { chat: ch.id, at: Date.now(), rec, stream, send: false };
  rec.ondataavailable = (e) => { if (e.data.size) parts.push(e.data); };
  rec.onstop = () => {
    const r = FR.rec;
    FR.rec = null;
    stream.getTracks().forEach((t) => t.stop());
    clearInterval(r.timer);
    if (r.send) {
      const blob = new Blob(parts, { type: rec.mimeType || type });
      const ms = Date.now() - r.at;
      frSendFile(`chats/${r.chat}/voice?ms=${ms}`, blob, (rec.mimeType || type).split(';')[0]);
    } else render(true);
  };
  rec.start(250);
  FR.rec.timer = setInterval(() => {
    const t = document.getElementById('fr-rec-t'); if (t && FR.rec) t.textContent = secs(Date.now() - FR.rec.at);
    if (FR.rec && Date.now() - FR.rec.at > 179000) frRecStop(true);
  }, 250);
  render(true);
}
function frRecStop(send) { if (!FR.rec) return; FR.rec.send = send; FR.rec.rec.stop(); }

/** One voice message plays at a time. */
function frPlay(btn) {
  const id = Number(btn.dataset.voicePlay);
  if (FR.plays && FR.plays.id === id) { FR.plays.audio.pause(); FR.plays = null; frRedraw(false); return; }
  if (FR.plays) FR.plays.audio.pause();
  const audio = new Audio(btn.dataset.src);
  FR.plays = { id, audio, at: 0 };
  audio.play().catch(() => { FR.plays = null; frRedraw(false); });
  const tick = () => {
    if (!FR.plays || FR.plays.audio !== audio) return;
    if (audio.duration && isFinite(audio.duration)) FR.plays.at = audio.currentTime / audio.duration;
    const bar = document.querySelector(`[data-voice="${id}"] .vbar i`); if (bar) bar.style.transform = `scaleX(${FR.plays.at})`;
    requestAnimationFrame(tick);
  };
  audio.addEventListener('ended', () => { if (FR.plays && FR.plays.audio === audio) { FR.plays = null; frRedraw(false); } });
  tick();
  frRedraw(false);
}

// ---- what the screens do

function frWireMsgs(root) {
  const on = (sel, ev, fn) => root.querySelectorAll(sel).forEach((el) => el.addEventListener(ev, (e) => fn(el, e)));
  const ch = FR.chat;
  if (!ch) return;
  const find = (id) => ch.messages.find((m) => m.id === Number(id));
  on('#fr-older', 'click', async () => {
    const box = document.getElementById('fr-msgs'), from = box ? box.scrollHeight - box.scrollTop : 0;
    const r = await api(`chats/${ch.id}?before=${ch.messages[0].id}`);
    if (!r.ok) return;
    ch.messages = r.data.messages.concat(ch.messages); ch.more = r.data.more; ch.stick = false;
    frRedraw(false);
    const b = document.getElementById('fr-msgs'); if (b) b.scrollTop = b.scrollHeight - from;
  });
  on('[data-reply]', 'click', (b) => { const m = find(b.dataset.reply); ch.reply = { id: m.id, author: m.author && m.author.login, kind: m.kind, text: m.body }; ch.edit = null; render(true); const i = document.getElementById('fr-in'); if (i) i.focus(); });
  on('[data-edit]', 'click', (b) => { const m = find(b.dataset.edit); ch.edit = { id: m.id, body: m.body }; ch.reply = null; ch.draft = m.body; render(true); const i = document.getElementById('fr-in'); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } });
  on('[data-react-open]', 'click', (b) => { const id = Number(b.dataset.reactOpen); FR.react = FR.react === id ? 0 : id; frRedraw(false); });
  on('[data-react]', 'click', (b) => { const [id, e] = b.dataset.react.split(':'); FR.react = 0; api(`chats/${ch.id}/messages/${id}/react`, { emoji: e }); });
  on('[data-pin]', 'click', (b) => api(`chats/${ch.id}/pin`, { message: Number(b.dataset.pin) }));
  on('[data-del]', 'click', async (b) => {
    const id = Number(b.dataset.del);
    if (FR.del !== id) { FR.del = id; frRedraw(false); setTimeout(() => { if (FR.del === id) { FR.del = 0; frRedraw(false); } }, 4000); return; }
    FR.del = 0;
    await api(`chats/${ch.id}/messages/${id}`, null, 'DELETE');
  });
  on('[data-report]', 'click', (b) => { FR.report = Number(b.dataset.report); FR.reportWhy = ''; frRedraw(false); const i = document.getElementById('fr-report-why'); if (i) i.focus(); });
  on('#fr-report-why', 'input', (i) => { FR.reportWhy = i.value; });
  on('#fr-report-no', 'click', () => { FR.report = 0; frRedraw(false); });
  on('#fr-report-go', 'click', async () => {
    const r = await api(`chats/${ch.id}/messages/${FR.report}/report`, { why: FR.reportWhy });
    FR.report = 0; frRedraw(false);
    const msg = document.getElementById('fr-msg'); if (msg) { msg.textContent = r.ok ? L('Sent to Cursed’s staff. They see only this message and the ten before it.', 'Отправлено персоналу Cursed. Он видит только это сообщение и десять перед ним.') : frFault(r); msg.className = 'hint ' + (r.ok ? 'ok' : 'bad'); }
  });
  on('[data-pic]', 'click', (b) => { FR.pic = b.dataset.pic; render(true); });
  on('[data-voice-play]', 'click', (b) => frPlay(b));
  on('[data-jump-msg]', 'click', (b, e) => {
    if (e.target.closest('[data-unpin]')) return;
    const el = document.querySelector(`.fr-msg[data-msg="${b.dataset.jumpMsg}"]`);
    if (el) { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); el.classList.add('lit'); setTimeout(() => el.classList.remove('lit'), 1600); }
  });
}
function frWireRail(root) {
  const on = (sel, ev, fn) => root.querySelectorAll(sel).forEach((el) => el.addEventListener(ev, (e) => fn(el, e)));
  on('[data-inv-join]', 'click', async (b) => { const r = await api(`chats/${b.dataset.invJoin}/join`, {}); forget('chats'); if (r.ok) location.hash = frHref(r.data.chat.id); else render(true); });
  on('[data-inv-no]', 'click', async (b) => { await api(`chats/${b.dataset.invNo}/invites/me`, null, 'DELETE'); forget('chats'); render(true); });
}

function friendsWire() {
  if (state.route !== 'friends' && state.route !== 'u') return;
  const on = (sel, ev, fn) => $app.querySelectorAll(sel).forEach((el) => el.addEventListener(ev, (e) => fn(el, e)));
  // Anywhere: write to someone, befriend, accept, part, block.
  on('[data-dm]', 'click', async (b) => {
    const r = await api('chats/dm', { login: b.dataset.dm });
    if (r.ok) { forget('chats'); location.hash = frHref(r.data.chat.id); return; }
    const msg = document.getElementById('fr-add-msg') || document.getElementById('rel-msg'); if (msg) { msg.textContent = frFault(r); msg.className = 'hint bad'; }
  });
  on('[data-befriend]', 'click', async (b) => { const r = await api('friends', { login: b.dataset.befriend }); const msg = document.getElementById('rel-msg'); if (!r.ok && msg) { msg.textContent = frFault(r); msg.className = 'hint bad'; } forget('friends', 'u/'); render(true); });
  on('[data-accept]', 'click', async (b) => { await api(`friends/${encodeURIComponent(b.dataset.accept)}/accept`, {}); forget('friends', 'u/'); render(true); });
  // A request declined or taken back at once; a friendship ends on a second press (the first asks "Remove?").
  on('[data-unfriend]', 'click', async (b) => { await api(`friends/${encodeURIComponent(b.dataset.unfriend)}`, null, 'DELETE'); forget('friends', 'u/'); render(true); });
  on('[data-remove-friend]', 'click', async (b) => {
    const login = b.dataset.removeFriend;
    if (FR.unfriend !== login) { FR.unfriend = login; render(true); setTimeout(() => { if (FR.unfriend === login) { FR.unfriend = ''; render(true); } }, 4000); return; }
    FR.unfriend = '';
    await api(`friends/${encodeURIComponent(login)}`, null, 'DELETE'); forget('friends', 'u/', 'chats'); render(true);
  });
  on('[data-block]', 'click', async (b) => { const r = await api('blocks', { login: b.dataset.block }); const msg = document.getElementById('rel-msg'); if (!r.ok && msg) { msg.textContent = frFault(r); msg.className = 'hint bad'; return; } forget('friends', 'u/', 'chats'); render(true); });
  on('[data-unblock]', 'click', async (b) => { await api(`blocks/${encodeURIComponent(b.dataset.unblock)}`, null, 'DELETE'); forget('friends', 'u/'); render(true); });
  if (state.route !== 'friends') return;
  const ch = FR.chat;
  frWireRail($app);
  // Friends: a request by login.
  on('#fr-add-in', 'input', (i) => { FR.add = i.value; });
  on('#fr-add-in', 'keydown', (i, e) => { if (e.key === 'Enter') document.getElementById('fr-add-go').click(); });
  on('#fr-add-go', 'click', async () => {
    const login = FR.add.trim();
    if (!login) return;
    const r = await api('friends', { login });
    FR.addBad = !r.ok;
    FR.addMsg = r.ok ? (r.data.state === 'friends' ? L('You are friends now.', 'Теперь вы друзья.') : L('Request sent.', 'Заявка отправлена.')) : r.status === 404 ? L('No member with that login.', 'Нет участника с таким логином.') : r.error === 'self' ? L('That is you.', 'Это вы.') : frFault(r);
    if (r.ok) FR.add = '';
    forget('friends'); render(true);
  });
  // A new group.
  const ng = FR.ng;
  if (ng) {
    on('#ng-title', 'input', (i) => { ng.title = i.value; });
    on('[data-ng-pick]', 'click', (b) => { const l = b.dataset.ngPick, i = ng.pick.indexOf(l); if (i >= 0) ng.pick.splice(i, 1); else if (ng.pick.length < 49) ng.pick.push(l); render(true); });
    on('#ng-go', 'click', async () => {
      const r = await api('chats/groups', { title: ng.title, invite: ng.pick });
      if (r.ok) { FR.ng = null; forget('chats'); location.hash = frHref(r.data.chat.id); } else { ng.msg = frFault(r); render(true); }
    });
  }
  on('[data-link-join]', 'click', async (b) => {
    const r = await api('chats/link/' + encodeURIComponent(b.dataset.linkJoin), {});
    if (r.ok) { forget('chats'); location.hash = frHref(r.data.chat.id); } else { const m = document.getElementById('join-msg'); if (m) m.textContent = frFault(r); }
  });
  if (!ch) return;
  frWireMsgs($app);
  // The messages stay at the bottom while they are read there; scrolled up, they stay where they are.
  const box = document.getElementById('fr-msgs');
  if (box) {
    if (ch.stick) box.scrollTop = box.scrollHeight; else if (ch.scroll !== undefined) box.scrollTop = ch.scroll;
    box.addEventListener('scroll', () => { ch.scroll = box.scrollTop; ch.stick = box.scrollHeight - box.scrollTop - box.clientHeight < 80; });
    box.addEventListener('dragover', (e) => { e.preventDefault(); box.classList.add('over'); });
    box.addEventListener('dragleave', () => box.classList.remove('over'));
    box.addEventListener('drop', (e) => { e.preventDefault(); box.classList.remove('over'); const f = [...e.dataTransfer.files].find((x) => x.type.startsWith('image/')); if (f) frSendFile(`chats/${ch.id}/pictures${ch.reply ? '?reply_to=' + ch.reply.id : ''}`, f); });
  }
  on('#fr-in', 'input', (t) => {
    ch.draft = t.value; (FR.drafts || (FR.drafts = {}))[ch.id] = t.value;
    t.style.height = 'auto'; t.style.height = Math.min(180, t.scrollHeight) + 'px';
    if (t.value && Date.now() - FR.typingAt > 3000) { FR.typingAt = Date.now(); api(`chats/${ch.id}/typing`, {}); }
  });
  on('#fr-in', 'keydown', (t, e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); frSend(); }
    if (e.key === 'Escape' && (ch.reply || ch.edit)) { ch.reply = null; if (ch.edit) ch.draft = ''; ch.edit = null; render(true); }
    if (e.key === 'ArrowUp' && !t.value) { const m = [...ch.messages].reverse().find((x) => mine(x) && x.kind === 'text' && !x.deleted); if (m) { e.preventDefault(); ch.edit = { id: m.id, body: m.body }; ch.draft = m.body; render(true); } }
  });
  on('#fr-in', 'paste', (t, e) => {
    const f = [...(e.clipboardData ? e.clipboardData.files : [])].find((x) => x.type.startsWith('image/'));
    if (f) { e.preventDefault(); frSendFile(`chats/${ch.id}/pictures${ch.reply ? '?reply_to=' + ch.reply.id : ''}`, f); }
  });
  const inp = document.getElementById('fr-in'); if (inp && inp.value) { inp.style.height = 'auto'; inp.style.height = Math.min(180, inp.scrollHeight) + 'px'; }
  on('#fr-send', 'click', frSend);
  on('#fr-bar-x', 'click', () => { ch.reply = null; if (ch.edit) ch.draft = ''; ch.edit = null; render(true); });
  on('#fr-file', 'change', (i) => { if (i.files[0]) frSendFile(`chats/${ch.id}/pictures${ch.reply ? '?reply_to=' + ch.reply.id : ''}`, i.files[0]); });
  on('#fr-mic', 'click', frRecord);
  on('#fr-rec-go', 'click', () => frRecStop(true));
  on('#fr-rec-no', 'click', () => frRecStop(false));
  on('#fr-lb-close', 'click', () => { FR.pic = null; render(true); });
  on('#fr-lightbox', 'click', (el, e) => { if (e.target === el) { FR.pic = null; render(true); } });
  on('[data-unpin]', 'click', (el, e) => { e.stopPropagation(); api(`chats/${ch.id}/pin`, { message: null }); });
  on('[data-mute]', 'click', () => api(`chats/${ch.id}`, { muted: !(ch.meta && ch.meta.muted) }, 'PATCH'));
  on('[data-panel]', 'click', () => { FR.panel = !FR.panel; FR.leaving = false; render(true); });
  // A group's panel.
  on('#fr-invite-go', 'click', async () => {
    const i = document.getElementById('fr-invite-in'), r = await api(`chats/${ch.id}/invites`, { login: i.value.trim() });
    const m = document.getElementById('fr-invite-msg');
    if (m) { m.textContent = r.ok ? L('Invited.', 'Приглашение отправлено.') : r.status === 404 ? L('No member with that login.', 'Нет участника с таким логином.') : r.error === 'member' ? L('Already in the group.', 'Уже в группе.') : r.error === 'friends' ? L('Only friends can be invited.', 'Пригласить можно только друзей.') : frFault(r); m.className = 'hint ' + (r.ok ? 'ok' : 'bad'); }
    if (r.ok) i.value = '';
  });
  on('#fr-title-go', 'click', () => api(`chats/${ch.id}`, { title: document.getElementById('fr-title-in').value }, 'PATCH'));
  on('#fr-av-file', 'change', (i) => { if (i.files[0]) fetch(`/api/chats/${ch.id}/avatar`, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': i.files[0].type }, body: i.files[0] }); });
  on('#fr-link-new', 'click', () => api(`chats/${ch.id}/link`, { on: true }));
  on('#fr-link-off', 'click', () => api(`chats/${ch.id}/link`, { on: false }));
  on('[data-rank]', 'click', (b) => { const [login, admin] = b.dataset.rank.split(':'); api(`chats/${ch.id}/members/${encodeURIComponent(login)}/role`, { admin: admin === '1' }).then(() => frLoad(ch.id)); });
  on('[data-kick]', 'click', (b) => api(`chats/${ch.id}/members/${encodeURIComponent(b.dataset.kick)}`, null, 'DELETE').then(() => frLoad(ch.id)));
  on('#fr-leave', 'click', async () => {
    if (!FR.leaving) { FR.leaving = true; render(true); return; }
    FR.leaving = false;
    await api(`chats/${ch.id}/members/me`, null, 'DELETE');
    FR.chat = null; FR.panel = false; forget('chats'); location.hash = '#/friends';
  });
}

/** The friends' part of a profile: befriend, accept, write, block. */
function relationActs(p) {
  const r = p.relation, who = p.person.login;
  if (!r || !state.user) return '';
  const canWrite = !r.blocked && !r.blocks_me && (p.dm === 'all' || (p.dm !== 'none' && r.friends) || (state.user.perms || []).length);
  const friend = r.friends ? `<button class="w small" data-remove-friend="${esc(who)}">${FR.unfriend === who ? L('Remove?', 'Удалить?') : L('Remove friend', 'Удалить из друзей')}</button>`
    : r.asks ? `<button class="w lead" data-accept="${esc(who)}">Accept request</button>` : r.asked ? `<button class="w small" data-unfriend="${esc(who)}">${L('Take back the request', 'Отозвать заявку')}</button>`
    : r.blocked || r.blocks_me ? '' : `<button class="w lead" data-befriend="${esc(who)}">Add friend</button>`;
  return `${canWrite ? `<button class="w ${r.friends ? 'lead' : ''}" data-dm="${esc(who)}">Message</button>` : ''}${friend}
    ${r.blocked ? `<button class="w small" data-unblock="${esc(who)}">Unblock</button>` : p.person.staff ? '' : `<button class="w small bad" data-block="${esc(who)}">Block</button>`}<span class="hint" id="rel-msg" role="status"></span>`;
}
