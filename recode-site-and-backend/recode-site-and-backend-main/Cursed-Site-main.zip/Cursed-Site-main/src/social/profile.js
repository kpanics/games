// ---- a member's profile (#/u/<login>; the old #/author/<login> comes here too)

/** The networks, as the profile draws them: a small mark each (drawn here, in the site's own line), and its address. */
const NETS = {
  discord: ['Discord', null, '<path d="M7 7.5c3.3-1.6 6.7-1.6 10 0 1.3 2.4 2 5 2 8-1.4 1.1-2.9 1.8-4.5 2.2l-.9-1.6m-7.2 0-.9 1.6C3.9 17.3 2.4 16.6 1 15.5c0-3 .7-5.6 2-8z" transform="translate(2 0)"/><circle cx="9.6" cy="12.6" r="1.3" fill="currentColor" stroke="none"/><circle cx="14.4" cy="12.6" r="1.3" fill="currentColor" stroke="none"/>'],
  telegram: ['Telegram', (h) => 'https://t.me/' + h, '<path d="M3 11.5 20.5 4.5l-3 15-5.2-4.4-3 2.9.4-4.5L17 7.8l-9.6 5.6z"/>'],
  youtube: ['YouTube', (h) => 'https://www.youtube.com/' + h, '<rect x="2.5" y="5.5" width="19" height="13" rx="4"/><path d="M10 9.2v5.6l4.8-2.8z" fill="currentColor" stroke="none"/>'],
  twitch: ['Twitch', (h) => 'https://www.twitch.tv/' + h, '<path d="M4.5 3.5h15v10l-4 4h-4l-3 3v-3h-4z"/><path d="M11 8v4M15 8v4"/>'],
  tiktok: ['TikTok', (h) => 'https://www.tiktok.com/@' + h, '<path d="M13 3.5v11.5a3.5 3.5 0 1 1-3.5-3.5"/><path d="M13 3.5c.4 2.6 2.2 4.4 5 4.6"/>'],
  vk: ['VK', (h) => 'https://vk.com/' + h, '<path d="M3.5 7.5c.3 5.6 3.4 9 8.2 9h.5v-3.4c1.9.2 3.3 1.6 3.9 3.4h2.5c-.8-2.6-2.7-4.1-3.8-4.6 1.2-.7 2.8-2.4 3.2-4.4h-2.3c-.5 1.6-1.9 3.1-3.5 3.3V7.5H9.9v6.3c-1.6-.4-3.3-2.4-3.6-6.3z"/>'],
  steam: ['Steam', (h) => 'https://steamcommunity.com/' + h, '<circle cx="15.5" cy="9" r="3.5"/><circle cx="8.5" cy="16" r="2.6"/><path d="M2.5 13.5 6.2 15m4.6.6 2.4-3.8"/>'],
  github: ['GitHub', (h) => 'https://github.com/' + h, '<path d="M9 19c-4.5 1.4-4.5-2.2-6.5-2.7M15 21.5v-3.4c0-1 .1-1.4-.5-2 2.8-.3 5.5-1.4 5.5-6a4.7 4.7 0 0 0-1.3-3.2 4.3 4.3 0 0 0-.1-3.2s-1-.3-3.4 1.3a11.6 11.6 0 0 0-6.1 0C6.7 3.4 5.7 3.7 5.7 3.7a4.3 4.3 0 0 0-.1 3.2 4.7 4.7 0 0 0-1.3 3.2c0 4.6 2.7 5.7 5.5 6-.6.6-.6 1.2-.5 2v3.4"/>'],
  soundcloud: ['SoundCloud', (h) => 'https://soundcloud.com/' + h, '<path d="M8 17V9.5M5 17v-5M2.5 17v-3M11 17V7.5c4.6-1.3 7.7 1.4 8 4.5a3 3 0 0 1-.5 5z"/>'],
  site: ['Site', (h) => h, '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.8 3.8 5.8 3.8 9s-1.2 6.2-3.8 9c-2.6-2.8-3.8-5.8-3.8-9s1.2-6.2 3.8-9z"/>'],
};
const netMark = (id) => `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${NETS[id][2]}</svg>`;
function socialLinks(s) {
  const out = [];
  for (const id of Object.keys(NETS)) {
    const v = s && s[id];
    if (!v) continue;
    const [name, href] = NETS[id];
    // Discord has no address of a person: the name is shown, and copied on a click.
    out.push(href ? `<a class="net" href="${esc(href(v))}" target="_blank" rel="noopener noreferrer nofollow" title="${esc(name)}: ${esc(v)}">${netMark(id)}<span class="sr">${esc(name)}</span></a>`
      : `<button class="net" data-copy="${esc(v)}" title="${esc(name)}: ${esc(v)}">${netMark(id)}<span class="sr">${esc(name)}</span></button>`);
  }
  return out.length ? `<div class="nets" translate="no">${out.join('')}</div>` : '';
}

const THEME_NAMES = { eclipse: ['Eclipse', 'Затмение'], void: ['Void', 'Пустота'], aurora: ['Aurora', 'Сияние'], ember: ['Ember', 'Угли'], frost: ['Frost', 'Иней'], bloom: ['Bloom', 'Цветение'] };
const ACCENTS = ['#BFC0E7', '#6669F5', '#F2F1CB', '#E5484D', '#F0629B', '#E8B04B', '#4FC3B5', '#7BD88F', '#59A5F5', '#B583F5', '#FF8A4C', '#FFFFFF'];
const hours = (h) => L(`${fmt(h)} h`, `${fmt(h)} ч`);

function viewProfile(arg) {
  const login = decodeURIComponent(String(arg || '').split('/')[0] || me().name);
  const c = ask('u/' + encodeURIComponent(login));
  if (waiting(c)) return `<div class="prof"><div class="prof-banner theme-eclipse ghost"></div><div class="wrap prof-top"><div class="prof-av ghost-av"></div></div></div>`;
  if (!c.ok) return `<div class="page-head"><h1 class="giant">${c.status === 404 ? 'No such member' : 'Profile'}</h1></div><div class="wrap">${trouble(c)}</div>`;
  const p = c.data, who = p.person, own = p.viewer.self;
  SOC.profileMusic = p.music;
  const acc = who.accent || '#BFC0E7';
  const packs = ask('market?author=' + encodeURIComponent(who.login) + '&sort=users');
  // A banner whose file is not there: the theme's own picture instead of a broken one (its icon showed in the corner).
  const banner = p.banner ? `<img src="${esc(p.banner.url)}" alt="" decoding="async" onerror="this.parentElement.classList.remove('has');this.remove()">` : '';
  const pres = p.presence || {};
  const where = pres.online ? `<p class="presence">${dot(pres.online)}<span>${pres.online === 'game' ? tr('In the game') : tr('On the site')}</span>${pres.server ? `<span class="ash" translate="no">· ${esc(pres.server)}</span>` : ''}${pres.listening ? `<span class="listening">${emo('c_play', 18)}<span translate="no">${esc(pres.listening.title)}${pres.listening.artist ? ' — ' + esc(pres.listening.artist) : ''}</span></span>` : ''}</p>` : '';
  const have = {}; for (const b of p.badges) have[b.id] = b;
  const cat = ask('badges'), defs = cat.ok ? cat.data.badges : [];
  const def = (id) => defs.find((b) => b.id === id);
  const shown = (p.showcase.length ? p.showcase : p.badges.slice(-6).map((b) => b.id)).map(def).filter(Boolean);
  const music = p.music ? `<div class="player" style="--acc:${esc(acc)}"><button class="play" data-play aria-label="Listen"><i></i></button>
      <div class="pl"><b translate="no">${esc(p.music.title || L('Untitled', 'Без названия'))}</b><span class="ash" translate="no">${esc(p.music.artist || '')}${p.music.kind === 'soundcloud' ? ' · SoundCloud' : ''}</span><span class="prog"><i></i></span></div>
      <span class="eq" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></span></div>` : '';
  const stats = [[p.stats.posts, L('posts', plural(p.stats.posts, 'пост', 'поста', 'постов'))], [p.stats.threads, L('threads', plural(p.stats.threads, 'тема', 'темы', 'тем'))], [p.stats.packs, L('packs', plural(p.stats.packs, 'пак', 'пака', 'паков'))]];
  if (p.stats.hours !== null && p.stats.hours !== undefined) stats.push([p.stats.hours, L('hours in Cursed', plural(p.stats.hours, 'час в Cursed', 'часа в Cursed', 'часов в Cursed'))]);
  const roleBar = !own && state.user && (state.user.perms || []).includes('users.roles') && SOC.meta ? `<div class="block"><h2 class="sec">Roles</h2><div class="acts role-picks">${SOC.meta.roles.filter((r) => r.id !== 'creator').map((r) => `<button class="w small ${who.prefix && who.prefix.role === r.id ? 'on' : ''}" data-give-role="${esc(r.id)}" style="--c:${esc(r.colour)}" translate="no">${esc(r.prefix)}</button>`).join('')}</div><p class="hint" id="role-msg"></p></div>` : '';
  return `<div class="prof" style="--acc:${esc(acc)}">
    <div class="prof-banner theme-${esc(p.theme || 'eclipse')} ${banner ? 'has' : ''}">${banner}</div>
    <div class="wrap prof-top">
      <div class="prof-av">${head(who.login, 132)}${dot(pres.online)}</div>
      <div class="prof-name">
        <p class="prefix-line">${pfx(who)}<span class="ash num" translate="no">UID ${esc(String(who.uid_text || who.uid))}</span></p>
        <h1 class="giant" translate="no" style="color:var(--acc)">${esc(who.login)}</h1>
        ${who.status ? `<p class="status big-status">${emo(who.status.emoji, 24)}<span translate="no">${esc(who.status.text || '')}</span></p>` : ''}
        ${where}
      </div>
      <div class="prof-acts acts">${own ? '<a class="w lead" href="#/dashboard/profile">Edit profile</a><a class="w" href="#/badges">Badges</a><a class="w" href="#/friends/people">Friends</a>' : relationActs(p)}</div>
    </div>
    <div class="wrap prof-body">
      <div class="prof-side">
        ${music}
        ${socialLinks(p.socials)}
        <div class="prof-stats">${stats.map(([n, w]) => `<div><b class="num">${fmt(n)}</b><span>${w}</span></div>`).join('')}</div>
        <p class="ash joined">${L('With Cursed since', 'В Cursed с')} ${when(p.since)}</p>
        ${roleBar}
      </div>
      <div class="prof-main">
        ${p.about ? `<div class="block"><h2 class="sec">About me</h2><div class="prose" translate="no">${prose(p.about)}</div></div>` : own ? '<div class="block"><h2 class="sec">About me</h2><p class="ash">Say something of yourself: <a class="w small" href="#/dashboard/profile">Edit profile</a></p></div>' : ''}
        ${p.badges.length ? `<div class="block"><h2 class="sec">Badges <span class="ash num">${p.badges.length}</span></h2>
          <div class="bdgs showcase">${shown.map((b) => badgeTile(b, have[b.id], true)).join('')}</div>
          ${p.badges.length > shown.length ? `<div class="bdgs rest">${p.badges.filter((b) => !shown.some((s) => s.id === b.id)).map((b) => def(b.id)).filter(Boolean).map((b) => badgeTile(b, have[b.id])).join('')}</div>` : ''}
          ${state.badgeOpen && def(state.badgeOpen) ? badgeCard(def(state.badgeOpen), have[state.badgeOpen]) : ''}</div>` : ''}
        ${p.shots.length || own ? `<div class="block"><h2 class="sec">Screenshots <span class="ash num">${p.shots.length}</span></h2>
          ${p.shots.length ? `<div class="shots">${p.shots.map((s, i) => `<button class="shot-t" data-shot-open="${i}"><img src="${esc(s.thumb)}" alt="" loading="lazy"></button>`).join('')}</div>` : '<p class="ash">From the game: press F2, then “To the gallery”. Or add them in your profile.</p>'}</div>` : ''}
        ${packs.ok && packs.data.items.length ? `<div class="block"><h2 class="sec">Packs <span class="ash num">${packs.data.items.length}</span></h2><div class="grid">${packs.data.items.map(card).join('')}</div></div>` : ''}
      </div>
    </div>
    ${state.shotOpen !== undefined && p.shots[state.shotOpen] ? `<div class="lightbox" id="lightbox"><img src="${esc(p.shots[state.shotOpen].url)}" alt=""><button class="w small lb-close" id="lb-close">Close</button>
      ${state.shotOpen > 0 ? '<button class="lb-prev" data-shot-step="-1" aria-label="Previous">‹</button>' : ''}${state.shotOpen < p.shots.length - 1 ? '<button class="lb-next" data-shot-step="1" aria-label="Next">›</button>' : ''}</div>` : ''}
  </div>`;
}
