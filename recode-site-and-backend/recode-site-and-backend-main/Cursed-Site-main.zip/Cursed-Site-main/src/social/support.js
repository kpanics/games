// ================================================================================================ support (03.10.2026)
// Tickets (site/server/src/tickets.rs): a member's own (opened, answered, closed, rated), and for the staff the queue
// with its states, who it is given to, notes the author never sees, ready answers, the author's computer freed. The
// text is written in the forum's editor (forum.js); a bug sent from the game shows what the game said of itself and
// its log.

MEMBERS_ONLY.add('support');
const TK = { view: 'mine', state: 'active', msg: '', bad: false, internal: false, rate: 0, rateNote: '', cat: '' };
const TK_CATS = {
  account: ['Account and computer', 'Аккаунт и компьютер', 'Signing in, the computer the account is bound to, a ban.', 'Вход, привязка к компьютеру, бан.'],
  bug: ['A bug', 'Баг', 'Something broken in Cursed. From the game it is quicker: the log and the system go with it.', 'Что-то сломалось в Cursed. Из игры быстрее: лог и система прикладываются сами.'],
  complaint: ['A complaint', 'Жалоба', 'About a member, a post, a pack. Say who and what; screenshots help.', 'На участника, пост, пак. Напишите, кто и что; скриншоты помогают.'],
  partner: ['Partnership', 'Партнёрство', 'Servers, projects, advertising.', 'Сервера, проекты, реклама.'],
  media: ['Media', 'Медиа', 'You make videos or stream: your channel and what you would like.', 'Вы снимаете видео или стримите: ваш канал и что хотели бы.'],
  other: ['Something else', 'Другое', 'Anything that fits nowhere above.', 'Всё, что не подошло выше.'],
};
const TK_STATES = { open: ['Open', 'Открыт', ''], working: ['In work', 'В работе', 'cream'], waiting: ['Waiting for you', 'Ждём ответа', 'ok'], closed: ['Closed', 'Закрыт', 'warn'] };
const TK_STATES_STAFF = { open: ['Open', 'Открыт'], working: ['In work', 'В работе'], waiting: ['Waiting for the author', 'Ждём автора'], closed: ['Closed', 'Закрыт'] };
const tkCat = (k) => (TK_CATS[k] ? L(TK_CATS[k][0], TK_CATS[k][1]) : k);
const tkState = (s, staffSide) => {
  const w = staffSide ? TK_STATES_STAFF[s] : TK_STATES[s];
  return w ? `<span class="st ${TK_STATES[s][2]}">${L(w[0], w[1])}</span>` : '';
};
const tkStaff = () => !!(state.user && (state.user.admin || (state.user.perms || []).includes('tickets.handle')));
const tkMeta = { build: ['Build', 'Сборка'], version: ['Version', 'Версия'], gpu: ['Video card', 'Видеокарта'], driver: ['Driver', 'Драйвер'], os: ['System', 'Система'], cpu: ['Processor', 'Процессор'], ram: ['Memory', 'Память'], java: ['Java', 'Java'], screen: ['Screen', 'Экран'], server: ['Server', 'Сервер'], fps: ['FPS', 'FPS'], modules: ['Modules on', 'Включённые модули'] };

function viewSupport(arg) {
  const [part, x] = String(arg || '').split('/');
  const body = part === 't' ? tkTicket(Number(x)) : part === 'new' ? tkNew(x || '') : tkList();
  return `<div class="dash">${rail('support')}<div><h1 class="sr">Support</h1>${body}</div></div>`;
}

function tkList() {
  const staffSide = tkStaff() && TK.view === 'queue';
  const q = staffSide ? `tickets?all=1${TK.state === 'mine' ? '&assignee=me&state=active' : TK.state === 'none' ? '&assignee=none&state=active' : '&state=' + TK.state}` : 'tickets';
  const c = ask(q);
  const counts = c.ok && c.data.counts;
  const tab = (k, en, ru, n) => `<button class="w small ${TK.state === k ? 'on' : ''}" data-tk-state="${k}">${L(en, ru)}${n ? ` · <span class="num">${n}</span>` : ''}</button>`;
  const list = waiting(c) ? '<div class="rows"><div>&nbsp;</div></div>' : !c.ok ? trouble(c) : c.data.items.length ? c.data.items.map((t) => `<a class="tk-row ${t.unread ? 'unread' : ''}" href="#/support/t/${t.id}">
      ${staffSide ? head(t.author.login, 36) : ''}<span class="tk-main"><b translate="no">${esc(t.title)}</b>
      <span class="ash">${tkCat(t.category)} · ${ago(t.updated)}${staffSide ? ` · ${pfx(t.author)}<span translate="no">${esc(t.author.login)}</span>` : ''}${t.assignee ? ` · ${L('with', 'у')} <span translate="no">${esc(t.assignee.login)}</span>` : ''}</span></span>
      ${tkState(t.state, staffSide)}</a>`).join('') : `<div class="empty">${staffSide ? L('Nothing here.', 'Здесь пусто.') : L('No tickets yet. Something wrong? Write to us.', 'Обращений пока нет. Что-то не так? Напишите нам.')}</div>`;
  return `<p class="sub">${L('Your account and computer, bugs, complaints, partnership: Cursed’s staff answer here.', 'Аккаунт и компьютер, баги, жалобы, партнёрство: здесь отвечает персонал Cursed.')}</p>
    <div class="acts" style="margin-top:22px"><a class="w lead" href="#/support/new">${L('New ticket', 'Новое обращение')}</a>
      ${tkStaff() ? `<span class="gap"></span><button class="w ${TK.view === 'mine' ? 'on' : ''}" data-tk-view="mine">${L('Mine', 'Мои')}</button><button class="w ${TK.view === 'queue' ? 'on' : ''}" data-tk-view="queue">${L('The queue', 'Очередь')}</button>` : ''}</div>
    ${staffSide ? `<div class="acts tk-filter">${tab('active', 'Active', 'Активные')}${tab('open', 'Open', 'Открытые', counts && counts.open)}${tab('working', 'In work', 'В работе', counts && counts.working)}${tab('waiting', 'Waiting for the author', 'Ждём автора', counts && counts.waiting)}${tab('none', 'Nobody’s', 'Ничьи', counts && counts.unassigned)}${tab('mine', 'Given to me', 'На мне')}${tab('closed', 'Closed', 'Закрытые')}</div>` : ''}
    <div class="sections"><div class="tk-list">${list}</div></div>`;
}

function tkNew(cat) {
  const chosen = TK.cat || (TK_CATS[cat] ? cat : '') || foDraft('tk:cat') || 'other';
  const c = TK_CATS[chosen] || TK_CATS.other;
  return `<div class="crumb"><a href="#/support">Support</a> / ${L('New ticket', 'Новое обращение')}</div><h2 class="big" style="margin-top:14px">${L('New ticket', 'Новое обращение')}</h2>
    <div class="form" style="max-width:760px;margin-top:24px">
      <div><span class="lab">${L('What it is about', 'О чём')}</span><div class="acts tk-cats">${Object.keys(TK_CATS).map((k) => `<button class="w small ${k === chosen ? 'on' : ''}" data-tk-cat="${k}">${tkCat(k)}</button>`).join('')}</div>
        <p class="hint">${L(c[2], c[3])}</p></div>
      <div><label class="lab" for="tk-title">Title</label><input class="in" id="tk-title" maxlength="120" value="${esc(foDraft('tk:title'))}"></div>
      <div><label class="lab" for="tk-body">Text</label>${editor('tk-body', foDraft('tk:body'), 8)}</div>
      <div class="acts"><button class="w menu lead" id="tk-start" data-cat="${chosen}" data-submit-for="tk-body">${L('Send', 'Отправить')}</button><a class="w menu" href="#/support">Cancel</a></div>
      <p class="hint ${TK.bad ? 'bad' : ''}" role="status">${esc(TK.msg)}</p></div>`;
}

function tkSystem(m) {
  const who = m.author ? `<b translate="no">${esc(m.author.login)}</b>` : '';
  const [k, v] = m.body.split(/:(.*)/s);
  const line = k === 'state' ? L(`${who} set it to “${(TK_STATES_STAFF[v] || [v])[0]}”`, `${who}: статус «${(TK_STATES_STAFF[v] || [v, v])[1]}»`)
    : k === 'assigned' ? (v ? L(`${who} gave it to <b translate="no">${esc(v)}</b>`, `${who} передаёт обращение: <b translate="no">${esc(v)}</b>`) : L(`${who} gave it back`, `${who} снимает обращение с себя`))
    : k === 'file' ? L(`${who} attached ${esc(v)}`, `${who} прикладывает ${esc(v)}`)
    : k === 'device-reset' ? L(`${who} freed the account’s computer`, `${who} сбрасывает привязку к компьютеру`) : esc(m.body);
  return `<div class="tk-sys">${line} · ${ago(m.created)}</div>`;
}

function tkTicket(id) {
  const c = ask(`tickets/${id}`);
  if (waiting(c)) return `<div class="crumb"><a href="#/support">Support</a></div><h2 class="big ghost-t">&nbsp;</h2>`;
  if (!c.ok) return `<div class="crumb"><a href="#/support">Support</a></div><p class="ash" style="margin-top:20px">${L('This ticket is gone, or not yours.', 'Такого обращения нет, или оно не ваше.')}</p>`;
  const t = c.data, staffSide = t.staff_view, perms = (state.user && state.user.perms) || [];
  const meta = t.meta ? `<div class="block tk-meta"><h2 class="sec">${L('From the game', 'Из игры')}</h2><div class="kv">${Object.keys(tkMeta).filter((k) => t.meta[k]).map((k) => `<div><span class="ash">${L(...tkMeta[k])}</span><span translate="no">${esc(t.meta[k])}</span></div>`).join('')}</div></div>` : '';
  const files = t.files.length ? `<div class="block"><h2 class="sec">${L('Files', 'Файлы')}</h2><div class="tk-files">${t.files.map((f) => `<a class="w small" href="/api/tickets/${t.id}/files/${f.id}" download="${esc(f.name)}" translate="no">${esc(f.name)} · ${mb(f.size)}</a>`).join('')}</div></div>` : '';
  const msgs = t.messages.map((m) => (m.kind === 'system' ? tkSystem(m) : `<div class="review post tk-msg ${m.internal ? 'internal' : ''} ${m.staff ? 'from-staff' : ''}">${head(m.author ? m.author.login : '?', 40)}<div>
      <div class="top">${nm(m.author)}${m.staff && !m.internal ? `<span class="cream">${L('Cursed’s staff', 'Персонал Cursed')}</span>` : ''}${m.internal ? `<span class="st cream">${L('A note for the staff', 'Заметка для персонала')}</span>` : ''}<span>${ago(m.created)}</span></div>
      <div class="prose post-body" translate="no">${prose(m.body, m)}</div></div></div>`)).join('');
  const staffTools = staffSide ? `<div class="acts thread-tools tk-tools"><span class="ash">${L('Staff', 'Персонал')}</span>
      ${Object.keys(TK_STATES_STAFF).map((s) => `<button class="w small ${t.state === s ? 'on' : ''}" data-tk-set="${s}">${L(...TK_STATES_STAFF[s])}</button>`).join('')}
      ${t.assignee && t.assignee.uid === state.user.uid ? `<button class="w small" data-tk-assign="">${L('Give it back', 'Снять с себя')}</button>` : `<button class="w small" data-tk-assign="${esc(state.user.login || me().name)}">${L('Take it', 'Взять себе')}</button>`}
      ${perms.includes('users.device') || state.user.admin ? `<button class="w small" data-tk-device="1">${L('Free their computer', 'Сбросить привязку к компьютеру')}</button>` : ''}</div>
      ${t.device ? `<p class="hint">${L('Their computer: bound', 'Компьютер: привязан')} ${when(t.device.bound)} · ${L('last seen', 'заходил(а)')} ${ago(t.device.seen)}</p>` : `<p class="hint">${L('No computer bound to the account.', 'К аккаунту не привязан компьютер.')}</p>`}` : '';
  const ready = staffSide ? ask('staff/replies') : null;
  const closed = t.state === 'closed';
  const rateBox = !staffSide && closed ? (t.rating ? `<p class="ash">${L('You rated the help', 'Ваша оценка помощи')}: <b class="cream">${t.rating} / 5</b>${t.rating_note ? ` · <span translate="no">${esc(t.rating_note)}</span>` : ''}</p>`
    : `<div class="block tk-rate"><h2 class="sec">${L('How was the help?', 'Как вам помогли?')}</h2><div class="acts">${[1, 2, 3, 4, 5].map((n) => `<button class="w small ${TK.rate === n ? 'on' : ''}" data-tk-rate="${n}">${n}</button>`).join('')}</div>
        <div class="fr-invite" style="margin-top:10px"><input class="in" id="tk-rate-note" maxlength="300" placeholder="${L('A few words, if you like', 'Пара слов, если хотите')}" value="${esc(TK.rateNote)}"><button class="w small lead" id="tk-rate-go" ${TK.rate ? '' : 'disabled'}>${L('Rate', 'Оценить')}</button></div></div>`) : '';
  const replyBox = closed && !staffSide ? `<p class="st warn" style="margin-top:22px">${L('This ticket is closed.', 'Обращение закрыто.')}</p><div class="acts"><button class="w small" data-tk-set="open">${L('Open it again', 'Открыть снова')}</button></div>`
    : `<div class="form reply-box"><label class="lab" for="tk-reply">${staffSide && TK.internal ? L('A note for the staff', 'Заметка для персонала') : L('Your answer', 'Ваш ответ')}</label>${editor('tk-reply', foDraft('tk:' + t.id), 5)}
        <div class="acts">${staffSide ? `<label class="tk-check"><input type="checkbox" id="tk-internal" ${TK.internal ? 'checked' : ''}> ${L('Only the staff see it', 'Видит только персонал')}</label>
          ${ready && ready.ok && ready.data.items.length ? `<select class="in small-select" id="tk-ready" aria-label="${L('A ready answer', 'Готовый ответ')}"><option value="">${L('A ready answer…', 'Готовый ответ…')}</option>${ready.data.items.map((r) => `<option value="${r.id}">${esc(r.title)}</option>`).join('')}</select>` : ''}
          <button class="w small" id="tk-ready-new">${L('Keep this as a ready answer', 'Сохранить как готовый ответ')}</button>` : ''}
          <span class="gap"></span>${!staffSide && !closed ? `<button class="w small" data-tk-set="closed">${L('Close the ticket', 'Закрыть обращение')}</button>` : ''}<button class="w menu lead" data-tk-send="${t.id}" data-submit-for="tk-reply">${L('Send', 'Отправить')}</button></div>
        <p class="hint ${TK.bad ? 'bad' : ''}" role="status">${esc(TK.msg)}</p></div>`;
  return `<div class="thread tk">
      <div class="crumb"><a href="#/support">Support</a> / <span class="num">#${t.id}</span></div>
      <h1 class="big" translate="no">${esc(t.title)}</h1>
      <div class="by"><span>${tkState(t.state, staffSide)}</span><span class="ash">${tkCat(t.category)} · ${staffSide ? `${nm(t.author)} · ` : ''}${L('opened', 'открыто')} ${ago(t.created)}${t.assignee ? ` · ${L('with', 'у')} ${nm(t.assignee)}` : ''}</span></div>
      ${staffTools}${meta}${files}
      <div class="posts">${msgs}</div>
      ${rateBox}${replyBox}
      ${FO.pic ? `<div class="lightbox" id="fo-lightbox"><img src="${esc(FO.pic)}" alt=""><button class="w small lb-close" id="fo-lb-close">Close</button></div>` : ''}
    </div>`;
}

function supportWire() {
  if (state.route !== 'support') return;
  const on = (sel, ev, fn) => $app.querySelectorAll(sel).forEach((el) => el.addEventListener(ev, (e) => fn(el, e)));
  const id = () => Number(String(state.arg).split('/')[1]);
  const said = (r, ok) => { TK.bad = !r.ok; TK.msg = r.ok ? ok || '' : r.error === 'many' ? L('Three tickets open at most: wait for an answer.', 'Не больше трёх открытых обращений: дождитесь ответа.') : r.error === 'slow' ? L('A new ticket once a minute.', 'Новое обращение — раз в минуту.') : r.error === 'closed' ? L('This ticket is closed: open it again or start a new one.', 'Обращение закрыто: откройте его снова или создайте новое.') : tr(r.message || SAY[r.error] || SAY.busy); };
  foEditorsWire(on);
  on('[data-tk-view]', 'click', (b) => { TK.view = b.dataset.tkView; TK.state = 'active'; render(true); });
  on('[data-tk-state]', 'click', (b) => { TK.state = b.dataset.tkState; render(true); });
  on('[data-tk-cat]', 'click', (b) => { TK.cat = b.dataset.tkCat; foDraft('tk:cat', TK.cat); render(true); });
  on('#tk-title', 'input', (el) => { foDraft('tk:title', el.value); });
  on('#tk-body', 'input', (el) => { foDraft('tk:body', el.value); });
  on('#tk-reply', 'input', (el) => { foDraft('tk:' + id(), el.value); });
  on('#tk-internal', 'change', (el) => { TK.internal = el.checked; render(true); });
  on('#tk-start', 'click', async (b) => {
    if (FO.uploading) return;
    b.disabled = true;
    const r = await api('tickets', { category: b.dataset.cat, title: foDraft('tk:title'), body: foDraft('tk:body') });
    if (!r.ok) { said(r); b.disabled = false; render(true); return; }
    foDraft('tk:title', ''); foDraft('tk:body', ''); foDraft('tk:cat', ''); TK.cat = ''; TK.msg = '';
    forget('tickets');
    location.hash = `#/support/t/${r.data.id}`;
  });
  on('[data-tk-send]', 'click', async (b) => {
    if (FO.uploading) return;
    const t = Number(b.dataset.tkSend);
    b.disabled = true;
    const r = await api(`tickets/${t}/messages`, { body: foDraft('tk:' + t), internal: TK.internal });
    if (r.ok) { foDraft('tk:' + t, ''); TK.msg = ''; FO.preview['tk-reply'] = false; } else said(r);
    forget('tickets'); render(true);
  });
  on('[data-tk-set]', 'click', async (b) => { const r = await api(`tickets/${id()}/state`, { state: b.dataset.tkSet }); said(r); forget('tickets'); render(true); });
  on('[data-tk-assign]', 'click', async (b) => { const r = await api(`tickets/${id()}/assign`, { login: b.dataset.tkAssign || null }); said(r); forget('tickets'); render(true); });
  on('[data-tk-device]', 'click', async (b) => {
    if (b.dataset.sure !== '1') { b.dataset.sure = '1'; b.textContent = L('Free it?', 'Сбросить?'); return; }
    const r = await api(`tickets/${id()}/device-reset`, {}); said(r, L('Freed: the next start of the loader binds the computer it runs on.', 'Сброшено: следующий запуск лоудера привяжет тот компьютер, на котором он запущен.')); forget('tickets'); render(true);
  });
  on('[data-tk-rate]', 'click', (b) => { TK.rate = Number(b.dataset.tkRate); render(true); });
  on('#tk-rate-note', 'input', (el) => { TK.rateNote = el.value; });
  on('#tk-rate-go', 'click', async () => { const r = await api(`tickets/${id()}/rate`, { rating: TK.rate, note: TK.rateNote }); said(r, L('Thank you.', 'Спасибо.')); TK.rate = 0; TK.rateNote = ''; forget('tickets'); render(true); });
  on('#tk-ready', 'change', (s) => {
    const c = got.get('staff/replies'), r = c && c.ok && c.data.items.find((x) => String(x.id) === s.value), box = document.getElementById('tk-reply');
    if (r && box) { box.value = (box.value ? box.value.replace(/\s*$/, '\n\n') : '') + r.body; box.dispatchEvent(new Event('input', { bubbles: true })); box.focus(); }
  });
  on('#tk-ready-new', 'click', async () => {
    const body = foDraft('tk:' + id()).trim();
    if (!body) { TK.bad = true; TK.msg = L('Write the answer first.', 'Сначала напишите ответ.'); render(true); return; }
    const title = window.prompt(L('A name for this ready answer', 'Название готового ответа'), body.split('\n')[0].slice(0, 40));
    if (!title) return;
    const r = await api('staff/replies', { title, body }); said(r, L('Kept among the ready answers.', 'Сохранено в готовых ответах.')); forget('staff/replies'); render(true);
  });
  on('[data-fo-pic]', 'click', (b) => { FO.pic = b.dataset.foPic; render(true); });
  on('#fo-lb-close', 'click', () => { FO.pic = null; render(true); });
  on('#fo-lightbox', 'click', (el, e) => { if (e.target === el) { FO.pic = null; render(true); } });
  on('.spoiler', 'click', (s) => s.classList.add('shown'));
}

// ---- one's own computer (in Sessions)

function dashDevice() {
  const c = ask('me/device');
  if (waiting(c) || !c.ok) return '';
  const d = c.data, wait = d.reset_from > d.now;
  return `<div class="block"><h2 class="sec">${L('The computer you play on', 'Компьютер для игры')}</h2>
    <p class="ash">${d.bound ? `${L('Bound', 'Привязан')} ${when(d.bound)} · ${L('last start', 'последний запуск')} ${ago(d.seen)}` : L('None yet: the loader binds the computer it first starts on.', 'Пока никакого: лоудер привяжет компьютер при первом запуске.')}</p>
    <p class="hint">${L('One account plays on one computer. A new computer: free the old one here (once a day), then start the loader on the new one. More often — through support.', 'Один аккаунт — один компьютер. Новый компьютер: сбросьте привязку здесь (раз в сутки), потом запустите лоудер на новом. Чаще — через поддержку.')}</p>
    ${d.bound ? `<div class="acts"><button class="w ${wait ? '' : 'lead'}" id="dev-reset" ${wait ? 'disabled' : ''}>${wait ? `${L('Again from', 'Снова можно с')} ${esc(new Date(d.reset_from * 1000).toLocaleString(LANG === 'ru' ? 'ru-RU' : 'en-GB', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }))}` : L('Free the computer', 'Сбросить привязку')}</button></div>` : ''}
    <p class="hint" id="dev-msg" role="status"></p></div>`;
}

function deviceWire() {
  if (state.route !== 'dashboard') return;
  const b = document.getElementById('dev-reset');
  if (!b) return;
  b.addEventListener('click', async () => {
    if (b.dataset.sure !== '1') { b.dataset.sure = '1'; b.textContent = L('Free it? The loader then binds the next computer it starts on', 'Сбросить? Лоудер привяжет следующий компьютер, где запустится'); return; }
    const r = await api('me/device/reset', {});
    const msg = document.getElementById('dev-msg');
    forget('me/device');
    if (msg) { msg.textContent = r.ok ? L('Freed. Start the loader on the computer you play on now.', 'Сброшено. Запустите лоудер на компьютере, где будете играть.') : r.error === 'wait' ? L('Once a day: try again later or write to support.', 'Раз в сутки: попробуйте позже или напишите в поддержку.') : tr(r.message || SAY[r.error] || SAY.busy); msg.className = 'hint ' + (r.ok ? 'ok' : 'bad'); }
    setTimeout(() => render(true), 1800);
  });
}
