// ================================================================================================ configs (03.10.2026)
// The dashboard's Configs: the member's configs of the cloud (the client runs by the active one and sends its changes)
// and those shared with them; which one is in use, codes with a number of activations, who uses them, taken back;
// a code someone gave, typed in. The settings themselves are the client's: they are changed in the game.

const CFG = { open: 0, msg: '', bad: false, limit: 10, code: '', sure: '' };

function dashConfigs() {
  const c = ask('configs');
  if (waiting(c)) return `<h1 class="sr">Configs</h1><div class="sections">${ghosts(1)}</div>`;
  if (!c.ok) return trouble(c);
  const d = c.data, all = d.mine.concat(d.shared);
  if (!CFG.open || !all.some((x) => x.id === CFG.open)) CFG.open = d.active || (all[0] && all[0].id) || 0;
  const row = (x) => `<button class="cfg-row ${x.id === CFG.open ? 'on' : ''} ${x.active ? 'active' : ''}" data-cfg="${x.id}"><b translate="no">${esc(x.name)}</b>
      <span class="ash">${x.own ? ago(x.updated) + (x.access ? L(` · ${x.access} using`, ` · пользуются: ${x.access}`) : '') : L('from ', 'от ') + esc(x.owner.login)}</span>${x.active ? `<span class="cfg-in">${L('In use', 'Включён')}</span>` : ''}</button>`;
  const x = all.find((y) => y.id === CFG.open);
  let detail = `<p class="ash">${L('Your settings live in the cloud: the same on every computer you play on. A new config is made in the game, of the settings as they are.', 'Ваши настройки живут в облаке: одни и те же на любом компьютере. Новый конфиг делается в игре — из текущих настроек.')}</p>`;
  if (x) {
    const acc = x.own && x.access ? ask(`configs/${x.id}/access`) : null;
    detail = `<div class="cfg-head"><h2 class="big" translate="no">${esc(x.name)}</h2>${x.active ? `<span class="cfg-in">${L('In use', 'Включён')}</span>` : `<button class="w lead" data-cfg-use="${x.id}">${L('Run by it', 'Включить')}</button>`}</div>
      <p class="ash">${x.own ? '' : L('From ', 'От ') + `<b translate="no">${esc(x.owner.login)}</b> · `}${L('changed', 'изменён')} ${ago(x.updated)} · ${mb(x.bytes)}</p>
      ${x.own ? `<div class="block"><h2 class="sec">Name</h2><div class="fr-invite"><input class="in" id="cfg-name" maxlength="40" value="${esc(x.name)}"><button class="w small" id="cfg-rename">Rename</button></div></div>
      <div class="block"><h2 class="sec">${L('Share', 'Поделиться')}</h2>
        <p class="hint">${L('A code runs it for whoever types it in, as many times as you allow; you take it back whenever you like.', 'По коду конфиг включается у того, кто его введёт, — столько раз, сколько разрешите; забрать доступ можно в любой момент.')}</p>
        <div class="fr-invite"><label class="lab">${L('Activations', 'Активаций')}</label><input class="in num" id="cfg-limit" type="number" min="1" max="10000" value="${CFG.limit}" style="max-width:120px"><button class="w small lead" id="cfg-code">${L('Make a code', 'Создать код')}</button></div>
        ${x.codes.length ? `<div class="cfg-codes">${x.codes.map((k) => `<div class="cfg-code"><b class="mono cream" translate="no">${esc(k.code)}</b><span class="ash num">${k.uses} / ${k.max_uses}</span><span class="acts"><button class="w small" data-copy="${esc(k.code)}">Copy</button><button class="w small" data-cfg-revoke="${esc(k.code)}">${L('Take back', 'Забрать')}</button></span></div>`).join('')}</div>` : ''}
      </div>
      ${acc ? `<div class="block"><h2 class="sec">${L('Using it', 'Пользуются')} <span class="ash num">${x.access}</span></h2>${waiting(acc) ? '' : acc.ok ? acc.data.people.map((p) => `<div class="fr-person">${head(p.person.login, 32)}<span class="fr-l">${nm(p.person)}<span class="ash">${esc(p.code)} · ${p.active ? L('runs by it now', 'включён сейчас') : L('has it', 'есть доступ')}</span></span><span class="acts"><button class="w small" data-cfg-kick="${esc(p.person.login)}">${L('Take back', 'Забрать')}</button></span></div>`).join('') : trouble(acc)}</div>` : ''}`
        : `<p class="hint">${L('Someone else’s config: you run by it, its owner changes it.', 'Чужой конфиг: вы играете с ним, а меняет его владелец.')}</p>`}
      <div class="acts" style="margin-top:26px"><button class="w small bad" data-cfg-delete="${x.id}">${CFG.sure === String(x.id) ? L('Sure?', 'Точно?') : x.own ? L('Delete the config', 'Удалить конфиг') : L('Remove it from mine', 'Убрать у себя')}</button></div>`;
  }
  return `<h1 class="sr">Configs</h1><div class="sections cfg">
    <div class="cfg-side">
      <div class="block"><h2 class="sec">${L('A code', 'Код')}</h2><div class="fr-invite"><input class="in mono" id="cfg-redeem-in" maxlength="12" placeholder="XXXX-XXXX" value="${esc(CFG.code)}" translate="no"><button class="w small lead" id="cfg-redeem">${L('Take', 'Взять')}</button></div></div>
      <div class="block"><h2 class="sec">${L('Mine', 'Мои')} <span class="ash num">${d.mine.length} / ${d.most}</span></h2>${d.mine.map(row).join('') || `<p class="ash">${L('None yet: the game makes the first one of your settings.', 'Пока нет: первый сделает игра — из ваших настроек.')}</p>`}</div>
      ${d.shared.length ? `<div class="block"><h2 class="sec">${L('Shared with me', 'Поделились со мной')}</h2>${d.shared.map(row).join('')}</div>` : ''}
    </div>
    <div class="cfg-main">${detail}<p class="hint ${CFG.bad ? 'bad' : 'ok'}" id="cfg-msg" role="status">${esc(CFG.msg)}</p></div>
  </div>`;
}

function configsWire() {
  if (state.route !== 'dashboard') return;
  const on = (sel, ev, fn) => $app.querySelectorAll(sel).forEach((el) => el.addEventListener(ev, (e) => fn(el, e)));
  const said = (r, ok) => { CFG.bad = !r.ok; CFG.msg = r.ok ? ok : r.error === 'used' ? L('This code has no activations left.', 'У этого кода закончились активации.') : r.error === 'revoked' ? L('This code was taken back.', 'Этот код отозван.')
    : r.error === 'own' ? L('This config is yours.', 'Это ваш конфиг.') : r.error === 'code' || r.status === 404 ? L('No such code.', 'Такого кода нет.') : r.error === 'last' ? L('The last config of yours stays.', 'Последний ваш конфиг остаётся.') : tr(r.message || SAY[r.error] || SAY.busy); forget('configs'); render(true); };
  on('[data-cfg]', 'click', (b) => { CFG.open = Number(b.dataset.cfg); CFG.sure = ''; CFG.msg = ''; render(true); });
  on('[data-cfg-use]', 'click', async (b) => said(await api(`configs/${b.dataset.cfgUse}/active`, {}), L('In use: the game takes it at once.', 'Включён: игра подхватит сразу.')));
  on('#cfg-rename', 'click', async () => said(await api(`configs/${CFG.open}`, { name: document.getElementById('cfg-name').value }, 'PATCH'), L('Renamed.', 'Переименовано.')));
  on('#cfg-limit', 'input', (i) => { CFG.limit = Number(i.value) || 1; });
  on('#cfg-code', 'click', async () => said(await api(`configs/${CFG.open}/codes`, { max_uses: CFG.limit }), L('A code made: give it to whom you like.', 'Код создан: отдайте его кому хотите.')));
  on('[data-cfg-revoke]', 'click', async (b) => said(await api(`configs/${CFG.open}/codes/${encodeURIComponent(b.dataset.cfgRevoke)}`, null, 'DELETE'), L('Taken back.', 'Доступ забран.')));
  on('[data-cfg-kick]', 'click', async (b) => { const r = await api(`configs/${CFG.open}/access/${encodeURIComponent(b.dataset.cfgKick)}`, null, 'DELETE'); forget(`configs/${CFG.open}/access`); said(r, L('Taken back.', 'Доступ забран.')); });
  on('[data-cfg-delete]', 'click', async (b) => {
    if (CFG.sure !== b.dataset.cfgDelete) { CFG.sure = b.dataset.cfgDelete; render(true); return; }
    CFG.sure = '';
    const r = await api(`configs/${b.dataset.cfgDelete}`, null, 'DELETE');
    if (r.ok) CFG.open = 0;
    said(r, L('Deleted.', 'Удалено.'));
  });
  on('#cfg-redeem-in', 'input', (i) => { CFG.code = i.value; });
  on('#cfg-redeem', 'click', async () => {
    const r = await api('configs/redeem', { code: CFG.code });
    if (r.ok) { CFG.code = ''; CFG.open = r.data.config.id; }
    said(r, L('The config is yours to run by: the game takes it at once.', 'Конфиг ваш и уже включён: игра подхватит сразу.'));
  });
}
