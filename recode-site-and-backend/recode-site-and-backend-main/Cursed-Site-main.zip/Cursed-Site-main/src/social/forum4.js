// ================================================================================================ forum 4.0 (08.10.2026)
// Her word: "the forum is still raw: 4.0, as cool as it can be". The front of the forum is a scene of its own now: an
// eclipse over its name, what it holds counted up as it comes, who is here now; its categories are cards (each its
// sign and its colour, how much is in it, its last thread with its author's face); a thread is read with a line along
// the top that fills as it is read, its posts strung on a thread, the first one larger.

// ---- the categories' signs

const F4_ICON = {
  announcements: '<path d="M4 10v4h3l6 4V6l-6 4H4Z"/><path d="M16.5 9.2a4 4 0 0 1 0 5.6M19 6.8a7.5 7.5 0 0 1 0 10.4"/>',
  bugs: '<path d="M9 7.5a3 3 0 0 1 6 0V9H9V7.5Z"/><rect x="7" y="9" width="10" height="10" rx="5"/><path d="M12 13v6M4 13h3M17 13h3M5 8l2.5 2M19 8l-2.5 2M5 19l2.5-2M19 19l-2.5-2"/>',
  ideas: '<path d="M9 18h6M10 21h4"/><path d="M12 3a6 6 0 0 0-3.6 10.8c.7.5 1.1 1.3 1.1 2.2h5c0-.9.4-1.7 1.1-2.2A6 6 0 0 0 12 3Z"/>',
  help: '<circle cx="12" cy="12" r="9"/><path d="M9.6 9.3a2.5 2.5 0 0 1 4.8.9c0 1.7-2.4 2.2-2.4 3.8"/><path d="M12 17h.01"/>',
  market: '<path d="M4 8l8-4 8 4-8 4-8-4Z"/><path d="M4 8v8l8 4 8-4V8M12 12v8"/>',
  showcase: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="m4 17 5-5 4 4 2-2 5 5"/>',
  making: '<path d="M14.5 4.5a4 4 0 0 0-5.3 5.3L4 15l5 5 5.2-5.2a4 4 0 0 0 5.3-5.3l-2.6 2.6-2.4-.6-.6-2.4 2.6-2.6Z"/>',
  offtopic: '<path d="M4 6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5v7a2.5 2.5 0 0 1-2.5 2.5H10l-4.5 4v-4h-1A2.5 2.5 0 0 1 2 13.5"/>',
};
const f4Svg = (inner) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${inner}</svg>`;

// ---- the front: its scene, its categories

/** The scene over the forum's front: the eclipse, its name, what it holds (counted up), who is here now. */
function f4Hero(f, threads, posts, el) {
  const online = f.online || [];
  const fact = (n, en, ru1, ru2, ru5) => `<div class="f4-fact"><b class="num" data-f4-count="${n}">${fmt(n)}</b><span>${L(en, plural(n, ru1, ru2, ru5))}</span></div>`;
  return `<section class="f4-hero${f3Cls(el)}">
      <div class="f4-sky" aria-hidden="true"><i class="f4-stars"></i><i class="f4-corona"></i><i class="f4-moon"></i></div>
      <div class="f4-hero-in">
        <p class="f4-kicker">${L('The community of Cursed', 'Сообщество Cursed')}</p>
        <h2 class="f4-title">${L('Forum', 'Форум')}</h2>
        <p class="f4-sub">${L('Bugs, ideas, questions and everything about Cursed: the developer and the players answer here.', 'Баги, идеи, вопросы и всё о Cursed: здесь отвечают разработчик и игроки.')}</p>
        <div class="f4-facts">${fact(threads, threads === 1 ? 'thread' : 'threads', 'тема', 'темы', 'тем')}${fact(posts, posts === 1 ? 'post' : 'posts', 'сообщение', 'сообщения', 'сообщений')}${fact(online.length, 'online now', 'сейчас онлайн', 'сейчас онлайн', 'сейчас онлайн')}</div>
        ${online.length ? `<div class="f4-online" translate="no">${online.slice(0, 18).map((o) => `<a href="${profHref(o.login)}" data-u="${esc(o.login)}">${head(o.login, 30)}</a>`).join('')}${online.length > 18 ? `<span class="more num">+${online.length - 18}</span>` : ''}</div>` : ''}
      </div>
    </section>`;
}

/** A category as a card: its sign in its colour, its name and what it is for, how much is in it, its last thread. */
function f4Cat(c, t, i, el) {
  const n = (v, en1, en2, ru1, ru2, ru5) => `<span><b class="num">${fmt(v || 0)}</b>${L(v === 1 ? en1 : en2, plural(v || 0, ru1, ru2, ru5))}</span>`;
  return `<a class="f4-cat" href="#/forum/c/${c.id}" style="--c:${esc(c.colour || '#BFC0E7')}"${f3Row(i, el)}>
      <span class="f4-glyph">${f4Svg(F4_ICON[c.id] || F4_ICON.offtopic)}</span>
      <span class="f4-cat-body"><h3>${esc(c.name)}</h3><p>${esc(c.about || '')}</p></span>
      <span class="f4-cat-n">${n(c.threads, 'thread', 'threads', 'тема', 'темы', 'тем')}${n(c.posts, 'post', 'posts', 'сообщение', 'сообщения', 'сообщений')}</span>
      ${t ? `<span class="f4-cat-last">${head(t.author.login, 22)}<span><b translate="no">${esc(t.title)}</b><span class="ash">${ago(t.last.at)}</span></span></span>` : `<span class="f4-cat-last ash">${L('No threads yet', 'Тем пока нет')}</span>`}
    </a>`;
}

/** A category's own page: its head as its card on the front, larger (its sign lit in its colour, its name, what it is
 * for, how much is in it), its sign again faint and large at the right as the front's eclipse is; its filters under it. */
function f4CatHead(c, filters, el) {
  const n = (v, en1, en2, ru1, ru2, ru5) => `<span><b class="num" data-f4-count="${v || 0}">${fmt(v || 0)}</b>${L(v === 1 ? en1 : en2, plural(v || 0, ru1, ru2, ru5))}</span>`;
  const sign = f4Svg(F4_ICON[c.id] || F4_ICON.offtopic);
  return `<section class="f4-chead${f3Cls(el)}" style="--c:${esc(c.colour || '#BFC0E7')}">
      <span class="f4-chead-mark" aria-hidden="true">${sign}</span>
      <div class="f4-chead-in">
        <span class="f4-glyph">${sign}</span>
        <div><h2>${esc(c.name)}</h2><p>${esc(c.about || '')}</p>
          <span class="f4-cat-n">${n(c.threads, 'thread', 'threads', 'тема', 'темы', 'тем')}${n(c.posts, 'post', 'posts', 'сообщение', 'сообщения', 'сообщений')}</span></div>
      </div>
      ${filters}
    </section>`;
}

// ---- numbers counted up as they come (once each)

// The page is drawn again at every answer of the server: a number counts up once a screen (F3.key), not each time.
const f4Counted = new WeakSet();
const f4Done = new Set();
function f4Count(root) {
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  root.querySelectorAll('[data-f4-count]').forEach((b, i) => {
    if (f4Counted.has(b)) return;
    f4Counted.add(b);
    const to = Number(b.dataset.f4Count) || 0;
    const key = `${F3.key}:${i}`;
    if (reduce || to < 2 || f4Done.has(key)) return;
    f4Done.add(key);
    const start = performance.now(), long = 900 + Math.min(600, to * 4);
    const step = (now) => {
      const k = Math.min(1, (now - start) / long);
      const e = 1 - Math.pow(1 - k, 3);
      b.textContent = fmt(Math.round(to * e));
      if (k < 1 && b.isConnected) requestAnimationFrame(step);
    };
    b.textContent = '0';
    requestAnimationFrame(step);
  });
}
new MutationObserver((list) => {
  for (const m of list) for (const n of m.addedNodes) if (n instanceof Element) f4Count(n.matches('[data-f4-count]') ? n.parentElement || n : n);
}).observe(document.documentElement, { childList: true, subtree: true });

// ---- a thread read: the line along the top

let f4Bar = null;
function f4Read() {
  const on = /^#\/forum\/t\//.test(location.hash);
  if (!f4Bar) {
    f4Bar = document.createElement('div');
    f4Bar.className = 'f4-read';
    f4Bar.innerHTML = '<i></i>';
    document.body.appendChild(f4Bar);
  }
  f4Bar.classList.toggle('on', on);
  if (!on) return;
  const max = document.documentElement.scrollHeight - window.innerHeight;
  const k = max > 0 ? Math.min(1, Math.max(0, window.scrollY / max)) : 1;
  f4Bar.firstChild.style.transform = `scaleX(${k})`;
}
window.addEventListener('scroll', f4Read, { passive: true });
window.addEventListener('hashchange', () => setTimeout(f4Read, 60));
window.addEventListener('resize', f4Read);
