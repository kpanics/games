// ================================================================================================= people (02.10.2026)
// What every screen of people shares: the live line (one stream from the server: notifications, presence), the bell
// and its count, the notes that come and go in the corner, and how a person is drawn — their prefix, their name in
// their accent, their status with its emoji. Built into app.js before its start (build.py), so the screens below are
// known to the router; the router itself is told of them by a few swaps.

const SOC = { live: null, unread: 0, retry: 0, notes: [], noteId: 0, meta: null, playing: null };
MEMBERS_ONLY.add('u').add('notifications').add('badges');

// ---- drawing a person

/** One of the pack's emoji (an animated GIF); small ones from the small set. */
const emo = (id, size) => (id ? `<img class="emo" src="/e/${size > 40 ? '' : 's/'}${esc(id)}.gif" alt="" width="${size}" height="${size}" decoding="async" aria-hidden="true">` : '');
/** A role's prefix: its word in its colour, a hairline of it under the word. */
const pfx = (p) => (p && p.prefix ? `<span class="pfx" style="--c:${esc(p.prefix.colour)}" title="${esc(L(p.prefix.en, p.prefix.ru))}" translate="no">${esc(p.prefix.text)}</span>` : '');
const profHref = (login) => `#/u/${encodeURIComponent(login)}`;
/** A person's name as a link to their profile: in their accent, their prefix before it. */
const nm = (p, opts) => {
  if (!p) return '<span class="ash">—</span>';
  const o = opts || {};
  const name = `<b translate="no"${p.accent ? ` style="color:${esc(p.accent)}"` : ''}>${esc(p.login)}</b>`;
  return `<a class="who-name" href="${profHref(p.login)}">${o.noPrefix ? '' : pfx(p)}${name}</a>${o.status && p.status ? statusOf(p.status) : ''}`;
};
const statusOf = (s) => (s && (s.text || s.emoji) ? `<span class="status">${emo(s.emoji, 18)}<span translate="no">${esc(s.text || '')}</span></span>` : '');
/** The dot of where someone is: in the game (indigo), on the site (glow). */
const dot = (online) => (online ? `<i class="here ${online}" title="${online === 'game' ? tr('In the game') : tr('On the site')}"></i>` : '');

// ---- an avatar whose picture is not there

// Its file lost (04.10: sequwi's), or not made again yet: the head of the login takes its place, here and from now on
// (the server forgets such an avatar too, and the client's next word of the skin makes it again).
document.addEventListener('error', (e) => {
  const img = e.target;
  if (!(img instanceof HTMLImageElement) || !img.classList.contains('av') || !img.dataset.login) return;
  const login = img.dataset.login, k = login.toLowerCase();
  delete AV[k]; AVSKIN.delete(k);
  const c = document.createElement('canvas');
  c.className = 'head'; c.dataset.head = login; c.style.cssText = img.style.cssText; c.setAttribute('aria-hidden', 'true');
  img.replaceWith(c);
  drawHead(c);
}, true);

// ---- the live line

function socialStart() {
  if (SOC.live || !state.user) return;
  let es;
  try { es = new EventSource('/api/live'); } catch (e) { return; }
  SOC.live = es;
  frStart();
  es.onmessage = (m) => { let ev; try { ev = JSON.parse(m.data); } catch (e) { return; } heard(ev); };
  es.onopen = () => { SOC.retry = 0; };
  es.onerror = () => {
    // The browser tries again by itself; after the server says "signed out" it stops, and so do we.
    if (es.readyState === EventSource.CLOSED) {
      SOC.live = null;
      if (state.user) setTimeout(socialStart, Math.min(30000, 1000 * 2 ** SOC.retry++));
    }
  };
}
function socialStop() {
  if (SOC.live) SOC.live.close();
  if (FR.rec) frRecStop(false);
  FR.chat = null; frUnread(0);
  SOC.live = null; SOC.unread = 0;
  stopMusic();
}
function setUnread(n) {
  SOC.unread = Math.max(0, n | 0);
  document.querySelectorAll('.bell').forEach((b) => {
    b.classList.toggle('lit', SOC.unread > 0);
    const c = b.querySelector('.count'); if (c) c.textContent = SOC.unread > 99 ? '99+' : SOC.unread || '';
  });
  document.title = (SOC.unread ? `(${SOC.unread}) ` : '') + 'Cursed';
}
function heard(ev) {
  if (frHeard(ev)) return;
  if (ev.t === 'hello') { setUnread(ev.unread); return; }
  if (ev.t === 'unread') { setUnread(ev.unread); return; }
  if (ev.t === 'note') {
    setUnread(ev.unread);
    forget('notifications');
    if (ev.site !== false) toast(ev.n);
    if (state.route === 'notifications') render(true);
    return;
  }
  if (ev.t === 'presence' && state.route === 'u') { forget('u/'); render(true); }
  if (ev.t === 'ticket') { forget('tickets'); if (state.route === 'support') render(true); }
}

// ---- notifications: their words, where they lead

/** What a notification says, and where it leads: [line (HTML), href, emoji]. */
function noteWords(n) {
  const d = n.data || {}, a = n.actor ? `<b translate="no">${esc(n.actor.login)}</b>` : '', t = `<span translate="no">${L('“', '«')}${esc(d.title || '')}${L('”', '»')}</span>`;
  const thread = d.thread ? `#/forum/t/${d.thread}/${d.page || 1}` : '#/forum';
  switch (n.kind) {
    case 'reply': return [L(`${a} replied in ${t}`, `Ответ от ${a} в ${t}`), thread, 'c_chat'];
    case 'mention': return [L(`${a} mentioned you in ${t}`, `Упоминание от ${a} в ${t}`), thread, 'c_bell'];
    case 'moderation':
      if (d.what === 'warning') return [L(`A warning from Cursed’s staff: “${esc(d.why || '')}”`, `Предупреждение от персонала Cursed: «${esc(d.why || '')}»`), '#/notifications', 'c_warn'];
      if (d.what === 'mute') return [L(`You can’t post on the forum until ${esc(new Date(d.until * 1000).toLocaleString('en-GB', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }))}: “${esc(d.why || '')}”`, `Писать на форуме нельзя до ${esc(new Date(d.until * 1000).toLocaleString('ru-RU', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }))}: «${esc(d.why || '')}»`), '#/forum', 'c_lock'];
      return [L(`Your ${d.what === 'thread' ? 'thread' : 'post'} in ${t} was hidden: “${esc(d.why || '')}”`, `Ваш${d.what === 'thread' ? 'а тема' : ' пост'} в ${t} скрыт${d.what === 'thread' ? 'а' : ''}: «${esc(d.why || '')}»`), thread, 'c_gavel'];
    case 'forum': {
      if (d.status === 'released') return [L(`Your bug ${t} is fixed in build ${d.build}: update the client`, `Ваш баг ${t} исправлен в сборке ${d.build}: обновите клиент`), thread, 'c_check'];
      if (d.status === 'answer') return [L(`Your reply in ${t} is marked as the answer`, `Ваш ответ в ${t} отмечен как решение`), thread, 'c_check'];
      if (d.category === 'bugs' && d.status === 'fixed') return [L(`Your bug ${t} is fixed: the fix comes with the next build`, `Ваш баг ${t} исправлен: исправление войдёт в следующую сборку`), thread, 'c_check'];
      const st = (d.category === 'bugs' ? BUG_ST : IDEA_ST)[d.status] || [d.status, d.status];
      return [d.category === 'bugs' ? L(`Your bug ${t}: ${st[0].toLowerCase()}`, `Ваш баг ${t}: ${st[1].toLowerCase()}`) : L(`Your idea ${t}: ${st[0].toLowerCase()}`, `Ваша идея ${t}: ${st[1].toLowerCase()}`), thread, d.category === 'bugs' ? 'c_warn' : 'c_gem'];
    }
    case 'report': return [d.outcome === 'hide' ? L('Your report was heard: it is hidden now.', 'Ваша жалоба принята: это скрыто.') : L('Your report was looked at and dismissed.', 'Вашу жалобу рассмотрели и отклонили.'), '#/forum', 'c_shield'];
    case 'badge': return [L(`A new badge: <b>${esc(d.en || '')}</b>`, `Новый значок: <b>${esc(d.ru || '')}</b>`), `#/u/${encodeURIComponent(me().name)}`, d.icon || 'c_gem'];
    case 'friend': return [d.accepted ? L(`${a} accepted your friend request`, `${a} теперь в ваших друзьях`) : L(`${a} wants to be friends`, `${a} хочет добавить вас в друзья`), d.accepted ? '#/friends/people' : '#/friends/people', 'c_team'];
    case 'group': return [L(`${a} invites you to ${t}`, `${a} зовёт вас в группу ${t}`), '#/friends', 'c_team'];
    case 'message': return [`${a}<span translate="no">: ${esc(d.text || '')}</span>`, `#/friends/c/${d.chat}`, 'c_chat'];
    case 'ticket': {
      const w = d.what || '', st = w.startsWith('state:') ? w.slice(6) : '';
      const line = w === 'new' ? L(`${a} opened a ticket: ${t}`, `${a} открывает обращение: ${t}`)
        : w === 'reply' ? L(`${a} answered in ${t}`, `Ответ от ${a} в ${t}`)
        : w === 'assigned' ? L(`${a} gave you a ticket: ${t}`, `${a} передаёт вам обращение: ${t}`)
        : w === 'device-reset' ? L(`Your computer is freed: ${t}`, `Привязка к компьютеру сброшена: ${t}`)
        : st === 'closed' ? L(`Your ticket is closed: ${t}`, `Обращение закрыто: ${t}`)
        : st ? L(`${t}: ${(TK_STATES_STAFF[st] || [st])[0].toLowerCase()}`, `${t}: ${(TK_STATES_STAFF[st] || [st, st])[1].toLowerCase()}`)
        : L(`Something new in ${t}`, `Новое в обращении ${t}`);
      return [line, `#/support/t/${d.ticket}`, 'c_chat'];
    }
    case 'role': return [L(`You are <b>${esc(d.en || '')}</b> now`, `Теперь вы — <b>${esc(d.ru || '')}</b>`), `#/u/${encodeURIComponent(me().name)}`, 'c_crown'];
    default: return [esc(d.text || L('Something happened.', 'Что-то случилось.')), d.href || '#/notifications', 'c_bell'];
  }
}

// ---- notes in the corner (a notification as it comes)

function toast(n) {
  const [line, href, icon] = noteWords(n);
  const id = ++SOC.noteId;
  SOC.notes.push({ id, line, href, icon, actor: n.actor, nid: n.id });
  drawNotes();
  setTimeout(() => { SOC.notes = SOC.notes.filter((x) => x.id !== id); drawNotes(); }, 7000);
}
function drawNotes() {
  let box = document.getElementById('notes');
  if (!box) { box = document.createElement('div'); box.id = 'notes'; box.setAttribute('aria-live', 'polite'); document.body.appendChild(box); }
  const shown = new Set([...box.children].map((c) => Number(c.dataset.id)));
  for (const el of [...box.children]) if (!SOC.notes.some((x) => x.id === Number(el.dataset.id))) { el.classList.add('out'); setTimeout(() => el.remove(), 320); }
  for (const x of SOC.notes.slice(-4)) {
    if (shown.has(x.id)) continue;
    const a = document.createElement('a');
    a.className = 'note'; a.dataset.id = x.id; a.href = x.href;
    a.innerHTML = `${x.actor ? head(x.actor.login, 34) : emo(x.icon, 34)}<span>${x.line}</span>`;
    a.addEventListener('click', () => { if (x.nid) api('notifications/read', { ids: [x.nid] }); SOC.notes = SOC.notes.filter((y) => y.id !== x.id); drawNotes(); });
    box.appendChild(a);
    a.querySelectorAll('canvas[data-head]').forEach(drawHead);
    translate(a);
  }
}

/** The bell in the bar: lit, with its count, while something waits unread. */
// A ring of glass the avatar's size next to it, a line bell in it (the site's icons' hand); the count a cream pill on its
// shoulder (her word 04.10: the emoji bell stood apart and out of proportion).
const bell = () => `<a class="bell ${SOC.unread ? 'lit' : ''}" href="#/notifications" aria-label="Notifications" title="Notifications"><svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M6.2 16.6V11a5.8 5.8 0 0 1 11.6 0v5.6l1.6 2.1H4.6z"/><path d="M10 20.6a2.1 2.1 0 0 0 4 0"/></svg><span class="count num">${SOC.unread > 99 ? '99+' : SOC.unread || ''}</span></a>`;

// ---- the list of notifications

function viewNotifications() {
  const c = ask('notifications');
  const more = SOC.notesMore || [];
  const items = c.ok ? c.data.items.concat(more) : [];
  const row = (n) => {
    const [line, href, icon] = noteWords(n);
    return `<a class="nrow ${n.read ? '' : 'unread'}" href="${href}" data-note="${n.id}">${n.actor ? head(n.actor.login, 40) : `<span class="ico">${emo(icon, 40)}</span>`}
      <span class="nl"><span>${line}</span><span class="ash">${ago(n.created)}</span></span></a>`;
  };
  return `<div class="page-head"><h1 class="giant">Notifications</h1></div>
    <div class="wrap notes-page">
      <div class="acts" style="margin-bottom:22px"><button class="w small" id="notes-all" ${SOC.unread ? '' : 'disabled'}>Mark all read</button><a class="w small" href="#/dashboard/notify">Settings</a></div>
      ${waiting(c) ? '<div class="nlist ghost-rows"><div></div><div></div><div></div></div>' : !c.ok ? trouble(c)
        : items.length ? `<div class="nlist">${items.map(row).join('')}</div>${(more.length ? SOC.notesMoreLeft : c.data.more) ? '<div class="acts" style="margin-top:24px"><button class="w small" id="notes-more">Older</button></div>' : ''}`
        : '<div class="empty">Nothing yet. Replies, mentions and badges show up here.</div>'}
    </div>`;
}

// ---- the badges

const RARITY = ['Common', 'Rare', 'Epic', 'Legendary', 'Mythic'];
const rarityName = (r) => tr(RARITY[r] || RARITY[0]);
/** A badge's rarity at its level (a badge of levels climbs). */
const rarityAt = (b, level) => (b.levels && b.levels.length ? (b.levels[Math.max(0, (level || 1) - 1)] || b.levels[0]).rarity : b.rarity);
const badgeName = (b) => L(b.en, b.ru);
function badgeTile(b, mine, big) {
  const r = rarityAt(b, mine && mine.level);
  const lvl = b.levels && b.levels.length > 1 && mine ? `<span class="lvl num">${mine.level}</span>` : '';
  return `<button class="bdg r${r} ${mine ? 'has' : 'not'} ${big ? 'bdg-l' : ''}" data-badge="${esc(b.id)}" title="${esc(badgeName(b))}">
      <span class="gem">${emo(b.icon, big ? 64 : 44)}${lvl}</span><span class="bn">${esc(badgeName(b))}</span></button>`;
}
function badgeCard(b, mine) {
  const r = rarityAt(b, mine && mine.level);
  const levels = b.levels && b.levels.length > 1 ? `<p class="ash">${L('Levels', 'Уровни')}: ${b.levels.map((l, i) => `<span class="${mine && mine.level > i ? 'cream' : ''}">${fmt(l.at)}</span>`).join(' · ')}</p>` : '';
  return `<div class="bdg-card r${r}">${emo(b.icon, 96)}<div><h3 class="sec">${esc(badgeName(b))}</h3>
      <p>${esc(L(b.about_en, b.about_ru))}</p>${levels}
      <p class="ash">${rarityName(r)} · ${L(`${b.share}% of players have it`, `есть у ${String(b.share).replace('.', ',')}% игроков`)}${mine ? ` · ${L('received', 'получен')} ${when(mine.at)}` : ''}</p></div></div>`;
}
function viewBadges() {
  const c = ask('badges'), mine = ask('u/' + encodeURIComponent(me().name));
  if (waiting(c)) return `<div class="page-head"><h1 class="giant">Badges</h1></div><div class="wrap">${ghosts(2)}</div>`;
  if (!c.ok) return trouble(c);
  const have = {}; if (mine.ok) for (const b of mine.data.badges) have[b.id] = b;
  const open = state.badgeOpen && c.data.badges.find((b) => b.id === state.badgeOpen);
  const count = Object.keys(have).length;
  return `<div class="page-head"><h1 class="giant">Badges</h1><p class="ash num">${L(`${count} of ${c.data.badges.length} collected`, `Собрано ${count} из ${c.data.badges.length}`)}</p></div>
    <div class="wrap">${open ? badgeCard(open, have[open.id]) : ''}<div class="bdgs grid-b">${c.data.badges.map((b) => badgeTile(b, have[b.id])).join('')}</div></div>`;
}

// ---- the profile's music (one plays at a time; leaving the page stops it)

function stopMusic() {
  const p = SOC.playing;
  if (!p) return;
  if (p.audio) p.audio.pause();
  if (p.frame) p.frame.remove();
  cancelAnimationFrame(p.raf || 0);
  SOC.playing = null;
  document.querySelectorAll('.player.on').forEach((el) => el.classList.remove('on'));
}
function playMusic(btn) {
  const m = SOC.profileMusic;
  if (!m) return;
  if (SOC.playing && SOC.playing.btn === btn) { stopMusic(); return; }
  stopMusic();
  const box = btn.closest('.player');
  if (m.kind === 'file') {
    const audio = new Audio(m.url);
    audio.volume = 0.7;
    audio.play().catch(() => {});
    SOC.playing = { audio, btn };
    box.classList.add('on');
    const bar = box.querySelector('.prog i');
    const tick = () => { if (!SOC.playing || SOC.playing.audio !== audio) return; if (bar && audio.duration) bar.style.transform = `scaleX(${audio.currentTime / audio.duration})`; SOC.playing.raf = requestAnimationFrame(tick); };
    tick();
    audio.addEventListener('ended', stopMusic);
  } else {
    // SoundCloud plays in its own (hidden) player; this page says play and stop.
    const f = document.createElement('iframe');
    f.className = 'sc-frame'; f.allow = 'autoplay';
    f.src = 'https://w.soundcloud.com/player/?url=' + encodeURIComponent(m.url) + '&auto_play=true&visual=false&show_artwork=false';
    document.body.appendChild(f);
    SOC.playing = { frame: f, btn };
    box.classList.add('on');
  }
}
window.addEventListener('hashchange', () => { if (!/^#\/(u|author)\//.test(location.hash)) stopMusic(); });
