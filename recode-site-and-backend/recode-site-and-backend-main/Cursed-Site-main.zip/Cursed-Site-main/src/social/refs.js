// ================================================================================================ referral links (09.10.2026)
// site/server/src/refs.rs. Media, partners and admins: their links (the personal one, their login; and their own, one
// for each place they put a link up), what each brought — the people who opened it, the accounts made by it, who of
// them started the game, played this week, is in it now — by the hour today or by the day, and who came. Admins:
// everyone's, against the accounts made without a link. A visitor's code is kept for 30 days (refCatch) and handed in
// with the registration; the registration page shows the owner of a personal link ("an invitation from …").

const RF = { days: 30, link: 0, make: false, name: '', code: '', codeTouched: false, msg: '', bad: false, edit: 0, editName: '', sure: 0, more: null, moreKey: '', moreLeft: false, drawn: '', shown: {}, fresh: 0 };
const REF_KEY = 'cursed.ref';
const REF_DAYS = 30;
const RF_PERIODS = [[1, 'Today', 'Сегодня'], [7, '7 days', '7 дней'], [30, '30 days', '30 дней'], [0, 'All time', 'Всё время']];
const rfCan = () => !!(state.user && (state.user.admin || (state.user.perms || []).includes('refs.own') || (state.user.perms || []).includes('refs.all')));
const rfAll = () => !!(state.user && (state.user.admin || (state.user.perms || []).includes('refs.all')));
/** The dashboard's rail: the page, for those who have links. */
const refsRail = (link) => (rfCan() ? link('refs', L('Referrals', 'Рефералы')) : '');

// ---- the visitor: the code kept, given with the registration

/** /?ref=<code> (nginx sends /r/<code> here): the visit counted, the code kept for the registration, the address cleaned. */
function refCatch() {
  let code = '';
  try { code = new URLSearchParams(location.search).get('ref') || ''; } catch (e) { return; }
  if (!code) return;
  try { history.replaceState(null, '', location.pathname + location.hash); } catch (e) { /* the address stays */ }
  code = code.trim().toLowerCase().slice(0, 24);
  api('ref/hit', { code }).then((r) => {
    if (!r.ok) return;
    try { localStorage.setItem(REF_KEY, JSON.stringify({ code: r.data.code, at: Date.now(), by: r.data.by || null })); } catch (e) { /* not kept */ }
    if (state.route === 'register') render(true);
  });
}
function refStored() {
  try {
    const r = JSON.parse(localStorage.getItem(REF_KEY) || 'null');
    return r && r.code && Date.now() - r.at < REF_DAYS * 864e5 ? r : null;
  } catch (e) { return null; }
}
const refCode = () => (refStored() || {}).code || '';
function refDone() { try { localStorage.removeItem(REF_KEY); } catch (e) { /* nothing kept */ } }
/** Above the registration form: whose personal link brought them. */
function refInvite() {
  const r = refStored();
  if (!r || !r.by) return '';
  const p = r.by;
  learnAv(p);
  return `<p class="rf-invite">${head(p.login, 34)}<span><span class="ash">${L('An invitation from', 'Приглашение от')}</span> ${pfx(p)}<b translate="no"${p.accent ? ` style="color:${esc(p.accent)}"` : ''}>${esc(p.login)}</b></span></p>`;
}

// ---- pieces

const rfPct = (a, b) => (b ? Math.min(100, Math.round((100 * a) / b)) + '%' : '—');
const rfHost = (base) => String(base || '').replace(/^https?:\/\//, '');
const rfName = (l) => (l.main ? L('Personal', 'Личная') : esc(l.name));
const rfMsk = { timeZone: 'Europe/Moscow' };
const rfDay = (t, o) => new Date(t * 1000).toLocaleDateString(L('en-GB', 'ru-RU'), { ...rfMsk, ...o });
const rfWhen = (t) => new Date(t * 1000).toLocaleString(L('en-GB', 'ru-RU'), { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
/** A number tile: the value counts up to itself the first time it shows or changes. */
const rfNum = (key, n, label, sub, lead, unit) => `<div class="rf-num ${lead ? 'lead' : ''}"><b class="num" data-rf-to="${n}" data-rf-key="${key}" data-rf-unit="${unit || ''}">${fmt(RF.shown[key] === undefined ? 0 : RF.shown[key])}${unit || ''}</b><span>${label}</span>${sub ? `<span class="ash s">${sub}</span>` : ''}</div>`;
const rfCopy = (url, word) => `<button class="w small ${word ? 'lead' : ''}" data-rf-copy="${esc(url)}">${word || L('Copy', 'Копировать')}</button>`;
const rfPeriods = () => `<div class="acts rf-days" role="group" aria-label="${L('Period', 'Период')}">${RF_PERIODS.map(([d, en, ru]) => `<button class="w small ${RF.days === d ? 'on' : ''}" data-rf-days="${d}">${L(en, ru)}</button>`).join('')}</div>`;
const rfTop = (scope) => `<div class="rf-top">${rfAll() ? `<nav class="acts rf-scope" aria-label="${L('Whose links', 'Чьи ссылки')}"><a class="w ${scope === 'mine' ? 'on' : ''}" href="#/dashboard/refs">${L('My links', 'Мои ссылки')}</a><a class="w ${scope === 'mine' ? '' : 'on'}" href="#/dashboard/refs/all">${L('Everyone', 'Все')}</a></nav>` : '<span></span>'}${rfPeriods()}</div>`;
const rfGhost = (scope) => `<h1 class="sr">${L('Referrals', 'Рефералы')}</h1><div class="rf">${rfTop(scope)}<div class="ghost-rows"><div></div><div></div><div></div></div></div>`;
/** A row's numbers; on a phone each says what it is (the table's head is hidden there). */
const rfCells = (n) => [[n.people, L('Opened', 'Открыли')], [n.regs, L('Registered', 'Регистрации')], [n.played, L('Played', 'Играли')]].map(([v, l]) => `<td class="r num" data-l="${l}">${fmt(v)}</td>`).join('')
  + `<td class="r num ash" data-l="${L('Conversion', 'Конверсия')}">${rfPct(n.regs, n.people)}</td>`;
const rfSum = (lists) => { const out = []; for (const a of lists) a.forEach((v, i) => { out[i] = (out[i] || 0) + v; }); return out; };

/** Russian letters in Latin, for a code made of a link's name ("Пост в TG" → "post-v-tg"). */
function rfSlug(s) {
  const T = { а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'e', ж: 'zh', з: 'z', и: 'i', й: 'y', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'h', ц: 'c', ч: 'ch', ш: 'sh', щ: 'sch', ъ: '', ы: 'y', ь: '', э: 'e', ю: 'yu', я: 'ya' };
  return [...String(s).toLowerCase()].map((ch) => (T[ch] !== undefined ? T[ch] : ch)).join('').replace(/[^a-z0-9_]+/g, '-').replace(/^[-_]+|[-_]+$/g, '').slice(0, 24).replace(/[-_]+$/, '');
}
const rfCodeOk = (s) => /^[a-z0-9](?:[a-z0-9_-]{1,22})[a-z0-9]$/.test(s);

// ---- the chart: small multiples on one time axis (people who opened, accounts made), a column a slot

/**
 * `lanes`: [{ key, name, parts: [{ cls, name, values }] }] — a lane of one part is plain columns; of more, they stack
 * (the first at the baseline). Hovering a slot tells all its values.
 */
function rfChart(ch, lanes) {
  const n = ch.n, hourly = ch.step === 3600;
  const totals = lanes.map((ln) => Array.from({ length: n }, (_, i) => ln.parts.reduce((s, p) => s + (p.values[i] || 0), 0)));
  const tops = totals.map((t) => Math.max(1, ...t) * 1.22);
  const peaks = totals.map((t) => { const m = Math.max(...t); return m > 0 ? t.indexOf(m) : -1; });
  const now = Date.now() / 1000;
  const slots = [];
  for (let i = 0; i < n; i++) {
    const cells = lanes.map((ln, k) => {
      const total = totals[k][i];
      if (!total) return '<div class="rf-cell"></div>';
      const h = `height:${((100 * total) / tops[k]).toFixed(2)}%`;
      if (ln.parts.length === 1) return `<div class="rf-cell"><i class="${ln.parts[0].cls}" style="${h}"></i></div>`;
      return `<div class="rf-cell"><span class="rf-stack" style="${h}">${ln.parts.map((p) => (p.values[i] ? `<i class="${p.cls}" style="flex:${p.values[i]}"></i>` : '')).join('')}</span></div>`;
    }).join('');
    const later = ch.since + i * ch.step > now;
    slots.push(`<div class="rf-slot ${later ? 'later' : ''}" data-i="${i}" style="--d:${Math.min(i * (n > 60 ? 3 : 14), 420)}ms">${cells}</div>`);
  }
  const at = (i) => `calc(${((i + 0.5) * 100) / n}% )`;
  const laneMarks = lanes.map((ln, k) => {
    const p = peaks[k];
    const legend = ln.parts.length > 1 ? `<span class="rf-keys">${ln.parts.map((x) => `<span><i class="${x.cls}"></i>${x.name}</span>`).join('')}</span>` : '';
    const peak = p >= 0 ? `<em class="rf-peak ${p < n * 0.12 ? 'start' : p > n * 0.88 ? 'end' : ''}" style="left:${at(p)};bottom:calc(${((100 * totals[k][p]) / tops[k]).toFixed(2)}% + 6px)">${fmt(totals[k][p])}</em>` : '';
    return `<div class="rf-lane" style="--row:${k}"><span class="rf-lname">${ln.name}${legend}</span>${peak}</div>`;
  }).join('');
  // A label every few slots: the hours of today, or days (and "today" at the end).
  const every = hourly ? 3 : n <= 8 ? 1 : n <= 31 ? Math.ceil(n / 7) : Math.ceil(n / 8);
  // Hours from midnight; days back from today, so today always has its word.
  const ticks = [];
  const marks = hourly ? Array.from({ length: 8 }, (_, k) => k * 3) : Array.from({ length: Math.ceil(n / every) }, (_, k) => n - 1 - k * every);
  for (const i of marks) {
    const t = ch.since + i * ch.step;
    const word = hourly ? `${String(i).padStart(2, '0')}:00` : i === n - 1 ? L('today', 'сегодня') : rfDay(t, { day: 'numeric', month: 'short' }).replace('.', '');
    const cls = [i === 0 ? 'start' : i === n - 1 ? 'end' : i > n - 1 - every / 2 ? 'end' : '', !hourly && i === n - 1 ? 'now' : ''].join(' ');
    ticks.push(`<span class="${cls}" style="left:${at(i)}">${word}</span>`);
  }
  const head = hourly ? L('Hour (Moscow)', 'Час (МСК)') : L('Day', 'День');
  const table = `<table class="sr"><caption>${lanes.map((l) => l.name).join(', ')}</caption><thead><tr><th>${head}</th>${lanes.flatMap((l) => l.parts.map((p) => `<th>${p.name}</th>`)).join('')}</tr></thead><tbody>${Array.from({ length: n }, (_, i) => `<tr><td>${hourly ? `${String(i).padStart(2, '0')}:00` : rfDay(ch.since + i * ch.step, { day: 'numeric', month: 'long' })}</td>${lanes.flatMap((l) => l.parts.map((p) => `<td>${p.values[i] || 0}</td>`)).join('')}</tr>`).join('')}</tbody></table>`;
  RF.chart = { ch, lanes };
  const empty = totals.every((t) => t.every((x) => !x)) ? `<p class="rf-empty">${L('Nothing yet: the columns rise with the first visits.', 'Пока пусто: столбики вырастут с первыми переходами.')}</p>` : '';
  return `<figure class="rf-chart" style="--n:${n};--lanes:${lanes.length}" aria-label="${L('Chart', 'График')}">
      <div class="rf-plot">${laneMarks}${empty}<div class="rf-slots">${slots.join('')}</div></div>
      <div class="rf-axis" aria-hidden="true">${ticks.join('')}</div>
      <div class="rf-tip" role="tooltip" hidden></div>${table}</figure>`;
}
/** What a slot of the chart says, under the pointer. */
function rfChartWire(fig) {
  const tip = fig.querySelector('.rf-tip'), plot = fig.querySelector('.rf-plot'), data = RF.chart;
  if (!tip || !plot || !data) return;
  const { ch, lanes } = data;
  const show = (slot) => {
    fig.querySelectorAll('.rf-slot.on').forEach((s) => s.classList.remove('on'));
    if (!slot) { tip.hidden = true; return; }
    slot.classList.add('on');
    const i = Number(slot.dataset.i), t = ch.since + i * ch.step;
    const when = ch.step === 3600 ? `${String(i).padStart(2, '0')}:00–${String((i + 1) % 24).padStart(2, '0')}:00 ${L('Moscow', 'МСК')}` : rfDay(t, { weekday: 'short', day: 'numeric', month: 'long' });
    tip.innerHTML = `<b>${when}</b>${lanes.flatMap((l) => l.parts.map((p) => `<span><i class="${p.cls}"></i>${p.name}<b class="num">${fmt(p.values[i] || 0)}</b></span>`)).join('')}`;
    tip.hidden = false;
    const box = fig.getBoundingClientRect(), s = slot.getBoundingClientRect();
    const x = s.left - box.left + s.width / 2, w = tip.offsetWidth;
    tip.style.left = Math.max(0, Math.min(box.width - w, x - w / 2)) + 'px';
  };
  plot.addEventListener('pointermove', (e) => { const s = e.target.closest('.rf-slot'); if (s && !s.classList.contains('on')) show(s); });
  plot.addEventListener('pointerleave', () => show(null));
}

// ---- a member's page

function viewRefs(arg) {
  const a = String(arg || '');
  if (!state.user) return rfGhost('mine');
  if (!rfCan()) return `<h1 class="sr">${L('Referrals', 'Рефералы')}</h1><div class="empty">${L('Referral links are for media, partners and admins.', 'Реферальные ссылки — для медиа, партнёров и админов.')}</div>`;
  if (a === 'all' && rfAll()) return rfEveryone();
  if (a.startsWith('u/') && rfAll()) return rfPage(Number(a.slice(2)));
  return rfPage(null);
}

function rfPage(uid) {
  const someone = uid !== null && !Number.isNaN(uid);
  const path = `refs?days=${RF.days}${someone ? '&uid=' + uid : ''}`;
  const c = ask(path);
  if (waiting(c)) return rfGhost(someone ? 'all' : 'mine');
  if (!c.ok) return `<div class="rf">${rfTop(someone ? 'all' : 'mine')}${trouble(c)}</div>`;
  const d = c.data;
  if (RF.link && !d.links.some((l) => l.id === RF.link)) RF.link = 0;
  const focus = RF.link ? d.links.find((l) => l.id === RF.link) : null;
  const main = d.links.find((l) => l.main) || d.links[0];
  const shownLink = focus || main;
  const host = rfHost(d.base);
  const t = focus || d.total;
  const key = path + '#' + RF.link;
  const animate = RF.drawn !== key;
  RF.drawn = key;
  RF.page = { uid: someone ? uid : null, d };

  // The chart of the links shown: one link, or all of them summed.
  const ids = focus ? [String(focus.id)] : Object.keys(d.chart.links);
  const v = rfSum(ids.map((id) => d.chart.links[id].v)), r = rfSum(ids.map((id) => d.chart.links[id].r));
  const chart = rfChart(d.chart, [
    { key: 'v', name: L('Opened the site', 'Открыли сайт'), parts: [{ cls: 'v', name: L('Opened the site', 'Открыли сайт'), values: v }] },
    { key: 'r', name: L('Registered', 'Зарегистрировались'), parts: [{ cls: 'r', name: L('Registered', 'Зарегистрировались'), values: r }] },
  ]);

  const owner = d.owner || {};
  const title = d.mine ? `<h1 class="giant">${L('Referrals', 'Рефералы')}</h1>`
    : `<div class="crumb"><a href="#/dashboard/refs/all">${L('Everyone', 'Все')}</a> / <span translate="no">${esc(owner.login || '')}</span></div>
       <div class="rf-who">${head(owner.login || '?', 64)}<h1 class="giant" translate="no">${pfx(owner)}${esc(owner.login || '')}</h1></div>`;
  const url = shownLink ? d.base + shownLink.code : '';
  const linkLine = shownLink ? `<div class="rf-link"><span class="rf-url" translate="no"><span class="host">${esc(host)}</span><b>${esc(shownLink.code)}</b></span>${rfCopy(url, L('Copy the link', 'Скопировать ссылку'))}</div>
      <p class="hint">${focus ? `${rfName(focus)}${focus.archived ? ' · ' + L('put away: takes nobody new', 'в архиве: новых не засчитывает') : ''} · <button class="w small" data-rf-focus="0">${L('All links', 'Все ссылки')}</button>`
        : d.mine ? L('Whoever opens it and registers within 30 days counts as yours. Make a link of its own for each place you post it, to see which one works.', 'Кто откроет её и зарегистрируется в течение 30 дней — засчитается вам. Для каждого места, где публикуете, сделайте свою ссылку — будет видно, какая работает.')
        : L('Their personal link.', 'Личная ссылка.')}</p>` : '';

  const nums = `<div class="rf-nums">
      ${rfNum('people', t.people, L('opened the site', 'открыли сайт'), t.opened > t.people ? L(`${fmt(t.opened)} visits`, `${fmt(t.opened)} ${plural(t.opened, 'переход', 'перехода', 'переходов')}`) : '')}
      ${rfNum('regs', t.regs, L('registered', 'зарегистрировались'), t.people ? L(`${rfPct(t.regs, t.people)} of them`, `${rfPct(t.regs, t.people)} от открывших`) : '', true)}
      ${rfNum('played', t.played, L('started the game', 'запустили игру'), t.regs ? L(`${rfPct(t.played, t.regs)} of the registered`, `${rfPct(t.played, t.regs)} от зарегистрированных`) : '')}
      ${rfNum('week', t.week, L('played this week', 'играли на этой неделе'))}
      ${rfNum('hours', t.hours, L('hours in the game', 'часов в игре'))}
      ${rfNum('now', t.now, `${t.now ? '<i class="here game"></i>' : ''}${L('in the game now', 'сейчас в игре')}`)}
    </div>`;

  return `<h1 class="sr">${L('Referrals', 'Рефералы')}</h1><div class="rf ${animate ? 'anim' : ''}">
    ${rfTop(d.mine ? 'mine' : 'all')}
    <header class="rf-head">${title}${linkLine}${RF.msg ? `<p class="hint rf-msg ${RF.bad ? 'bad' : 'ok'}" id="rf-msg" role="status">${esc(RF.msg)}</p>` : ''}</header>
    ${nums}
    ${chart}
    ${rfLinks(d)}
    ${rfPeople(d)}
  </div>`;
}

function rfLinks(d) {
  const own = d.links.filter((l) => !l.main).length;
  const row = (l) => {
    const url = d.base + l.code;
    const edit = RF.edit === l.id ? `<tr class="rf-edit"><td colspan="6"><form class="fr-invite" id="rf-edit-form" data-id="${l.id}">
        <input class="in" id="rf-edit-name" maxlength="40" value="${esc(RF.editName)}" aria-label="${L('Name', 'Название')}">
        <button class="w small lead" type="submit">${L('Save', 'Сохранить')}</button>
        <button class="w small" type="button" data-rf-archive="${l.id}" data-on="${l.archived ? 0 : 1}">${l.archived ? L('Bring back', 'Вернуть из архива') : RF.sure === l.id ? L('Put it away?', 'Точно в архив?') : L('Put away', 'В архив')}</button>
        <button class="w small" type="button" data-rf-cancel="1">${L('Cancel', 'Отмена')}</button></form>
        <p class="hint">${L('A link put away takes nobody new; what it brought stays.', 'Ссылка в архиве не засчитывает новых; то, что она привела, остаётся.')}</p></td></tr>` : '';
    return `<tr class="${RF.link === l.id ? 'on' : ''} ${l.archived ? 'off' : ''}">
        <td class="who"><button class="rf-lname-b" data-rf-focus="${l.id}" title="${L('Show this link only', 'Показать только её')}"><b>${rfName(l)}${l.archived ? ` <span class="ash">· ${L('put away', 'в архиве')}</span>` : ''}</b><span class="mono ash" translate="no">/r/${esc(l.code)}</span></button></td>
        ${rfCells(l)}
        <td class="acts-c">${rfCopy(url)}${!l.main && (d.mine || d.all) ? `<button class="w small" data-rf-edit="${l.id}">${L('Edit', 'Изменить')}</button>` : ''}</td></tr>${edit}`;
  };
  const form = RF.make ? `<form class="form rf-form" id="rf-form" novalidate>
      <div><label class="lab" for="rf-name">${L('Where it goes', 'Где будет ссылка')}</label><input class="in" id="rf-name" maxlength="40" placeholder="${L('A Telegram post, a video…', 'Пост в Telegram, видео на YouTube…')}" value="${esc(RF.name)}"></div>
      <div><label class="lab" for="rf-code">${L('The link', 'Ссылка')}</label><div class="rf-code-in"><span class="ash mono" translate="no">${esc(rfHost(d.base))}</span><input class="in mono" id="rf-code" maxlength="24" autocomplete="off" spellcheck="false" value="${esc(RF.code)}" translate="no"></div>
        <p class="hint" id="rf-code-h">${L('3–24 of a–z, 0–9, _ and -', '3–24 символа: a–z, 0–9, _ и -')}</p></div>
      <div class="acts"><button class="w lead" type="submit">${L('Make the link', 'Создать ссылку')}</button><button class="w" type="button" id="rf-new-no">${L('Cancel', 'Отмена')}</button></div></form>` : '';
  return `<section class="block rf-links"><div class="rf-sec"><h2 class="sec">${L('Links', 'Ссылки')} <span class="ash num">${d.links.length}</span></h2>
      ${d.mine && own < d.limit ? `<button class="w small ${RF.make ? 'on' : 'lead'}" id="rf-new">${L('A new link', 'Новая ссылка')}</button>` : ''}</div>
    ${form}
    <div class="scroll-x"><table class="rf-table"><thead><tr><th>${L('Link', 'Ссылка')}</th><th class="r">${L('Opened', 'Открыли')}</th><th class="r">${L('Registered', 'Регистрации')}</th><th class="r">${L('Played', 'Играли')}</th><th class="r">${L('Conversion', 'Конверсия')}</th><th></th></tr></thead>
      <tbody>${d.links.map(row).join('')}</tbody></table></div></section>`;
}

function rfPeople(d) {
  const uid = RF.page && RF.page.uid !== null ? RF.page.uid : null;
  const mk = `${uid}|${RF.link}`;
  if (RF.moreKey !== mk) { RF.more = null; RF.moreKey = mk; }
  let list = d.people, left = d.more;
  if (RF.link) {
    const c = ask(`refs/people?before=9000000000000&link=${RF.link}${uid !== null ? '&uid=' + uid : ''}`);
    if (waiting(c)) return `<section class="block"><h2 class="sec">${L('Who came', 'Кто пришёл')}</h2><div class="ghost-rows"><div></div><div></div></div></section>`;
    list = c.ok ? c.data.people : [];
    left = c.ok && c.data.more;
  }
  if (RF.more) { list = list.concat(RF.more); left = RF.moreLeft; }
  const names = Object.fromEntries(d.links.map((l) => [l.id, l.main ? L('personal link', 'личная ссылка') : l.name]));
  const status = (p) => (p.week ? `<span class="st ok">${L('Plays', 'Играет')}</span>` : p.played ? `<span class="st">${L('Not lately', 'Давно не играет')}</span>` : `<span class="st off">${L('Not in the game yet', 'Ещё не играет')}</span>`);
  const row = (p) => `<div class="rf-person">${head(p.card.login, 36)}<span class="tk-main"><b>${nm(p.card)}</b>
      <span class="ash">${esc(names[p.link] || '')} · ${rfWhen(p.at)}${p.hours !== undefined ? ` · ${p.hours} ${L('h in the game', 'ч в игре')}` : ''}</span></span>${status(p)}</div>`;
  return `<section class="block"><h2 class="sec">${L('Who came', 'Кто пришёл')}</h2>
    ${list.length ? `<div class="rf-people">${list.map(row).join('')}</div>${left ? `<div class="acts"><button class="w small" id="rf-more">${L('More', 'Ещё')}</button></div>` : ''}`
      : `<p class="ash">${L('Nobody yet. Whoever registers by your links shows up here.', 'Пока никого. Здесь появятся те, кто зарегистрируется по вашим ссылкам.')}</p>`}</section>`;
}

// ---- everyone's (admins)

function rfEveryone() {
  const c = ask(`refs/all?days=${RF.days}`);
  if (waiting(c)) return rfGhost('all');
  if (!c.ok) return `<div class="rf">${rfTop('all')}${trouble(c)}</div>`;
  const d = c.data, t = d.total;
  const key = 'all#' + RF.days;
  const animate = RF.drawn !== key;
  RF.drawn = key;
  const made = t.regs + d.organic;
  const chart = rfChart(d.chart, [
    { key: 'v', name: L('Opened the site by a link', 'Открыли сайт по ссылке'), parts: [{ cls: 'v', name: L('Opened by a link', 'Открыли по ссылке'), values: d.chart.v }] },
    { key: 'r', name: L('Registered', 'Зарегистрировались'), parts: [{ cls: 'r', name: L('By a link', 'По ссылке'), values: d.chart.r }, { cls: 'o', name: L('Without one', 'Без ссылки'), values: d.chart.o }] },
  ]);
  const row = (o, i) => {
    const p = o.card, n = o.total, active = o.links.filter((l) => !l.archived).length;
    return `<tr><td class="rank ash num">${i + 1}</td>
      <td class="who"><a class="rf-owner" href="#/dashboard/refs/u/${p.uid}">${head(p.login, 32)}<span><b translate="no"${p.accent ? ` style="color:${esc(p.accent)}"` : ''}>${pfx(p)}${esc(p.login)}</b><span class="ash">${active} ${L(active === 1 ? 'link' : 'links', plural(active, 'ссылка', 'ссылки', 'ссылок'))}</span></span></a></td>
      ${rfCells(n)}
      <td class="acts-c"><a class="w small" href="#/dashboard/refs/u/${p.uid}">${L('Open', 'Открыть')}</a></td></tr>`;
  };
  return `<h1 class="sr">${L('Referrals', 'Рефералы')}</h1><div class="rf ${animate ? 'anim' : ''}">
    ${rfTop('all')}
    <header class="rf-head"><h1 class="giant">${L('Everyone’s links', 'Все ссылки')}</h1>
      <p class="hint">${L('Media, partners and admins. An admin’s own links are for adverts: make one in “My links” for each.', 'Медиа, партнёры и админы. Свои ссылки админа — для рекламы: на каждую закупку своя, в «Моих ссылках».')}</p></header>
    <div class="rf-nums">
      ${rfNum('a-people', t.people, L('opened the site by a link', 'открыли сайт по ссылке'))}
      ${rfNum('a-regs', t.regs, L('registered by a link', 'зарегистрировались по ссылке'), t.people ? L(`${rfPct(t.regs, t.people)} of them`, `${rfPct(t.regs, t.people)} от открывших`) : '', true)}
      ${rfNum('a-organic', d.organic, L('registered without one', 'зарегистрировались без ссылки'))}
      ${rfNum('a-share', made ? Math.round((100 * t.regs) / made) : 0, L('of all registrations came by links', 'всех регистраций — по ссылкам'), '', false, '%')}
      ${rfNum('a-played', t.played, L('of them started the game', 'из них запустили игру'), t.regs ? rfPct(t.played, t.regs) : '')}
      ${rfNum('a-hours', t.hours, L('hours in the game', 'часов в игре'))}
    </div>
    ${chart}
    <section class="block"><h2 class="sec">${L('Who brings people', 'Кто приводит')}</h2>
      ${d.owners.length ? `<div class="scroll-x"><table class="rf-table"><thead><tr><th></th><th>${L('Member', 'Участник')}</th><th class="r">${L('Opened', 'Открыли')}</th><th class="r">${L('Registered', 'Регистрации')}</th><th class="r">${L('Played', 'Играли')}</th><th class="r">${L('Conversion', 'Конверсия')}</th><th></th></tr></thead>
        <tbody>${d.owners.map(row).join('')}</tbody></table></div>` : `<p class="ash">${L('Nobody has links yet.', 'Ссылок пока ни у кого нет.')}</p>`}
    </section>
  </div>`;
}

// ---- the page's hands

function rfCount() {
  const els = $app.querySelectorAll('[data-rf-to]');
  const still = matchMedia('(prefers-reduced-motion: reduce)').matches;
  els.forEach((el) => {
    const key = el.dataset.rfKey, to = Number(el.dataset.rfTo), from = RF.shown[key] === undefined ? 0 : RF.shown[key], unit = el.dataset.rfUnit || '';
    RF.shown[key] = to;
    if (from === to || still) { el.textContent = fmt(to) + unit; return; }
    const t0 = performance.now(), dur = 900;
    const step = (now) => {
      const k = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - k, 3);
      if (!el.isConnected) return;
      el.textContent = fmt(Math.round(from + (to - from) * e)) + unit;
      if (k < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  });
}

async function rfCopyText(btn) {
  const text = btn.dataset.rfCopy;
  let ok = false;
  try { await navigator.clipboard.writeText(text); ok = true; } catch (e) {
    const ta = document.createElement('textarea');
    ta.value = text; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;opacity:0';
    document.body.appendChild(ta); ta.select();
    try { ok = document.execCommand('copy'); } catch (e2) { ok = false; }
    ta.remove();
  }
  const was = btn.dataset.word || btn.textContent;
  btn.dataset.word = was;
  btn.textContent = ok ? L('Copied', 'Скопировано') : L('Copy it by hand', 'Скопируйте вручную');
  btn.classList.add('done');
  clearTimeout(btn._t);
  btn._t = setTimeout(() => { btn.textContent = was; btn.classList.remove('done'); }, 1600);
}

function refsWire() {
  if (state.route !== 'dashboard' || !String(state.arg).startsWith('refs')) return;
  const on = (sel, ev, fn) => $app.querySelectorAll(sel).forEach((el) => el.addEventListener(ev, (e) => fn(el, e)));
  const said = (r, ok) => { RF.bad = !r.ok; RF.msg = r.ok ? ok || '' : r.message ? tr(r.message) : r.error === 'staff' ? L('Your role does not allow it.', 'Ваша роль этого не позволяет.') : SAY[r.error] || SAY.busy; };
  const codeHint = () => {
    const h = document.getElementById('rf-code-h'); if (!h) return;
    const ok = !RF.code || rfCodeOk(RF.code);
    h.classList.toggle('bad', !ok);
  };
  rfCount();
  $app.querySelectorAll('.rf-chart').forEach(rfChartWire);
  on('[data-rf-days]', 'click', (b) => { RF.days = Number(b.dataset.rfDays); RF.msg = ''; render(true); });
  on('[data-rf-focus]', 'click', (b) => { const id = Number(b.dataset.rfFocus); RF.link = RF.link === id ? 0 : id; RF.msg = ''; render(true); });
  on('[data-rf-copy]', 'click', (b) => rfCopyText(b));
  on('#rf-new', 'click', () => {
    RF.make = !RF.make; RF.msg = '';
    if (RF.make) { RF.name = ''; RF.code = ''; RF.codeTouched = false; }
    render(true);
    const i = document.getElementById('rf-name'); if (i) i.focus();
  });
  on('#rf-new-no', 'click', () => { RF.make = false; render(true); });
  on('#rf-name', 'input', (el) => {
    RF.name = el.value;
    if (!RF.codeTouched) { RF.code = rfSlug(el.value); const ci = document.getElementById('rf-code'); if (ci) ci.value = RF.code; codeHint(); }
  });
  on('#rf-code', 'input', (el) => { RF.codeTouched = true; RF.code = el.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''); if (el.value !== RF.code) el.value = RF.code; codeHint(); });
  on('form#rf-form', 'submit', async (f, e) => {
    e.preventDefault();
    if (!RF.name.trim()) { said({ ok: false, message: L('Give it a name: where it goes.', 'Дайте ссылке название — где она будет.') }); render(true); return; }
    if (!rfCodeOk(RF.code)) { said({ ok: false, message: L('The link: 3–24 of a–z, 0–9, _ and -, a letter or a digit at both ends.', 'Ссылка: 3–24 символа a–z, 0–9, _ и -, по краям буква или цифра.') }); render(true); return; }
    const r = await api('refs', { name: RF.name.trim(), code: RF.code });
    said(r, L('The link is made: copy it and put it up.', 'Ссылка создана — скопируйте и публикуйте.'));
    if (r.ok) { RF.make = false; RF.link = r.data.id; forget('refs'); }
    render(true);
  });
  on('[data-rf-edit]', 'click', (b) => {
    const id = Number(b.dataset.rfEdit), l = RF.page && RF.page.d.links.find((x) => x.id === id);
    RF.edit = RF.edit === id ? 0 : id; RF.editName = l ? l.name : ''; RF.sure = 0;
    render(true);
    const i = document.getElementById('rf-edit-name'); if (i) i.focus();
  });
  on('#rf-edit-name', 'input', (el) => { RF.editName = el.value; });
  on('[data-rf-cancel]', 'click', () => { RF.edit = 0; RF.sure = 0; render(true); });
  on('form#rf-edit-form', 'submit', async (f, e) => {
    e.preventDefault();
    const r = await api(`refs/${f.dataset.id}`, { name: RF.editName }, 'PATCH');
    said(r, L('Saved.', 'Сохранено.'));
    if (r.ok) { RF.edit = 0; forget('refs'); }
    render(true);
  });
  on('[data-rf-archive]', 'click', async (b) => {
    const id = Number(b.dataset.rfArchive), put = b.dataset.on === '1';
    if (put && RF.sure !== id) { RF.sure = id; render(true); return; }
    RF.sure = 0;
    const r = await api(`refs/${id}`, { archived: put }, 'PATCH');
    said(r, put ? L('Put away.', 'Ссылка в архиве.') : L('It works again.', 'Ссылка снова работает.'));
    if (r.ok) { RF.edit = 0; forget('refs'); }
    render(true);
  });
  on('#rf-more', 'click', async (b) => {
    const p = RF.page; if (!p) return;
    const who = p.uid !== null ? '&uid=' + p.uid : '';
    // The last one shown: of the page's own forty, or of the one link's list, or of what came after them.
    const first = RF.link ? ((got.get(`refs/people?before=9000000000000&link=${RF.link}${who}`) || {}).data || {}).people || [] : p.d.people;
    const all = first.concat(RF.more || []), last = all[all.length - 1];
    if (!last) return;
    b.disabled = true;
    const r = await api(`refs/people?before=${last.at}&before_uid=${last.uid}${RF.link ? '&link=' + RF.link : ''}${who}`);
    if (r.ok) { RF.more = (RF.more || []).concat(r.data.people); RF.moreLeft = r.data.more; }
    render(true);
  });
}
// Leaving the page: its message and open forms are not waiting there next time.
window.addEventListener('hashchange', () => { if (!/^#\/dashboard\/refs/.test(location.hash)) Object.assign(RF, { msg: '', make: false, edit: 0, sure: 0 }); });
