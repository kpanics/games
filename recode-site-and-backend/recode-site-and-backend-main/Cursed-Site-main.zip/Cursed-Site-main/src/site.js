// The music: it comes in softly on the first click or key anywhere (browsers let no sound start before that), fades
// out at the track's end and comes back in from its start, fades out and pauses while the tab is hidden, and the sound
// button fades it in and out and remembers the choice. The loudness goes through Web Audio (an <audio>'s volume cannot
// be changed on an iPhone), and the button's bars dance to the track's own spectrum.
(() => {
  const TRACK = '/music/air.m4a';
  const LOUD = 0.2;       // how loud it plays (of full)
  const COME_IN = 2.8;    // seconds to come in
  const GO_OUT = 1.4;     // seconds to go out (a click, a hidden tab)
  const EDGE = 3.2;       // seconds the track's end fades over before it starts again
  const KEY = 'cursed.sound';

  const button = document.getElementById('sound');
  const bars = button ? Array.from(button.querySelectorAll('i')) : [];
  const audio = new Audio(TRACK);
  audio.preload = 'none';

  let wanted = true;
  try { wanted = localStorage.getItem(KEY) !== 'off'; } catch (e) { /* no storage: the default */ }
  let ctx = null, gain = null, analyser = null, spectrum = null;
  let heard = false;      // a click or a key has come: sound may start
  let playing = false;
  let edging = false;
  let stopTimer = 0;

  function remember() {
    try { localStorage.setItem(KEY, wanted ? 'on' : 'off'); } catch (e) { /* not kept */ }
  }

  function setup() {
    if (ctx) return true;
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return false;
    ctx = new Ctx();
    const source = ctx.createMediaElementSource(audio);
    gain = ctx.createGain();
    gain.gain.value = 0;
    analyser = ctx.createAnalyser();
    analyser.fftSize = 128;
    analyser.smoothingTimeConstant = 0.78;
    spectrum = new Uint8Array(analyser.frequencyBinCount);
    source.connect(gain);
    gain.connect(analyser);
    analyser.connect(ctx.destination);
    return true;
  }

  function ramp(to, seconds) {
    const now = ctx.currentTime;
    const g = gain.gain;
    const from = g.value;
    g.cancelScheduledValues(now);
    g.setValueAtTime(from, now);
    g.linearRampToValueAtTime(to, now + Math.max(0.01, seconds));
  }

  async function start() {
    if (!setup()) return;
    clearTimeout(stopTimer);
    try {
      if (ctx.state !== 'running') await ctx.resume();
      await audio.play();
    } catch (e) {
      return;
    }
    playing = true;
    edging = false;
    ramp(LOUD, COME_IN);
    show();
    loop();
  }

  function stop() {
    playing = false;
    show();
    loop();
    if (!ctx) return;
    ramp(0, GO_OUT);
    clearTimeout(stopTimer);
    stopTimer = setTimeout(() => { if (!playing) audio.pause(); }, GO_OUT * 1000 + 80);
  }

  function show() {
    if (!button) return;
    button.classList.toggle('on', playing);
    button.setAttribute('aria-pressed', playing ? 'true' : 'false');
    document.body.dataset.sound = playing ? 'on' : 'off';
  }

  // The track's end fades out; it starts again from the beginning and comes back in.
  audio.addEventListener('timeupdate', () => {
    if (!playing || edging || !audio.duration) return;
    const left = audio.duration - audio.currentTime;
    if (left < EDGE) {
      edging = true;
      ramp(0, left);
    }
  });
  audio.addEventListener('ended', () => {
    if (!playing) return;
    audio.currentTime = 0;
    start();
  });

  // The first click or key anywhere lets it start (unless it was turned off before).
  function first() {
    if (heard) return;
    heard = true;
    ['pointerdown', 'keydown', 'touchstart'].forEach((t) => document.removeEventListener(t, first, true));
    if (wanted && !document.hidden) start();
  }
  ['pointerdown', 'keydown', 'touchstart'].forEach((t) => document.addEventListener(t, first, true));

  if (button) {
    button.addEventListener('click', (e) => {
      e.stopPropagation();
      heard = true;
      wanted = !playing;
      remember();
      if (wanted) start(); else stop();
    });
  }

  // A hidden tab: out and paused; back: in again, as it was wanted.
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      if (playing) { stop(); playing = false; wanted = true; }
    } else if (heard && wanted && !playing) {
      start();
    }
  });

  // The bars: the track's spectrum while it plays, easing down to rest when it stops.
  const BINS = [1, 3, 6, 10, 15];
  const levels = bars.map(() => 0);
  const low = bars.map(() => 1);
  const high = bars.map(() => 0);
  const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function frame() {
    if (analyser && playing) analyser.getByteFrequencyData(spectrum);
    const bands = spectrum ? spectrum.length : 0;
    bars.forEach((bar, i) => {
      let target = 0.18;
      if (playing && bands) {
        // The bass, the low middle, the middle, the high middle and the highs (bins of some 344 Hz), each bar within the
        // range its band has had lately (a floor and a ceiling drifting towards each other), so every bar moves.
        const raw = spectrum[Math.min(bands - 1, BINS[i % BINS.length])] / 255;
        low[i] = Math.min(raw, low[i] + 0.004);
        high[i] = Math.max(raw, high[i] - 0.004);
        const span = Math.max(0.08, high[i] - low[i]);
        target = reduce ? 0.55 : 0.18 + 0.82 * Math.max(0, Math.min(1, (raw - low[i]) / span));
      }
      levels[i] += (target - levels[i]) * (target > levels[i] ? 0.35 : 0.12);
      bar.style.transform = `scaleY(${levels[i].toFixed(3)})`;
    });
    // At rest (no music, the bars down): no more frames until the music comes back.
    if (!playing && levels.every((l) => Math.abs(l - 0.18) < 0.002)) { looping = false; return; }
    requestAnimationFrame(frame);
  }
  let looping = false;
  function loop() {
    if (looping || !bars.length) return;
    looping = true;
    requestAnimationFrame(frame);
  }
  loop();
  show();
})();
