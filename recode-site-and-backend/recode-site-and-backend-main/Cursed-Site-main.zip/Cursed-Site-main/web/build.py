"""build.py: the site for cursedclient.xyz (10.10.2026: the Recode shell over the old site's screens) -> dist/.

src/index.html gets its CSS inline (the fonts, the old site's CSS, the shell's); the scripts stay files, loaded in order:
shaders.js (the world of Recode's menu), world.js (drawing it), app.js (every screen's work, from the old site), shell.js
(the menu, the window, the boot). Each script's address carries the build's mark, so a new build is fetched at once.
Deploy: tools/deploy.sh (copies dist/ over /var/www/cursedclient, keeping what only lives there)."""
import hashlib
import pathlib
import shutil

here = pathlib.Path(__file__).parent
src, dist = here / "src", here / "dist"
shutil.rmtree(dist, ignore_errors=True)
dist.mkdir()
scripts = ["shaders.js", "world.js", "app.js", "news.js", "tops.js", "pccheck.js", "figure.js", "wardrobe.js", "shell.js", "income.js", "legal-dock.js"]
mark = hashlib.sha256(b"".join((src / s).read_bytes() for s in scripts) + (src / "recode.css").read_bytes()).hexdigest()[:10]
css = "\n".join((src / f).read_text(encoding="utf-8") for f in ["fonts/fonts.css", "legacy.css", "recode.css", "wardrobe.css", "news.css", "tops.css", "income.css"])
page = (src / "index.html").read_text(encoding="utf-8").replace("/*%%CSS%%*/", css).replace("%%V%%", mark)
assert "%%" not in page
(dist / "index.html").write_text(page, encoding="utf-8", newline="\n")
for s in scripts:
    shutil.copy(src / s, dist / s)
shutil.copytree(src / "legal", dist / "legal")
for d in ["fonts", "img", "music"]:
    shutil.copytree(src / d, dist / d, ignore=shutil.ignore_patterns("*.css"))
shutil.copy(src / "fonts/fonts.css", dist / "fonts/fonts.css")
print("dist:", mark, sum(f.stat().st_size for f in dist.rglob("*") if f.is_file()) // 1024, "KB")
