// node devserve.mjs <root> [port] — the site from a folder; /api and /media from the staging copy (an SSH tunnel to
// 127.0.0.1:8088 on the server, kept up here); every other file it doesn't have, read from the live site (GET only).
import http from "node:http";
import https from "node:https";
import { spawn } from "node:child_process";
import { createReadStream, statSync } from "node:fs";
import { join, extname, normalize } from "node:path";

const root = process.argv[2], port = +(process.argv[3] || 8791), TUN = 18088;
const types = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json",
  ".png": "image/png", ".gif": "image/gif", ".jpg": "image/jpeg", ".webp": "image/webp", ".svg": "image/svg+xml", ".ico": "image/x-icon",
  ".woff2": "font/woff2", ".ttf": "font/ttf", ".mp3": "audio/mpeg", ".m4a": "audio/mp4" };
const tunnel = spawn("ssh", ["-N", "-o", "ExitOnForwardFailure=yes", "-o", "ServerAliveInterval=20", "-L", `${TUN}:127.0.0.1:8088`, "Cursed"], { stdio: "ignore" });
process.on("exit", () => tunnel.kill());
for (const s of ["SIGINT", "SIGTERM"]) process.on(s, () => process.exit(0));

http.createServer((req, res) => {
  const url = new URL(req.url, "http://x");
  const path = decodeURIComponent(url.pathname);
  if (path.startsWith("/api/") || path.startsWith("/media/")) {
    const headers = { ...req.headers, host: "127.0.0.1:8088" };
    const up = http.request({ host: "127.0.0.1", port: TUN, path: req.url, method: req.method, headers }, (r) => { res.writeHead(r.statusCode, r.headers); r.pipe(res); });
    up.on("error", () => { res.writeHead(502); res.end("tunnel"); });
    req.pipe(up);
    return;
  }
  let file = normalize(join(root, path === "/" ? "index.html" : path));
  if (!file.startsWith(normalize(root))) { res.writeHead(403); res.end(); return; }
  try {
    if (statSync(file).isFile()) {
      res.writeHead(200, { "content-type": types[extname(file)] || "application/octet-stream", "cache-control": "no-store" });
      createReadStream(file).pipe(res);
      return;
    }
  } catch (e) { /* not here: the live site has it */ }
  if (req.method !== "GET") { res.writeHead(404); res.end(); return; }
  https.get({ host: "cursedclient.xyz", path: req.url, headers: { "user-agent": "cursed-devserve" } }, (r) => { res.writeHead(r.statusCode, r.headers); r.pipe(res); })
    .on("error", () => { res.writeHead(502); res.end(); });
}).listen(port, "127.0.0.1", () => console.log(`http://127.0.0.1:${port} <- ${root}`));
