"""One-off (10.10.2026): app.js's screens hand out their handlers again after every drawing. A screen now changes in
place (shell.js morphs it), so an element kept from the last drawing would gather a second handler, a third...: every
`on(...)` and the few direct addEventListener calls of the wiring go through bindOnce (shell.js), which keeps one per
element, event and place, the newest."""
import re
import sys

p = sys.argv[1]
s = open(p, encoding="utf-8").read()
n = 0


def tag(m):
    global n
    n += 1
    root = m.group(1)
    return f"const on = (sel, ev, fn) => {root}.querySelectorAll(sel).forEach((el) => bindOnce(el, ev, 'w{n}|' + sel, (e) => fn(el, e)));"


s, k = re.subn(r"const on = \(sel, ev, fn\) => (\$app|root)\.querySelectorAll\(sel\)\.forEach\(\(el\) => el\.addEventListener\(ev, \(e\) => fn\(el, e\)\)\);", tag, s)
assert k == 10, k

reps = [
    ("['dragenter', 'dragover'].forEach((t) => drop.addEventListener(t, (ev) => { ev.preventDefault(); drop.classList.add('over'); }));",
     "['dragenter', 'dragover'].forEach((t) => bindOnce(drop, t, 'up-a', (ev) => { ev.preventDefault(); drop.classList.add('over'); }));"),
    ("['dragleave', 'drop'].forEach((t) => drop.addEventListener(t, () => drop.classList.remove('over')));",
     "['dragleave', 'drop'].forEach((t) => bindOnce(drop, t, 'up-b', () => drop.classList.remove('over')));"),
    ("drop.addEventListener('drop', (ev) => { ev.preventDefault(); const f = ev.dataTransfer.files[0]; if (f) upSend(f); });",
     "bindOnce(drop, 'drop', 'up-c', (ev) => { ev.preventDefault(); const f = ev.dataTransfer.files[0]; if (f) upSend(f); });"),
    ("  login.addEventListener('input', () => {", "  bindOnce(login, 'input', 'reg', () => {"),
    ("  pass.addEventListener('input', () => {", "  bindOnce(pass, 'input', 'reg', () => {"),
    ("  [terms, email].forEach((el) => el.addEventListener('input', check));", "  [terms, email].forEach((el) => bindOnce(el, 'input', 'reg', check));"),
    ("    box.addEventListener('scroll', () => { ch.scroll = box.scrollTop;", "    bindOnce(box, 'scroll', 'fr', () => { ch.scroll = box.scrollTop;"),
    ("    box.addEventListener('dragover', (e) => { e.preventDefault(); box.classList.add('over'); });", "    bindOnce(box, 'dragover', 'fr', (e) => { e.preventDefault(); box.classList.add('over'); });"),
    ("    box.addEventListener('dragleave', () => box.classList.remove('over'));", "    bindOnce(box, 'dragleave', 'fr', () => box.classList.remove('over'));"),
    ("    box.addEventListener('drop', (e) => { e.preventDefault(); box.classList.remove('over');", "    bindOnce(box, 'drop', 'fr', (e) => { e.preventDefault(); box.classList.remove('over');"),
    ("  plot.addEventListener('pointermove', (e) => {", "  bindOnce(plot, 'pointermove', 'rf', (e) => {"),
    ("  plot.addEventListener('pointerleave', () => show(null));", "  bindOnce(plot, 'pointerleave', 'rf', () => show(null));"),
]
for a, b in reps:
    c = s.count(a)
    assert c == 1, (a[:70], c)
    s = s.replace(a, b)
open(p, "w", encoding="utf-8").write(s)
print("on helpers:", k, "direct:", len(reps))
