// node wshot.mjs <outdir> <w>x<h> "name=/route?query;JS|…" [dpr] — frames of the site on the dev server (devserve.mjs), Edge
// without a window and without sound. SESSION=<token> signs in (the staging copy's cookie). query: wait=<ms> after the page
// says it's ready (window.__ready, or 3 s), post=<ms> after the JS. Errors of the page are printed.
import { spawn } from "node:child_process";
import { writeFileSync, mkdirSync, readFileSync } from "node:fs";
const [outdir, size, list, dprArg = "1"] = process.argv.slice(2);
const [W, H] = size.split("x").map(Number);
const BASE = process.env.BASE || "http://127.0.0.1:8791";
const EDGE = "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe";
const port = 9400 + Math.floor(Math.random() * 400);
mkdirSync(outdir, { recursive: true });
const prof = process.env.TEMP + "/cursed-wshot-" + port;
const edge = spawn(EDGE, ["--headless=new", `--remote-debugging-port=${port}`, `--user-data-dir=${prof}`, "--use-angle=d3d11", "--enable-gpu", "--ignore-gpu-blocklist",
  "--hide-scrollbars", "--mute-audio", "--no-first-run", `--window-size=${W},${H}`, "about:blank"], { stdio: "ignore" });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let tabs;
for (let i = 0; i < 60; i++) { try { tabs = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json(); if (tabs.find((x) => x.type === "page")) break; } catch {} await sleep(250); }
const pg = tabs.find((x) => x.type === "page");
const ws = new WebSocket(pg.webSocketDebuggerUrl);
await new Promise((r) => ws.addEventListener("open", r));
let id = 0, errors = 0; const wait = new Map();
ws.addEventListener("message", (ev) => {
  const m = JSON.parse(ev.data);
  if (m.id && wait.has(m.id)) { wait.get(m.id)(m); wait.delete(m.id); }
  else if (m.method === "Runtime.consoleAPICalled" && (m.params.type === "error" || m.params.type === "warning")) { errors++; console.log("console." + m.params.type + ":", m.params.args.map((a) => a.value ?? a.description ?? "").join(" ").slice(0, 700)); }
  else if (m.method === "Runtime.exceptionThrown") { errors++; console.log("EXCEPTION:", JSON.stringify(m.params.exceptionDetails).slice(0, 900)); }
  else if (m.method === "Network.loadingFailed" && !/net::ERR_ABORTED/.test(m.params.errorText)) { console.log("LOAD FAILED:", m.params.errorText); }
});
const send = (method, params = {}) => new Promise((r) => { const i = ++id; wait.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
await send("Runtime.enable"); await send("Page.enable"); await send("Network.enable");
await send("Emulation.setDeviceMetricsOverride", { width: W, height: H, deviceScaleFactor: +dprArg, mobile: W < 700 });
if (process.env.SESSION) await send("Network.setCookie", { name: "cursed_session", value: process.env.SESSION, url: BASE + "/api/", path: "/api", httpOnly: true });
if (process.env.LANG_SITE) await send("Page.addScriptToEvaluateOnNewDocument", { source: `try{localStorage.setItem('cursed.lang','${process.env.LANG_SITE}')}catch(e){}` });
for (const item of list.split("|")) {
  const sc = item.indexOf(";"), head = sc < 0 ? item : item.slice(0, sc), js0 = sc < 0 ? "" : item.slice(sc + 1);
  const js = js0.startsWith("@") ? readFileSync(js0.slice(1), "utf8") : js0;  // ";@file.js": the script from a file
  const cut = head.indexOf("="), name = head.slice(0, cut), rest = head.slice(cut + 1);
  const qi = rest.indexOf("?"), route = qi < 0 ? rest : rest.slice(0, qi), q = new URLSearchParams(qi < 0 ? "" : rest.slice(qi + 1));
  const nonce = "n" + Math.random().toString(36).slice(2, 8);
  await send("Page.navigate", { url: `${BASE}/?${nonce}=1${q.has("nointro") ? "&nointro" : ""}#${route}` });
  let ok = false;
  for (let i = 0; i < 120; i++) { await sleep(250); const r = await send("Runtime.evaluate", { expression: `location.search.includes("${nonce}") && document.readyState === "complete" && (window.__ready === true || window.__ready === undefined)` }); if (r.result?.result?.value) { ok = true; break; } }
  await sleep(+(q.get("wait") || 2500));
  if (js) { const ev = await send("Runtime.evaluate", { expression: js, awaitPromise: true }); if (ev.result?.exceptionDetails) console.log("EVAL FAILED:", JSON.stringify(ev.result.exceptionDetails).slice(0, 400)); await sleep(+(q.get("post") || 1200)); }
  const shot = await send("Page.captureScreenshot", { format: "png", captureBeyondViewport: false });
  writeFileSync(`${outdir}/${name}.png`, Buffer.from(shot.result.data, "base64"));
  console.log(ok ? "ok" : "NOT READY", name);
}
console.log("errors:", errors);
ws.close(); edge.kill();
