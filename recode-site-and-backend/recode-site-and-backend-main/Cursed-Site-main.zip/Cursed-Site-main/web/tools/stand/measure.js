const q = (sel) => document.querySelectorAll(sel);
const text = (sel) => [...q(sel)].map((n) => n.textContent.trim());
console.warn('MEASURE ' + JSON.stringify({
  cols: [...document.querySelectorAll('.col')].map((c, i) => {
    const t = c.querySelector('.wt-top'), a = c.querySelector('.wt-at'), r = c.querySelector('.wt-row');
    const tr = r.getBoundingClientRect();
    return {
      col: i,
      topW: Math.round(t.getBoundingClientRect().width),
      rowW: Math.round(tr.width),
      dateGap: Math.round(tr.right - a.getBoundingClientRect().right),
      ml: Math.round(parseFloat(getComputedStyle(a).marginLeft)),
      ai: getComputedStyle(r).alignItems,
    };
  }),
  seenLeft: q('.col.old .wt-seen').length,
  seenRight: q('.col:not(.old) .wt-seen').length,
  zurnal: text('.wt-seen').filter((s) => s.startsWith('Журнал')).length,
  vmFound: text('.wt-seen').filter((s) => s.includes('found: word virtual machine')).length,
  tid12: text('.wt-seen').filter((s) => s.includes('tid=12')).length,
  toolDbg: text('.wt-seen').filter((s) => s.includes('tool: x64dbg')).length,
  whyInSeen: text('.wt-seen').filter((s) => s.includes('virtual machine')).length,
  banSeen: [...q('.col:not(.old) .wt-row')].filter((r) => r.textContent.includes('Забанен правилами')).map((r) => (r.querySelector('.wt-seen') || { textContent: '(none)' }).textContent.trim()),
  kindsLeft: text('.col.old .wt-top > span:first-of-type'),
  kindsRight: text('.col:not(.old) .wt-top > span:first-of-type'),
  strayDot: text('.col.old p.ash').filter((s) => s.startsWith('·')).length,
}));
