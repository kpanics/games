#!/usr/bin/env python3
# split_emotes.py (the site night 23.10): each emote's moves out of the pack's big actions files into one small text file
# of its own (/var/lib/cursed-cosmetics/e/<action>.txt, the same lines: an/ao/ag/kf), so that the site's wardrobe fetches
# only the emote played (the pack's actions.bobj alone is 16 MB). Run again after a new pack.
import json, os, sys
CAT = '/var/lib/cursed/cosmetics/catalog.json'
F = '/var/lib/cursed-cosmetics/f'
OUT = '/var/lib/cursed-cosmetics/e'
cat = json.load(open(CAT, encoding='utf-8'))
files = cat['emotes']['files']
os.makedirs(OUT, exist_ok=True)
done = 0
for key, sha in files.items():
    name = key.rsplit('/', 1)[-1]
    if not (name.startswith('actions') and name.endswith('.bobj')):
        continue
    cur, buf = None, []
    def flush():
        global done
        if cur and buf:
            safe = ''.join(ch for ch in cur if ch.isalnum() or ch in '_-')
            with open(os.path.join(OUT, safe + '.txt'), 'w', encoding='utf-8', newline='\n') as f:
                f.write('\n'.join(buf) + '\n')
            done += 1
    for line in open(os.path.join(F, sha[:2], sha), encoding='utf-8', errors='replace'):
        line = line.rstrip('\r\n')
        if line.startswith('an '):
            flush()
            cur, buf = line[3:].strip(), [line]
        elif cur is not None and line[:3] in ('ao ', 'ag ', 'kf '):
            buf.append(line)
    flush()
print('actions written:', done)
# The bodies (wide, slim) and the props, beside the moves; and which props file holds which prop.
import shutil
for key, sha in files.items():
    name = key.rsplit('/', 1)[-1]
    out = {'default.bobj': 'body-wide.txt', 'slim.bobj': 'body-slim.txt'}.get(name) or (name.replace('.bobj', '.txt') if name.startswith('props') and '_simple' not in name else None)
    if out:
        shutil.copy(os.path.join(F, sha[:2], sha), os.path.join(OUT, out))
index = {}
for f in sorted(os.listdir(OUT)):
    if f.startswith('props'):
        for line in open(os.path.join(OUT, f), encoding='utf-8', errors='replace'):
            if line.startswith('o '):
                index.setdefault(line[2:].strip(), f)
json.dump({'props': index}, open(os.path.join(OUT, 'index.json'), 'w'))
os.system('chmod -R a+rX ' + OUT)
print('props indexed:', len(index))
