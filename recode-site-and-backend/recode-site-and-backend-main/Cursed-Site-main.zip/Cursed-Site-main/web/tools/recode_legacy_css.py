"""One-off (10.10.2026): the old site's CSS speaks Cursed — small labels in the display face, capitals, spaced; marks as
cream squares. In Recode the display face is only for big names; labels are Geist, quiet, as the modules' menu has
them; marks are dots. Every rule of legacy.css is read: a display font at 18 px or less becomes the text face (bold 700
to 600, no capitals, no spacing); a square mark (width = height, 9 px or less, with a background) becomes round."""
import re
import sys

p = sys.argv[1]
css = open(p, encoding="utf-8").read()
changed = {"labels": 0, "dots": 0}


def size_of(decls):
    m = re.search(r"font:\s*(?:\d{3}\s+)?(?:italic\s+)?([\d.]+)px", decls) or re.search(r"font-size:\s*([\d.]+)px", decls)
    return float(m.group(1)) if m else None


def fix(m):
    sel, decls = m.group(1), m.group(2)
    if "var(--display)" in decls:
        s = size_of(decls)
        if s is not None and s <= 18:
            decls = decls.replace("var(--display)", "var(--text)")
            decls = re.sub(r"text-transform:\s*uppercase;?\s*", "", decls)
            decls = re.sub(r"letter-spacing:\s*[\d.]+em;?\s*", "letter-spacing: 0; ", decls)
            decls = re.sub(r"font:\s*700\b", "font: 600", decls)
            changed["labels"] += 1
    w = re.search(r"(?<![-\w])width:\s*(\d+)px", decls)
    h = re.search(r"(?<![-\w])height:\s*(\d+)px", decls)
    if w and h and w.group(1) == h.group(1) and int(w.group(1)) <= 9 and re.search(r"background(-color)?:", decls) and "border-radius" not in decls and "::after" not in sel:
        decls = decls.rstrip().rstrip(";") + "; border-radius: 50%; "
        changed["dots"] += 1
    return sel + "{" + decls + "}"


css = re.sub(r"([^{}@][^{}]*)\{([^{}]*)\}", fix, css)
open(p, "w", encoding="utf-8").write(css)
print(changed)
