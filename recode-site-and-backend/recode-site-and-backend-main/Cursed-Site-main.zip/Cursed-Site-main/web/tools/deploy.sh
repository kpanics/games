#!/bin/sh
# deploy.sh: dist/ onto cursedclient.xyz. What lives only on the server (the FreeKassa check file, the icons, the emoji,
# the old fonts and music, .well-known) stays; the site's own files are replaced. The site before is kept whole first:
# /root/site.before-<time>.tar.gz (to roll back: tar -xzf it over /var/www/cursedclient).
set -e
cd "$(dirname "$0")/.."
# Built here, not taken as it lies: a dist/ older than the sources is how one session's page went
# out without another's changes. The mark in the page is then this build's, not a leftover one's.
python build.py
[ -f dist/index.html ] || { echo "build failed"; exit 1; }
STAMP=$(date +%Y%m%d-%H%M%S)
tar -czf /tmp/site-dist.tar.gz -C dist .
scp -q /tmp/site-dist.tar.gz Cursed:/tmp/site-dist.tar.gz
ssh Cursed "set -e
  tar -czf /root/site.before-$STAMP.tar.gz -C /var/www/cursedclient .
  mkdir -p /tmp/site-new && rm -rf /tmp/site-new/* && tar -xzf /tmp/site-dist.tar.gz -C /tmp/site-new
  cp -r /tmp/site-new/. /var/www/cursedclient/
  find /var/www/cursedclient -type d -exec chmod 755 {} + && find /var/www/cursedclient -type f -exec chmod 644 {} +
  rm -rf /tmp/site-new /tmp/site-dist.tar.gz
  echo deployed; echo backup: /root/site.before-$STAMP.tar.gz"
