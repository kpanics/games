// stand_watch.mjs: the rows of her «Подозрительные» list, drawn as the prod draws them now beside
// the ones with the note's detail under the line. The right-hand column runs the very wtWhy/wtSeen
// taken out of web/src/shell.js over the shapes a flag's detail really has — so what is measured is
// what ships. Writes web/tools/stand/index.html; shoot it with wshot.mjs over any static server.
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const src = join(here, "..", "src");
const shell = readFileSync(join(src, "shell.js"), "utf8");
const app = readFileSync(join(src, "app.js"), "utf8");
const css = ["fonts/fonts.css", "legacy.css", "recode.css"].map((f) => readFileSync(join(src, f), "utf8")).join("\n");

/** Everything from `from` up to the first following line that is exactly `};` or `}` at column 0. */
function span(text, from) {
  const at = text.indexOf(from);
  if (at < 0) throw new Error("not found: " + from.slice(0, 40));
  const end = text.indexOf("\n};", at);
  const end2 = text.indexOf("\n}", at);
  const stop = end >= 0 && (end2 < 0 || end < end2) ? end + 3 : end2 + 2;
  return text.slice(at, stop);
}

const WT_KIND = span(shell, "const WT_KIND = {");
const wtWhy = span(shell, "const wtWhy = (x) => {");
const wtSeen = span(shell, "const wtSeen = (x) => {");
const escSrc = span(app, "const esc = (s) => ").split("\n")[0];
const pluralSrc = span(app, "function plural(n, one, few, many)");

// The helpers the row drawing uses.
const helpers = `
let LANG = 'ru';
${escSrc}
${pluralSrc}
const L = (en, ru) => (LANG === 'ru' ? ru : en);
const rkDate = (t) => new Date(t * 1000).toLocaleString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
const rkDay = (t) => new Date(t * 1000).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
`;

// What the prod draws today: the same wtWhy it has always had, and no line under it.
const OLD_WHY = `
const wtWhy = (x) => {
  const d = x.detail || {}, times = d.times > 1 ? \` · \${L(\`\${d.times} times\`, \`\${d.times} \${plural(d.times, 'раз', 'раза', 'раз')}\`)}\` : '';
  if (x.kind === 'autoban') return esc(d.reason || '') + times;
  if (x.kind === 'resets') return L(\`\${d.week} in a week\`, \`\${d.week} за неделю\`) + times;
  if (x.kind === 'tpm-changed') return L('A TPM reset in the BIOS does this honestly; a spoofer too.', 'Так бывает честно (сброс TPM в BIOS) — и при подмене.') + times;
  if (x.kind === 'tpm-off') return L('A BIOS reset does this honestly; so does one who switches it off to get round a ban (a ban on the computer stands all the same).', 'Так бывает честно (сброс BIOS) — и когда выключают нарочно, чтобы обойти бан (бан на этот ПК всё равно действует).') + times;
  return times.slice(3);
};
`;
// …and the kinds as prod knows them: `protect` and the rest fall through to the raw kind.
const OLD_KIND = `
const WT_KIND = {
  autoban: ['Banned by the rules', 'Забанен правилами'],
  'tpm-changed': ['The TPM changed, the rest the same', 'Сменился TPM, остальное железо то же'],
  'tpm-off': ['The TPM switched off, the rest the same', 'TPM выключен, остальное железо то же'],
  'second-game': ['Tried a second game at once', 'Пытался запустить вторую игру'],
  resets: ['Frees the computer often', 'Часто сбрасывает привязку ПК'],
};
`;

// The row of her list as viewWatch draws it — the same lines, the same classes.
const ROW_FN = `
const ROW = (x, seen) => {
  const open = !x.verdict;
  const st = x.kind === 'autoban' ? ''
    : x.verdict === 'ok' ? \`<span class="st">\${L('all right', 'нормально')}\${x.by ? ' · ' + esc(x.by) : ''}</span>\`
      : x.verdict === 'ban' ? \`<span class="st cream">\${L('banned', 'забанен')}\${x.by ? ' · ' + esc(x.by) : ''}</span>\` : '';
  return \`<div class="wt-row \${open ? 'wt-open' : ''}">
      <div class="wt-top"><a class="wt-who" href="#" translate="no">\${esc(x.login)}</a>
        <span>\${L(...(WT_KIND[x.kind] || [x.kind, x.kind]))}</span>\${st}<span class="ash wt-at">\${rkDate(x.at)}</span></div>
      <p class="ash">\${wtWhy(x)}\${x.recode && x.recode.active ? \` · Recode \${x.recode.forever ? L('forever', 'навсегда') : L('until ', 'до ') + rkDay(x.recode.until)}\` : ''}\${x.banned && x.kind !== 'autoban' ? ' · ' + L('banned now', 'сейчас в бане') : ''}</p>
      \${seen ? wtSeen(x) : ''}
      \${open ? \`<div class="wt-acts"><button class="r-btn r-sm">\${L('All right', 'Нормально')}</button>
        <input class="in" placeholder="\${L('The ban’s reason', 'Причина бана')}">
        <input class="in wt-len" placeholder="\${L('7d · empty: for good', '7d · пусто: навсегда')}">
        <button class="r-btn r-sm r-pri">\${L('Ban', 'Бан')}</button></div>\` : ''}
    </div>\`;
};
return ROW;`;

/** The shipped functions, run here: the page is drawn by what actually ships. */
function rowWith(kindSrc, whySrc, seenSrc) {
  return new Function(`${helpers}\n${kindSrc}\n${whySrc}\n${seenSrc}\n${ROW_FN}`)();
}
const ROW = rowWith(WT_KIND, wtWhy, wtSeen);
const ROW_OLD = rowWith(OLD_KIND, OLD_WHY, "const wtSeen = (x) => '';");
const esc = new Function(`${helpers}\nreturn esc;`)();
const L = new Function(`${helpers}\nreturn L;`)();

// The shapes a flag's detail really has: the ones on the live list today, and the ones the note
// carries once the stub writes what it saw under the `why:` line.
const at = 1792583146;
const FIX = [
  ['autoban от руки в памяти — как в проде сейчас (crate, 20.10)', {
    login: 'crate', kind: 'autoban', at, verdict: 'ban', by: 'Lunuca',
    detail: { ban: 5, kind: 'inject', reason: 'Рука в памяти игры — inject (a hand was put on the game’s own memory — a thread 0x7ffa5f10a9e4 with no module, a write-class hand was already on us)', times: 1 },
  }],
  ['autoban от защиты — та же строка плюс что видела', {
    login: 'crate', kind: 'autoban', at, verdict: 'ban', by: 'Lunuca',
    detail: {
      ban: 5, reason: 'Инструменты разбора игры — повторное обнаружение (2 за неделю)', build: 47, file: '9-1792528944-protect-75cf32.log', days: 2, times: 1,
      why: 'this machine is a virtual machine’s guest',
      found: 'found: word virtual machine fw: Microsoft Corporation Virtual Machine dsk: Msft Virtual Disk tools: VirtualBox Guest Additions keys: HKLM\\SOFTWARE\\Microsoft\\Virtual Machine\\Guest\\Parameters hv: HypervisorPresent=False',
    },
  }],
  ['protect — nikiytiki как будет после долива из заметки (why есть, found в заметке нет)', {
    login: 'nikiytiki', kind: 'protect', at, banned: true,
    detail: { build: 47, file: '1354-1792583146-protect-75cf32.log', days: 1, times: 3, why: "this machine is a virtual machine's guest" },
  }],
  ['protect — why и найденное под ним', {
    login: 'nikiytiki', kind: 'protect', at, banned: true,
    detail: {
      build: 47, file: '1354-1792583146-protect-75cf32.log', days: 1, times: 2,
      why: 'this machine is a virtual machine’s guest',
      found: 'found: word virtual machine fw: Microsoft Corporation Virtual Machine dsk: Msft Virtual Disk tools: VirtualBox Guest Additions keys: HKLM\\SOFTWARE\\Microsoft\\Virtual Machine\\Guest\\Parameters hv: HypervisorPresent=False',
    },
  }],
  ['protect — нить без модуля: тот самый разбор crate', {
    login: 'crate', kind: 'protect', at, recode: { active: true, forever: true },
    detail: {
      build: 47, file: '9-1792529333-protect-aa11bb.log', days: 1, times: 1,
      why: 'a thread 0x7ffa5f10a9e4 with no module, a write-class hand was already on us',
      found: 'found: tid=12 start=0x7ffa5f10a9e4 mem=private prot=0x40 base=0x7ffa5f100000 where=-',
    },
  }],
  ['touch-unverified — note as it came (старый вид detail)', {
    login: 'liar', kind: 'touch-unverified', at,
    detail: { build: 47, file: 'touch: patch\nwhy: says the game\nfound: tid=7 mem=private where=-\n', times: 1 },
  }],
  ['touch-unverified — why и найденное', {
    login: 'liar', kind: 'touch-unverified', at,
    detail: { build: 47, file: 'touch: patch\nwhy: says the game\nfound: tid=7 mem=private where=-\n', why: 'says the game', found: 'found: tid=7 mem=private where=-', times: 1 },
  }],
  ['sight — что было рядом с игрой', {
    login: 'watcher', kind: 'sight', at,
    detail: { build: 6, score: 70, sights: [{ kind: 'tool', name: 'x64dbg' }, { kind: 'parent', name: 'python.exe' }], times: 1 },
  }],
  ['resets — как было, не тронуто', {
    login: 'resetter', kind: 'resets', at,
    detail: { week: 3, times: 1 },
  }],
];

// Both columns are drawn by the same row template; only the functions behind it differ. The
// generator runs the shipped ones, so the page on disk is the truth of shell.js as it stands.
const drawColumn = (row, seen) => FIX.map(([label, x]) => `<h3 class="lab">${esc(label)}</h3>
<div class="rows wt-list">${row(x, seen)}</div>`).join("\n");

const oldRows = drawColumn(ROW_OLD, false);
const newRows = drawColumn(ROW, true);

const page = `<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Подозрительные — строки</title>
<style>${css}
body { margin: 0; padding: 18px; background: var(--bg, #0e0f12); color: var(--text, #e8e8ea); font: 14px/1.5 Geist, system-ui, sans-serif; }
h2 { font-size: 15px; margin: 0 0 10px; font-weight: 600; }
h3.lab { font-size: 12px; font-weight: 600; color: var(--ash, #8a8d95); margin: 18px 0 6px; letter-spacing: .02em; }
.cols { display: grid; grid-template-columns: 1fr 1fr; gap: 22px; align-items: start; }
/* .r-win is the whole window in the site; here only its rules over the rows are wanted, not its layout.
   Relative, not static, so the window's sheen stays its own backdrop instead of painting the page. */
.cols .r-win { position: relative; left: auto; top: auto; transform: none; width: auto; height: auto; display: block; grid-template-columns: none; overflow: visible; border-radius: 0; }
.cols .r-win::after { display: none; }
/* the leak prod has today: legacy's .rows > * leaves align-items: baseline on the row, so the date
   never reaches the right edge. Only the left column keeps it, so «Было» is what she sees now. */
.col.old .wt-list > .wt-row { align-items: baseline; }
.rows.wt-list { display: flex; flex-direction: column; gap: 10px; }
</style></head>
<body>
<div class="cols">
  <div class="col old"><h2>Было — так прод рисует список сейчас</h2><div class="r-win"><div class="block">${oldRows}</div></div></div>
  <div class="col"><h2>Стало — подробности под строкой, дата справа</h2><div class="r-win"><div class="block">${newRows}</div></div></div>
</div>
</body></html>`;

const out = join(here, "stand");
mkdirSync(out, { recursive: true });
writeFileSync(join(out, "index.html"), page, "utf8");
console.log("stand:", join(out, "index.html"), page.length, "bytes");
