"""One-off (10.10.2026): every class the new shell draws gets the r- prefix, so the old site's CSS (which owns .in, .hero,
.menu, .big, .bar, .who …) never touches the shell, and the shell's CSS never touches the old screens."""
import re
import sys

p = sys.argv[1]
s = open(p, encoding="utf-8").read()
MAP = {
    'item': 'r-item', 'fl': 'r-fl', 'rv': 'r-rv', 'main': 'r-main', 'quit': 'r-quit', 'mid': 'r-mid', 'dis': 'r-dis', 'shift': 'r-shift', 'mask': 'r-mask', 'in': 'r-in', 'rl': 'r-rl', 'hl': 'r-hl', 'tag': 'r-tag',
    'last': 'r-last', 'cap': 'r-cap', 'srv': 'r-srv', 'hint': 'r-hint', 'say': 'r-say', 'field': 'r-field', 'lab': 'r-lab', 'fh': 'r-fh', 'u': 'r-u', 'uf': 'r-uf', 'err': 'r-err',
    'agree': 'r-agree', 'box': 'r-box', 'term': 'r-term', 'wd': 'r-wd', 'pr': 'r-pr', 'pd': 'r-pd', 'cd': 'r-cd', 'unit': 'r-unit', 'custom': 'r-custom', 'sel': 'r-sel',
    'check': 'r-check', 'big': 'r-bigp', 'per': 'r-per', 'krow': 'r-krow', 'k': 'r-k', 'opts': 'r-opts', 'opt': 'r-opt', 'acct': 'r-acct', 'cur': 'r-cur',
    'menu': 'r-menu', 'terms': 'r-terms', 'on': 'r-on',
    'who': 'r-who', 'nick': 'r-nick', 'alts': 'r-alts', 'alt': 'r-alt', 'add': 'r-add', 'nb': 'r-nb', 'n': 'r-n', 'disc': 'r-disc', 'track': 'r-track', 'artist': 'r-artist', 'bar': 'r-bar', 'ctl': 'r-ctl', 'btns': 'r-btns',
    'build': 'r-build', 'newsbtn': 'r-link', 'lng': 'r-lng',
    'side': 'r-side', 'brand': 'r-brand', 'lg': 'r-lg', 'grp': 'r-grp', 'sp': 'r-sp', 'side-foot': 'r-side-foot', 'side-row': 'r-side-row', 'me': 'r-me', 'out': 'r-out',
    'wh': 'r-wh', 'wt': 'r-wt', 'x': 'r-x', 'btn': 'r-btn', 'pri': 'r-pri', 'sm': 'r-sm', 'ghost': 'r-ghost', 'pill': 'r-pill', 'hero': 'r-hero', 'tile': 'r-tile', 'g3': 'r-g3',
}


def fix(m):
    toks = m.group(2).split(" ")
    return m.group(1) + " ".join(t if (not t or "${" in t) else MAP.get(t, t) for t in toks) + m.group(3)



reps = [
    ("closest('.fl')", "closest('.r-fl')"), ("closest('.menu')", "closest('.r-menu')"), ("closest('.item')", "closest('.r-item')"), ("closest('.term')", "closest('.r-term')"),
    ("querySelectorAll('.term')", "querySelectorAll('.r-term')"), ("querySelector('.term.sel')", "querySelector('.r-term.r-sel')"),
    ("querySelector('.check .last .srv')", "querySelector('.r-check .r-last .r-srv')"),
    ("toggle('sel', on)", "toggle('r-sel', on)"), ("classList.contains('dis')", "classList.contains('r-dis')"), ("toggle('dis', !BUY.agree)", "toggle('r-dis', !BUY.agree)"),
    ("classList.remove('pulse')", "classList.remove('r-pulse')"), ("classList.add('pulse')", "classList.add('r-pulse')"),
    ("classList.toggle('on', x === m)", "classList.toggle('r-on', x === m)"), ("ag.classList.toggle('on', BUY.agree)", "ag.classList.toggle('r-on', BUY.agree)"),
    ("f.classList.remove('gone'); f.classList.add('on');", "f.classList.remove('r-gone'); f.classList.add('r-on');"), ("box.classList.add('focus')", "box.classList.add('r-focus')"),
    ("f.classList.remove('on'); f.classList.add('gone');", "f.classList.remove('r-on'); f.classList.add('r-gone');"), ("box.classList.remove('focus')", "box.classList.remove('r-focus')"),
    ("if (!f.classList.contains('on')) f.classList.remove('gone');", "if (!f.classList.contains('r-on')) f.classList.remove('r-gone');"),
    ("el.classList.add('out');", "el.classList.add('r-out');"),
    ("el.classList.remove('out'); el.classList.add('below'); void el.offsetWidth; el.classList.remove('below');", "el.classList.remove('r-out'); el.classList.add('r-below'); void el.offsetWidth; el.classList.remove('r-below');"),
    ("alts.classList.remove('closing')", "alts.classList.remove('r-closing')"), ("alts.classList.add('closing')", "alts.classList.add('r-closing')"),
    ("$music.classList.contains('playing')", "$music.classList.contains('r-playing')"), ("$music.classList.toggle('playing', S.musicPlaying())", "$music.classList.toggle('r-playing', S.musicPlaying())"),
    ("g.classList.remove('entering', 'opening', 'held');", "g.classList.remove('r-entering', 'r-opening', 'r-held');"),
    ("sink($app.querySelector('.scene'), 'leaving', 420)", "sink($app.querySelector('.r-scene'), 'r-leaving', 420)"), ("sink($app.querySelector('.win'), 'closing', 320)", "sink($app.querySelector('.r-win'), 'r-closing', 320)"),
    ("$app.querySelector('.wb')", "$app.querySelector('.r-wb')"), ("document.querySelector('#app .wb')", "document.querySelector('#app .r-wb')"),
    ("document.querySelectorAll('.nav-notes .n')", "document.querySelectorAll('.r-nav-notes .r-n')"), ("document.querySelectorAll('.nav-fr .n')", "document.querySelectorAll('.r-nav-fr .r-n')"),
    ("document.querySelector('#who .nb')", "document.querySelector('#who .r-nb')"),
    ("x.classList.add('show')", "x.classList.add('r-show')"), ("$top.classList.add('show')", "$top.classList.add('r-show')"), ("$music.classList.add('show')", "$music.classList.add('r-show')"), ("$foot.classList.add('show')", "$foot.classList.add('r-show')"),
    ("$app.querySelector('.scene')", "$app.querySelector('.r-scene')"), ("s.classList.contains('held')", "s.classList.contains('r-held')"),
    ("s.classList.remove('held'); s.classList.add('entering');", "s.classList.remove('r-held'); s.classList.add('r-entering');"),
    ("terms.closest('.agree')", "terms.closest('.r-agree')"), ("box.classList.toggle('on', terms.checked)", "box.classList.toggle('r-on', terms.checked)"),
    ("document.querySelector('.win #signout')", "document.querySelector('.r-win #signout')"), ("e.target.closest('.win #signout')", "e.target.closest('.r-win #signout')"),
    ("const cls = `item fl rv${o.main ? ' main' : ''}${o.quit ? ' quit' : ''}${o.mid ? ' mid' : ''}${o.dis ? ' dis' : ''}`;",
     "const cls = `r-item r-fl r-rv${o.main ? ' r-main' : ''}${o.quit ? ' r-quit' : ''}${o.mid ? ' r-mid' : ''}${o.dis ? ' r-dis' : ''}`;"),
    ("const mLine = (html, o, cls) => `<div class=\"${cls || 'hint'} rv\"", "const mLine = (html, o, cls) => `<div class=\"${cls || 'r-hint'} r-rv\""),
    (", 2, 'say')", ", 2, 'r-say')"),
    ("const nav = (href, icon, name, on, count, cls) => `<a class=\"nav ${on ? 'on' : ''} ${cls || ''}\" href=\"${href}\">${ic(icon)}<span>${name}</span>${count !== undefined ? `<span class=\"n hot\">${count}</span>` : ''}</a>`;",
     "const nav = (href, icon, name, on, count, cls) => `<a class=\"r-nav ${on ? 'r-on' : ''} ${cls || ''}\" href=\"${href}\">${ic(icon)}<span>${name}</span>${count !== undefined ? `<span class=\"r-n\">${count}</span>` : ''}</a>`;"),
    ("n(FR.unread), 'nav-fr')", "n(FR.unread), 'r-nav-fr')"), ("n(SOC.unread), 'nav-notes')", "n(SOC.unread), 'r-nav-notes')"),
    ("<button class=\"${LANG === 'ru' ? 'on' : ''}\" data-lang=\"ru\">RU</button><button class=\"${LANG === 'en' ? 'on' : ''}\" data-lang=\"en\">EN</button>",
     "<button class=\"${LANG === 'ru' ? 'r-on' : ''}\" data-lang=\"ru\">RU</button><button class=\"${LANG === 'en' ? 'r-on' : ''}\" data-lang=\"en\">EN</button>"),
    ("<button data-lang=\"ru\" class=\"${LANG === 'ru' ? 'on' : ''}\">RU</button><button data-lang=\"en\" class=\"${LANG === 'en' ? 'on' : ''}\">EN</button>",
     "<button data-lang=\"ru\" class=\"${LANG === 'ru' ? 'r-on' : ''}\">RU</button><button data-lang=\"en\" class=\"${LANG === 'en' ? 'r-on' : ''}\">EN</button>"),
    ("<button class=\"term fl rv${BUY.term === t.d ? ' sel' : ''}\"", "<button class=\"r-term r-fl r-rv${BUY.term === t.d ? ' r-sel' : ''}\""),
    ("<div class=\"term custom fl rv${BUY.term === -1 ? ' sel' : ''}\"", "<div class=\"r-term r-custom r-fl r-rv${BUY.term === -1 ? ' r-sel' : ''}\""),
    ("<button class=\"opt${BUY.method === k ? ' on' : ''}\"", "<button class=\"r-opt${BUY.method === k ? ' r-on' : ''}\""),
    ("<button class=\"agree${BUY.agree ? ' on' : ''}\"", "<button class=\"r-agree${BUY.agree ? ' r-on' : ''}\""),
    ("<div class=\"hero\"><div class=\"shot ${SHOT ? '' : 'shotbg'}\"", "<div class=\"r-hero\"><div class=\"r-shot ${SHOT ? '' : 'r-shotbg'}\""),
    ("<button class=\"btn sm ${state.pwOpen ? 'on' : ''}\" id=\"pw-open\">", "<button class=\"r-btn r-sm ${state.pwOpen ? 'r-on' : ''}\" id=\"pw-open\">"),
    ("`<div class=\"scene ${key} ${key === 'signin' || key === 'register' ? 'door' : ''} ${moved ? 'entering' : ''} ${moved && before ? 'after' : ''} ${INTRO ? 'held' : ''}\" data-screen=\"${key}\">",
     "`<div class=\"r-scene r-s-${key} ${key === 'signin' || key === 'register' ? 'r-door' : ''} ${moved ? 'r-entering' : ''} ${moved && before ? 'r-after' : ''} ${INTRO ? 'r-held' : ''}\" data-screen=\"${key}\">"),
    ("`<div class=\"win ${opening ? 'opening' : ''}\"", "`<div class=\"r-win ${opening ? 'r-opening' : ''}\""),
    ("<div class=\"wb\"><div class=\"pg ${moved ? 'enter' : ''}\">", "<div class=\"r-wb\"><div class=\"r-pg ${moved ? 'r-enter' : ''}\">"),
    ("const rail = () => '';", "function rail() { return ''; }"),
    ("const shell = (inner) => inner;", "function shell(inner) { return inner; }"),
]
for a, b in reps:
    n = s.count(a)
    assert n >= 1, (a[:90], n)
    s = s.replace(a, b)
s = re.sub(r'(class=")([^"]*)(")', fix, s)
s = s.replace('<section class="r-main">', '<section class="r-mainsec">')
open(p, "w", encoding="utf-8").write(s)
bad = set()
for c in re.findall(r'class="([^"]*)"', s):
    for t in c.split():
        if "${" in t or t.startswith("r-") or t in ("sr", "num", "acts", "kv"):
            continue
        bad.add(t)
print("unprefixed:", sorted(bad))
