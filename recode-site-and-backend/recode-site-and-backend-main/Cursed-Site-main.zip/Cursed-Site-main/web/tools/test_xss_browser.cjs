// Isolated renderer regression. No real sessions; all network requests aborted.
// Usage: node test_xss_browser.cjs app.js incident-cases.json
const fs = require('fs');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE || 'playwright');
const source=fs.readFileSync(process.argv[2],'utf8');
const incidents=JSON.parse(fs.readFileSync(process.argv[3],'utf8'));
const slice=(a,b)=>{let i=source.indexOf(a),j=source.indexOf(b,i);if(i<0||j<0)throw Error(a);return source.slice(i,j);};
const helper=source.split('\n').find(x=>x.startsWith('const esc = '))+'\n'+
 "const FO={uploaded:{}};const L=(a,b)=>a;const profHref=s=>'#/u/'+encodeURIComponent(s);const me=()=>({name:'Owner'});const BUG_ST={},IDEA_ST={},TK_STATES_STAFF={};const ago=()=>'';"+
 slice('const YT_ID =','// ---- the editor')+slice('function noteWords(','// ---- notes in the corner')+slice('function tkSystem(','function tkTicket(');
const payload='<img src="https://invalid.test/x" onerror="window.__xss++">';
const cases=[...incidents,payload,'<svg onload="window.__xss++">','<script>window.__xss++</script>','javascript:window.__xss++','&lt;img src=x onerror=window.__xss++&gt;','https://example.invalid/" onmouseover="window.__xss++','<math><mtext><table><mglyph><style><!--</style><img title="--><img src=x onerror=window.__xss++>">'];
const wrappers=[x=>x,x=>'||'+x+'||',x=>'**'+x+'**',x=>'`'+x+'`',x=>'```html\n'+x+'\n```',x=>'> '+x,x=>'https://example.invalid/ '+x];
(async()=>{
const browser=await chromium.launch({executablePath:process.env.XSS_BROWSER_EXECUTABLE || undefined,headless:true,args:['--mute-audio','--disable-gpu','--no-first-run']});
try{
 const context=await browser.newContext();await context.route('**/*',r=>r.abort());const page=await context.newPage();
 await page.setContent('<main id="test"></main>');await page.addScriptTag({content:helper});
 const results=await page.evaluate(({cases,payload})=>{
  window.__xss=0;let count=0,issues=[];
  const inspect=(label,html)=>{const el=document.createElement('div');el.innerHTML=html;document.getElementById('test').append(el);count++;for(const n of el.querySelectorAll('*')){if(['SCRIPT','IFRAME','OBJECT','EMBED','SVG','MATH','BASE','FORM'].includes(n.tagName))issues.push([label,n.outerHTML]);for(const a of n.attributes){if(/^on/i.test(a.name)||a.name==='srcdoc'||(/^(href|src|action)$/i.test(a.name)&&/^\s*(javascript|data|vbscript):/i.test(a.value)))issues.push([label,n.outerHTML]);}}};
  for(const x of cases)inspect('prose',prose(x));
  for(const kind of ['reply','mention','warning','message','group','role','badge','forum','ticket','other']){
   const d={title:payload,text:payload,why:payload,en:payload,ru:payload,status:payload,category:'bugs',build:payload,href:'javascript:window.__xss++',thread:1,page:1,ticket:1,chat:1,what:'state:'+payload};
   const [line,href]=noteWords({kind,actor:{login:payload},data:d});inspect('note:'+kind,`<a href="${href}">${line}</a>`);
  }
  inspect('ticket-system',tkSystem({author:{login:'user'},body:'state:'+payload,created:0}));
  const normal=prose('**bold** *italic* `code` ||spoiler|| @player https://example.invalid/test');
  for(const tag of ['<b>','<i>','<code>','class="spoiler"','<a '])if(!normal.includes(tag))throw Error('Formatting regression: '+tag);
  const safe=noteWords({kind:'other',data:{text:'Hello',href:'#/forum/t/1'}});
  if(safe[0]!=='Hello'||safe[1]!=='#/forum/t/1')throw Error('Notification regression');
  inspect('normal-prose',normal);

  return {count,issues};
 },{cases:cases.flatMap(x=>wrappers.map(w=>w(x))),payload});
 await page.waitForTimeout(100);results.executed=await page.evaluate(()=>window.__xss);console.log(JSON.stringify(results));
 if(results.issues.length||results.executed)process.exitCode=1;
}finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
