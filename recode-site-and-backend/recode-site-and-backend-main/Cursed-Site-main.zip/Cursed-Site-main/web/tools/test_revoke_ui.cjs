// Pure UI regression: no browser, credentials, or network.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync(process.argv[2],'utf8');
const start=source.indexOf('  const rc = u.recode;'),end=source.indexOf('  const ban =',start);
assert(start>=0&&end>start);
const ctx=vm.createContext({u:{},AD:{sure:'',rcDays:30},login:'OtherUser',L:(en,ru)=>ru,adWhen:()=>'',rkTerm:String,RK_TERMS:[30],esc:String,section:(_,s)=>s});
function draw(can,keys,sure='') {ctx.u={recode:{forever:true,keys,given:[],can_revoke_all:can}};ctx.AD.sure=sure;return vm.runInContext('{'+source.slice(start,end)+' recode;}',ctx);}
assert(draw(true,1).includes('data-ad-rc-revoke-all'));
assert(!draw(false,1).includes('data-ad-rc-revoke-all'));
assert(!draw(true,0).includes('data-ad-rc-revoke-all'));
assert(draw(true,1,'rc-revoke-all:OtherUser').includes('Отозвать все покупки и выдачи?'));
assert(!draw(true,1,'rc-revoke-all:DifferentUser').includes('Отозвать все покупки и выдачи?'));
const a=source.indexOf("  on('[data-ad-rc-revoke-all]'"),b=source.indexOf("  on('[data-ad-rc-take]'",a);
let callback,target='OtherUser',requests=[];
const events=vm.createContext({AD:{sure:''},login:()=>target,on:(_,__,fn)=>{callback=fn},render:()=>{},api:async(...args)=>{requests.push(args);return{ok:true}},L:(a,b)=>b,said:()=>{},again:()=>{}});
vm.runInContext(source.slice(a,b),events);
(async()=>{
 await callback();assert.equal(requests.length,0);
 target='DifferentUser';await callback();assert.equal(requests.length,0);
 await callback();assert.equal(requests.length,1);assert.equal(requests[0][0],'admin/users/DifferentUser/recode/all');assert.equal(requests[0][2],'DELETE');
 console.log('PASS: revoke UI permission, empty subscription, confirmation and target-switch checks');
})().catch(e=>{console.error(e);process.exitCode=1});
