/* ================================================================================================ changing in place
   A screen drawn again (an answer came, a tab was pressed, a switch) is not thrown away: what is the same stays as it is
   (its scroll, its focus, its pictures), what changed changes — so its CSS transitions run — and what is new comes in
   softly. Another screen in the window: the window and its sections stay, only the page crossfades. */
const BOUND = new WeakMap();
/** One handler per element, event and place: the newest. (app.js hands its handlers out after every drawing.) */
function bindOnce(el, ev, key, h) {
  let m = BOUND.get(el);
  if (!m) { m = new Map(); BOUND.set(el, m); }
  const k = ev + '\u0001' + key, old = m.get(k);
  if (old) el.removeEventListener(ev, old);
  el.addEventListener(ev, h);
  m.set(k, h);
}
// Classes put on by the hand or by an animation under way, not by the drawing: kept through it.
const TRANSIENT = new Set(['r-opening', 'r-entering', 'r-after', 'r-held', 'r-enter', 'r-fresh', 'r-gone', 'r-focus', 'r-pulse', 'r-out', 'r-below', 'r-swap', 'over', 'lit']);
const keepsClass = (a, c) => TRANSIENT.has(c) || (c === 'r-on' && a.classList.contains('r-fl'));
const keyOf = (n) => (n.nodeType !== 1 ? '' : n.id ? '#' + n.id : n.getAttribute('data-key') || (n.tagName === 'A' ? n.getAttribute('href') || '' : ''));
function syncAttrs(a, b) {
  const focused = a === document.activeElement;
  for (const at of [...a.attributes]) {
    if (b.hasAttribute(at.name) || (focused && at.name === 'value')) continue;
    if (at.name === 'class') {
      const keep = [...a.classList].filter((c) => keepsClass(a, c));
      if (keep.length) a.className = keep.join(' '); else a.removeAttribute('class');
      continue;
    }
    a.removeAttribute(at.name);
  }
  for (const at of [...b.attributes]) {
    if (at.name === 'class') {
      const keep = [...a.classList].filter((c) => keepsClass(a, c) && !b.classList.contains(c));
      const v = keep.length ? at.value + ' ' + keep.join(' ') : at.value;
      if (a.getAttribute('class') !== v) a.setAttribute('class', v);
      continue;
    }
    if (a.getAttribute(at.name) !== at.value) a.setAttribute(at.name, at.value);
  }
}
function morphNode(a, b, fresh) {
  if (a.nodeType === 3 || a.nodeType === 8) { if (a.nodeValue !== b.nodeValue) a.nodeValue = b.nodeValue; return a; }
  if (a.tagName !== b.tagName) { a.replaceWith(b); if (fresh) b.classList.add('r-fresh'); return b; }
  syncAttrs(a, b);
  const focused = a === document.activeElement;
  switch (a.tagName) {
    case 'INPUT':
      if (!focused) {
        if (a.type === 'checkbox' || a.type === 'radio') a.checked = b.hasAttribute('checked');
        else if (a.type !== 'file') { const v = b.getAttribute('value') || ''; if (a.value !== v) a.value = v; }
      }
      return a;
    case 'TEXTAREA': if (!focused && a.value !== b.value) a.value = b.value; return a;
    case 'SELECT': { morphChildren(a, b, false); const o = b.querySelector('option[selected]'); if (o && a.value !== o.value) a.value = o.value; return a; }
    case 'CANVAS': case 'IFRAME': case 'VIDEO': case 'AUDIO': return a;
    default: break;
  }
  morphChildren(a, b, fresh);
  return a;
}
function morphChildren(from, to, fresh) {
  const keyed = new Map();
  for (let c = from.firstChild; c; c = c.nextSibling) { const k = keyOf(c); if (k && !keyed.has(k)) keyed.set(k, c); }
  let cur = from.firstChild, n = to.firstChild;
  while (n) {
    const next = n.nextSibling, k = keyOf(n);
    let m = null;
    if (k && keyed.has(k)) { m = keyed.get(k); keyed.delete(k); }
    else if (!k && cur && !keyOf(cur) && cur.nodeType === n.nodeType && (cur.nodeType !== 1 || (cur.tagName === n.tagName && (cur.type || '') === (n.type || '')))) m = cur;
    if (m) {
      if (m !== cur) from.insertBefore(m, cur); else cur = cur.nextSibling;
      morphNode(m, n, fresh);
    } else {
      from.insertBefore(n, cur);
      if (fresh && n.nodeType === 1) n.classList.add('r-fresh');
    }
    n = next;
  }
  while (cur) { const nx = cur.nextSibling; from.removeChild(cur); cur = nx; }
}
/** Its insides to this HTML, changed in place (translated first, so the words compare as they will be shown). */
function morphInner(el, html, fresh) {
  const t = document.createElement('div');
  t.innerHTML = html;
  translate(t);
  morphChildren(el, t, fresh);
}
document.addEventListener('animationend', (e) => {
  const t = e.target;
  if (t.classList && (e.animationName === 'freshIn' || e.animationName === 'pgIn' || e.animationName === 'titleIn')) t.classList.remove('r-fresh', 'r-enter', 'r-swap');
});

/** The selection in the window's sections: one pill gliding to the section open. */
function placeIndicator(now) {
  const side = $app.querySelector('.r-side'); if (!side) return;
  const ind = side.querySelector('.r-ind'), on = side.querySelector('.r-nav.r-on');
  if (!ind) return;
  if (!on) { ind.style.opacity = '0'; return; }
  if (now) ind.classList.add('r-now');
  ind.style.opacity = '1';
  ind.style.width = on.offsetWidth + 'px'; ind.style.height = on.offsetHeight + 'px';
  ind.style.transform = `translate(${on.offsetLeft}px, ${on.offsetTop}px)`;
  if (now) { void ind.offsetWidth; ind.classList.remove('r-now'); }
}

function render(keepScroll) {
  const [route, ...rest] = (location.hash.replace(/^#\/?/, '') || 'home').split('/');
  const changed = route !== state.route || rest.join('/') !== state.arg || !SCREEN;
  state.route = route; state.arg = rest.join('/');
  const views = VIEWS();
  state.gate = false;
  if (RANK[state.role] < RANK[need(route, state.arg)]) {
    if (state.jump) state.role = 'member';
    else if (state.role === 'guest') { state.gate = true; state.back = route + (state.arg ? '/' + state.arg : ''); }
  }
  state.jump = false;
  if (route === 'admin' && state.signedIn && !canStaff()) { location.hash = '#/dashboard/overview'; return; }
  if (changed) state.shot = 0;
  const lost = !views[route];
  const menu = state.gate || lost || MENU_ROUTES.has(route);
  const screen = menu ? (state.gate ? 'signin' : lost ? 'lost' : route) : 'win:' + route + '/' + state.arg;
  const was = document.activeElement, keep = was && was.id && $app.contains(was) ? [was.id, was.selectionStart, was.selectionEnd] : null;
  const mode = menu ? 'menu' : 'win', before = MODE, moved = changed && screen !== SCREEN;
  const inner = (state.gate ? viewSignin : lost ? viewLost : views[route])(state.arg);
  const key = state.gate ? 'signin' : lost ? 'lost' : route;
  let html;
  if (mode === 'menu') {
    html = `<div class="r-scene r-s-${key} ${key === 'signin' || key === 'register' ? 'r-door' : ''} ${moved ? 'r-entering' : ''} ${moved && before ? 'r-after' : ''} ${INTRO ? 'r-held' : ''}" data-screen="${key}">${inner}</div>`;
  } else {
    const [title, sub] = winTitle();
    html = `<div class="r-win ${before !== 'win' ? 'r-opening' : ''}" data-r="${esc(route)}" data-a="${esc(String(state.arg).split('/')[0])}" role="dialog" aria-label="Cursed">
        <nav class="r-side" aria-label="${L('Sections', 'Разделы')}"><i class="r-ind" aria-hidden="true"></i>${sidebar()}</nav>
        <section class="r-mainsec"><header class="r-wh"><div class="r-wt"><h1>${esc(title)}</h1>${sub ? `<p>${esc(sub)}</p>` : ''}</div></header>
          <div class="r-wb"><div class="r-pg ${moved ? 'r-enter' : ''}">${inner}</div></div>
          <a class="r-x" href="#/home" aria-label="${L('Close', 'Закрыть')}" title="${L('To the menu', 'В меню')}">${ic('x')}</a></section></div>`;
  }
  const tmp = document.createElement('div');
  tmp.innerHTML = html;
  translate(tmp);
  const next = tmp.firstElementChild, cur = $app.firstElementChild;
  if (cur && !moved && mode === before) {
    // The same screen, drawn again: changed in place.
    morphNode(cur, next, true);
  } else if (cur && mode === 'win' && before === 'win') {
    // Another page in the window: the frame stays (the selection glides, the title rises), the page crossfades.
    const oldTitle = cur.querySelector('.r-wt').textContent;
    syncAttrs(cur, next);
    morphNode(cur.querySelector('.r-side'), next.querySelector('.r-side'), false);
    morphNode(cur.querySelector('.r-wh'), next.querySelector('.r-wh'), false);
    const wt = cur.querySelector('.r-wt');
    if (wt.textContent !== oldTitle) { wt.classList.remove('r-swap'); void wt.offsetWidth; wt.classList.add('r-swap'); }
    const wb = cur.querySelector('.r-wb'), oldPg = wb.querySelector('.r-pg'), newPg = next.querySelector('.r-pg');
    if (oldPg) {
      // the page leaving: a copy where it stood, fading up and away over the new one coming in
      const g = oldPg.cloneNode(true);
      g.querySelectorAll('[id]').forEach((el) => el.removeAttribute('id'));
      g.classList.remove('r-enter');
      g.classList.add('r-pg-out');
      const box = document.createElement('div');
      box.className = 'r-pg-ghost';
      box.style.top = wb.offsetTop + 'px'; box.style.height = wb.clientHeight + 'px';
      g.style.transform = `translateY(${oldPg.offsetTop - wb.scrollTop}px)`;
      box.appendChild(g);
      wb.parentNode.insertBefore(box, wb.nextSibling);
      setTimeout(() => box.remove(), 280);
      wb.replaceChild(newPg, oldPg);
    } else wb.appendChild(newPg);
    if (!keepScroll) wb.scrollTop = 0;
  } else {
    // The menu sinks into its lines, the window closes; the new one comes.
    if (cur && before === 'menu') sink(cur, 'r-leaving', 420);
    if (cur && before === 'win' && mode === 'menu') sink(cur, 'r-closing', 320);
    $app.replaceChildren(next);
  }
  if (mode === 'menu') {
    World.station(STATIONS[key] || 'home', !before);
    // on a phone Recode's page scrolls: the RECODE signature at the bottom would lie over the payment
    World.lockup(key === 'buy' && innerWidth <= 760 ? 0 : 1);
  } else World.station('app', !before);
  if (moved) { World.calm(); World.select(null); }
  MODE = mode; SCREEN = screen;
  document.body.classList.toggle('mode-menu', mode === 'menu');
  document.body.classList.toggle('mode-win', mode === 'win');
  document.body.dataset.screen = menu ? screen : 'win';
  $app.querySelectorAll('canvas[data-head]').forEach(drawHead);
  wire();
  socialWire();
  refsWire();
  shellWire();
  if (keep) {
    const el = document.getElementById(keep[0]);
    if (el && el !== document.activeElement) { el.focus({ preventScroll: true }); try { el.setSelectionRange(keep[1], keep[2]); } catch (e) { /* not a text field */ } }
  }
  placeIndicator(before !== 'win');
  if (moved) World.layoutLockup();
}
