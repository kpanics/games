// What happens on the screen frame by frame after a step (window.__step, a hash or a JS): every drawing (when, how long,
// what the page says), and every frame the opacity of the page leaving and of the page coming.
(async () => {
  const s = (ms) => new Promise((r) => setTimeout(r, ms));
  const t0 = performance.now(), log = [];
  const at = () => (performance.now() - t0).toFixed(0).padStart(4);
  const r0 = render;
  window.render = render = function (k) { const t = performance.now(); r0(k); log.push(`${at()} render ${(performance.now() - t).toFixed(1)}ms  ${location.hash}  pg="${($app.querySelector('.r-wb .r-pg') || {}).textContent?.trim().slice(0, 50)}"`); };
  const step = window.__step || '#/forum/latest';
  if (step.startsWith('#')) location.hash = step; else (0, eval)(step);
  const end = performance.now() + 700;
  while (performance.now() < end) {
    await new Promise((r) => requestAnimationFrame(r));
    const g = document.querySelector('.r-pg-ghost .r-pg'), p = $app.querySelector('.r-wb .r-pg'), st = document.querySelector('.r-stand');
    log.push(`${at()} ghost=${g ? (+getComputedStyle(g).opacity).toFixed(2) : '-'} page=${p ? (+getComputedStyle(p).opacity).toFixed(2) : '-'} stand=${st ? 1 : 0} pages=${$app.querySelectorAll('.r-wb .r-pg').length}`);
  }
  console.warn(log.join('\n'));
})();
