(async () => {
  const s = (ms) => new Promise((r) => setTimeout(r, ms));
  const run = async (h) => {
    const d = []; let last = performance.now(), on = true;
    const tick = (t) => { d.push(t - last); last = t; if (on) requestAnimationFrame(tick); };
    requestAnimationFrame(tick);
    const lt = []; const po = new PerformanceObserver((l) => l.getEntries().forEach((e) => lt.push(Math.round(e.duration)))); po.observe({ type: 'longtask', buffered: false });
    const t0 = performance.now(); location.hash = h; await s(1200); on = false; po.disconnect();
    const big = d.filter((x) => x > 40).map((x) => Math.round(x));
    console.warn(h, 'frames', d.length, 'max', Math.round(Math.max(...d)), 'over40', JSON.stringify(big), 'longtasks', JSON.stringify(lt));
  };
  for (const h of ['#/market', '#/forum', '#/forum/t/104', '#/dashboard/overview', '#/admin/users']) { await run(h); await s(600); }
})();
