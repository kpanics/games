(async () => {
  const s = (ms) => new Promise((r) => setTimeout(r, ms));
  const go = async (h) => {
    location.hash = h; await s(1700);
    const t = document.querySelector('.r-wt h1'), ind = document.querySelector('.r-ind');
    console.warn(h, 'title=' + (t ? t.textContent : '-'), 'pgs=' + document.querySelectorAll('#app .r-pg').length, 'wins=' + document.querySelectorAll('#app .r-win').length, 'ghosts=' + document.querySelectorAll('.r-pg-ghost').length, 'ind=' + (ind ? ind.style.transform : '-'));
  };
  for (const h of ['#/forum/t/104', '#/market', '#/pack/dusk', '#/friends', '#/friends/c/22', '#/friends/people', '#/dashboard/overview', '#/dashboard/profile', '#/notifications', '#/badges', '#/support', '#/admin', '#/admin/users', '#/docs/offer', '#/u/Lunuca', '#/home', '#/forum']) await go(h);
})();
