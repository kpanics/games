(async () => {
  const s = (ms) => new Promise((r) => setTimeout(r, ms));
  const r0 = render;
  window.render = render = function (k) { const t = performance.now(); r0(k); const d = performance.now() - t; console.warn('render', location.hash, d.toFixed(1) + 'ms'); };
  const tr0 = translate;
  let trT = 0; translate = function (root) { const t = performance.now(); tr0(root); trT += performance.now() - t; };
  for (const h of ['#/market', '#/forum', '#/forum/t/104', '#/friends/c/22', '#/admin/users', '#/dashboard/overview', '#/notifications']) { trT = 0; location.hash = h; await s(1500); console.warn('  translate total', trT.toFixed(1) + 'ms'); }
})();
