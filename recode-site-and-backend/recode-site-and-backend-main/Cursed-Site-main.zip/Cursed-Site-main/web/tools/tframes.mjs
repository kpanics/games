// node tframes.mjs <outdir> <w>x<h> <route> <js-action> [count] [gapMs] — frames of a transition: the page is opened,
// then the action runs and `count` frames are taken every `gapMs` (JPEG, so they come fast). SESSION=, LANG_SITE= as wshot.
import { spawn } from "node:child_process";
import { writeFileSync, mkdirSync } from "node:fs";
const [outdir, size, route, action, countArg = "8", gapArg = "70"] = process.argv.slice(2);
const [W, H] = size.split("x").map(Number);
const BASE = process.env.BASE || "http://127.0.0.1:8791";
const EDGE = "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe";
const port = 9400 + Math.floor(Math.random() * 400);
mkdirSync(outdir, { recursive: true });
const edge = spawn(EDGE, ["--headless=new", `--remote-debugging-port=${port}`, `--user-data-dir=${process.env.TEMP}/cursed-tf-${port}`, "--use-angle=d3d11", "--enable-gpu", "--ignore-gpu-blocklist",
  "--hide-scrollbars", "--mute-audio", "--no-first-run", `--window-size=${W},${H}`, "about:blank"], { stdio: "ignore" });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let tabs;
for (let i = 0; i < 60; i++) { try { tabs = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json(); if (tabs.find((x) => x.type === "page")) break; } catch {} await sleep(250); }
const ws = new WebSocket(tabs.find((x) => x.type === "page").webSocketDebuggerUrl);
await new Promise((r) => ws.addEventListener("open", r));
let id = 0; const wait = new Map();
ws.addEventListener("message", (ev) => { const m = JSON.parse(ev.data); if (m.id && wait.has(m.id)) { wait.get(m.id)(m); wait.delete(m.id); } else if (m.method === "Runtime.exceptionThrown") console.log("EXCEPTION:", JSON.stringify(m.params.exceptionDetails).slice(0, 600)); });
const send = (method, params = {}) => new Promise((r) => { const i = ++id; wait.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
await send("Runtime.enable"); await send("Page.enable");
await send("Emulation.setDeviceMetricsOverride", { width: W, height: H, deviceScaleFactor: 1, mobile: false });
if (process.env.SESSION) await send("Network.setCookie", { name: "cursed_session", value: process.env.SESSION, url: BASE + "/api/", path: "/api", httpOnly: true });
if (process.env.LANG_SITE) await send("Page.addScriptToEvaluateOnNewDocument", { source: `try{localStorage.setItem('cursed.lang','${process.env.LANG_SITE}')}catch(e){}` });
await send("Page.navigate", { url: `${BASE}/?nointro#${route}` });
await sleep(+(process.env.SETTLE || 5000));
// the screen as it is drawn (a screencast: every frame the browser paints, with its time)
const frames = [];
ws.addEventListener("message", (ev) => {
  const m = JSON.parse(ev.data);
  if (m.method === "Page.screencastFrame") { frames.push({ t: m.params.metadata.timestamp, data: m.params.data }); send("Page.screencastFrameAck", { sessionId: m.params.sessionId }); }
});
await send("Page.startScreencast", { format: "jpeg", quality: 70, everyNthFrame: 1 });
await sleep(300);
const tAct = Date.now() / 1000;
send("Runtime.evaluate", { expression: action });
await sleep(+gapArg * +countArg);
await send("Page.stopScreencast");
const after = frames.filter((f) => f.t >= tAct - 0.05);
after.forEach((f, i) => writeFileSync(`${outdir}/f${String(i).padStart(3, "0")}_${Math.round((f.t - tAct) * 1000)}ms.jpg`, Buffer.from(f.data, "base64")));
console.log("frames:", after.length);
ws.close(); edge.kill();
