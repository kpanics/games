(() => {
  const nav = document.getElementById('public-legal');
  if (!nav) return;
  const toggle = nav.querySelector('.r-legal-toggle');
  let timer;

  function open() {
    clearTimeout(timer);
    nav.classList.add('is-open');
    toggle.setAttribute('aria-expanded', 'true');
  }

  function close() {
    clearTimeout(timer);
    nav.classList.remove('is-open');
    toggle.setAttribute('aria-expanded', 'false');
  }

  function later(ms = 1400, keepFocused = false) {
    clearTimeout(timer);
    timer = setTimeout(() => {
      if (keepFocused && nav.contains(document.activeElement)) later(ms, true);
      else close();
    }, ms);
  }

  toggle.addEventListener('click', () => nav.classList.contains('is-open') ? close() : open());
  nav.addEventListener('pointerenter', open);
  nav.addEventListener('pointerleave', () => later(1400, true));
  nav.addEventListener('focus', open, true);
  nav.addEventListener('focusout', (event) => {
    if (!event.relatedTarget || !nav.contains(event.relatedTarget)) later();
  }, true);
  document.addEventListener('pointerdown', (event) => {
    if (!nav.contains(event.target)) close();
  });
  document.addEventListener('scroll', (event) => {
    if (!nav.contains(event.target) && !nav.contains(document.activeElement)) close();
  }, true);
  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape' || !nav.classList.contains('is-open')) return;
    event.preventDefault();
    close();
    toggle.focus({ preventScroll: true });
  });
  addEventListener('blur', close);

  if (!matchMedia('(max-width: 600px)').matches) {
    open();
    later(3000);
  }
})();
