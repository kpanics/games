"use strict";
/* ================================================================================================ the figure (23.10.2026)
   The player in 3D on the site: their skin, and what the cosmetics' pack puts on them (/api/cosmetics, the same catalog
   and files the client wears), moved by the items' own animations. The client's native cosmetics read these files in
   geo.rs, anim.rs, molang.rs, lunar.rs, obj.rs, dragon.rs; what is here is their reading, the same rule for rule, so that
   an item looks on the site as it does in the game and in Blockbench, where it was made.

   Spaces: "the model's" is the game's (blocks, y down from the neck, the front toward -z): every quad is made there and
   turned with the part of the player it hangs on; the world's is y up from the feet, the front toward the camera. */

const Figure = (() => {

/* ---------------------------------------------------------------------------------------------- matrices (column-major) */
const ident = () => [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];
function mul(a, b) {
  const r = new Array(16);
  for (let c = 0; c < 4; c++) for (let i = 0; i < 4; i++) r[c * 4 + i] = a[i] * b[c * 4] + a[4 + i] * b[c * 4 + 1] + a[8 + i] * b[c * 4 + 2] + a[12 + i] * b[c * 4 + 3];
  return r;
}
const translate = (x, y, z) => { const m = ident(); m[12] = x; m[13] = y; m[14] = z; return m; };
const scale = (s) => { const m = ident(); m[0] = s[0]; m[5] = s[1]; m[10] = s[2]; return m; };
const RAD = Math.PI / 180;
function rotX(d) { const s = Math.sin(d * RAD), c = Math.cos(d * RAD), m = ident(); m[5] = c; m[6] = s; m[9] = -s; m[10] = c; return m; }
function rotY(d) { const s = Math.sin(d * RAD), c = Math.cos(d * RAD), m = ident(); m[0] = c; m[2] = -s; m[8] = s; m[10] = c; return m; }
function rotZ(d) { const s = Math.sin(d * RAD), c = Math.cos(d * RAD), m = ident(); m[0] = c; m[1] = s; m[4] = -s; m[5] = c; return m; }
/** A turn as a Bedrock file gives it, in Blockbench's space: x and y the other way, applied z, y, x. */
const turn = (r) => mul(rotZ(r[2]), mul(rotY(-r[1]), rotX(-r[0])));
const about = (p, m) => mul(translate(p[0], p[1], p[2]), mul(m, translate(-p[0], -p[1], -p[2])));
const apply = (m, p, w) => [m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12] * w, m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13] * w, m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14] * w];
function rotation(deg, axis) {
  const l = Math.hypot(axis[0], axis[1], axis[2]);
  if (l < 1e-6) return ident();
  const x = axis[0] / l, y = axis[1] / l, z = axis[2] / l, s = Math.sin(deg * RAD), c = Math.cos(deg * RAD), t = 1 - c;
  return [t * x * x + c, t * x * y + s * z, t * x * z - s * y, 0, t * x * y - s * z, t * y * y + c, t * y * z + s * x, 0, t * x * z + s * y, t * y * z - s * x, t * z * z + c, 0, 0, 0, 0, 1];
}
const det3 = (m) => m[0] * (m[5] * m[10] - m[6] * m[9]) - m[4] * (m[1] * m[10] - m[2] * m[9]) + m[8] * (m[1] * m[6] - m[2] * m[5]);
function perspective(fovy, aspect, near, far) {
  const f = 1 / Math.tan(fovy / 2), nf = 1 / (near - far);
  return [f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) * nf, -1, 0, 0, 2 * far * near * nf, 0];
}
function lookAt(eye, at) {
  let z = [eye[0] - at[0], eye[1] - at[1], eye[2] - at[2]]; const zl = Math.hypot(...z); z = z.map((v) => v / zl);
  let x = [z[2], 0, -z[0]]; const xl = Math.hypot(...x) || 1; x = x.map((v) => v / xl);
  const y = [z[1] * x[2] - z[2] * x[1], z[2] * x[0] - z[0] * x[2], z[0] * x[1] - z[1] * x[0]];
  return [x[0], y[0], z[0], 0, x[1], y[1], z[1], 0, x[2], y[2], z[2], 0, -(x[0] * eye[0] + x[1] * eye[1] + x[2] * eye[2]), -(y[0] * eye[0] + y[1] * eye[1] + y[2] * eye[2]), -(z[0] * eye[0] + z[1] * eye[1] + z[2] * eye[2]), 1];
}

/* ---------------------------------------------------------------------------------------------- Molang (molang.rs) */
const SYMS = ['&&', '||', '==', '!=', '<=', '>=', '??', '->', '(', ')', '{', '}', '[', ']', ',', ';', '?', ':', '+', '-', '*', '/', '<', '>'];
function lex(src) {
  const out = []; let i = 0; const n = src.length;
  const dig = (ch) => ch >= '0' && ch <= '9', alpha = (ch) => (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || ch === '_';
  while (i < n) {
    const c = src[i];
    if (c === ' ' || c === '\t' || c === '\n' || c === '\r') { i++; continue; }
    if ((c === '/' && src[i + 1] === '/') || c === '#') { while (i < n && src[i] !== '\n') i++; continue; }
    if (dig(c) || (c === '.' && dig(src[i + 1] || ''))) {
      const s = i; while (i < n && (dig(src[i]) || src[i] === '.')) i++;
      if ((src[i] === 'e' || src[i] === 'E') && /[0-9+-]/.test(src[i + 1] || '')) { i += 2; while (i < n && dig(src[i])) i++; }
      const text = src.slice(s, i);
      if ((src[i] === 'f' || src[i] === 'F') && !/[A-Za-z0-9_]/.test(src[i + 1] || '')) i++;
      const v = parseFloat(text); if (Number.isNaN(v)) throw new Error('number ' + text);
      out.push({ t: 'n', v }); continue;
    }
    if (alpha(c)) { const s = i; while (i < n && (alpha(src[i]) || dig(src[i]) || src[i] === '.')) i++; out.push({ t: 'w', v: src.slice(s, i).toLowerCase() }); continue; }
    if (c === '\'' || c === '"') { const s = i + 1; i++; while (i < n && src[i] !== c) i++; out.push({ t: 's', v: src.slice(s, i) }); i++; continue; }
    if (c === '=') { if (src[i + 1] === '=') { out.push({ t: 'y', v: '==' }); i += 2; } else { out.push({ t: 'y', v: '=' }); i++; } continue; }
    if (c === '!') { if (src[i + 1] === '=') { out.push({ t: 'y', v: '!=' }); i += 2; } else { out.push({ t: 'y', v: '!' }); i++; } continue; }
    const hit = SYMS.find((s) => src.startsWith(s, i));
    if (!hit) throw new Error('unexpected ' + c);
    out.push({ t: 'y', v: hit }); i += hit.length;
  }
  return out;
}
function hashStr(s) { let h = 2166136261 >>> 0; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i) & 255; h = Math.imul(h, 16777619) >>> 0; } return h >>> 8; }
function varOf(name) {
  const k = name.indexOf('.'); if (k < 0) return null;
  const scope = { c: 'c', context: 'c', v: 'v', variable: 'v', t: 't', temp: 't', a: 'a', arg: 'a', readout: 'r' }[name.slice(0, k)];
  return scope ? [scope, name.slice(k + 1)] : null;
}
class Parser {
  constructor(toks) { this.toks = toks; this.at = 0; }
  peek() { return this.toks[this.at]; }
  is(s) { const p = this.peek(); return !!p && p.t === 'y' && p.v === s; }
  eat(s) { if (this.is(s)) { this.at++; return true; } return false; }
  expect(s) { if (!this.eat(s)) throw new Error('expected ' + s); }
  word(w) { const p = this.peek(); return !!p && p.t === 'w' && p.v === w; }
  stmtsUntil(end) {
    const out = [];
    for (;;) {
      while (this.eat(';'));
      const p = this.peek();
      if (!p) { if (end) throw new Error('expected ' + end); return out; }
      if (end && p.t === 'y' && p.v === end) { this.at++; return out; }
      out.push(this.stmt());
    }
  }
  stmt() {
    if (this.word('return')) { this.at++; const e = this.is(';') || this.is('}') || !this.peek() ? { k: 'n', v: 0 } : this.expr(); return { k: 'ret', e }; }
    if (this.word('if')) {
      this.at++; this.expect('('); const c = this.expr(); this.expect(')');
      const then = this.body(); let other = [];
      if (this.word('else')) { this.at++; other = this.word('if') ? [this.stmt()] : this.body(); }
      return { k: 'if', c, then, other };
    }
    const e = this.expr();
    if (e.k === '??' && e.l.k === 'var' && this.is(';')) return { k: 'init', s: e.l.s, n: e.l.n, e: e.r };
    return { k: 'e', e };
  }
  body() { return this.eat('{') ? this.stmtsUntil('}') : [this.stmt()]; }
  expr() { return this.assign(); }
  assign() {
    const left = this.ternary();
    if (this.eat('=')) { const right = this.assign(); return left.k === 'var' ? { k: '=', s: left.s, n: left.n, e: right } : right; }
    return left;
  }
  ternary() {
    const c = this.coalesce();
    if (this.eat('?')) { const a = this.assign(); const b = this.eat(':') ? this.assign() : null; return { k: '?', c, a, b }; }
    return c;
  }
  coalesce() { let l = this.or(); while (this.eat('??')) l = { k: '??', l, r: this.or() }; return l; }
  or() { let l = this.and(); while (this.eat('||')) l = { k: 'b', op: '||', l, r: this.and() }; return l; }
  and() { let l = this.eq(); while (this.eat('&&')) l = { k: 'b', op: '&&', l, r: this.eq() }; return l; }
  eq() { let l = this.cmp(); for (;;) { const op = this.eat('==') ? '==' : this.eat('!=') ? '!=' : null; if (!op) return l; l = { k: 'b', op, l, r: this.cmp() }; } }
  cmp() { let l = this.add(); for (;;) { const op = this.eat('<=') ? '<=' : this.eat('>=') ? '>=' : this.eat('<') ? '<' : this.eat('>') ? '>' : null; if (!op) return l; l = { k: 'b', op, l, r: this.add() }; } }
  add() { let l = this.mulx(); for (;;) { const op = this.eat('+') ? '+' : this.eat('-') ? '-' : null; if (!op) return l; l = { k: 'b', op, l, r: this.mulx() }; } }
  mulx() { let l = this.unary(); for (;;) { const op = this.eat('*') ? '*' : this.eat('/') ? '/' : null; if (!op) return l; l = { k: 'b', op, l, r: this.unary() }; } }
  unary() {
    if (this.eat('!')) return { k: '!', e: this.unary() };
    if (this.eat('-')) { const e = this.unary(); return e.k === 'n' ? { k: 'n', v: -e.v } : { k: 'neg', e }; }
    if (this.eat('+')) return this.unary();
    return this.atom();
  }
  args() { const out = []; if (this.eat(')')) return out; for (;;) { out.push(this.expr()); if (this.eat(')')) return out; this.expect(','); } }
  atom() {
    const p = this.peek(); if (!p) throw new Error('unexpected end');
    if (p.t === 'n') { this.at++; return { k: 'n', v: p.v }; }
    if (p.t === 's') { this.at++; return { k: 'n', v: hashStr(p.v) }; }
    if (p.t === 'y' && p.v === '(') { this.at++; const e = this.expr(); this.expect(')'); return e; }
    if (p.t === 'y' && p.v === '{') { this.at++; return { k: 'blk', list: this.stmtsUntil('}') }; }
    if (p.t === 'w') {
      this.at++; const n = p.v;
      if (n === 'true') return { k: 'n', v: 1 };
      if (n === 'false') return { k: 'n', v: 0 };
      const args = this.eat('(') ? this.args() : null;
      if (n.startsWith('math.')) return { k: 'math', n: n.slice(5), a: args || [] };
      if (n.startsWith('q.')) return { k: 'q', n: n.slice(2), a: args || [] };
      if (n.startsWith('query.')) return { k: 'q', n: n.slice(6), a: args || [] };
      if (n.startsWith('option.')) return { k: 'q', n: 'option.' + n.slice(7), a: args || [] };
      if (n.startsWith('o.')) return { k: 'q', n: 'option.' + n.slice(2), a: args || [] };
      const v = varOf(n);
      if (v && !args) return { k: 'var', s: v[0], n: v[1] };
      return args ? { k: 'call', n, a: args } : { k: 'n', v: 0 };
    }
    throw new Error('unexpected ' + p.v);
  }
}
const NUM = (v) => ({ stmts: [{ k: 'e', e: { k: 'n', v } }], c: v });
function parse(src) {
  const p = new Parser(lex(src));
  const stmts = p.stmtsUntil(null);
  const c = stmts.length === 1 && stmts[0].k === 'e' && stmts[0].e.k === 'n' ? stmts[0].e.v : null;
  return { stmts, c };
}
const safeParse = (src, or) => { try { return parse(src); } catch (e) { return or || { stmts: [], c: null }; } };
function value(v) {
  if (typeof v === 'number') return NUM(v);
  if (typeof v === 'boolean') return NUM(v ? 1 : 0);
  if (typeof v === 'string') { const x = Number(v.trim()); return v.trim() !== '' && Number.isFinite(x) ? NUM(x) : safeParse(v); }
  return NUM(0);
}
function parseFunctions(text) {
  const map = new Map(); let head = null, body = '';
  const flush = () => { if (head) { try { map.set(head[0], [head[1], parse(body)]); } catch (e) { /* not read: not there */ } } head = null; body = ''; };
  for (const line of text.split('\n')) {
    const starts = line.length && !/\s/.test(line[0]);
    if (starts && line.includes('):')) {
      flush();
      const sig = line.slice(0, line.indexOf('):')), k = sig.indexOf('(');
      if (k > 0) head = [sig.slice(0, k).trim().toLowerCase(), sig.slice(k + 1).split(',').map((s) => s.trim()).filter(Boolean).map((s) => s.replace(/^a\.|^arg\./, '').toLowerCase())];
    } else if (head) body += line + '\n';
  }
  flush();
  return map;
}
const truth = (v) => v !== 0;
function runner(vars, q, funcs) {
  const r = { vars, temps: new Map(), args: new Map(), q, funcs, depth: 0 };
  return r;
}
function rget(r, s, n) { const m = s === 'c' ? r.vars.c : s === 'v' ? r.vars.v : s === 't' ? r.temps : s === 'a' ? r.args : null; return m ? m.get(n) : undefined; }
function rset(r, s, n, x) { if (!Number.isFinite(x)) x = 0; const m = s === 'c' ? r.vars.c : s === 'v' ? r.vars.v : s === 't' ? r.temps : s === 'a' ? r.args : null; if (m) m.set(n, x); }
function rand(vars) {
  // xorshift, as the client's (the same item runs the same way from the same seed): kept small here
  let x = (vars.seed = (vars.seed * 1103515245 + 12345) % 2147483648);
  return x / 2147483648;
}
function stmts(r, list) {
  for (const s of list) {
    if (s.k === 'e') ev(r, s.e);
    else if (s.k === 'init') { if (rget(r, s.s, s.n) === undefined) rset(r, s.s, s.n, ev(r, s.e)); }
    else if (s.k === 'if') { const f = truth(ev(r, s.c)) ? stmts(r, s.then) : stmts(r, s.other); if (f !== undefined) return f; }
    else if (s.k === 'ret') return ev(r, s.e);
  }
  return undefined;
}
function valueOf(r, list) {
  if (list.length && list[list.length - 1].k === 'e') { const f = stmts(r, list.slice(0, -1)); return f !== undefined ? f : ev(r, list[list.length - 1].e); }
  const f = stmts(r, list); return f !== undefined ? f : 0;
}
function ev(r, e) {
  switch (e.k) {
    case 'n': return e.v;
    case 'var': { const v = rget(r, e.s, e.n); return v === undefined ? 0 : v; }
    case 'q': return r.q(e.n, e.a.map((x) => ev(r, x)));
    case 'math': return math(r, e.n, e.a.map((x) => ev(r, x)));
    case 'call': return call(r, e.n, e.a.map((x) => ev(r, x)));
    case '!': return truth(ev(r, e.e)) ? 0 : 1;
    case 'neg': return -ev(r, e.e);
    case 'b': {
      const a = ev(r, e.l);
      if (e.op === '&&') return truth(a) && truth(ev(r, e.r)) ? 1 : 0;
      if (e.op === '||') return truth(a) || truth(ev(r, e.r)) ? 1 : 0;
      const b = ev(r, e.r);
      switch (e.op) {
        case '+': return a + b; case '-': return a - b; case '*': return a * b; case '/': return b === 0 ? 0 : a / b;
        case '<': return a < b ? 1 : 0; case '<=': return a <= b ? 1 : 0; case '>': return a > b ? 1 : 0; case '>=': return a >= b ? 1 : 0;
        case '==': return Math.abs(a - b) < 1e-6 ? 1 : 0; case '!=': return Math.abs(a - b) >= 1e-6 ? 1 : 0;
        default: return 0;
      }
    }
    case '?': return truth(ev(r, e.c)) ? ev(r, e.a) : e.b ? ev(r, e.b) : 0;
    case '??': if (e.l.k === 'var') { const v = rget(r, e.l.s, e.l.n); return v === undefined ? ev(r, e.r) : v; } return ev(r, e.l);
    case '=': { const v = ev(r, e.e); rset(r, e.s, e.n, v); return v; }
    case 'blk': { const f = stmts(r, e.list); return f === undefined ? 0 : f; }
    default: return 0;
  }
}
function call(r, name, args) {
  const f = r.funcs.get(name);
  if (!f) return r.q(name, args);
  if (r.depth >= 24) return 0;
  const sa = r.args, st = r.temps;
  r.args = new Map(); r.temps = new Map();
  f[0].forEach((p, i) => r.args.set(p, args[i] || 0));
  r.depth++; const out = valueOf(r, f[1].stmts); r.depth--;
  r.args = sa; r.temps = st;
  return out;
}
function math(r, n, a) {
  const x = (i) => a[i] || 0;
  switch (n) {
    case 'abs': return Math.abs(x(0));
    case 'sin': return Math.sin(x(0) * RAD);
    case 'cos': return Math.cos(x(0) * RAD);
    case 'tan': return Math.tan(x(0) * RAD);
    case 'asin': return Math.asin(Math.max(-1, Math.min(1, x(0)))) / RAD;
    case 'acos': return Math.acos(Math.max(-1, Math.min(1, x(0)))) / RAD;
    case 'atan': return Math.atan(x(0)) / RAD;
    case 'atan2': return Math.atan2(x(0), x(1)) / RAD;
    case 'ceil': return Math.ceil(x(0));
    case 'floor': return Math.floor(x(0));
    case 'round': return Math.round(x(0));
    case 'trunc': return Math.trunc(x(0));
    case 'clamp': return Math.min(Math.max(x(0), x(1)), x(2));
    case 'exp': return Math.exp(x(0));
    case 'ln': return x(0) > 0 ? Math.log(x(0)) : 0;
    case 'lerp': return x(0) + (x(1) - x(0)) * x(2);
    case 'lerprotate': { let d = (x(1) - x(0)) % 360; if (d > 180) d -= 360; if (d < -180) d += 360; return x(0) + d * x(2); }
    case 'inverse_lerp': { const d = x(1) - x(0); return d === 0 ? 0 : (x(2) - x(0)) / d; }
    case 'hermite_blend': { const t = x(0); return 3 * t * t - 2 * t * t * t; }
    case 'max': return Math.max(x(0), x(1));
    case 'min': return Math.min(x(0), x(1));
    case 'mod': return x(1) === 0 ? 0 : x(0) % x(1);
    case 'pi': return Math.PI;
    case 'pow': return Math.pow(x(0), x(1));
    case 'sqrt': return Math.sqrt(Math.max(0, x(0)));
    case 'sign': return x(0) > 0 ? 1 : x(0) < 0 ? -1 : 0;
    case 'copy_sign': return Math.abs(x(0)) * (x(1) < 0 ? -1 : 1);
    case 'min_angle': { let d = x(0) % 360; if (d >= 180) d -= 360; if (d < -180) d += 360; return d; }
    case 'random': return x(0) + (x(1) - x(0)) * rand(r.vars);
    case 'random_integer': return Math.min(x(1), Math.floor(x(0) + (x(1) - x(0) + 1) * rand(r.vars)));
    case 'die_roll': { let s = 0; for (let i = 0; i < Math.min(64, Math.max(0, x(0) | 0)); i++) s += x(1) + (x(2) - x(1)) * rand(r.vars); return s; }
    case 'die_roll_integer': { let s = 0; for (let i = 0; i < Math.min(64, Math.max(0, x(0) | 0)); i++) s += Math.floor(x(1) + (x(2) - x(1) + 1) * rand(r.vars)); return s; }
    default: return 0;
  }
}
const newVars = () => ({ c: new Map(), v: new Map(), seed: 1 + Math.floor(Math.random() * 1e6) });
/** A program's value (its `return`, or its last expression). */
function run(p, vars, q, funcs) { if (p.c !== null && p.c !== undefined) return p.c; return valueOf(runner(vars, q, funcs), p.stmts); }
/** A script run for what it does to the variables. */
function exec(p, vars, q, funcs) { stmts(runner(vars, q, funcs), p.stmts); }

/* ---------------------------------------------------------------------------------------------- animations (anim.rs) */
function ease(name, x, arg) {
  const n = String(name || 'linear').toLowerCase();
  x = Math.max(0, Math.min(1, x));
  const PI = Math.PI, c1 = arg === undefined || arg === null ? 1.70158 : arg, c2 = c1 * 1.525, c3 = c1 + 1, c4 = 2 * PI / 3, c5 = 2 * PI / 4.5;
  const ob = (x) => { const n1 = 7.5625, d1 = 2.75; if (x < 1 / d1) return n1 * x * x; if (x < 2 / d1) { x -= 1.5 / d1; return n1 * x * x + .75; } if (x < 2.5 / d1) { x -= 2.25 / d1; return n1 * x * x + .9375; } x -= 2.625 / d1; return n1 * x * x + .984375; };
  switch (n) {
    case 'step': return x < 1 ? 0 : 1;
    case 'easeinsine': return 1 - Math.cos(x * PI / 2);
    case 'easeoutsine': return Math.sin(x * PI / 2);
    case 'easeinoutsine': return -(Math.cos(PI * x) - 1) / 2;
    case 'easeinquad': return x * x;
    case 'easeoutquad': return 1 - (1 - x) * (1 - x);
    case 'easeinoutquad': return x < .5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2;
    case 'easeincubic': return x * x * x;
    case 'easeoutcubic': return 1 - Math.pow(1 - x, 3);
    case 'easeinoutcubic': return x < .5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
    case 'easeinquart': return Math.pow(x, 4);
    case 'easeoutquart': return 1 - Math.pow(1 - x, 4);
    case 'easeinoutquart': return x < .5 ? 8 * Math.pow(x, 4) : 1 - Math.pow(-2 * x + 2, 4) / 2;
    case 'easeinquint': return Math.pow(x, 5);
    case 'easeoutquint': return 1 - Math.pow(1 - x, 5);
    case 'easeinoutquint': return x < .5 ? 16 * Math.pow(x, 5) : 1 - Math.pow(-2 * x + 2, 5) / 2;
    case 'easeinexpo': return x === 0 ? 0 : Math.pow(2, 10 * x - 10);
    case 'easeoutexpo': return x === 1 ? 1 : 1 - Math.pow(2, -10 * x);
    case 'easeinoutexpo': return x === 0 || x === 1 ? x : x < .5 ? Math.pow(2, 20 * x - 10) / 2 : (2 - Math.pow(2, -20 * x + 10)) / 2;
    case 'easeincirc': return 1 - Math.sqrt(Math.max(0, 1 - x * x));
    case 'easeoutcirc': return Math.sqrt(Math.max(0, 1 - (x - 1) * (x - 1)));
    case 'easeinoutcirc': return x < .5 ? (1 - Math.sqrt(Math.max(0, 1 - 4 * x * x))) / 2 : (Math.sqrt(Math.max(0, 1 - Math.pow(-2 * x + 2, 2))) + 1) / 2;
    case 'easeinback': return c3 * x * x * x - c1 * x * x;
    case 'easeoutback': return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
    case 'easeinoutback': return x < .5 ? (Math.pow(2 * x, 2) * ((c2 + 1) * 2 * x - c2)) / 2 : (Math.pow(2 * x - 2, 2) * ((c2 + 1) * (x * 2 - 2) + c2) + 2) / 2;
    case 'easeinelastic': return x === 0 || x === 1 ? x : -Math.pow(2, 10 * x - 10) * Math.sin((x * 10 - 10.75) * c4);
    case 'easeoutelastic': return x === 0 || x === 1 ? x : Math.pow(2, -10 * x) * Math.sin((x * 10 - .75) * c4) + 1;
    case 'easeinoutelastic': return x === 0 || x === 1 ? x : x < .5 ? -(Math.pow(2, 20 * x - 10) * Math.sin((20 * x - 11.125) * c5)) / 2 : (Math.pow(2, -20 * x + 10) * Math.sin((20 * x - 11.125) * c5)) / 2 + 1;
    case 'easeinbounce': return 1 - ob(1 - x);
    case 'easeoutbounce': return ob(x);
    case 'easeinoutbounce': return x < .5 ? (1 - ob(1 - 2 * x)) / 2 : (1 + ob(2 * x - 1)) / 2;
    default: return x;
  }
}
function vec3(v) {
  if (Array.isArray(v)) {
    const get = (i) => (i < v.length ? value(v[i]) : NUM(0));
    if (v.length === 1) { const p = get(0); return [p, p, p]; }
    return [get(0), get(1), get(2)];
  }
  if (typeof v === 'number' || typeof v === 'string') { const p = value(v); return [p, p, p]; }
  return null;
}
function channel(v) {
  if (v === undefined || v === null) return null;
  if (typeof v === 'object' && !Array.isArray(v)) {
    if (v.vector !== undefined) { const x = vec3(v.vector); return x ? { kind: 'v', x } : null; }
    const keys = [];
    for (const time of Object.keys(v)) {
      const t = parseFloat(time.trim()); if (!Number.isFinite(t)) continue;
      const val = v[time];
      let pre, post, e = 'linear', arg = null;
      if (val && typeof val === 'object' && !Array.isArray(val)) {
        const main = val.vector !== undefined ? vec3(val.vector) : null;
        const side = (s) => { if (val[s] === undefined) return main; const p = val[s]; return vec3(p && typeof p === 'object' && !Array.isArray(p) && p.vector !== undefined ? p.vector : p) || main; };
        pre = side('pre'); post = side('post');
        e = val.easing || val.lerp_mode || 'linear';
        if (Array.isArray(val.easingArgs) && typeof val.easingArgs[0] === 'number') arg = val.easingArgs[0];
        if (!pre || !post) continue;
      } else { const x = vec3(val); if (!x) continue; pre = x; post = x; }
      keys.push({ t, pre, post, e: String(e).toLowerCase(), arg });
    }
    keys.sort((a, b) => a.t - b.t);
    return keys.length ? { kind: 'k', keys } : null;
  }
  const x = vec3(v); return x ? { kind: 'v', x } : null;
}
const catmull = (p0, p1, p2, p3, t) => .5 * (2 * p1 + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t + (-p0 + 3 * p1 - 3 * p2 + p3) * t * t * t);
function chanAt(ch, t, cx) {
  if (!ch) return null;
  const e3 = (v) => [cx.run(v[0]), cx.run(v[1]), cx.run(v[2])];
  if (ch.kind === 'v') return e3(ch.x);
  const keys = ch.keys, first = keys[0];
  if (keys.length === 1 || t <= first.t) return e3(first.pre);
  const last = keys[keys.length - 1];
  if (t >= last.t) return e3(last.post);
  let i = 0; while (i < keys.length - 1 && !(t < keys[i + 1].t)) i++;
  const a = keys[i], b = keys[i + 1], x = (t - a.t) / Math.max(1e-6, b.t - a.t);
  if (a.e === 'catmullrom' || b.e === 'catmullrom') {
    const p0 = i > 0 ? e3(keys[i - 1].post) : e3(a.post), p1 = e3(a.post), p2 = e3(b.pre), p3 = keys[i + 2] ? e3(keys[i + 2].pre) : p2;
    return [0, 1, 2].map((k) => catmull(p0[k], p1[k], p2[k], p3[k], x));
  }
  const k = ease(b.e, x, b.arg), va = e3(a.post), vb = e3(b.pre);
  return [va[0] + (vb[0] - va[0]) * k, va[1] + (vb[1] - va[1]) * k, va[2] + (vb[2] - va[2]) * k];
}
function readAnimation(a) {
  const bones = new Map(); let longest = 0;
  for (const [name, m] of Object.entries(a.bones || {})) {
    const ba = { rotation: channel(m && m.rotation), position: channel(m && m.position), scale: channel(m && m.scale) };
    for (const c of [ba.rotation, ba.position, ba.scale]) if (c && c.kind === 'k') longest = Math.max(longest, c.keys[c.keys.length - 1].t);
    bones.set(name.toLowerCase(), ba);
  }
  const lp = a.loop, looping = lp === true || lp === 'true' ? 'loop' : lp === 'hold_on_last_frame' ? 'hold' : 'once';
  return { length: typeof a.animation_length === 'number' ? a.animation_length : longest, looping, bones };
}
const animTime = (a, t) => (a.looping === 'loop' && a.length > 0 ? ((t % a.length) + a.length) % a.length : Math.min(t, Math.max(0, a.length)));
function readAll(v) { const out = new Map(); for (const [n, a] of Object.entries((v && v.animations) || {})) out.set(n, readAnimation(a)); return out; }
function sample(a, t, cx, out, weight) {
  cx.animTime = t;
  for (const [name, b] of a.bones) {
    const r = chanAt(b.rotation, t, cx), p = chanAt(b.position, t, cx), s = chanAt(b.scale, t, cx);
    if (!r && !p && !s) continue;
    let e = out.get(name); if (!e) { e = { rot: [0, 0, 0], pos: [0, 0, 0], scale: [1, 1, 1] }; out.set(name, e); }
    if (r) for (let k = 0; k < 3; k++) e.rot[k] += r[k] * weight;
    if (p) for (let k = 0; k < 3; k++) e.pos[k] += p[k] * weight;
    if (s) for (let k = 0; k < 3; k++) e.scale[k] *= 1 + (s[k] - 1) * weight;
  }
}
function readMachine(v, anims) {
  const fallback = () => ({ single: ['main', 'idle', 'animation'].find((n) => anims.has(n)) || anims.keys().next().value || '' });
  if (!v) return fallback();
  if (v.name === 'single') return { single: typeof v.anim === 'string' ? v.anim : fallback().single };
  if (v.name === 'molang') {
    const list = [];
    for (const c of v.controllers || []) {
      const dt = c.default_transition_ticks !== undefined ? value(c.default_transition_ticks).c : 8;
      const states = (c.states || []).map((s) => ({ anim: s.anim || '', when: s.plays_when !== undefined ? value(s.plays_when) : NUM(1), ticks: s.transition_ticks !== undefined ? value(s.transition_ticks).c : null, ease: s.transition_easing || 'linear' }));
      list.push({ states, ticks: dt === null || dt === undefined ? 8 : dt });
    }
    return list.length ? { ctl: list } : fallback();
  }
  return fallback();
}
/** A companion's animations as what it does chooses them (companion.rs: machine): on the site it only stands about. */
function companionMachine(extra) {
  const states = [];
  const add = (state, v) => {
    if (typeof v === 'string') states.push([state, v, '1']);
    else if (v && typeof v === 'object') for (const [anim, cond] of Object.entries(v)) states.push([state, anim, typeof cond === 'string' ? cond : JSON.stringify(cond)]);
  };
  (extra.states || []).forEach((s, k) => add(k, s.animation));
  add(-1, extra.default_anim);
  return { ctl: [{ states: states.map(([st, anim, cond]) => ({ anim, when: safeParse(`query.companion_state == ${st} && (${cond})`, NUM(0)), ticks: null, ease: 'linear' })), ticks: 5 }] };
}
function poseAnims(machine, anims, playing, now, cx, out) {
  if (machine.single !== undefined) {
    if (!playing.length) playing.push({ now: 0, since: now, before: null, blend: 0, ease: null });
    const a = anims.get(machine.single);
    if (a) sample(a, animTime(a, now - playing[0].since), cx, out, 1);
    return;
  }
  const list = machine.ctl;
  while (playing.length < list.length) playing.push({ now: null, since: now, before: null, blend: 0, ease: null });
  list.forEach((c, ci) => {
    let chosen = c.states.findIndex((s) => cx.run(s.when) !== 0); if (chosen < 0) chosen = null;
    const p = playing[ci];
    if (chosen !== p.now) {
      if (p.now !== null && chosen !== null) { p.before = [p.now, p.since]; const s = c.states[chosen]; p.blend = (s.ticks !== null && s.ticks !== undefined ? s.ticks : c.ticks) / 20; p.ease = s.ease; }
      else p.before = null;
      p.now = chosen; p.since = now;
    }
    const into = p.blend > 0 ? Math.max(0, Math.min(1, (now - p.since) / p.blend)) : 1;
    const w = ease(p.ease || 'linear', into, null);
    const before = p.before, since = p.since, nowState = p.now;
    if (into >= 1) p.before = null;
    if (before && w < 1) { const a = anims.get(c.states[before[0]].anim); if (a) sample(a, animTime(a, now - before[1]), cx, out, 1 - w); }
    if (nowState !== null) { const a = anims.get(c.states[nowState].anim); if (a) sample(a, animTime(a, now - since), cx, out, before ? w : 1); }
  });
}

/* ---------------------------------------------------------------------------------------------- geometry (geo.rs) */
const PART = { root: 0, head: 1, body: 2, rarm: 3, larm: 4, rleg: 5, lleg: 6 };
function partOfBone(name) {
  switch (name.toLowerCase()) {
    case 'bipedhead': case 'armorhead': return PART.head;
    case 'bipedbody': case 'armorbody': return PART.body;
    case 'bipedrightarm': case 'armorrightarm': return PART.rarm;
    case 'bipedleftarm': case 'armorleftarm': return PART.larm;
    case 'bipedrightleg': case 'armorrightleg': case 'armorrightboot': return PART.rleg;
    case 'bipedleftleg': case 'armorleftleg': case 'armorleftboot': return PART.lleg;
    default: return null;
  }
}
const n3 = (v) => { if (!Array.isArray(v) || v.length < 3) return null; const r = v.slice(0, 3).map((x) => (typeof x === 'number' ? x : parseFloat(x))); return r.every(Number.isFinite) ? r : null; };
const numOf = (v, k, or) => (v && typeof v[k] === 'number' ? v[k] : or);
const FACES = ['east', 'west', 'up', 'down', 'south', 'north'];
function faceOf(name, v) {
  if (!v || !Array.isArray(v.uv) || !Array.isArray(v.uv_size)) return null;
  const u = v.uv[0], w = v.uv[1], su = v.uv_size[0], sv = v.uv_size[1];
  let r = [u, w, u + su, w + sv];
  if (name === 'up' || name === 'down') r = [r[2], r[3], r[0], r[1]];
  return [r, numOf(v, 'uv_rotation', 0)];
}
function boxFaces(u, v, s, mirror) {
  const w = Math.floor(s[0]), h = Math.floor(s[1]), d = Math.floor(s[2]);
  const list = [[[0, d], [d, h]], [[d + w, d], [d, h]], [[d + w, d], [-w, -d]], [[d + w * 2, 0], [-w, d]], [[d * 2 + w, d], [w, h]], [[d, d], [w, h]]];
  if (mirror) { for (const f of list) { f[0][0] += f[1][0]; f[1][0] = -f[1][0]; } const t = list[0]; list[0] = list[1]; list[1] = t; }
  return list.map(([from, size]) => [[u + from[0], v + from[1], u + from[0] + size[0], v + from[1] + size[1]], 0]);
}
function readGeo(geo) {
  const desc = geo.description || {};
  const texture = [numOf(desc, 'texture_width', 64), numOf(desc, 'texture_height', 64)];
  const raw = Array.isArray(geo.bones) ? geo.bones : null; if (!raw) return null;
  const names = raw.map((b) => b.name || '');
  const flip = (p) => [-p[0], p[1], p[2]];
  const bones = raw.map((b) => {
    const boneMirror = !!b.mirror;
    const cubes = [];
    for (const c of b.cubes || []) {
      const origin = n3(c.origin), size = n3(c.size); if (!origin || !size) continue;
      const inflate = numOf(c, 'inflate', 0);
      let faces;
      if (c.uv && typeof c.uv === 'object' && !Array.isArray(c.uv)) faces = FACES.map((n) => faceOf(n, c.uv[n]));
      else if (Array.isArray(c.uv)) faces = boxFaces(c.uv[0] || 0, c.uv[1] || 0, size, c.mirror !== undefined ? !!c.mirror : boneMirror);
      else faces = [null, null, null, null, null, null];
      const from = [-(origin[0] + size[0]), origin[1], origin[2]];
      cubes.push({ from: [from[0] - inflate, from[1] - inflate, from[2] - inflate], to: [from[0] + size[0] + inflate, from[1] + size[1] + inflate, from[2] + size[2] + inflate], faces, pivot: flip(n3(c.pivot) || [0, 0, 0]), rotation: n3(c.rotation) || [0, 0, 0] });
    }
    const parent = b.parent ? names.indexOf(b.parent) : -1;
    return { name: b.name || '', lname: (b.name || '').toLowerCase(), parent: parent >= 0 ? parent : null, pivot: flip(n3(b.pivot) || [0, 0, 0]), rotation: n3(b.rotation) || [0, 0, 0], cubes };
  });
  if (bones.every((b) => !b.cubes.length)) return null;
  return { texture, bones };
}
function readGeoFile(v) {
  if (v && Array.isArray(v['minecraft:geometry']) && v['minecraft:geometry'][0]) return readGeo(v['minecraft:geometry'][0]);
  if (!v || typeof v !== 'object') return null;
  const k = Object.keys(v).find((x) => x.startsWith('geometry.'));
  if (!k) return null;
  const g = { ...v[k] };
  if (!g.description) g.description = { texture_width: numOf(g, 'texturewidth', 64), texture_height: numOf(g, 'textureheight', 64) };
  return readGeo(g);
}
function boneMatrices(g, pose) {
  const world = [];
  g.bones.forEach((b, i) => {
    const parent = b.parent !== null && b.parent < i ? world[b.parent] : ident();
    const p = pose(i);
    const rot = [b.rotation[0] + p.rot[0], b.rotation[1] + p.rot[1], b.rotation[2] + p.rot[2]];
    const local = mul(translate(-p.pos[0], p.pos[1], p.pos[2]), about(b.pivot, mul(turn(rot), scale(p.scale))));
    world.push(mul(parent, local));
  });
  return world;
}
const NOPOSE = { rot: [0, 0, 0], pos: [0, 0, 0], scale: [1, 1, 1] };
const toModel = (p) => [-p[0], 1.501 - p[1], p[2]];
const NORMALS = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
/** A model's quads by part (8 numbers a corner, 4 corners a quad: x y z in the model's space, u v, normal). */
function geoMesh(g, world, place, share, dv, partOf, out) {
  const tw = g.texture[0], th = g.texture[1];
  g.bones.forEach((b, bi) => {
    if (!b.cubes.length) return;
    const part = partOf(bi);
    let slot = out.find((o) => o.part === part); if (!slot) { slot = { part, q: [] }; out.push(slot); }
    const m = mul(place, world[bi]);
    for (const c of b.cubes) {
      const cm = mul(m, about(c.pivot, turn(c.rotation)));
      const f0 = c.from, t0 = c.to;
      const corners = [
        [[t0[0], t0[1], t0[2]], [t0[0], t0[1], f0[2]], [t0[0], f0[1], t0[2]], [t0[0], f0[1], f0[2]]],
        [[f0[0], t0[1], f0[2]], [f0[0], t0[1], t0[2]], [f0[0], f0[1], f0[2]], [f0[0], f0[1], t0[2]]],
        [[f0[0], t0[1], f0[2]], [t0[0], t0[1], f0[2]], [f0[0], t0[1], t0[2]], [t0[0], t0[1], t0[2]]],
        [[f0[0], f0[1], t0[2]], [t0[0], f0[1], t0[2]], [f0[0], f0[1], f0[2]], [t0[0], f0[1], f0[2]]],
        [[f0[0], t0[1], t0[2]], [t0[0], t0[1], t0[2]], [f0[0], f0[1], t0[2]], [t0[0], f0[1], t0[2]]],
        [[t0[0], t0[1], f0[2]], [f0[0], t0[1], f0[2]], [t0[0], f0[1], f0[2]], [f0[0], f0[1], f0[2]]],
      ];
      for (let f = 0; f < 6; f++) {
        const face = c.faces[f]; if (!face) continue;
        const [u0, v0, u1, v1] = face[0]; if (u0 === u1 && v0 === v1) continue;
        let n = apply(cm, NORMALS[f], 0); const nl = Math.max(1e-6, Math.hypot(n[0], n[1], n[2])); n = [n[0] / nl, n[1] / nl, n[2] / nl];
        let uvs = [[u0, v0], [u1, v0], [u0, v1], [u1, v1]];
        for (let r = face[1]; r > 0; r -= 90) uvs = [uvs[2], uvs[0], uvs[3], uvs[1]];
        for (const k of [0, 2, 3, 1]) {
          const v = toModel(apply(cm, corners[f][k], 1));
          slot.q.push(v[0], v[1], v[2], uvs[k][0] / tw, uvs[k][1] / th * share + dv, -n[0], -n[1], n[2]);
        }
      }
    }
  });
}

/* ---------------------------------------------------------------------------------------------- OBJ (obj.rs) */
function parseObj(text) {
  const pos = [], uv = [], nor = [], quads = [];
  for (const line of text.split('\n')) {
    const it = line.trim().split(/\s+/);
    const head = it[0];
    if (head === 'v') pos.push([+it[1] || 0, +it[2] || 0, +it[3] || 0]);
    else if (head === 'vt') uv.push([+it[1] || 0, +it[2] || 0]);
    else if (head === 'vn') nor.push([+it[1] || 0, +it[2] || 0, +it[3] || 0]);
    else if (head === 'f') {
      const at = (s, len) => { const n = parseInt(s, 10); if (!Number.isFinite(n)) return -1; const k = n < 0 ? len + n : n - 1; return k >= 0 && k < len ? k : -1; };
      const corners = [];
      for (const c of it.slice(1)) {
        const parts = c.split('/'); const pi = at(parts[0], pos.length); if (pi < 0) continue;
        const ti = parts[1] ? at(parts[1], uv.length) : -1, ni = parts[2] ? at(parts[2], nor.length) : -1;
        const p = pos[pi], t = ti >= 0 ? uv[ti] : [0, 0], n = ni >= 0 ? nor[ni] : [0, 1, 0];
        corners.push([p[0], p[1], p[2], t[0], 1 - t[1], n[0], n[1], n[2]]);
      }
      if (corners.length === 3) quads.push(corners[0], corners[1], corners[2], corners[2]);
      else if (corners.length === 4) quads.push(...corners);
      else for (let k = 1; k < corners.length - 1; k++) quads.push(corners[0], corners[k], corners[k + 1], corners[k + 1]);
    }
  }
  return quads;
}

/* ---------------------------------------------------------------------------------------------- dragon wings (dragon.rs) */
function javaBox(tex, u, v, x, y, z, w, h, d, mirror) {
  let x0 = x, x1 = x + w; const y0 = y, y1 = y + h, z0 = z, z1 = z + d;
  if (mirror) { const t = x0; x0 = x1; x1 = t; }
  const v7 = [x0, y0, z0], v0 = [x1, y0, z0], v1 = [x1, y1, z0], v2 = [x0, y1, z0], v3 = [x0, y0, z1], v4 = [x1, y0, z1], v5 = [x1, y1, z1], v6 = [x0, y1, z1];
  const f4 = u, f5 = u + d, f6 = u + d + w, f7 = u + d + w + w, f8 = u + d + w + d, f9 = u + d + w + d + w, f10 = v, f11 = v + d, f12 = v + d + h;
  const faces = [
    [[v4, v3, v7, v0], [f5, f10, f6, f11], [0, -1, 0]], [[v1, v2, v6, v5], [f6, f11, f7, f10], [0, 1, 0]],
    [[v7, v3, v6, v2], [f4, f11, f5, f12], [-1, 0, 0]], [[v0, v7, v2, v1], [f5, f11, f6, f12], [0, 0, -1]],
    [[v4, v0, v1, v5], [f6, f11, f8, f12], [1, 0, 0]], [[v3, v4, v5, v6], [f8, f11, f9, f12], [0, 0, 1]],
  ];
  return faces.map(([c, [u1, v1, u2, v2], n]) => {
    let q = [[...c[0], u2 / tex[0], v1 / tex[1]], [...c[1], u1 / tex[0], v1 / tex[1]], [...c[2], u1 / tex[0], v2 / tex[1]], [...c[3], u2 / tex[0], v2 / tex[1]]];
    let nn = n;
    if (mirror) { q = q.reverse(); if (nn[0] !== 0) nn = [-nn[0], nn[1], nn[2]]; }
    return [q, nn];
  });
}
const partM = (x, y, z, xr, yr, zr) => mul(translate(x, y, z), mul(rotZ(zr / RAD), mul(rotY(yr / RAD), rotX(xr / RAD))));
function dragonMesh(t, speed, share, dv, out) {
  const tex = [256, 256], f = t * Math.PI * 2 * .3 * speed;
  const lx = .125 - Math.cos(f) * .2, ly = -.25, lz = -(Math.sin(f) + .125) * .8, ltip = Math.sin(f + 2) * .75 + .5 * .75;
  const base = mul(translate(0, -1.5, 2.2), mul(rotX(-1.3 / RAD), scale([.2, .2, .2])));
  const q = [];
  const emit = (m, boxes) => {
    for (const [quad, n] of boxes) {
      const nn = apply(m, n, 0), l = Math.max(1e-6, Math.hypot(nn[0], nn[1], nn[2]));
      for (const c of quad) { const p = apply(m, [c[0], c[1], c[2]], 1); q.push(p[0] / 16, p[1] / 16, p[2] / 16, c[3], c[4] * share + dv, nn[0] / l, nn[1] / l, nn[2] / l); }
    }
  };
  for (const side of [-1, 1]) {
    const left = side > 0;
    const wing = mul(base, partM(side * 1.5, 0, 0, lx, (ly - .3) * side, (lz + .5) * side));
    const tip = mul(wing, partM(side * 56, 0, 0, 0, 0, ltip * side));
    const bx = left ? 0 : -56;
    emit(wing, [...javaBox(tex, 112, 88, bx, -4, -4, 56, 8, 8, left), ...javaBox(tex, -56, 88, bx, 0, 2, 56, 0, 56, left)]);
    emit(tip, [...javaBox(tex, 112, 136, bx, -2, -2, 56, 4, 4, left), ...javaBox(tex, -56, 144, bx, 0, 2, 56, 0, 56, left)]);
  }
  out.push({ part: PART.body, q });
}

/* ---------------------------------------------------------------------------------------------- the pack (pack.rs) */
const FILES = new Map();
const fileUrl = (sha) => `/cos/f/${sha.slice(0, 2)}/${sha}`;
function file(sha, as) {
  const key = as + ':' + sha;
  if (!FILES.has(key)) {
    FILES.set(key, fetch(fileUrl(sha)).then((r) => {
      if (!r.ok) throw new Error('file ' + r.status);
      if (as === 'json') return r.json();
      if (as === 'text') return r.text();
      return r.blob().then((b) => createImageBitmap(b));
    }));
    FILES.get(key).catch(() => FILES.delete(key));
  }
  return FILES.get(key);
}
let CATALOG = null, MOLANG = null;
function catalog() {
  if (!CATALOG) {
    CATALOG = fetch('/api/cosmetics', { credentials: 'same-origin' }).then((r) => { if (!r.ok) throw new Error('catalog ' + r.status); return r.json(); }).then((c) => {
      const byId = new Map(); for (const it of c.items) byId.set(it.id, it);
      return { items: c.items, byId, molang: c.molang || {}, emotes: c.emotes };
    });
    CATALOG.catch(() => { CATALOG = null; });
  }
  return CATALOG;
}
function molang() {
  if (!MOLANG) {
    MOLANG = catalog().then((c) => Promise.all([c.molang.constants ? file(c.molang.constants, 'text') : '', c.molang.functions ? file(c.molang.functions, 'text') : '']))
      .then(([cs, fs]) => ({ constants: safeParse(cs), funcs: parseFunctions(fs) }));
    MOLANG.catch(() => { MOLANG = null; });
  }
  return MOLANG;
}
const formOf = (it) => (it.cloak ? 'cloak' : it.gek ? 'gek' : it.dragon ? 'dragon' : it.indexed ? 'indexed' : '');
const texOf = (it) => { const f = it.cloak || it.gek || it.dragon || it.indexed; return f ? { sha: f.tex, frames: f.frames || null } : null; };
function placing(tf) {
  let m = ident();
  for (const t of Array.isArray(tf) ? tf : []) {
    let v = t.values || {};
    if (v.player) v = v.player; else if (!(v.x !== undefined || v.angle !== undefined)) continue;
    const n = (k, or) => (typeof v[k] === 'number' ? v[k] : or);
    let step;
    if (t.transformType === 'translate') step = translate(n('x', 0), n('y', 0), n('z', 0));
    else if (t.transformType === 'scale') step = scale([n('x', 1), n('y', 1), n('z', 1)]);
    else if (t.transformType === 'rotate') step = rotation(n('angle', 0), [n('x', 0), n('y', 0), n('z', 0)]);
    else continue;
    m = mul(m, step);
  }
  return m;
}
const partNamed = (s) => ({ HEAD: PART.head, RIGHT_ARM: PART.rarm, LEFT_ARM: PART.larm, RIGHT_LEG: PART.rleg, LEFT_LEG: PART.lleg }[String(s || '').toUpperCase()] || PART.body);
const MODELS = new Map();
/** An item, read and ready to pose (lunar.rs: Model::build). */
function model(id) {
  if (!MODELS.has(id)) {
    const p = (async () => {
      const cat = await catalog(); const it = cat.byId.get(id); if (!it) throw new Error('no item');
      const form = formOf(it), tex = texOf(it);
      const picture = await file(tex.sha, 'img');
      const m = { id, name: it.name, kind: it.kind, form, tex, size: [picture.width, picture.height], picture, mode: 0, hides: 0, held: null, options: [], specs: [], cardPlace: null };
      if (form === 'cloak') m.shape = { kind: 'cloak' };
      else if (form === 'dragon') m.shape = { kind: 'dragon' };
      else if (form === 'indexed') {
        const x = it.indexed, part = partNamed(x.part);
        const quads = parseObj(await file(x.obj, 'text'));
        const place = part === PART.head ? mul(rotation(90, [0, 1, 0]), placing(x.tf)) : placing(x.tf);
        m.shape = { kind: 'obj', quads, part, place };
      } else if (form === 'gek') {
        const g = it.gek, ml = await molang();
        const variants = [];
        for (const [sha, cond] of g.models || []) { const geo = readGeoFile(await file(sha, 'json')); if (geo) variants.push([safeParse(cond || '1', NUM(1)), geo]); }
        if (!variants.length) throw new Error('no geometry');
        const anims = g.anim ? readAll(await file(g.anim, 'json')) : new Map();
        const machine = it.kind === 'companion' ? companionMachine(g) : readMachine(g.sm, anims);
        if (g.is_translucent === true) m.mode = 1;
        if (g.emissive_texture === true) m.mode = 2;
        ['hide_head', 'hide_body', 'hide_right_arm', 'hide_left_arm', 'hide_right_leg', 'hide_left_leg'].forEach((k, i) => { if (g[k] === true) m.hides |= 1 << i; });
        const ht = String(g.item_render_type || '');
        if (ht === 'SHIELD' || ht === 'SWORD' || ht === 'SHOVEL' || it.kind === 'hand') m.held = ht || 'EMPTY';
        for (const o of g.cosmetic_options || []) {
          if (typeof o.molang_query !== 'string') continue;
          const name = o.molang_query.replace(/^option\.|^o\./, '');
          const def = typeof o.default === 'boolean' ? (o.default ? 1 : 0) : typeof o.default === 'number' ? o.default : 0;
          m.options.push(['option.' + name, def]);
          const label = String(o.id || name); const range = o.type !== 'boolean' && typeof o.min === 'number' && typeof o.max === 'number' && o.max > o.min ? [o.min, o.max] : null;
          m.specs.push({ name: 'option.' + name, label: label.charAt(0).toUpperCase() + label.slice(1).toLowerCase(), range, def });
        }
        const attach = { HEAD: PART.head, RIGHT_ARM: PART.rarm, LEFT_ARM: PART.larm }[String(g.bone || '')] || PART.body;
        const place = placing(g.tf);
        m.shape = { kind: 'geo', variants, anims, machine, attach, place, ml };
        if (Math.abs(det3(place)) < 1e-9) m.cardPlace = ident();
      }
      return m;
    })();
    MODELS.set(id, p);
    p.catch(() => {});
  }
  return MODELS.get(id);
}
function frameOffset(m, t) {
  const f = m.tex.frames; if (!f || !f.h || !m.size[1]) return 0;
  const count = Math.max(1, Math.floor(m.size[1] / f.h));
  const tick = Math.floor(t * 20 / Math.max(1, f.t || 1));
  const frame = f.order && f.order.length ? f.order[tick % f.order.length] % count : tick % count;
  return frame * f.h / m.size[1];
}
const frameShare = (m) => { const f = m.tex.frames; return f && f.h && m.size[1] ? f.h / m.size[1] : 1; };

/* ---------------------------------------------------------------------------------------------- the player asked */
/** What an item's Molang asks of the player (lunar.rs: Player::query): the stage's player, standing or walking. */
function playerQuery(p) {
  return (name, args) => {
    const i = name.indexOf('_smooth'); if (i > 0) name = name.slice(0, i);
    if (name.startsWith('option.')) { const o = p.options && p.options.find((x) => x[0] === name); return o ? o[1] : 0; }
    switch (name) {
      case 'life_time': case 'time_stamp': return p.t;
      case 'ground_speed': case 'modified_move_speed': case 'instant_ground_speed': case 'ground_speed_smoothed': return p.speed;
      case 'x_velocity': case 'local_x_velocity': return 0;
      case 'z_velocity': case 'local_z_velocity': return p.speed / 20;
      case 'y_velocity': case 'vertical_speed': case 'instant_y_velocity': return 0;
      case 'is_on_ground': return 1;
      case 'is_moving': return p.speed > .25 ? 1 : 0;
      case 'is_running': case 'is_sprinting': return p.run ? 1 : 0;
      case 'head_x_rotation': return p.headPitch;
      case 'head_y_rotation': return p.headYaw;
      case 'is_slim_model': return p.slim ? 1 : 0;
      case 'is_in_gui': case 'is_in_preview_model': case 'is_in_ui': return p.gui ? 1 : 0;
      case 'absolute_speed': return p.speed / 20;
      case 'right_arm_x_rotation': return p.rarm[0];
      case 'right_arm_y_rotation': return p.rarm[1];
      case 'right_arm_z_rotation': return p.rarm[2];
      case 'left_arm_x_rotation': return p.larm[0];
      case 'left_arm_y_rotation': return p.larm[1];
      case 'left_arm_z_rotation': return p.larm[2];
      case 'right_leg_x_rotation': return p.rleg;
      case 'left_leg_x_rotation': return p.lleg;
      case 'is_alive': return 1;
      case 'health': case 'max_health': return 20;
      case 'companion_state': return -1;
      case 'owner_distance': return 2;
      default: return 0;
    }
  };
}

/** An item posed at `t`: its quads by part (lunar.rs: pose_in). `inst` keeps its variables and states from frame to frame. */
function poseItem(m, inst, p, out, thumb) {
  const dv = frameOffset(m, p.t), share = frameShare(m), sh = m.shape;
  if (sh.kind === 'dragon') dragonMesh(p.t, p.speed > 3 ? 1.6 : 1, share, dv, out);
  else if (sh.kind === 'obj') {
    const q = [];
    for (const c of sh.quads) {
      const v = apply(sh.place, [c[0], c[1], c[2]], 1), n = apply(sh.place, [c[5], c[6], c[7]], 0), l = Math.max(1e-6, Math.hypot(n[0], n[1], n[2]));
      q.push(v[0], v[1], v[2], c[3], c[4] * share + dv, n[0] / l, n[1] / l, n[2] / l);
    }
    out.push({ part: sh.part, q });
  } else if (sh.kind === 'geo') {
    const place = thumb && m.cardPlace ? m.cardPlace : sh.place;
    if (p.t < inst.last || p.t - inst.last > 2) inst.playing = [];
    inst.last = p.t;
    // the item's own settings: as set (the wardrobe, a look), else its file's
    const asked = playerQuery({ ...p, options: inst.options ? m.options.map(([n, v]) => { const o = inst.options.find((x) => x[0] === n); return o ? [n, o[1]] : [n, v]; }) : m.options });
    exec(sh.ml.constants, inst.vars, asked, sh.ml.funcs);
    const cx = { animTime: 0, run: (prog) => run(prog, inst.vars, (n, a) => (n === 'anim_time' ? cx.animTime : asked(n, a)), sh.ml.funcs) };
    const v = sh.variants.find(([c]) => cx.run(c) !== 0); const g = (v || sh.variants[0])[1];
    const poses = new Map();
    poseAnims(sh.machine, sh.anims, inst.playing, p.t, cx, poses);
    const world = boneMatrices(g, (i) => poses.get(g.bones[i].lname) || NOPOSE);
    const parts = g.bones.map((b, i) => { let at = i; while (at !== null && at !== undefined) { const pt = partOfBone(g.bones[at].name); if (pt !== null) return pt; at = g.bones[at].parent; } return sh.attach; });
    const pieces = [];
    geoMesh(g, world, scale([1 / 16, 1 / 16, 1 / 16]), share, dv, (i) => parts[i], pieces);
    for (const pc of pieces) {
      for (let k = 0; k < pc.q.length; k += 8) {
        const v3 = apply(place, [pc.q[k], pc.q[k + 1], pc.q[k + 2]], 1), n = apply(place, [pc.q[k + 5], pc.q[k + 6], pc.q[k + 7]], 0);
        pc.q[k] = v3[0]; pc.q[k + 1] = v3[1]; pc.q[k + 2] = v3[2]; pc.q[k + 5] = n[0]; pc.q[k + 6] = n[1]; pc.q[k + 7] = n[2];
      }
      out.push(pc);
    }
  }
}
const newInst = () => ({ vars: newVars(), playing: [], last: 0, options: null });

/* ---------------------------------------------------------------------------------------------- the player's own body */
/* The game's player model (PlayerModel): each part a pivot (pixels, the model's space) and its cubes from there; the
   skin's corners of each cube on the 64 × 64 picture, and the outer layer a little bigger. */
function bodyParts(slim) {
  const aw = slim ? 3 : 4, ay = slim ? 2.5 : 2;
  return [
    { part: PART.head, pivot: [0, 0, 0], cubes: [[0, 0, -4, -8, -4, 8, 8, 8, 0], [32, 0, -4, -8, -4, 8, 8, 8, .5]] },
    { part: PART.body, pivot: [0, 0, 0], cubes: [[16, 16, -4, 0, -2, 8, 12, 4, 0], [16, 32, -4, 0, -2, 8, 12, 4, .25]] },
    { part: PART.rarm, pivot: [-5, ay, 0], cubes: [[40, 16, slim ? -2 : -3, -2, -2, aw, 12, 4, 0], [40, 32, slim ? -2 : -3, -2, -2, aw, 12, 4, .25]] },
    { part: PART.larm, pivot: [5, ay, 0], cubes: [[32, 48, -1, -2, -2, aw, 12, 4, 0], [48, 48, -1, -2, -2, aw, 12, 4, .25]] },
    { part: PART.rleg, pivot: [-1.9, 12, 0], cubes: [[0, 16, -2, 0, -2, 4, 12, 4, 0], [0, 32, -2, 0, -2, 4, 12, 4, .25]] },
    { part: PART.lleg, pivot: [1.9, 12, 0], cubes: [[16, 48, -2, 0, -2, 4, 12, 4, 0], [0, 48, -2, 0, -2, 4, 12, 4, .25]] },
  ];
}
/** The pose of the player's parts (radians, as the game's model has them) at `t`: standing, walking, running, waving. */
function bodyPose(state, t) {
  const P = {};
  const z3 = () => [0, 0, 0];
  for (const k of ['head', 'body', 'rarm', 'larm', 'rleg', 'lleg']) P[k] = z3();
  const age = t * 20;
  const walk = state.speed > .1 ? (state.run ? 1 : .8) : 0;
  const pos = state.walked * .6662;
  P.rarm[0] = Math.cos(pos + Math.PI) * 2 * walk * .5;
  P.larm[0] = Math.cos(pos) * 2 * walk * .5;
  P.rleg[0] = Math.cos(pos) * 1.4 * walk;
  P.lleg[0] = Math.cos(pos + Math.PI) * 1.4 * walk;
  // the arms breathe (AnimationUtils.bobArms)
  P.rarm[2] += Math.cos(age * .09) * .05 + .05; P.larm[2] -= Math.cos(age * .09) * .05 + .05;
  P.rarm[0] += Math.sin(age * .067) * .05; P.larm[0] -= Math.sin(age * .067) * .05;
  if (state.wave) { const w = Math.sin(t * 7); P.rarm[0] = -2.9; P.rarm[2] = -.25 + w * .28; P.rarm[1] = -.15; }
  P.head[1] = state.headYaw * RAD; P.head[0] = state.headPitch * RAD;
  return P;
}
const PIVOT0 = (slim) => ({ [PART.head]: [0, 0, 0], [PART.body]: [0, 0, 0], [PART.rarm]: [-5, slim ? 2.5 : 2, 0], [PART.larm]: [5, slim ? 2.5 : 2, 0], [PART.rleg]: [-1.9, 12, 0], [PART.lleg]: [1.9, 12, 0] });
/** Each part's place this moment (the model's space, blocks): turned about where it stands, as ModelPart.translateAndRotate. */
function partMatrices(pose, slim) {
  const piv = PIVOT0(slim), key = { [PART.head]: 'head', [PART.body]: 'body', [PART.rarm]: 'rarm', [PART.larm]: 'larm', [PART.rleg]: 'rleg', [PART.lleg]: 'lleg' };
  const out = { [PART.root]: ident() };
  for (const k of [PART.head, PART.body, PART.rarm, PART.larm, PART.rleg, PART.lleg]) {
    const p = piv[k], r = pose[key[k]];
    const R = mul(rotZ(r[2] / RAD), mul(rotY(r[1] / RAD), rotX(r[0] / RAD)));
    out[k] = { at: mul(translate(p[0] / 16, p[1] / 16, p[2] / 16), R), from: translate(-p[0] / 16, -p[1] / 16, -p[2] / 16) };
  }
  return out;
}
/* The outer layer is the inner cube grown (CubeDeformation): laid out on the picture at its own size, only its corners
   pushed out; javaBox would take a bigger rectangle for a bigger cube. */
function cubeQuads(tex, u, v, x, y, z, w, h, d, grow, mirror) {
  const base = javaBox(tex, u, v, x, y, z, w, h, d, mirror);
  if (!grow) return base;
  const cx = x + w / 2, cy = y + h / 2, cz = z + d / 2;
  const sx = (w + 2 * grow) / w, sy = (h + 2 * grow) / h, sz = (d + 2 * grow) / Math.max(d, 1e-6);
  return base.map(([q, n]) => [q.map((c) => [cx + (c[0] - cx) * sx, cy + (c[1] - cy) * sy, cz + (c[2] - cz) * (d ? sz : 1), c[3], c[4]]), n]);
}
/** The skin's quads, posed (the model's space). `hides` the parts something worn takes the place of. */
function skinQuads(slim, mats, hides, out) {
  for (const bp of bodyParts(slim)) {
    const bit = { [PART.head]: 0, [PART.body]: 1, [PART.rarm]: 2, [PART.larm]: 3, [PART.rleg]: 4, [PART.lleg]: 5 }[bp.part];
    if (hides & (1 << bit)) continue;
    const m = mats[bp.part].at;
    bp.cubes.forEach(([u, v, x, y, z, w, h, d, g]) => {
      const q = [];
      for (const [quad, n] of cubeQuads([64, 64], u, v, x, y, z, w, h, d, g, false)) {
        const nn = apply(m, n, 0);
        for (const c of quad) { const pp = apply(m, [c[0] / 16, c[1] / 16, c[2] / 16], 1); q.push(pp[0], pp[1], pp[2], c[3], c[4], nn[0], nn[1], nn[2]); }
      }
      out.push({ q, over: g > 0 });
    });
  }
}
/** The cape (PlayerCapeModel): behind the body, its top at the shoulders, swinging back as it moves. `units` the picture's
   size in the cape's own units: 22 × 17 for a cloak of the pack (its frames), 64 × 32 for a Mojang cape. */
function capeQuads(mats, units, share, dv, angle, out) {
  const body = mats[PART.body].at;
  const hinge = mul(body, mul(translate(0, 0, 2 / 16), mul(rotX(angle), rotY(180))));
  const q = [];
  for (const [quad, n] of javaBox(units, 0, 0, -5, 0, -1, 10, 16, 1, false)) {
    const nn = apply(hinge, n, 0);
    for (const c of quad) { const pp = apply(hinge, [c[0] / 16, c[1] / 16, c[2] / 16], 1); q.push(pp[0], pp[1], pp[2], c[3], c[4] * share + dv, nn[0], nn[1], nn[2]); }
  }
  out.push(q);
}

/** The cape as cloth: ten strips down from the shoulders, each turned a little more than the one above, a wave running
   down them; still it hangs, walking and running it flies back. The picture is the cape's own (the same layout as
   `capeQuads`: the outer side 1…11 × 1…17 of its units, the inner 12…22, the edges 0…1 and 11…12, the top 1…11 × 0…1). */
function capeCloth(mats, units, share, dv, t, speed, out) {
  const N = 10, L = 16 / N, mv = Math.min(1, speed / 4.3), run = speed > 5 ? 1 : 0;
  const hinge = mul(mats[PART.body].at, translate(0, 0, 2 / 16));
  // the spine: each strip's angle from straight down (degrees; more is further back)
  const ang = [], J = [[0, 0]];
  for (let i = 0; i < N; i++) {
    const k = (i + 1) / N;
    const a = 5 + Math.sin(t * 1.25 - i * .32) * 2.2 * (.4 + k) + mv * (22 + run * 18) * Math.pow(k, 1.3) + mv * Math.sin(t * (7 + run * 4) - i * .7) * (5 + run * 4) * k;
    ang.push(a);
    const r = a * RAD, p = J[i];
    J.push([p[0] + L * Math.cos(r), p[1] + L * Math.sin(r)]);
  }
  const U = (u) => u / units[0], V = (v) => (v / units[1]) * share + dv, q = [];
  const put = (pts, uvs, n) => {
    const nn = apply(hinge, n, 0), l = Math.max(1e-6, Math.hypot(nn[0], nn[1], nn[2]));
    for (let k = 0; k < 4; k++) { const p = apply(hinge, [pts[k][0] / 16, pts[k][1] / 16, pts[k][2] / 16], 1); q.push(p[0], p[1], p[2], uvs[k][0], uvs[k][1], nn[0] / l, nn[1] / l, nn[2] / l); }
  };
  for (let i = 0; i < N; i++) {
    const [y0, z0] = J[i], [y1, z1] = J[i + 1], r = ang[i] * RAD;
    // the strip's back (away from the body): the spine pushed out by the cloth's thickness
    const ny = -Math.sin(r), nz = Math.cos(r);
    const o = (y, z) => [y + ny, z + nz];
    const [oy0, oz0] = o(y0, z0), [oy1, oz1] = o(y1, z1);
    const va = 1 + i * L, vb = 1 + (i + 1) * L;
    // outside: the cape's picture (x mirrored as the cape model turns it round)
    put([[-5, oy0, oz0], [5, oy0, oz0], [5, oy1, oz1], [-5, oy1, oz1]], [[U(11), V(va)], [U(1), V(va)], [U(1), V(vb)], [U(11), V(vb)]], [0, ny, nz]);
    // inside, toward the back
    put([[5, y0, z0], [-5, y0, z0], [-5, y1, z1], [5, y1, z1]], [[U(22), V(va)], [U(12), V(va)], [U(12), V(vb)], [U(22), V(vb)]], [0, -ny, -nz]);
    // the edges
    put([[-5, y0, z0], [-5, oy0, oz0], [-5, oy1, oz1], [-5, y1, z1]], [[U(12), V(va)], [U(11), V(va)], [U(11), V(vb)], [U(12), V(vb)]], [-1, 0, 0]);
    put([[5, oy0, oz0], [5, y0, z0], [5, y1, z1], [5, oy1, oz1]], [[U(1), V(va)], [U(0), V(va)], [U(0), V(vb)], [U(1), V(vb)]], [1, 0, 0]);
    if (i === 0) put([[-5, y0, z0], [5, y0, z0], [5, oy0, oz0], [-5, oy0, oz0]], [[U(11), V(0)], [U(1), V(0)], [U(1), V(1)], [U(11), V(1)]], [0, -1, 0]);
    if (i === N - 1) put([[-5, oy1, oz1], [5, oy1, oz1], [5, y1, z1], [-5, y1, z1]], [[U(21), V(0)], [U(11), V(0)], [U(11), V(1)], [U(21), V(1)]], [0, 1, 0]);
  }
  out.push(q);
}

/* ---------------------------------------------------------------------------------------------- emotes (emote.rs) */
/* The player's body as a mesh on bones (Blockbuster's OBJ, McHorse's emotes), moved by Bézier curves frame by frame
   (twenty a second), with props that come out at their moment. On the site each emote's moves come alone (/cos/e/:
   split_emotes.py cuts them out of the pack's big files), the bodies and the props from there too, compressed. */
function rowMajor(v) { const m = new Array(16); for (let r = 0; r < 4; r++) for (let c = 0; c < 4; c++) m[c * 4 + r] = v[r * 4 + c]; return m; }
function invert(m) {
  const a = (r, c) => m[c * 4 + r];
  const s0 = a(0, 0) * a(1, 1) - a(1, 0) * a(0, 1), s1 = a(0, 0) * a(1, 2) - a(1, 0) * a(0, 2), s2 = a(0, 0) * a(1, 3) - a(1, 0) * a(0, 3);
  const s3 = a(0, 1) * a(1, 2) - a(1, 1) * a(0, 2), s4 = a(0, 1) * a(1, 3) - a(1, 1) * a(0, 3), s5 = a(0, 2) * a(1, 3) - a(1, 2) * a(0, 3);
  const c5 = a(2, 2) * a(3, 3) - a(3, 2) * a(2, 3), c4 = a(2, 1) * a(3, 3) - a(3, 1) * a(2, 3), c3 = a(2, 1) * a(3, 2) - a(3, 1) * a(2, 2);
  const c2 = a(2, 0) * a(3, 3) - a(3, 0) * a(2, 3), c1 = a(2, 0) * a(3, 2) - a(3, 0) * a(2, 2), c0 = a(2, 0) * a(3, 1) - a(3, 0) * a(2, 1);
  const det = s0 * c5 - s1 * c4 + s2 * c3 + s3 * c2 - s4 * c1 + s5 * c0;
  if (Math.abs(det) < 1e-12) return ident();
  const d = 1 / det, b = [
    [(a(1, 1) * c5 - a(1, 2) * c4 + a(1, 3) * c3) * d, (-a(0, 1) * c5 + a(0, 2) * c4 - a(0, 3) * c3) * d, (a(3, 1) * s5 - a(3, 2) * s4 + a(3, 3) * s3) * d, (-a(2, 1) * s5 + a(2, 2) * s4 - a(2, 3) * s3) * d],
    [(-a(1, 0) * c5 + a(1, 2) * c2 - a(1, 3) * c1) * d, (a(0, 0) * c5 - a(0, 2) * c2 + a(0, 3) * c1) * d, (-a(3, 0) * s5 + a(3, 2) * s2 - a(3, 3) * s1) * d, (a(2, 0) * s5 - a(2, 2) * s2 + a(2, 3) * s1) * d],
    [(a(1, 0) * c4 - a(1, 1) * c2 + a(1, 3) * c0) * d, (-a(0, 0) * c4 + a(0, 1) * c2 - a(0, 3) * c0) * d, (a(3, 0) * s4 - a(3, 1) * s2 + a(3, 3) * s0) * d, (-a(2, 0) * s4 + a(2, 1) * s2 - a(2, 3) * s0) * d],
    [(-a(1, 0) * c3 + a(1, 1) * c1 - a(1, 2) * c0) * d, (a(0, 0) * c3 - a(0, 1) * c1 + a(0, 2) * c0) * d, (-a(3, 0) * s3 + a(3, 1) * s1 - a(3, 2) * s0) * d, (a(2, 0) * s3 - a(2, 1) * s1 + a(2, 2) * s0) * d],
  ];
  const inv = new Array(16); for (let r = 0; r < 4; r++) for (let c = 0; c < 4; c++) inv[c * 4 + r] = b[r][c];
  return inv;
}
const nums = (s) => s.split(/\s+/).filter(Boolean).map(Number).filter(Number.isFinite);
function parseBobj(text) {
  const out = { arm: { bones: [], byName: new Map() }, meshes: [], uvs: [], normals: [] };
  const points = [], weights = []; let cur = null, tris = [];
  const flush = () => { if (cur) out.meshes.push({ name: cur, points, weights, tris }); cur = null; tris = []; };
  for (const raw of text.split('\n')) {
    const line = raw.replace(/\r$/, ''), sp = line.indexOf(' '), head = sp < 0 ? line : line.slice(0, sp), rest = sp < 0 ? '' : line.slice(sp + 1);
    if (head === 'arm_bone') {
      const parts = rest.split(' '), name = parts[0], parentName = parts[1], v = nums(parts.slice(2).join(' '));
      if (v.length < 19) continue;
      const restM = rowMajor(v.slice(3, 19)), parent = out.arm.byName.has(parentName) ? out.arm.byName.get(parentName) : null, restInv = invert(restM);
      const rel = parent !== null ? mul(out.arm.bones[parent].restInv, restM) : restM;
      out.arm.byName.set(name, out.arm.bones.length);
      out.arm.bones.push({ name, parent, rest: restM, restInv, rel });
    } else if (head === 'o') { flush(); cur = rest.trim(); }
    else if (head === 'v') { const v = nums(rest); if (v.length >= 3) { points.push([v[0], v[1], v[2]]); weights.push([]); } }
    else if (head === 'vw') { const p = rest.trim().split(/\s+/), w = parseFloat(p[1]); if (w > 0 && weights.length) weights[weights.length - 1].push([p[0], w]); }
    else if (head === 'vt') { const v = nums(rest); if (v.length >= 2) out.uvs.push([v[0], 1 - v[1]]); }
    else if (head === 'vn') { const v = nums(rest); if (v.length >= 3) out.normals.push([v[0], v[1], v[2]]); }
    else if (head === 'f') {
      const corners = rest.trim().split(/\s+/).map((c) => { const it = c.split('/'); return [(parseInt(it[0], 10) || 1) - 1, (parseInt(it[1], 10) || 1) - 1, (parseInt(it[2], 10) || 1) - 1]; });
      for (let k = 1; k < corners.length - 1; k++) tris.push([corners[0], corners[k], corners[k + 1]]);
    }
  }
  flush();
  return out;
}
function parseActions(text) {
  const out = new Map(); let action = null, bone = null, channel = null;
  for (const raw of text.split('\n')) {
    const line = raw.replace(/\r$/, ''), sp = line.indexOf(' '), head = line.slice(0, sp), rest = line.slice(sp + 1);
    if (head === 'an') { action = rest.trim(); if (!out.has(action)) out.set(action, { bones: new Map(), length: 0 }); }
    else if (head === 'ao') bone = rest.trim();
    else if (head === 'ag') { const p = rest.trim().split(/\s+/), base = { location: 0, rotation: 3, scale: 6 }[p[0]]; const i = parseInt(p[1], 10); channel = base !== undefined && i >= 0 && i < 3 ? base + i : null; }
    else if (head === 'kf') {
      if (action === null || bone === null || channel === null) continue;
      const p = rest.trim().split(/\s+/); if (p.length < 3) continue;
      const frame = +p[0] || 0, val = +p[1] || 0, how = { BEZIER: 0, LINEAR: 1, CONSTANT: 2 }[p[2]] ?? 3;
      const h = (i) => (p[i] !== undefined && Number.isFinite(+p[i]) ? +p[i] : null);
      const act = out.get(action); act.length = Math.max(act.length, frame);
      if (!act.bones.has(bone)) act.bones.set(bone, [[], [], [], [], [], [], [], [], []]);
      act.bones.get(bone)[channel].push({ frame, value: val, how, left: [h(3) ?? frame, h(4) ?? val], right: [h(5) ?? frame, h(6) ?? val] });
    }
  }
  for (const a of out.values()) for (const c of a.bones.values()) for (const k of c) k.sort((x, y) => x.frame - y.frame);
  return out;
}
const cubic = (p0, p1, p2, p3, s) => { const u = 1 - s; return u * u * u * p0 + 3 * u * u * s * p1 + 3 * u * s * s * p2 + s * s * s * p3; };
function sampleKeys(keys, frame) {
  if (!keys.length) return null;
  if (frame <= keys[0].frame) return keys[0].value;
  const last = keys[keys.length - 1]; if (frame >= last.frame) return last.value;
  let i = 0; while (i < keys.length - 1 && keys[i + 1].frame <= frame) i++;
  const a = keys[i], b = keys[Math.min(i + 1, keys.length - 1)], f = Math.max(0, Math.min(1, (frame - a.frame) / Math.max(1e-6, b.frame - a.frame)));
  if (a.how === 2) return a.value;
  if (a.how === 1) return a.value + (b.value - a.value) * f;
  if (a.how === 3) return a.value + (b.value - a.value) * (.5 - .5 * Math.cos(f * Math.PI));
  const x1 = Math.max(a.frame, Math.min(b.frame, a.right[0])), x2 = Math.max(a.frame, Math.min(b.frame, b.left[0]));
  let lo = 0, hi = 1, s = f;
  for (let k = 0; k < 24; k++) { const x = cubic(a.frame, x1, x2, b.frame, s); if (Math.abs(x - frame) < 1e-4) break; if (x < frame) lo = s; else hi = s; s = (lo + hi) / 2; }
  return cubic(a.value, a.right[1], b.left[1], b.value, s);
}
const rx = (a) => rotX(a / RAD), ry = (a) => rotY(a / RAD), rz = (a) => rotZ(a / RAD);
function emotePose(arm, action, frame) {
  const world = [];
  for (const b of arm.bones) {
    const c = action && action.bones.get(b.name);
    const ch = (i, or) => { if (!c) return or; const v = sampleKeys(c[i], frame); return v === null ? or : v; };
    const local = mul(translate(ch(0, 0), ch(1, 0), ch(2, 0)), mul(mul(rz(ch(5, 0)), mul(ry(ch(4, 0)), rx(ch(3, 0)))), scale([ch(6, 1), ch(7, 1), ch(8, 1)])));
    world.push(b.parent !== null && b.parent < world.length ? mul(world[b.parent], mul(b.rel, local)) : mul(b.rest, local));
  }
  return world.map((w, i) => mul(w, arm.bones[i].restInv));
}
/** A mesh moved by the bones, as quads (each triangle its last corner twice) in the model's space. */
function skinMesh(file, mesh, arm, mats) {
  const moved = new Array(mesh.points.length), out = new Float32Array(mesh.tris.length * 32); let o = 0;
  const corner = ([v, t, n]) => {
    const p = mesh.points[v]; if (!p) return;
    let mv = moved[v];
    if (!mv) {
      const m = new Array(16).fill(0); let total = 0;
      for (const [bone, w] of mesh.weights[v]) { const i = arm.byName.get(bone); if (i !== undefined && mats[i]) { const s = mats[i]; for (let k = 0; k < 16; k++) m[k] += s[k] * w; total += w; } }
      const mm = total > 1e-6 ? m.map((x) => x / total) : ident();
      mv = moved[v] = [apply(mm, p, 1), mm];
    }
    const nn = apply(mv[1], file.normals[n] || [0, 1, 0], 0), l = Math.max(1e-6, Math.hypot(nn[0], nn[1], nn[2])), uv = file.uvs[t] || [0, 0], q = mv[0];
    out[o++] = q[0]; out[o++] = 1.501 - q[1]; out[o++] = -q[2]; out[o++] = uv[0]; out[o++] = uv[1]; out[o++] = nn[0] / l; out[o++] = -nn[1] / l; out[o++] = -nn[2] / l;
  };
  for (const tri of mesh.tris) { corner(tri[0]); corner(tri[1]); corner(tri[2]); corner(tri[2]); }
  return o === out.length ? out : out.subarray(0, o);
}
const EMO_TEXT = new Map();
function emoText(name) {
  if (!EMO_TEXT.has(name)) { const p = fetch('/cos/e/' + name).then((r) => { if (!r.ok) throw new Error(String(r.status)); return r.text(); }); EMO_TEXT.set(name, p); p.catch(() => EMO_TEXT.delete(name)); }
  return EMO_TEXT.get(name);
}
const EMO = { bodies: new Map(), props: new Map(), index: null, actions: new Map() };
const emoBody = (slim) => { const k = slim ? 'body-slim.txt' : 'body-wide.txt'; if (!EMO.bodies.has(k)) EMO.bodies.set(k, emoText(k).then(parseBobj)); return EMO.bodies.get(k); };
const emoIndex = () => { if (!EMO.index) { EMO.index = emoText('index.json').then((t) => JSON.parse(t)); EMO.index.catch(() => { EMO.index = null; }); } return EMO.index; };
const emoPropsFile = (f) => { if (!EMO.props.has(f)) EMO.props.set(f, emoText(f).then(parseBobj)); return EMO.props.get(f); };
function emoAction(name) {
  if (!EMO.actions.has(name)) {
    const p = emoText(name + '.txt').then((t) => parseActions(t).get(name) || null);
    EMO.actions.set(name, p); p.catch(() => EMO.actions.delete(name));
  }
  return EMO.actions.get(name);
}
/** The pack's emotes, as the wardrobe lists them: number, name, how long (ticks), looping, props, its picture. */
async function emotes() {
  const c = await catalog(), e = c.emotes || {}, files = e.files || {};
  return ((e.list && e.list.emotes) || []).map((x) => ({
    id: x.id, name: x.name, title: String(x.name).replace(/_/g, ' ').replace(/^./, (ch) => ch.toUpperCase()), ticks: Math.max(1, x.duration || 20), looping: !!x.looping, cloak: x.renderCloak !== false,
    props: (x.meshes || []).map((m) => [m.name, m.show_at || 0]), icon: files[`cursed:emotes/icons/${x.id}.webp`] || null, action: (e.actions && e.actions['emote_' + x.name]) ? 'emote_' + x.name : x.name,
  }));
}
/** An emote made ready to play: its moves, the body, its props with their pictures. */
async function emoteReady(info, slim) {
  const [action, body, index, cat] = [await emoAction(info.action), await emoBody(slim), await emoIndex().catch(() => ({ props: {} })), await catalog()];
  const props = [];
  const files = (cat.emotes && cat.emotes.files) || {};
  // the props the player's own model names (its "meshes": the popcorn) beside the list's
  let own = {};
  try { const d = files['cursed:emotes/models/entity/default.json']; if (d) own = ((await file(d, 'json')) || {}).meshes || {}; } catch (e) { own = {}; }
  const meshes = { ...own, ...((cat.emotes && cat.emotes.list && cat.emotes.list.meshes) || {}) };
  for (const [name, at] of info.props) {
    const f = index.props && index.props[name], tex = meshes[name] && files[meshes[name].texture];
    if (!f || !tex) continue;
    try { const file = await emoPropsFile(f), mesh = file.meshes.find((m) => m.name === name); if (mesh) props.push({ file, mesh, at, picture: await file2img(tex), sha: tex }); } catch (e) { /* a prop missing: the rest dance */ }
  }
  return { info, action, body, mesh: body.meshes.find((m) => m.name === 'body'), props };
}
const file2img = (sha) => file(sha, 'img');
/** The emote's bones the player's parts follow (the model's space), and below each joint the bone under it. */
function emoteParts(arm, mats) {
  const c = mul(translate(0, 1.501, 0), scale([1, -1, -1]));
  const bone = (n) => { const i = arm.byName.get(n); return i !== undefined && mats[i] ? mul(c, mul(mats[i], c)) : ident(); };
  const joint = (n, or) => { const i = arm.byName.get(n); return i !== undefined ? 1.501 - arm.bones[i].rest[13] : or; };
  return {
    [PART.head]: [bone('head')], [PART.body]: [bone('low_body'), bone('body'), joint('low_body', .375)],
    [PART.rarm]: [bone('right_arm'), bone('low_right_arm'), joint('low_right_arm', .375)], [PART.larm]: [bone('left_arm'), bone('low_left_arm'), joint('low_left_arm', .375)],
    [PART.rleg]: [bone('right_leg'), bone('low_leg_right'), joint('low_leg_right', 1.125)], [PART.lleg]: [bone('left_leg'), bone('low_left_leg'), joint('low_left_leg', 1.125)],
  };
}
/** A worn piece carried by the emote's bones: each point by its part's bone, below the joint by the bone under it. */
function followEmote(q, follow) {
  const [m, lo, at] = follow, out = new Float32Array(q.length);
  for (let k = 0; k < q.length; k += 8) {
    const pos = [q[k], q[k + 1], q[k + 2]], nrm = [q[k + 5], q[k + 6], q[k + 7]];
    let v = apply(m, pos, 1), n = apply(m, nrm, 0);
    if (lo) {
      let s = Math.max(0, Math.min(1, (pos[1] - (at - 1 / 32)) / (2 / 32))); s = s * s * (3 - 2 * s);
      if (s > 0) { const vl = apply(lo, pos, 1), nl = apply(lo, nrm, 0); v = v.map((x, i) => x + (vl[i] - x) * s); n = n.map((x, i) => x + (nl[i] - x) * s); }
    }
    out[k] = v[0]; out[k + 1] = v[1]; out[k + 2] = v[2]; out[k + 3] = q[k + 3]; out[k + 4] = q[k + 4]; out[k + 5] = n[0]; out[k + 6] = n[1]; out[k + 7] = n[2];
  }
  return out;
}

/* ---------------------------------------------------------------------------------------------- skins */
/** A skin picture made whole: the old 64 × 32 ones get their left arm and leg (the right ones turned over). */
function wholeSkin(img) {
  const c = document.createElement('canvas'); c.width = 64; c.height = 64;
  const x = c.getContext('2d'); x.imageSmoothingEnabled = false;
  const legacy = img.height < 64;
  if (!legacy) x.drawImage(img, 0, 0, 64, 64);
  else {
    x.drawImage(img, 0, 0, 64, 32, 0, 0, 64, 32);
    const flip = (sx, sy, w, h, dx, dy) => { x.save(); x.translate(dx + w, dy); x.scale(-1, 1); x.drawImage(img, sx, sy, w, h, 0, 0, w, h); x.restore(); };
    // the leg and the arm: each face taken over, left and right swapped
    for (const [sx, dx] of [[0, 16], [40, 32]]) {
      flip(sx + 4, 16, 4, 4, dx + 4, 48); flip(sx + 8, 16, 4, 4, dx + 8, 48);
      flip(sx + 0, 20, 4, 12, dx + 8, 52); flip(sx + 4, 20, 4, 12, dx + 4, 52); flip(sx + 8, 20, 4, 12, dx + 0, 52); flip(sx + 12, 20, 4, 12, dx + 12, 52);
    }
  }
  // As the game reads a skin (SkinTextureDownloader): the inner layer is never see-through, and an old skin's hat that
  // has no see-through pixel at all is taken for none (many old skins fill it black).
  const d = x.getImageData(0, 0, 64, 64), px = d.data;
  const opaque = (x0, y0, x1, y1) => { for (let yy = y0; yy < y1; yy++) for (let xx = x0; xx < x1; xx++) px[(yy * 64 + xx) * 4 + 3] = 255; };
  opaque(0, 0, 32, 16); opaque(0, 16, 64, 32); opaque(16, 48, 48, 64);
  if (legacy) {
    let seeThrough = false;
    for (let yy = 0; yy < 16 && !seeThrough; yy++) for (let xx = 32; xx < 64; xx++) if (px[(yy * 64 + xx) * 4 + 3] < 128) { seeThrough = true; break; }
    if (!seeThrough) for (let yy = 0; yy < 16; yy++) for (let xx = 32; xx < 64; xx++) px[(yy * 64 + xx) * 4 + 3] = 0;
  }
  x.putImageData(d, 0, 0);
  return c;
}
/** Whether a skin is drawn for the slim arms: the wide arm's last column is empty there. */
function looksSlim(c) {
  try { const d = c.getContext('2d').getImageData(54, 20, 2, 12).data; for (let i = 3; i < d.length; i += 8) if (d[i] !== 0) return false; return true; } catch (e) { return false; }
}
/** The figure before a skin is chosen: a hooded shape in the site's own greys, its eyes lit (no Mojang picture is shipped). */
function steve() {
  const c = document.createElement('canvas'); c.width = 64; c.height = 64;
  const x = c.getContext('2d');
  let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const fill = (hex, rects, vary) => {
    const r0 = parseInt(hex.slice(1, 3), 16), g0 = parseInt(hex.slice(3, 5), 16), b0 = parseInt(hex.slice(5, 7), 16);
    for (const [px, py, w, h] of rects) for (let yy = py; yy < py + h; yy++) for (let xx = px; xx < px + w; xx++) {
      const k = vary ? Math.round((rnd() - .5) * vary) : 0;
      x.fillStyle = `rgb(${r0 + k},${g0 + k},${b0 + k})`; x.fillRect(xx, yy, 1, 1);
    }
  };
  fill('#26262c', [[0, 0, 32, 16]], 6);                        // the head: under a hood
  fill('#141418', [[8, 8, 8, 8]], 3);                          // the face in its shadow
  fill('#e9e9f2', [[9, 12, 2, 1], [13, 12, 2, 1]]);             // the eyes, lit
  fill('#7d7d88', [[9, 13, 2, 1], [13, 13, 2, 1]]);
  fill('#1f1f25', [[16, 16, 24, 16], [40, 16, 16, 16], [32, 48, 16, 16]], 6);   // the hoodie, the sleeves
  fill('#d9d9e2', [[21, 22, 1, 1], [22, 23, 1, 1], [23, 24, 1, 1], [26, 22, 1, 1], [25, 23, 1, 1], [24, 24, 1, 1]]);   // the mark
  fill('#8d8d97', [[40, 30, 16, 2], [32, 62, 16, 2]], 4);       // the hands
  fill('#2a2a31', [[0, 16, 16, 16], [16, 48, 16, 16]], 5);      // the trousers
  fill('#111114', [[0, 30, 16, 2], [16, 62, 16, 2]], 2);        // the shoes
  fill('#2e2e35', [[40, 0, 16, 8], [32, 8, 8, 8], [48, 8, 16, 8], [40, 8, 8, 1], [40, 8, 1, 8], [47, 8, 1, 8]], 6);   // the hood over it
  return c;
}

/* ---------------------------------------------------------------------------------------------- the drawing */
const VS = `#version 300 es
in vec3 aPos; in vec2 aUv; in vec3 aNor;
uniform mat4 uVP; uniform mat4 uWorld;
out vec2 vUv; out vec3 vNor; out vec3 vPos;
void main(){ vec4 w = uWorld * vec4(aPos, 1.); vPos = w.xyz; vUv = aUv; vNor = mat3(uWorld) * aNor; gl_Position = uVP * w; }`;
const FS = `#version 300 es
precision highp float;
in vec2 vUv; in vec3 vNor; in vec3 vPos;
uniform sampler2D uTex; uniform int uMode; uniform vec3 uEye; uniform float uAlpha;
out vec4 o;
void main(){
  if (uMode == 3) {
    // the shadow on the floor: a soft dark pool under the feet, and a faint light round it
    float r = length(vPos.xz) / .85;
    float sh = exp(-r * r * 2.2) * .55;
    float ring = exp(-pow((r - 1.05) / .09, 2.)) * .05;
    o = vec4(vec3(ring / max(ring + sh, 1e-4)), (ring + sh) * uAlpha); return;
  }
  vec4 c = texture(uTex, vUv);
  if (uMode != 1 && c.a < .1) discard;
  if (c.a < .01) discard;
  vec3 n = normalize(gl_FrontFacing ? vNor : -vNor);
  vec3 v = normalize(uEye - vPos);
  // the game's two lights, a little colder, and a light from behind on the edges (the valley's glow)
  float d = .42 + .36 * max(dot(n, normalize(vec3(.35, 1., .7))), 0.) + .3 * max(dot(n, normalize(vec3(-.5, .6, -.2))), 0.);
  float rim = pow(1. - max(dot(n, v), 0.), 3.) * .35;
  vec3 col = c.rgb * min(d, 1.08) + vec3(.82, .84, 1.) * rim * c.rgb;
  if (uMode == 2) col = c.rgb * 1.05;
  o = vec4(col, (uMode == 1 ? c.a : 1.) * uAlpha);
}`;

function makeGL(canvas) {
  const gl = canvas.getContext('webgl2', { antialias: true, alpha: true, premultipliedAlpha: false, preserveDrawingBuffer: false });
  if (!gl) return null;
  const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
  const p = gl.createProgram(); gl.attachShader(p, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(p, sh(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
  const u = {}; for (const n of ['uVP', 'uWorld', 'uTex', 'uMode', 'uEye', 'uAlpha']) u[n] = gl.getUniformLocation(p, n);
  const vao = gl.createVertexArray(), buf = gl.createBuffer(), idx = gl.createBuffer();
  gl.bindVertexArray(vao); gl.bindBuffer(gl.ARRAY_BUFFER, buf);
  const at = (n) => gl.getAttribLocation(p, n);
  gl.enableVertexAttribArray(at('aPos')); gl.vertexAttribPointer(at('aPos'), 3, gl.FLOAT, false, 32, 0);
  gl.enableVertexAttribArray(at('aUv')); gl.vertexAttribPointer(at('aUv'), 2, gl.FLOAT, false, 32, 12);
  gl.enableVertexAttribArray(at('aNor')); gl.vertexAttribPointer(at('aNor'), 3, gl.FLOAT, false, 32, 20);
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, idx);
  const white = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, white); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([255, 255, 255, 255]));
  return { gl, p, u, vao, buf, idx, idxLen: 0, white, texs: new Map() };
}
function texture(G, key, src) {
  let t = G.texs.get(key);
  if (t) return t;
  const gl = G.gl; t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false); gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  G.texs.set(key, t);
  return t;
}
/** Quads (8 numbers a corner) as triangles, drawn with a picture. */
function drawQuads(G, q, tex, mode, alpha) {
  const gl = G.gl, n = q.length / 32 | 0; if (!n) return;
  gl.bindBuffer(gl.ARRAY_BUFFER, G.buf); gl.bufferData(gl.ARRAY_BUFFER, q instanceof Float32Array ? q : new Float32Array(q), gl.STREAM_DRAW);
  if (G.idxLen < n) {
    const ix = new Uint32Array(n * 6);
    for (let i = 0; i < n; i++) { const b = i * 4, k = i * 6; ix[k] = b; ix[k + 1] = b + 1; ix[k + 2] = b + 2; ix[k + 3] = b; ix[k + 4] = b + 2; ix[k + 5] = b + 3; }
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, G.idx); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, ix, gl.STATIC_DRAW); G.idxLen = n;
  }
  gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, tex || G.white); gl.uniform1i(G.u.uTex, 0);
  gl.uniform1i(G.u.uMode, mode); gl.uniform1f(G.u.uAlpha, alpha === undefined ? 1 : alpha);
  gl.drawElements(gl.TRIANGLES, n * 6, gl.UNSIGNED_INT, 0);
}
/** The model's space to the world's (the game's: turned over and up to the neck), then turned to face `yaw`. */
const MODEL_TO_WORLD = mul(translate(0, 1.501, 0), rotX(180));

/* ---------------------------------------------------------------------------------------------- a stage */
/* A canvas with a player on it: their skin, their worn items; turned by the hand, looking at the pointer, standing,
   walking or waving. One WebGL context a stage; pictures of single items are made by `snapshot` on the same one. */
function stage(canvas, opts) {
  let G = null;
  try { G = makeGL(canvas); } catch (e) { G = null; }
  if (!G) return null;
  const gl = G.gl;
  const S = {
    skin: null, skinKey: '', slim: false, cape: null, worn: new Map(), insts: new Map(), models: new Map(), pending: new Set(),
    yaw: opts && opts.yaw !== undefined ? opts.yaw : -22, yawV: 0, pitch: 6, dist: opts && opts.dist || 4.4, distTo: 0, look: [0, 0], lookTo: [0, 0],
    mode: 'idle', walked: 0, t0: performance.now(), alive: true, drag: null, auto: !!(opts && opts.auto), onLoad: null, ty: opts && opts.target || 1.02, tyTo: opts && opts.target || 1.02,
    options: new Map(), hidden: false, frameT: 0, raf: 0, emote: null, photo: null,
  };
  S.distTo = S.dist;
  S.skin = texture(G, 'skin:default', steve()); S.slim = false;
  const resize = () => {
    const dpr = Math.min(devicePixelRatio || 1, 2), w = Math.max(1, Math.round(canvas.clientWidth * dpr)), h = Math.max(1, Math.round(canvas.clientHeight * dpr));
    if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
  };
  // the hand: drag turns (and lets go with a little spin), the wheel brings closer, the pointer is looked at
  const down = (e) => { if (e.button !== 0) return; S.drag = { x: e.clientX, y: e.clientY, yaw: S.yaw, pitch: S.pitch, t: performance.now(), last: e.clientX }; S.yawV = 0; try { canvas.setPointerCapture(e.pointerId); } catch (err) { /* a pointer the page did not see go down */ } canvas.classList.add('f-grab'); };
  const move = (e) => {
    const r = canvas.getBoundingClientRect();
    S.lookTo = [Math.max(-1, Math.min(1, (e.clientX - (r.left + r.width / 2)) / (r.width * .6))), Math.max(-1, Math.min(1, (e.clientY - (r.top + r.height * .32)) / (r.height * .6)))];
    if (!S.drag) return;
    const now = performance.now(), dx = e.clientX - S.drag.last;
    S.yawV = dx / Math.max(1, now - S.drag.t) * 16 * .5; S.drag.t = now; S.drag.last = e.clientX;
    S.yaw = S.drag.yaw + (e.clientX - S.drag.x) * .45;
    S.pitch = Math.max(-25, Math.min(40, S.drag.pitch + (e.clientY - S.drag.y) * .25));
  };
  const up = () => { if (S.drag) { S.drag = null; canvas.classList.remove('f-grab'); } };
  const wheel = (e) => { if (!opts || opts.zoom === false) return; e.preventDefault(); S.distTo = Math.max(2.2, Math.min(7.5, S.distTo * Math.exp(e.deltaY * .0012))); };
  const leave = () => { S.lookTo = [0, 0]; };
  canvas.addEventListener('pointerdown', down); addEventListener('pointermove', move, { passive: true }); addEventListener('pointerup', up); canvas.addEventListener('wheel', wheel, { passive: false });
  document.documentElement.addEventListener('pointerleave', leave);
  const home = { dist: opts && opts.dist || 4.4, ty: opts && opts.target || 1.02 };
  canvas.addEventListener('dblclick', () => { S.distTo = home.dist; S.tyTo = home.ty; S.pitch = 6; turnTo(-22); });

  function turnTo(yaw) { S.yawV = 0; const d = (((yaw - S.yaw) % 360) + 540) % 360 - 180; const from = S.yaw; const t0 = performance.now(); const step = () => { const k = Math.min(1, (performance.now() - t0) / 800); const e = 1 - Math.pow(1 - k, 3); if (!S.drag) S.yaw = from + d * e; if (k < 1 && !S.drag) requestAnimationFrame(step); }; step(); }
  function setSkin(img, slim) {
    const c = img ? wholeSkin(img) : steve();
    const key = 'skin:' + Math.random();
    const old = S.skin; S.skin = texture(G, key, c); if (old && old !== G.texs.get('skin:default')) gl.deleteTexture(old);
    S.slim = slim === undefined || slim === null ? looksSlim(c) : !!slim;
  }
  function setCape(img) { S.cape = img ? texture(G, 'mojang-cape:' + Math.random(), img) : null; }
  /** What is worn: slot → item id. Items not read yet are fetched; until then they are not drawn. */
  function wear(map) {
    S.worn = new Map(Object.entries(map || {}).filter(([, v]) => v));
    for (const id of S.worn.values()) {
      if (S.models.has(id) || S.pending.has(id)) continue;
      S.pending.add(id);
      model(id).then((m) => { S.models.set(id, m); S.pending.delete(id); if (S.onLoad) S.onLoad(id, true); }, () => { S.pending.delete(id); S.models.set(id, null); if (S.onLoad) S.onLoad(id, false); });
    }
  }
  function frame() {
    if (!S.alive) return;
    S.raf = requestAnimationFrame(frame);
    if (S.hidden || !canvas.isConnected) return;
    const now = performance.now(), dt = Math.min(.1, (now - (S.frameT || now)) / 1000); S.frameT = now;
    const t = (now - S.t0) / 1000;
    resize();
    // the hand let go: the spin dies down; left alone a while, the stage turns slowly by itself if asked to
    if (!S.drag) { S.yaw += S.yawV; S.yawV *= Math.pow(.9, dt * 60); if (S.auto && Math.abs(S.yawV) < .02) S.yaw += dt * 9; }
    S.dist += (S.distTo - S.dist) * Math.min(1, dt * 7);
    S.ty += (S.tyTo - S.ty) * Math.min(1, dt * 5);
    S.look[0] += (S.lookTo[0] - S.look[0]) * Math.min(1, dt * 5); S.look[1] += (S.lookTo[1] - S.look[1]) * Math.min(1, dt * 5);
    const speed = S.emote ? 0 : S.mode === 'walk' ? 4.3 : S.mode === 'run' ? 5.6 : 0;
    S.walked += (S.mode === 'walk' ? 10 : S.mode === 'run' ? 14.5 : 0) * dt;
    draw(t, speed);
    if (S.photo) { const cb = S.photo; S.photo = null; try { cb(canvas); } catch (e) { console.error(e); } }
  }
  function draw(t, speed) {
    const W = canvas.width, H = canvas.height;
    gl.viewport(0, 0, W, H); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.useProgram(G.p); gl.bindVertexArray(G.vao);
    // the head and the body turn toward the pointer as in the game's inventory (the head more than the body)
    const yawRel = ((S.yaw % 360) + 540) % 360 - 180;
    const headYaw = Math.max(-50, Math.min(50, (Math.abs(yawRel) < 100 ? yawRel * .55 : 0) + S.look[0] * 38)), headPitch = Math.max(-30, Math.min(30, S.look[1] * 30));
    const state = { speed, walked: S.walked, run: S.mode === 'run', wave: S.mode === 'wave', headYaw, headPitch };
    const pose = bodyPose(state, t);
    // the camera: round the figure's middle, a little above
    const target = [0, S.ty, 0];
    const yawR = (S.yaw) * RAD, pitR = S.pitch * RAD, d = S.dist;
    const eye = [target[0] + Math.sin(yawR) * Math.cos(pitR) * d, target[1] + Math.sin(pitR) * d, target[2] + Math.cos(yawR) * Math.cos(pitR) * d];
    const VP = mul(perspective(30 * RAD, W / H, .05, 60), lookAt(eye, target));
    gl.uniformMatrix4fv(G.u.uVP, false, new Float32Array(VP));
    gl.uniform3fv(G.u.uEye, eye);
    gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); gl.disable(gl.CULL_FACE);
    // the floor's shadow first, under everything (it writes no depth)
    gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false);
    gl.uniformMatrix4fv(G.u.uWorld, false, new Float32Array(ident()));
    drawQuads(G, [-1.6, 0, -1.6, 0, 0, 0, 1, 0, 1.6, 0, -1.6, 1, 0, 0, 1, 0, 1.6, 0, 1.6, 1, 1, 0, 1, 0, -1.6, 0, 1.6, 0, 1, 0, 1, 0], null, 3, 1);
    gl.depthMask(true);
    const mats = partMatrices(pose, S.slim);
    const pl = { t, speed, run: state.run, headYaw, headPitch, slim: S.slim, gui: false, rarm: pose.rarm.map((x) => x / RAD), larm: pose.larm.map((x) => x / RAD), rleg: pose.rleg[0] / RAD, lleg: pose.lleg[0] / RAD };
    // what is worn, posed; each piece turned with its part (from where the part first stands)
    // an emote playing: the body is its mesh, what is worn goes with its bones (the cape stays off: the back it hangs
    // from bends away under it)
    let emo = null;
    const E = S.emote && S.emote.ready;
    if (E && E.mesh) {
      if (!S.emote.start) S.emote.start = t;
      const raw = (t - S.emote.start) * 20, ticks = E.info.ticks;
      const tick = E.info.looping ? raw % ticks : Math.min(raw % (ticks + 30), ticks);
      const arm = E.body.arm, em = emotePose(arm, E.action, tick);
      emo = { parts: emoteParts(arm, em), body: skinMesh(E.body, E.mesh, arm, em), props: E.props.filter((pr) => tick >= pr.at).map((pr) => ({ q: skinMesh(pr.file, pr.mesh, arm, em), picture: pr.picture, sha: pr.sha })) };
    }
    const draws = []; let hides = 0, capeDrawn = false;
    for (const [slot, id] of S.worn) {
      const m = S.models.get(id); if (!m) continue;
      if (m.shape.kind === 'cloak') {
        if (emo) continue;
        const q = [];
        capeCloth(mats, [22, 17], frameShare(m), frameOffset(m, t), t, speed, q);
        draws.push({ tex: texture(G, 'p:' + m.tex.sha, m.picture), mode: 0, q: q[0], world: MODEL_TO_WORLD });
        capeDrawn = true; continue;
      }
      let inst = S.insts.get(slot + ':' + id); if (!inst) { inst = newInst(); S.insts.set(slot + ':' + id, inst); }
      inst.options = S.options.get(id) || null;
      const pieces = [];
      try { poseItem(m, inst, pl, pieces, false); } catch (e) { continue; }
      hides |= m.hides;
      const tex = texture(G, 'p:' + m.tex.sha, m.picture);
      if (m.kind === 'companion') {
        // a companion stands beside its player, turned a little toward the camera
        const toWorld = mul(mul(translate(.95, 0, .35), rotY(-25)), MODEL_TO_WORLD);
        for (const pc of pieces) draws.push({ tex, mode: m.mode, q: pc.q, world: toWorld });
        continue;
      }
      for (const pc of pieces) {
        if (emo) { draws.push({ tex, mode: m.mode, q: pc.part === PART.root ? pc.q : followEmote(pc.q, emo.parts[pc.part]), world: MODEL_TO_WORLD }); continue; }
        const pm = pc.part === PART.root ? ident() : mul(mats[pc.part].at, mats[pc.part].from);
        draws.push({ tex, mode: m.mode, q: transformQuads(pc.q, pm), world: MODEL_TO_WORLD });
      }
    }
    if (emo) {
      draws.unshift({ tex: S.skin, mode: 0, q: emo.body, world: MODEL_TO_WORLD });
      for (const pr of emo.props) draws.push({ tex: texture(G, 'p:' + pr.sha, pr.picture), mode: 0, q: pr.q, world: MODEL_TO_WORLD });
    }
    if (!capeDrawn && S.cape && !emo) {
      const q = []; capeCloth(mats, [64, 32], 1, 0, t, speed, q);
      draws.push({ tex: S.cape, mode: 0, q: q[0], world: MODEL_TO_WORLD });
    }
    const body = []; if (!emo) skinQuads(S.slim, mats, hides, body);
    for (const b of body) draws.unshift({ tex: S.skin, mode: 0, q: b.q, world: MODEL_TO_WORLD });
    const turnW = rotY(0);
    gl.disable(gl.BLEND);
    for (const dr of draws) if (dr.mode !== 1) { gl.uniformMatrix4fv(G.u.uWorld, false, new Float32Array(mul(turnW, dr.world))); drawQuads(G, dr.q, dr.tex, dr.mode, 1); }
    gl.enable(gl.BLEND); gl.depthMask(false);
    for (const dr of draws) if (dr.mode === 1) { gl.uniformMatrix4fv(G.u.uWorld, false, new Float32Array(mul(turnW, dr.world))); drawQuads(G, dr.q, dr.tex, 1, 1); }
    gl.depthMask(true);
  }
  S.raf = requestAnimationFrame(frame);
  const io = typeof IntersectionObserver === 'function' ? new IntersectionObserver((es) => { S.hidden = !es[0].isIntersecting; }) : null;
  if (io) io.observe(canvas);
  return {
    setSkin, setCape, wear,
    set mode(m) { S.mode = m; }, get mode() { return S.mode; },
    set onLoad(f) { S.onLoad = f; },
    setOptions(id, list) { S.options.set(id, list); },
    /** An emote played (its info from `emotes()`), or none: it starts once its files are here. */
    emote(info) {
      if (!info) { S.emote = null; return Promise.resolve(); }
      const mine = { info, ready: null, start: 0 };
      S.emote = mine;
      return emoteReady(info, S.slim).then((r) => { if (S.emote === mine) { mine.ready = r; mine.start = 0; } return r; });
    },
    get emoting() { return !!S.emote; },
    /** The canvas handed to `cb` right after its next drawing (while its pixels are still there to be read). */
    photo(cb) { S.photo = cb; },
    turnTo,
    /** The camera brought to what is tried on: the head, the feet, the back, the whole figure. */
    look(at) {
      const L = { head: [1.6, 4.4, null], face: [1.6, 4.2, -18], body: [1.15, 4.4, null], feet: [.45, 3.6, -30], back: [1.15, 6.2, 160], wide: [.95, 7.6, null], all: [home.ty, home.dist, null] }[at] || [home.ty, home.dist, null];
      S.tyTo = L[0]; S.distTo = L[1]; if (L[2] !== null) turnTo(L[2]);
    },
    get yaw() { return S.yaw; },
    snapshot: (id, size) => snapshot(G, id, size),
    destroy() {
      S.alive = false; cancelAnimationFrame(S.raf); if (io) io.disconnect();
      removeEventListener('pointermove', move); removeEventListener('pointerup', up); document.documentElement.removeEventListener('pointerleave', leave);
      const ext = gl.getExtension('WEBGL_lose_context'); if (ext) ext.loseContext();
    },
  };
}
function transformQuads(q, m) {
  const out = new Float32Array(q.length);
  for (let k = 0; k < q.length; k += 8) {
    const v = apply(m, [q[k], q[k + 1], q[k + 2]], 1), n = apply(m, [q[k + 5], q[k + 6], q[k + 7]], 0);
    out[k] = v[0]; out[k + 1] = v[1]; out[k + 2] = v[2]; out[k + 3] = q[k + 3]; out[k + 4] = q[k + 4]; out[k + 5] = n[0]; out[k + 6] = n[1]; out[k + 7] = n[2];
  }
  return out;
}

/* ---------------------------------------------------------------------------------------------- an item's picture */
/* An item alone, as the wardrobe's card shows it: posed once, framed to its own size, drawn on the stage's context into
   a picture (a cloak is its own small picture, the pack's thumb). */
const SNAP_PARTS = () => partMatrices(bodyPose({ speed: 0, walked: 0, headYaw: 0, headPitch: 0 }, 0), false);
async function snapshot(G, id, size) {
  const m = await model(id);
  const gl = G.gl;
  const pieces = [];
  const pl = { t: 1.2, speed: 0, headYaw: 0, headPitch: 0, slim: false, gui: true, rarm: [0, 0, 0], larm: [0, 0, 0], rleg: 0, lleg: 0 };
  let q = [];
  if (m.shape.kind === 'cloak') { const out = []; capeQuads(SNAP_PARTS(), [22, 17], frameShare(m), 0, 0, out); q = out[0]; }
  else {
    poseItem(m, newInst(), pl, pieces, true);
    const mats = SNAP_PARTS(), parts = pieces.map((pc) => transformQuads(pc.q, pc.part === PART.root ? ident() : mul(mats[pc.part].at, mats[pc.part].from)));
    q = new Float32Array(parts.reduce((n, a) => n + a.length, 0));
    let at = 0; for (const a of parts) { q.set(a, at); at += a.length; }
  }
  if (!q.length) return null;
  // its box in the world's space (as drawn), its middle and its size
  const lo = [1e9, 1e9, 1e9], hi = [-1e9, -1e9, -1e9];
  const yaw = m.shape.kind === 'cloak' ? 180 : m.kind === 'pet' || m.kind === 'companion' ? -30 : m.kind === 'backpack' || m.kind === 'dragon_wings' ? 160 : -28;
  const W = mul(rotY(yaw), MODEL_TO_WORLD);
  for (let k = 0; k < q.length; k += 8) { const p = apply(W, [q[k], q[k + 1], q[k + 2]], 1); for (let i = 0; i < 3; i++) { lo[i] = Math.min(lo[i], p[i]); hi[i] = Math.max(hi[i], p[i]); } }
  const mid = [(lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2, (lo[2] + hi[2]) / 2], rad = Math.max(.05, Math.hypot(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]) / 2);
  const dist = rad / Math.tan(15 * RAD) * 1.08;
  const eye = [mid[0] + Math.sin(8 * RAD) * dist * .2, mid[1] + dist * .16, mid[2] + dist];
  const fb = snapTarget(G, size);
  gl.bindFramebuffer(gl.FRAMEBUFFER, fb.f); gl.viewport(0, 0, size, size);
  gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  gl.useProgram(G.p); gl.bindVertexArray(G.vao);
  gl.uniformMatrix4fv(G.u.uVP, false, new Float32Array(mul(perspective(30 * RAD, 1, .02, 80), lookAt(eye, mid))));
  gl.uniform3fv(G.u.uEye, eye);
  gl.uniformMatrix4fv(G.u.uWorld, false, new Float32Array(W));
  gl.enable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE);
  const tex = texture(G, 'p:' + m.tex.sha, m.picture);
  if (m.mode === 1) { gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); } else gl.disable(gl.BLEND);
  drawQuads(G, q, tex, m.mode, 1);
  const px = new Uint8Array(size * size * 4);
  gl.readPixels(0, 0, size, size, gl.RGBA, gl.UNSIGNED_BYTE, px);
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  const c = document.createElement('canvas'); c.width = size; c.height = size;
  const id2 = c.getContext('2d').createImageData(size, size);
  for (let y = 0; y < size; y++) id2.data.set(px.subarray((size - 1 - y) * size * 4, (size - y) * size * 4), y * size * 4);
  c.getContext('2d').putImageData(id2, 0, 0);
  return c;
}
function snapTarget(G, size) {
  const gl = G.gl;
  if (G.snap && G.snap.size === size) return G.snap;
  const t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, size, size, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
  const d = gl.createRenderbuffer(); gl.bindRenderbuffer(gl.RENDERBUFFER, d); gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT24, size, size);
  const f = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, f);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t, 0); gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, d);
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  G.snap = { f, size };
  return G.snap;
}

/** A skin from a picture's address (our own: /api/skin/…): its picture and whether it is slim, as the server says. */
async function loadImage(url) { const r = await fetch(url, { credentials: 'same-origin' }); if (!r.ok) throw new Error(String(r.status)); return createImageBitmap(await r.blob()); }

return { stage, catalog, model, emotes, loadImage, wholeSkin, looksSlim, slotOf: (kind) => (kind === 'backpack' ? 'back' : kind === 'dragon_wings' ? 'wings' : kind), _parse: parse, _run: run };
})();
