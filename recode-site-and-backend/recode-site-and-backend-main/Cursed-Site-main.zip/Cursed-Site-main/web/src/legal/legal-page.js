"use strict";
(() => {
  const sections = [...document.querySelectorAll('section[id]')];
  const links = [...document.querySelectorAll('.contents a')];
  const progress = document.querySelector('.progress');
  let scheduled = false;
  function update() {
    scheduled = false;
    let active = sections[0];
    for (const section of sections) if (section.getBoundingClientRect().top <= 160) active = section;
    for (const link of links) {
      const on = active && link.hash === '#' + active.id;
      link.classList.toggle('active', !!on);
      if (on) link.setAttribute('aria-current', 'location'); else link.removeAttribute('aria-current');
    }
    const total = document.documentElement.scrollHeight - innerHeight;
    progress.style.width = (total > 0 ? Math.min(100, scrollY / total * 100) : 0) + '%';
  }
  addEventListener('scroll', () => { if (!scheduled) { scheduled = true; requestAnimationFrame(update); } }, { passive: true });
  addEventListener('resize', update);
  update();
})();
