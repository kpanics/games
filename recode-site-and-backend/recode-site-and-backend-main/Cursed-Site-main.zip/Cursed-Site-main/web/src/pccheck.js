"use strict";
/* ================================================================================================ the computer's check (23.10.2026)
   Before buying Recode: the browser names the video card it draws with (WebGL's renderer), and that is held up against
   what Recode needs (Documents → Requirements, 21.10: Vulkan 1.3 with dynamic rendering, synchronization2, push
   descriptors; NVIDIA from Maxwell, AMD from Polaris, Intel from Skylake). What it cannot tell (the driver, a laptop's
   second card, a name it does not know, Firefox's stand-in names) it says so, and sends to support. */

const PC = { done: false, gpu: '', verdict: '', why: ['', ''], os: '', ram: 0, vague: false };

/** The card the browser draws with, as the system names it, and whether the browser gives only a stand-in for it
   (Firefox: ", or similar" and a model of the same family, not the real one). */
function pcGpu() {
  try {
    const c = document.createElement('canvas'), gl = c.getContext('webgl2') || c.getContext('webgl');
    if (!gl) return ['', false];
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    let s = String(ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER) || '');
    const lose = gl.getExtension('WEBGL_lose_context'); if (lose) lose.loseContext();
    const vague = /,\s*or similar\s*$/i.test(s);
    s = s.replace(/,\s*or similar\s*$/i, '').trim();
    // ANGLE's form: "ANGLE (Vendor, Name (0x…) Direct3D11 …, D3D11)", on its Vulkan back end "ANGLE (Vendor, Vulkan 1.3.x (Name (0x…)), …)"
    const vk = s.match(/^ANGLE \([^,]+,\s*Vulkan [\d.]+ \((.+?)(?:\s*\(0x[0-9a-f]+\))?\)(?=\s*,|\)$)/i);
    const m = s.match(/^ANGLE \([^,]+,\s*(\S.+?)(?:\s*\(0x[0-9a-f]+\))?\s*(?:Direct3D|D3D|OpenGL|Metal)[^)]*(?:,\s*[^)]*)?\)$/i);
    if (vk) s = vk[1]; else if (m) s = m[1];
    return [s.replace(/\s+/g, ' ').trim(), vague];
  } catch (e) { return ['', false]; }
}

/** What the card's name says of Recode: 'ok', 'no', or 'maybe' (not sure), and why (English, Russian). */
function pcJudge(name, vague) {
  const n = name.toLowerCase();
  const ok = (en, ru) => ['ok', [en, ru]], no = (en, ru) => ['no', [en, ru]], maybe = (en, ru) => ['maybe', [en, ru]];
  if (!n) return maybe('The browser does not name its video card.', 'Браузер не называет видеокарту.');
  if (/swiftshader|llvmpipe|basic render|microsoft basic|software/.test(n)) return maybe('The browser draws without the video card (software): check the card in the Task Manager.', 'Браузер рисует без видеокарты (программно) — посмотрите видеокарту в диспетчере задач.');
  // Firefox gives a stand-in of the card's family, not the card: an NVIDIA from Maxwell on is told as a GTX 980; for
  // the others the stand-in says too little
  if (vague) {
    if (/gtx 980/.test(n)) return ok('NVIDIA from Maxwell on (Firefox names the family, not the model): Recode runs on it.', 'NVIDIA от поколения Maxwell (Firefox называет семейство, а не модель) — Recode на ней работает.');
    return maybe('Firefox hides the exact model: check in Chrome or Edge, or in the Task Manager.', 'Firefox прячет точную модель — проверьте в Chrome или Edge, или в диспетчере задач.');
  }
  if (/nvidia|geforce|quadro|rtx|gtx|tesla/.test(n)) {
    if (/gtx 8[78]0m|gt 7[1-3]0\b|gtx 6\d\d|gtx 7[6-8]0\b|gt 6\d\d|gt 7\d\dm|gtx 7[0-9]0m|gtx titan( black| z)?$|quadro k\d/.test(n)) return no('A Kepler NVIDIA (GT 710/730, GTX 600, 760–780, laptop 600M/700M, 870M/880M): it has no Vulkan 1.3 under any driver.', 'NVIDIA поколения Kepler (GT 710/730, GTX 600, 760–780, ноутбучные 600M/700M, 870M/880M): у неё нет Vulkan 1.3 ни с каким драйвером.');
    if (/gtx 860m/.test(n)) return maybe('The GTX 860M was made as a Maxwell and as a Kepler: only the Maxwell one fits. Ask support.', 'GTX 860M выпускали и на Maxwell, и на Kepler — подходит только Maxwell. Спросите в поддержке.');
    if (/rtx|titan (x|v|rtx)|gtx 16\d\d|gtx 10\d\d|gt 10[3-9]0|gtx 9\d\d|gtx 750|mx ?\d{3}|\d{3}mx|gtx 850m|quadro (p|t|m|rtx|gv|gp)\d|\bt[46]00\b|\bt1[02]00\b|\ba\d{3,4}\b|tesla (p|t|v)/.test(n)) return ok('NVIDIA from Maxwell on: Recode runs on it.', 'NVIDIA от поколения Maxwell — Recode на ней работает.');
    return maybe('An NVIDIA card we cannot place by its name.', 'NVIDIA, которую не узнать по названию.');
  }
  if (/amd|radeon|ati /.test(n)) {
    if (/rx ?(4\d\d|5\d\d|6\d\d|vega|5\d{3}|6\d{3}|7\d{3}|9\d{3})|vega|radeon\(tm\) graphics|radeon graphics|radeon \d{3}m|radeon 8\d0m|radeon 7\d0m|radeon 6\d0m|radeon pro w\d|radeon pro/.test(n)) return ok('AMD from Polaris on (RX 400 and newer, Vega, Ryzen\'s graphics): Recode runs on it.', 'AMD от RX 400 и новее, Vega, графика Ryzen — Recode на ней работает.');
    if (/hd ?[5-8]\d{3}|r[579] ?\d{3}|r9 ?(fury|nano)|fury/.test(n)) return no('An older AMD (HD 7000, R5/R7/R9, Fury): it has no Vulkan 1.3.', 'Старая AMD (HD 7000, R5/R7/R9, Fury): у неё нет Vulkan 1.3.');
    return maybe('An AMD card we cannot place by its name.', 'AMD, которую не узнать по названию.');
  }
  if (/intel/.test(n)) {
    if (/arc|iris\(r\) xe|iris xe|uhd|iris plus|iris\(r\) plus|hd graphics p?(5\d\d|6\d\d)\b|iris(\(r\))? graphics 5[45]0|iris(\(r\))? pro graphics 580|iris(\(r\))? plus graphics 6[45]0/.test(n)) return ok('Intel from Skylake on (HD 500/600, UHD, Iris Xe, Arc): Recode runs on it with a fresh driver.', 'Intel от Skylake и новее (HD 500/600, UHD, Iris Xe, Arc) — Recode работает со свежим драйвером.');
    if (/hd graphics( (2|3|4|5)\d{3}| 6000)?$|hd graphics (2|3|4)\d{3}|hd graphics 5[0-5]00|hd graphics 6000|iris(\(r\))? pro graphics 5200|iris(\(r\))? graphics 5100|iris(\(r\))? pro graphics 6200/.test(n)) return no('An Intel before Skylake (HD 4000, 4600, 5500 and older): it has no Vulkan 1.3.', 'Intel старше Skylake (HD 4000, 4600, 5500 и старше): у неё нет Vulkan 1.3.');
    return maybe('An Intel card we cannot place by its name.', 'Intel, которую не узнать по названию.');
  }
  return maybe('A card we cannot place by its name.', 'Видеокарта, которую не узнать по названию.');
}

/** Everything the browser can tell, judged once. */
function pcRun() {
  if (PC.done) return PC;
  const ua = navigator.userAgent || '';
  PC.os = /Windows NT 10/.test(ua) ? 'win10' : /Windows/.test(ua) ? 'winold' : /Android|iPhone|iPad|Mac OS X|Linux|CrOS/.test(ua) ? 'other' : '';
  [PC.gpu, PC.vague] = pcGpu();
  [PC.verdict, PC.why] = pcJudge(PC.gpu, PC.vague);
  if (PC.os === 'winold') { PC.verdict = 'no'; PC.why = ['Windows older than 10: Recode needs Windows 10 or 11.', 'Windows старше 10-й — Recode нужен Windows 10 или 11.']; }
  // a phone, a Mac, Linux: not the computer the game will run on; nothing of the card here says anything of that one
  else if (PC.os === 'other') { PC.verdict = 'maybe'; PC.why = ['This is not a Windows computer: open this page on the computer you will play on.', 'Это не компьютер с Windows — откройте эту страницу на компьютере, где будете играть.']; }
  PC.ram = navigator.deviceMemory || 0;
  PC.done = true;
  return PC;
}
/** The check's lines for the menu (Recode's page): the card, and what it means. */
function pcLines() {
  const p = pcRun();
  const word = p.verdict === 'ok' ? L('fits', 'подходит') : p.verdict === 'no' ? L('does not fit', 'не подходит') : L('not sure', 'не уверен');
  return { card: p.gpu || L('the card is hidden', 'видеокарта скрыта'), word, why: L(...p.why), verdict: p.verdict };
}
/* Documents → Requirements: the same check over the list, for whoever comes to read it before buying. */
const viewDocsBase = viewDocs;
viewDocs = function (which) {
  const html = viewDocsBase(which);
  if (which !== 'reqs') return html;
  const p = pcLines();
  const block = `<div class="pc-doc pc-doc-${p.verdict}"><span class="pc-k">${L('Your PC, as this browser sees it', 'Ваш ПК — как его видит этот браузер')}</span><span class="pc-row"><b translate="no">${esc(p.card)}</b><span class="pc-w">${esc(p.word)}</span></span><p>${esc(p.why)}</p></div>`;
  return html.replace(/(<p class="status"[^>]*>[^<]*<\/p>)/, `$1${block}`);
};
