"use strict";
/* The world of Recode's main menu, as the client draws it: its shaders, copied from the launch preview
   (Desktop\Cursed Recode Launch\src.html, 10.10.2026) so the site and the game show the same valley. */
const COMMON = `#version 300 es
precision highp float;
precision highp int;
float hash12(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * .1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
float hash13(vec3 p3){ p3 = fract(p3 * .1031); p3 += dot(p3, p3.zyx + 31.32); return fract((p3.x + p3.y) * p3.z); }
float vn2(vec2 p){ vec2 i = floor(p), f = fract(p); vec2 u = f*f*(3.-2.*f);
  return mix(mix(hash12(i), hash12(i+vec2(1,0)), u.x), mix(hash12(i+vec2(0,1)), hash12(i+vec2(1,1)), u.x), u.y); }
float fbm2(vec2 p){ float s = 0., a = .5; for (int i = 0; i < 4; i++) { s += a * vn2(p); p = p * 2.03 + vec2(17.1, 9.3); a *= .5; } return s / .9375; }
vec2 gr2(vec2 i){ float h = hash12(i) * 6.2831853; return vec2(cos(h), sin(h)); }
float gn2(vec2 p){ vec2 i = floor(p), f = fract(p); vec2 u = f * f * f * (f * (f * 6. - 15.) + 10.);
  return mix(mix(dot(gr2(i), f), dot(gr2(i + vec2(1, 0)), f - vec2(1, 0)), u.x), mix(dot(gr2(i + vec2(0, 1)), f - vec2(0, 1)), dot(gr2(i + vec2(1, 1)), f - vec2(1, 1)), u.x), u.y); }
`;
const VS_TRI = `#version 300 es
void main(){ vec2 p = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2); gl_Position = vec4(p * 2. - 1., 0., 1.); }`;

// Вход: 30 тысяч нитей дыма в потоке (поле без дивергенции) держат форму её лого; курсор их раздвигает,
// удержание стягивает всё в уголёк по спирали, вспышка разметает. Состояние частиц — в текстурах (пинг-понг).
const FS_SIM = COMMON + `
uniform sampler2D uState, uHome;
uniform float uDt, uTime, uHold, uBeat, uBurst, uAr, uInit;
uniform vec3 uCur;
out vec4 o;
float h1(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float psi(vec2 p, float t){ return vn2(p * 1.7 + vec2(t * .07, -t * .11)) * .62 + vn2(p * 3.9 - vec2(t * .13, t * .05)) * .26 + vn2(p * 8.3 + vec2(t * .21, t * .17)) * .08; }
vec2 curl(vec2 p, float t){ const float e = .012; return vec2(psi(p + vec2(0., e), t) - psi(p - vec2(0., e), t), psi(p - vec2(e, 0.), t) - psi(p + vec2(e, 0.), t)) / (2. * e); }
void main(){
  ivec2 ij = ivec2(gl_FragCoord.xy);
  vec4 st = texelFetch(uState, ij, 0), hm = texelFetch(uHome, ij, 0);
  vec2 p = st.xy, v = st.zw, home = hm.xy;
  float kind = hm.z, seed = hm.w;
  float rate = kind > .5 ? .16 + .1 * fract(seed * 7.3) : .07;
  float cyc = uTime * rate + seed, life = fract(cyc), lifePrev = fract((uTime - uDt) * rate + seed);
  if (uInit > .5 || life < lifePrev) {
    float a = h1(vec2(seed, floor(cyc))) * 6.2832, r = h1(vec2(seed * 3.1, floor(cyc)));
    if (uInit > .5) p = vec2(cos(a), sin(a)) * (.3 + 1.5 * sqrt(r)) * vec2(uAr, 1.);       // при открытии — пыль во тьме
    else if (uHold > .25) p = vec2(cos(a), sin(a)) * (1.2 + .5 * r) * vec2(uAr, 1.);        // держат — новые летят со всех сторон
    else p = home + vec2(cos(a), sin(a)) * .025 * r;
    v = vec2(0.);
  }
  vec2 F = curl(p, uTime) * (kind > .5 ? .07 : .16) + (home - p) * (kind > .5 ? 2.4 : .18);
  float rl = length(p) + 1e-4;
  F += p / rl * uBeat * 1.2 * exp(-rl * 1.3);                                                 // удар сердца: дым отшатывается
  vec2 dc = p - uCur.xy; float r2 = dot(dc, dc);
  F += (dc * 1.3 + vec2(-dc.y, dc.x) * 1.9) / (r2 + .004) * .013 * uCur.z * exp(-r2 / .05);  // курсор: расступается и вьётся
  float g = smoothstep(0., .7, uHold);
  F = mix(F, (-p / rl * (1.6 + 11. * uHold) + vec2(-p.y, p.x) / rl * (1.3 + .9 * uHold)) / (.3 + rl), g);
  if (uBurst >= 0.) F += p / rl * 10. * exp(-uBurst * 3.);
  v = v * exp(-uDt * (2.6 - .6 * g)) + F * uDt;
  o = vec4(p + v * uDt, v);
}`;
const VS_GP = `#version 300 es
precision highp float;
uniform sampler2D uState, uHome; uniform ivec2 uSize; uniform float uAr, uTime, uAlpha, uPx, uHold;
out float vI;
void main(){
  ivec2 ij = ivec2(gl_VertexID % uSize.x, gl_VertexID / uSize.x);
  vec4 st = texelFetch(uState, ij, 0), hm = texelFetch(uHome, ij, 0);
  float rate = hm.z > .5 ? .16 + .1 * fract(hm.w * 7.3) : .07;
  float life = fract(uTime * rate + hm.w);
  gl_Position = vec4(st.x / uAr, st.y, 0., 1.);
  gl_PointSize = (hm.z > .5 ? 1.5 : 1.15) * uPx;
  vI = sin(3.14159 * life) * (hm.z > .5 ? .068 : .024) * (.45 + 1.3 * min(length(st.zw), 1.2)) * (1. + 1.1 * uHold) * uAlpha * (1. - .45 * uHold * uHold);
}`;
const FS_GP = `#version 300 es
precision highp float;
in float vI; out vec4 o;
void main(){ vec2 c = gl_PointCoord * 2. - 1.; o = vec4(vec3(vI * exp(-dot(c, c) * 1.8)), 1.); }`;
const FS_FADE = `#version 300 es
precision highp float;
out vec4 o;
void main(){ o = vec4(0.); }`;

// Рельеф мира: один раз в текстуру 384×768 (x −192…191, z −64…703). Река по долине, уступы, горы; дальше 250 — озеро.
const FS_HEIGHT = COMMON + `
out vec4 o;
float riverX(float z){ return 7. * sin(z * .012) + 3. * sin(z * .031 + 1.3); }
void main(){
  vec2 p = vec2(floor(gl_FragCoord.x) - 192., floor(gl_FragCoord.y) - 64.) + .5;
  float dx = p.x - riverX(p.y);
  float vw = 15. + 5. * sin(p.y * .017 + .7) + max(p.y - 70., 0.) * .32;   // дальше долина раскрывается к озеру
  float ad = abs(dx);
  float floorH = 7.4 + 1.4 * vn2(p * .11);
  float hills = 11. + 13. * fbm2(p * .021 + 3.1);
  float ridge = 1. - abs(fbm2(p * .015 + 7.7) * 2. - 1.);
  float mount = hills + ridge * ridge * 22. * smoothstep(vw * .8, vw * 3.2, ad);
  mount = floor(mount / 2.) * 2. + step(.72, vn2(p * .23));
  mount = mix(mount, 9. + (mount - 9.) * .45, smoothstep(80., 210., p.y));
  float bank = smoothstep(vw * .32, vw * 1.15, ad);
  float h = mix(floorH, mount, bank);
  h = mix(h, 6.5 + 2.5 * vn2(p * .06), smoothstep(225., 285., p.y));
  o = vec4(clamp(floor(h), 1., 40.) / 255., 0., 0., 1.);
}`;

// Логотип: форма и распределение жара сняты с её лого (uLogoBase), огонь, нити, дым, рост — свои.
const LOGO_GLSL = `
const vec2 LB = vec2(.509, .866);
float logoFire(vec2 uv, float t, float grow, out float smokeOut){
  smokeOut = 0.;
  if (uv.x < -.25 || uv.x > 1.25 || uv.y < -.35 || uv.y > 1.1) return 0.;
  vec2 q = uv - LB;
  float r = length(q);
  float th = atan(q.x, -q.y);
  // огонь течёт от острия наружу: край дрожит, языки вытягиваются
  vec2 w = vec2(gn2(vec2(th * 7., r * 9. - t * 1.7)), gn2(vec2(th * 7. + 9.1, r * 9. - t * 1.7)));
  w += .5 * vec2(gn2(vec2(th * 17., r * 22. - t * 2.6)), gn2(vec2(th * 17. + 3.3, r * 22. - t * 2.6)));
  float B = texture(uLogoBase, uv + w * .016 * smoothstep(.02, .25, r)).r;
  vec2 fp = vec2(th * 15., r * 3.2 - t * .8);
  fp.x += .9 * gn2(vec2(th * 4., r * 3. - t * .5));
  float fil = 0., amp = 1.;
  for (int k = 0; k < 3; k++) {
    fil += pow(clamp(1. - abs(gn2(fp) * 2.5), 0., 1.), 10.) * amp;
    fp = fp * vec2(1.9, 1.5) + vec2(5.3, 2.9); amp *= .6;
  }
  float body = smoothstep(.03, .95, B);
  float core = smoothstep(.55, 1., B) * (1. - smoothstep(.1, .5, r));
  float e = body * body * 1.55 * (.4 + .95 * fil) + smoothstep(.05, .45, B) * fil * .8 + core * 1.6;
  float band = smoothstep(.0, .08, B) * smoothstep(.45, .1, B);
  e += pow(clamp(1. - abs(gn2(vec2(th * 22., r * 7. - t * 1.2) + w * 3.) * 3.), 0., 1.), 14.) * band * 1.6;
  // огонь поднимается от острия; фронт рваный, у фронта горячее
  float front = grow - .11 * fbm2(vec2(th * 9., r * 4. - t * 2.6)) - .04 * gn2(vec2(th * 30., t * 3.));
  float alive = smoothstep(front + .02, front - .14, r);
  e = e * alive + e * smoothstep(0., .12, alive) * (1. - alive) * 1.4;
  // дым вокруг крыльев поднимается и тает; растёт мягко вслед за огнём
  float sm = fbm2(uv * 4. + vec2(0., t * .12) + .6 * vec2(fbm2(uv * 3. - t * .07), fbm2(uv * 3. + 4.)));
  smokeOut = smoothstep(.52, .95, sm) * smoothstep(.62, .2, length((uv - vec2(.5, .52)) * vec2(.85, 1.))) * .38 * smoothstep(.15, .9, grow - r);
  return e;
}`;

const FS_SCENE = `
uniform vec2 uRes;
uniform float uTime, uGrow, uEmber, uLogoI, uSun, uGlow, uBoost, uZO, uGather, uIgn, uFlash, uFlashC, uRim, uBeat;
uniform vec3 uReach;   // куда тянется уголёк (uv лого) и насколько
uniform vec4 uCur;   // свет курсора: где и сколько
uniform vec3 uCam, uRight, uUp, uFwd;
uniform float uTanH, uAspect;
uniform sampler2D uHM, uLogoBase;
uniform vec3 uLC, uLR, uLU, uLN; uniform float uLS;
out vec4 outColor;
` + LOGO_GLSL + `
const float WATER = 9.6;
vec3 gLd;   // направление на свет из камеры

float hAt(vec2 c){ ivec2 q = ivec2(c.x + 192., c.y - uZO); if (q.x < 0 || q.y < 0 || q.x >= 384 || q.y >= 768) return 6.; return floor(texelFetch(uHM, q, 0).r * 255. + .5); }

// воздух: два слоя тумана (общая дымка и низкий туман над водой), считается точно, без шагов
float fogDepth(vec3 ro, vec3 rd, float t){
  float acc = 0.;
  for (int i = 0; i < 2; i++) {
    float a = i == 0 ? .0045 : .006, H = i == 0 ? 24. : 3.5;
    float k = rd.y / H;
    float base = a * exp(-(ro.y - WATER) / H);
    acc += abs(k * t) < 1e-3 ? base * t : base * (1. - exp(-k * t)) / k;
  }
  return acc;
}
// свет лого, рассеянный в воздухе: вперёд сильнее всего
float phaseL(vec3 rd){ float mu = max(dot(rd, gLd), 0.); return .005 + 1.1 * pow(mu, 30.) + .2 * pow(mu, 10.) + .02 * mu; }
// свет, рассеянный в воздухе между нами и миром; когда лого за горами, ближний воздух им уже не освещён
float airLight(vec3 rd){ return uGlow * (1. + uBoost) * phaseL(rd) * 1.1 * (1. - .85 * smoothstep(.3, -.04, gLd.y)) + .003; }
// зарево: когда лого низко или уже за горами, у горизонта с его стороны лежит тонкая яркая полоса
float afterglow(vec3 rd){
  float low = smoothstep(.3, -.04, gLd.y);
  if (low <= 0.) return 0.;
  vec2 a = normalize(rd.xz + 1e-5), b = normalize(gLd.xz + 1e-5);
  float az = acos(clamp(dot(a, b), -1., 1.));
  float above = max(rd.y - .002, 0.);
  float b1 = exp(-above * 9.) * exp(-az * az * 2.2);
  float b2 = exp(-above * 3.) * exp(-az * az * .7) * .2;
  return low * (b1 + b2) * uGlow * (1. + uBoost + uFlashC * .8) * 1.8;
}

// перед вспышкой свет со всех сторон стягивается в уголёк: тонкие штрихи, всё быстрее
float gatherStreaks(vec2 uv){
  if (uGather <= 0. || uIgn >= 0.) return 0.;
  vec2 q = uv - LB;
  float acc = 0.;
  for (int i = 0; i < 30; i++) {
    float fi = float(i);
    float h = hash12(vec2(fi, 3.7)), h2 = hash12(vec2(fi, 9.1));
    float ang = fi / 30. * 6.28318 + (h - .5) * .35;
    float st = h2 * .5;
    float p = clamp((uGather - st) / (1. - st), 0., 1.);
    if (p <= 0.) continue;
    float head = (.32 + .4 * h) * (1. - p) * (1. - p);
    float len = .02 + .2 * p * p;
    vec2 dir = vec2(cos(ang), sin(ang));
    float along = dot(q, dir), across = abs(q.x * dir.y - q.y * dir.x);
    float seg = smoothstep(head - .004, head + .006, along) * smoothstep(head + len, head + len * .3, along);
    float w = .0016 + .0016 * (1. - p);
    acc += seg * exp(-across * across / (w * w)) * (.25 + 1.6 * p * p) * (1. - clamp((along - head) / len, 0., 1.) * .7);
  }
  return acc;
}
float logoAlong(vec3 ro, vec3 rd, out float smoke){
  smoke = 0.;
  float dn = dot(rd, -uLN);
  if (dn <= 1e-4) return 0.;
  float t = dot(uLC - ro, -uLN) / dn;
  if (t <= 0.) return 0.;
  vec3 q = ro + rd * t - uLC;
  vec2 uv = vec2(dot(q, uLR) / uLS + .5, .5 - dot(q, uLU) / uLS);
  float e = logoFire(uv, uTime, uGrow, smoke) * uLogoI;
  float b = length(uv - LB);
  e += (exp(-b * b / .00022) * 2.4 + exp(-b * 15.) * .3) * uEmber * (1. + .55 * uBeat);   // уголёк в острие, бьётся как сердце
  // уголёк чует курсор и тянется к нему тонкой дрожащей нитью
  if (uReach.z > 0.) {
    vec2 ab = uReach.xy - LB; float L = length(ab);
    if (L > .002) {
      vec2 d = ab / L, rel = uv - LB;
      float along = clamp(dot(rel, d), 0., L), k = along / L;
      float wob = gn2(vec2(along * 22., uTime * 1.4)) * .014 * k + gn2(vec2(along * 60., uTime * 3.)) * .004 * k;
      float dist = abs(dot(rel, vec2(-d.y, d.x)) - wob);
      float w = .0009 + .0025 * k;
      e += exp(-dist * dist / (w * w)) * pow(1. - k, 1.6) * (.7 + .5 * uBeat) * uReach.z * step(0., dot(rel, d));
    }
  }
  e += (exp(-b * b / .0004) * 6. + exp(-b * 9.) * .7) * uFlash;   // вспышка: собранный свет разом
  e += gatherStreaks(uv);
  return e;
}

// облака высоко над лого: снизу их подсвечивает огонь
vec3 clouds(vec3 ro, vec3 rd, vec3 sky){
  if (rd.y <= .02) return sky;
  float t = (520. - ro.y) / rd.y;
  vec3 p = ro + rd * t;
  vec2 cp = p.xz * .0032 + vec2(uTime * .006, uTime * .002);
  float d = fbm2(cp + .5 * vec2(fbm2(cp * 1.7 + 3.), fbm2(cp * 1.7 - 5.)));
  float cov = smoothstep(.5, .82, d) * exp(-t * .0007);
  if (cov <= 0.) return sky;
  vec3 lp = uLC;
  float near = exp(-length(p.xz - lp.xz) * .0016);
  float lit = uLogoI * (.08 + 1.5 * near) * (.6 + .4 * fbm2(cp * 4.)) + uGlow * phaseL(rd) * .5;
  float dl = length(p.xz - lp.xz);
  // вспышка: свет волной бежит по облакам
  if (uIgn >= 0. && uIgn < 5.) lit += 1.5 * exp(-pow((dl - uIgn * 900.) / (120. + uIgn * 90.), 2.)) * exp(-uIgn * .8) + 1.4 * exp(-uIgn * 3.) * near;
  // зарницы: огонь за горами вспыхивает в облаках
  lit += uFlashC * exp(-dl * .0012) * 2.4;
  return mix(sky, vec3(.006 + lit * .5), cov * .85);
}

// дальние горы: три гряды-плоскости, ступенчатые, как из блоков
float ridgeH(int k, float x){
  float bw = k == 0 ? 2. : (k == 1 ? 3. : 4.);
  float xq = floor(x / bw) * bw;
  float f = k == 0 ? .011 : (k == 1 ? .0075 : .0052);
  float s = float(k) * 17.3 + 2.;
  float n = 0., a = .55, fx = xq * f;
  for (int i = 0; i < 4; i++) { float v = 1. - abs(vn2(vec2(fx, s)) * 2. - 1.); n += v * v * a; fx = fx * 2.1 + 3.7; a *= .5; }
  float base = k == 0 ? 14. : (k == 1 ? 22. : 34.);
  float amp = k == 0 ? 40. : (k == 1 ? 74. : 130.);
  return floor((base + amp * n) / bw) * bw;
}
// ближайшая гряда по лучу: t и насколько ниже гребня (для каймы света)
bool ridges(vec3 ro, vec3 rd, out float tr, out float below, out int kk){
  tr = 1e9; below = 0.; kk = 0;
  if (rd.z <= 1e-3) return false;
  for (int k = 0; k < 3; k++) {
    float zk = k == 0 ? 330. : (k == 1 ? 470. : 660.);
    float t = (zk - ro.z) / rd.z;
    if (t <= 0.) continue;
    vec3 p = ro + rd * t;
    // седловина там, куда садится лого: зарево видно между вершинами
    float gx = uCam.x + (uLC.x - uCam.x) / max(uLC.z - uCam.z, 1.) * (zk - uCam.z);
    float h = ridgeH(k, p.x) * mix(.42, 1., smoothstep(20. + 12. * float(k), 120. + 60. * float(k), abs(p.x - gx)));
    h = floor(h);
    if (p.y < h) { tr = t; below = h - p.y; kk = k; return true; }
  }
  return false;
}

bool trace(vec3 ro, vec3 rd, float tMax, out float tHit, out vec3 n, out vec2 cell, out float hc){
  n = vec3(0, 1, 0); tHit = 0.; cell = vec2(0.); hc = 0.;
  if (ro.y > 41. && rd.y >= 0.) return false;
  vec2 ci = floor(ro.xz);
  vec2 st = sign(rd.xz);
  vec2 inv = 1. / max(abs(rd.xz), vec2(1e-5));
  vec2 tN = (st * (ci - ro.xz) + st * .5 + .5) * inv;
  float t = 0.;
  for (int i = 0; i < 340; i++) {
    float h = hAt(ci);
    float tx = min(tN.x, tN.y);
    if (ro.y + rd.y * t < h) { tHit = t; cell = ci; hc = h; return true; }
    if (ro.y + rd.y * tx < h) { tHit = (h - ro.y) / rd.y; n = vec3(0, 1, 0); cell = ci; hc = h; return true; }
    if (tN.x < tN.y) { t = tN.x; tN.x += inv.x; ci.x += st.x; n = vec3(-st.x, 0, 0); }
    else             { t = tN.y; tN.y += inv.y; ci.y += st.y; n = vec3(0, 0, -st.y); }
    if (t > tMax || (rd.y > 0. && ro.y + rd.y * t > 41.)) break;
  }
  return false;
}
float shadowRay(vec3 ro, vec3 rd){
  if (rd.y <= 0.) return 0.;
  vec2 ci = floor(ro.xz);
  vec2 st = sign(rd.xz);
  vec2 inv = 1. / max(abs(rd.xz), vec2(1e-5));
  vec2 tN = (st * (ci - ro.xz) + st * .5 + .5) * inv;
  float t = 0.;
  for (int i = 0; i < 48; i++) {
    if (ro.y + rd.y * t < hAt(ci) - .002) return 0.;
    if (tN.x < tN.y) { t = tN.x; tN.x += inv.x; ci.x += st.x; } else { t = tN.y; tN.y += inv.y; ci.y += st.y; }
    if (ro.y + rd.y * t > 41.) return 1.;
  }
  return 1.;
}

vec3 shadeBlock(vec3 p, vec3 n, vec2 cell, float hc, float dist){
  vec2 uv;
  if (n.y > .5) uv = fract(p.xz); else if (abs(n.x) > .5) uv = vec2(fract(p.z), fract(p.y)); else uv = vec2(fract(p.x), fract(p.y));
  float by = n.y > .5 ? hc - 1. : floor(p.y - n.y * .01);
  vec2 px = floor(uv * 16.);
  // текстура и швы блоков гаснут вдали, чтобы не рябить
  float far = smoothstep(25., 110., dist);
  float tex = mix(.8 + .4 * hash13(vec3(px, by * 3.1 + dot(cell, vec2(13.1, 7.7)))), 1., far);
  float alb = (n.y > .5 ? .3 : (by >= hc - 1. ? .2 : .13)) * tex;
  float e = min(min(uv.x, 1. - uv.x), min(uv.y, 1. - uv.y));
  alb *= mix(mix(.62, 1., smoothstep(0., .07, e)), .85, far);
  vec3 L = normalize(uLC - p);
  float lam = max(dot(n, L), 0.);
  if (lam > 0. && uSun > 0.) lam *= shadowRay(p + n * .02, L); else lam = 0.;
  // свет лого — прямой; зарево — мягкое, с его стороны
  vec3 Lh = normalize(vec3(L.x, max(L.y, .12), L.z));
  float amb = .022 + .055 * max(n.y, 0.) + uGlow * (1. + uBoost) * (.03 + .16 * max(dot(n, Lh), 0.));
  // самые высокие уступы ещё ловят последний свет, когда лого уже за горами
  float last = uGlow * smoothstep(22., 38., p.y) * max(dot(n, Lh), 0.) * .5 * (1. - smoothstep(0., .1, L.y));
  // верхние грани в сторону зарева ловят его кромкой
  float rimTop = max(n.y, 0.) * pow(max(dot(normalize(p - uCam), gLd), 0.), 5.) * uGlow * (1. + uBoost) * .5 * smoothstep(.3, -.04, gLd.y);
  // свет курсора: тёплое пятно в мире под рукой
  vec3 Lc = uCur.xyz - p; float dc = length(Lc);
  float cur = uCur.w * max(dot(n, Lc / max(dc, 1e-3)), 0.) * 45. / (30. + dc * dc);
  return vec3(alb * (lam * uSun * 1.7 + amb + last + rimTop + cur));
}

vec3 ridgeColor(vec3 rd, float below, int k){
  float rim = exp(-below * (k == 0 ? .45 : .3)) * (.03 + 1.5 * pow(max(dot(rd, gLd), 0.), 9.)) * uGlow * (1. + uBoost + uRim + uFlashC);
  return vec3(.006 + rim * .35);
}

vec3 skyCol(vec3 ro, vec3 rd, bool withLogo){
  float F = fogDepth(ro, rd, 3000.);
  float T = exp(-F);
  vec3 c = vec3(airLight(rd) * (1. - T) + afterglow(rd));
  c = clouds(ro, rd, c);
  if (withLogo) {
    float sm; float e = logoAlong(ro, rd, sm);
    c += vec3(e) * mix(1., T, .8) + vec3(sm * uLogoI * .5);
  }
  return c;
}

void main(){
  vec2 uv = gl_FragCoord.xy / uRes * 2. - 1.;
  vec3 ro = uCam;
  vec3 rd = normalize(uFwd + uv.x * uTanH * uAspect * uRight + uv.y * uTanH * uUp);
  gLd = normalize(uLC - ro);
  vec3 col;
  float depth = 1e4;
#if WORLD == 0
  col = skyCol(ro, rd, true);
#else
  float tHit; vec3 n; vec2 cell; float hc;
  bool hit = trace(ro, rd, 300., tHit, n, cell, hc);
  float tS = hit ? tHit : 1e9;
  float tR, below; int kk;
  bool rh = ridges(ro, rd, tR, below, kk);
  if (rh && tR < tS) { tS = tR; }
  float tW = rd.y < 0. ? (WATER - ro.y) / rd.y : 1e9;
  if (tW < tS) {
    // река и озеро: отражают зарево, гряды, лого; у берегов — тень от склонов
    vec3 pw = ro + rd * tW;
    vec2 wv = vec2(fbm2(pw.xz * .25 + vec2(uTime * .16, 0.)), fbm2(pw.xz * .25 + vec2(3.7, uTime * .14))) - .5;
    vec2 wv2 = vec2(vn2(pw.xz * 1.3 + uTime * .5), vn2(pw.xz * 1.3 - uTime * .4 + 7.)) - .5;
    vec3 wn = normalize(vec3(wv.x * .12 + wv2.x * .05, 1., wv.y * .12 + wv2.y * .05));
    vec3 rr = reflect(rd, wn);
    float fr = .03 + .97 * pow(1. - max(dot(-rd, wn), 0.), 5.);
    vec3 refl;
    float tr2, bl2; int k2;
    if (ridges(pw, rr, tr2, bl2, k2)) {
      float T2 = exp(-fogDepth(pw, rr, tr2));
      refl = ridgeColor(rr, bl2, k2) * T2 + vec3(airLight(rr) * (1. - T2));
    } else refl = skyCol(pw, rr, true);
    // склоны рядом закрывают небо в отражении
    float occ = 1.;
    for (int i = 1; i <= 12; i++) {
      vec3 s = pw + rr * (float(i) * float(i) * .9);
      if (s.y < hAt(floor(s.xz))) { occ = 0.; break; }
      if (s.y > 41.) break;
    }
    refl *= mix(.05, 1., occ);
    col = vec3(.003) + refl * (.25 + .75 * fr);
    if (uCur.w > 0.) {
      vec3 Lc = uCur.xyz - pw; float dc = length(Lc);
      col += vec3(uCur.w * (.6 * 16. / (16. + dc * dc) + 2.4 * pow(max(dot(rr, Lc / dc), 0.), 70.) * 60. / (60. + dc * dc)));
    }
    depth = tW;
  } else if (hit && tHit <= tS) {
    vec3 p = ro + rd * tHit;
    col = shadeBlock(p, n, cell, hc, tHit);
    depth = tHit;
  } else if (rh) {
    col = ridgeColor(rd, below, kk);
    depth = tR;
  } else {
    col = skyCol(ro, rd, true);
  }
  if (depth < 1e4) {
    float T = exp(-fogDepth(ro, rd, depth) * (.75 + .5 * fbm2((ro + rd * depth).xz * .012 + uTime * .01)));
    col = col * T + vec3(airLight(rd) * (1. - T));
  }
  // курсор светит в туман
  if (uCur.w > 0.) {
    float tc = clamp(dot(uCur.xyz - ro, rd), 0., depth);
    float dd = length(ro + rd * tc - uCur.xyz);
    col += vec3(uCur.w * (.26 * exp(-dd * .3) + .06 * exp(-dd * .055)));
  }
#endif
  outColor = vec4(col, depth);
}`;
const sceneSrc = world => COMMON.replace("precision highp int;", "precision highp int;\n#define WORLD " + world) + FS_SCENE;

// Искры: угли с крыльев, разлёт при вспышке, искры с куемого титра, искры с горящей линии под курсором.
const VS_PART = `#version 300 es
precision highp float;
uniform float uTime, uH, uEmbers, uSet, uIgn;
uniform vec3 uCam, uRight, uUp, uFwd, uLC, uLR, uLU;
uniform float uTanH, uAspect, uLS;
uniform vec2 uRes;            // css px
uniform float uPx;            // пикселей цели на css px
uniform vec4 uLk;             // титр: x, y снизу, w, h (css px)
uniform vec2 uRule;           // линия: высота над низом титра (доля), полуширина (доля)
uniform float uForge, uForgeA;
uniform vec4 uHov; uniform float uHovA;
out float vI; out float vDist;
float h1(float x){ return fract(sin(x * 127.1) * 43758.5453); }
vec4 world(vec3 p){ vec3 dd = p - uCam; float xc = dot(dd, uRight), yc = dot(dd, uUp), zc = dot(dd, uFwd); vDist = length(dd); if (zc < .3) return vec4(2., 2., 2., 1.); return vec4(xc / (uTanH * uAspect), yc / uTanH, .5 * zc, zc); }
vec4 screen(vec2 px){ vDist = 0.; return vec4(px / uRes * 2. - 1., 0., 1.); }
vec3 onLogo(vec2 uv){ return uLC + uLR * (uv.x - .5) * uLS + uLU * (.5 - uv.y) * uLS; }
void main(){
  gl_Position = vec4(2., 2., 2., 1.); gl_PointSize = 0.; vI = 0.; vDist = 0.;
  float id = float(gl_VertexID);
  float r1 = h1(id * 1.17 + .3), r2 = h1(id * 2.31 + .7), r3 = h1(id * 3.77 + .1);
  if (id < 180.) {
    if (uEmbers <= 0.) return;
    float life = 2.6 + r1 * 3.2;
    float tt = uTime + r2 * life;
    float k = floor(tt / life), age = fract(tt / life);
    bool left = h1(id * 9.1 + k) < .5;
    vec2 tip = vec2(.509, .866);
    vec2 top = left ? vec2(.159, .253) : vec2(.841, .209);
    float a = .25 + .75 * h1(id * 4.3 + k * 3.1);
    vec2 d = top - tip; vec2 nn = normalize(vec2(-d.y, d.x));
    vec2 uv = tip + d * a + nn * (h1(id * 6.7 + k) - .5) * .18 * sin(3.14159 * a);
    float s = age * life;
    uv.y -= s * (.025 + r3 * .04);
    uv.x += sin(s * 1.3 + r2 * 6.28) * .018 * s;
    vec3 p = onLogo(uv);
    float bright = sin(age * 3.14159) * (.4 + 1.1 * r3);
    if (!(uSet > 0. && h1(id * 7.7) < uSet)) return;   // у крыльев искр нет
    {
      // лого за горами: искры встают из-за гребней и медленно уходят вверх
      float l2 = 7. + r1 * 7.;
      float tt2 = uTime + r2 * l2; float k2 = floor(tt2 / l2), a2 = fract(tt2 / l2);
      p = uLC + uLR * (h1(id * 3.1 + k2) - .5) * uLS * 2.2 + vec3(0., 1., 0.) * (uLS * .25 + a2 * l2 * (5. + 9. * r3)) + uLR * sin(a2 * 6.28 + r1 * 9.) * 6.;
      bright = sin(a2 * 3.14159) * (.25 + .6 * r3) * 1.6;
    }
    gl_Position = world(p);
    gl_PointSize = clamp((1.2 + r3 * 1.8) * uH / 720., 1., 4.);
    vI = bright * uEmbers;
  } else if (id < 420.) {
    // (вспышка больше не рассыпает искры вокруг лого — это были «зёрна» на фоне крыльев)
    return;
    float life = 1.1 + r1 * 2.3;
    float a = uIgn;
    if (a > life) return;
    float ang = r2 * 6.28318;
    vec2 dir = vec2(cos(ang), sin(ang) * .75 - .3);
    float sp = .22 + .8 * r3 * r3;
    vec2 uv = vec2(.509, .866) + dir * sp * (1. - exp(-a * 2.4)) / 2.4 * 2.;
    uv.y -= a * a * .028 * (.4 + r1);
    gl_Position = world(onLogo(uv));
    gl_PointSize = clamp((1.6 + r3 * 2.8) * uH / 720., 1., 7.);
    float f = 1. - a / life;
    vI = f * f * (1.6 + 2.4 * r1);
  } else if (id < 560.) {
    // титр куётся: искры срываются с горящей линии
    if (uForgeA <= 0.) return;
    float life = .9 + r1 * 1.4;
    float tt = uForge + r2 * life; float k = floor(tt / life), age = fract(tt / life);
    float born = uForge - age * life;
    if (born < 0.) return;
    float spread = clamp(born / .75, 0., 1.) * uRule.y;
    float x = uLk.x + uLk.z * (.5 + (h1(id * 5.1 + k) - .5) * 2. * spread);
    float s = age * life;
    vec2 px = vec2(x + sin(s * 3. + r3 * 9.) * 7. * s, uLk.y + uLk.w * uRule.x + s * (26. + 70. * r3) - s * s * 10.);
    gl_Position = screen(px);
    gl_PointSize = (1.2 + 1.8 * r3) * uPx;
    vI = sin(age * 3.14159) * (1. + 1.6 * r1) * uForgeA;
  } else {
    // под курсором: искры поднимаются с горящей линии
    if (uHovA <= 0.) return;
    float life = .55 + r1 * .9;
    float tt = uTime + r2 * life; float k = floor(tt / life), age = fract(tt / life);
    float x = uHov.x + (uHov.z - uHov.x) * h1(id * 4.7 + k) * uHov.w;
    float s = age * life;
    vec2 px = vec2(x + sin(s * 4. + r3 * 7.) * 4., uHov.y + s * (16. + 42. * r3));
    gl_Position = screen(px);
    gl_PointSize = (1. + 1.4 * r3) * uPx;
    vI = sin(age * 3.14159) * (.5 + 1.1 * r1) * uHovA;
  }
}`;
const FS_PART = `#version 300 es
precision highp float;
uniform sampler2D uScene; uniform int uHasDepth;
in float vI; in float vDist;
out vec4 o;
void main(){
  if (uHasDepth == 1 && texelFetch(uScene, ivec2(gl_FragCoord.xy), 0).a < vDist - 1.) discard;
  vec2 c = gl_PointCoord * 2. - 1.;
  o = vec4(vec3(vI * exp(-dot(c, c) * 2.4)), 0.);
}`;
const FS_DOWN = `#version 300 es
precision highp float;
uniform sampler2D uA; uniform sampler2D uB; uniform vec2 uSrcTexel, uDst; uniform int uFirst;
out vec4 o;
vec3 s(vec2 uv){ vec3 c = texture(uA, uv).rgb; if (uFirst == 1) { c += texture(uB, uv).rgb; c = max(c - 1., 0.); } return c; }
void main(){
  vec2 uv = gl_FragCoord.xy / uDst; vec2 t = uSrcTexel;
  vec3 a = s(uv + t * vec2(-2., 2.)), b = s(uv + t * vec2(0., 2.)), c = s(uv + t * vec2(2., 2.));
  vec3 d = s(uv + t * vec2(-2., 0.)), e = s(uv), f = s(uv + t * vec2(2., 0.));
  vec3 g = s(uv + t * vec2(-2., -2.)), h = s(uv + t * vec2(0., -2.)), i = s(uv + t * vec2(2., -2.));
  vec3 j = s(uv + t * vec2(-1., 1.)), k = s(uv + t * vec2(1., 1.)), l = s(uv + t * vec2(-1., -1.)), m = s(uv + t * vec2(1., -1.));
  o = vec4(e * .125 + (a + c + g + i) * .03125 + (b + d + f + h) * .0625 + (j + k + l + m) * .125, 1.);
}`;
const FS_UP = `#version 300 es
precision highp float;
uniform sampler2D uA; uniform vec2 uSrcTexel, uDst;
out vec4 o;
void main(){
  vec2 uv = gl_FragCoord.xy / uDst; vec2 t = uSrcTexel;
  vec3 c = texture(uA, uv).rgb * 4.
    + (texture(uA, uv + vec2(t.x, 0.)).rgb + texture(uA, uv - vec2(t.x, 0.)).rgb + texture(uA, uv + vec2(0., t.y)).rgb + texture(uA, uv - vec2(0., t.y)).rgb) * 2.
    + texture(uA, uv + t).rgb + texture(uA, uv - t).rgb + texture(uA, uv + vec2(t.x, -t.y)).rgb + texture(uA, uv + vec2(-t.x, t.y)).rgb;
  o = vec4(c / 16., 1.);
}`;
// Лучи: отдельным проходом в четверть разрешения, много отсчётов — потом мягко растягиваются на экран
const FS_RAYS = COMMON + `
uniform sampler2D uSrc; uniform vec2 uDst, uLS; uniform float uLSr, uTime;
out vec4 o;
float hq(vec2 p, float s){ uvec2 q = uvec2(ivec2(p)) * uvec2(1597334673U, 3812015801U); uint n = (q.x ^ q.y ^ uint(s)) * 1597334673U; n ^= n >> 15; n *= 2246822519U; n ^= n >> 13; return float(n) * (1. / 4294967295.); }
void main(){
  vec2 uv = gl_FragCoord.xy / uDst;
  float ar = uDst.x / uDst.y;
  vec2 dir = (uLS - uv) / 96.;
  vec2 q = uv + dir * hq(gl_FragCoord.xy, 5.);
  float dec = 1.; vec3 acc = vec3(0.);
  for (int i = 0; i < 96; i++) {
    float near = smoothstep(uLSr * 3.4, uLSr * .35, length((q - uLS) * vec2(ar, 1.)));
    acc += texture(uSrc, q).rgb * dec * near;
    q += dir; dec *= .985;
  }
  o = vec4(acc * (2.6 / 96.), 1.);
}`;
const FS_COMP = COMMON + `
uniform sampler2D uScene; uniform sampler2D uPart; uniform sampler2D uBloom; uniform sampler2D uMask; uniform sampler2D uRaySrc;
uniform float uSqueeze, uBloomK, uTrailK; uniform sampler2D uTrail;                        // пока держат запуск, темнота сжимается к угольку
float hq(vec2 p, float s){ uvec2 q = uvec2(ivec2(p)) * uvec2(1597334673U, 3812015801U); uint n = (q.x ^ q.y ^ uint(s)) * 1597334673U; n ^= n >> 15; n *= 2246822519U; n ^= n >> 13; return float(n) * (1. / 4294967295.); }
uniform vec2 uRes; uniform float uTime, uMenuShade, uCornerShade, uFade, uPx;
uniform vec2 uLS; uniform float uLSr;          // свет на экране (uv) и его радиус (доли высоты)
uniform float uRays, uStreak, uHeat;
uniform vec4 uLk;                              // титр: x, y снизу, w, h (css px)
uniform vec4 uLkA;                             // секунды ковки, освещённость, «CURSED PRESENTS», вся надпись
uniform vec3 uLkM;                             // верх букв, основание, линия (y текстуры)
uniform vec4 uHov0, uHov1; uniform vec2 uHovA; // горящие линии под словами: x0, y, x1, прогресс (css px)
out vec4 o;
float flameLine(vec2 f, vec4 h, float a){
  if (a <= 0.) return 0.;
  float px = (f.x - h.x) / max(h.z - h.x, 1.);
  float dy = f.y - h.y;
  if (px < -.05 || px > 1.05 || dy < -4. || dy > 110.) return 0.;
  float rev = smoothstep(h.w + .03, h.w - .1, px) * smoothstep(-.05, .03, px) * smoothstep(1.05, .96, px);
  // языки огня: каждый своей высоты, сужаются и тают кверху, колышутся; поверх — тонкие высокие нити
  float xs = f.x * .045 + 1.1 * fbm2(vec2(f.x * .018, dy * .028 - uTime * 1.7));
  float cell = floor(xs), fx = fract(xs) - .5;
  float hh = 12. + 58. * pow(vn2(vec2(cell * 1.7, uTime * 2.3)), 2.);
  float rise = clamp(dy / hh, 0., 1.);
  float w = .38 * pow(1. - rise, .8) + .04;
  float tongue = smoothstep(w, 0., abs(fx + .16 * sin(dy * .09 - uTime * 6.5 + cell * 2.3))) * pow(1. - rise, 1.3) * step(0., dy);
  float xs2 = f.x * .09 + 1.4 * fbm2(vec2(f.x * .03 + 7., dy * .04 - uTime * 2.4));
  float c2 = floor(xs2), f2 = fract(xs2) - .5;
  float h2 = 24. + 80. * pow(vn2(vec2(c2 * 2.9, uTime * 1.9 + 5.)), 3.);
  float r2 = clamp(dy / h2, 0., 1.);
  float wisp = smoothstep(.1 * (1. - r2) + .02, 0., abs(f2 + .2 * sin(dy * .12 - uTime * 7. + c2))) * pow(1. - r2, 1.6) * step(0., dy) * .55;
  float base = exp(-dy * dy / 3.) * .32 + exp(-max(dy, 0.) / 8.) * .22 * step(-1., dy);
  return (tongue * 1.15 + wisp + base) * rev * a;
}
void main(){
  vec2 frag = gl_FragCoord.xy;
  vec2 uv = frag / uRes;
  float ar = uRes.x / uRes.y;
  vec3 c = texture(uScene, uv).rgb + texture(uPart, uv).rgb + texture(uBloom, uv).rgb * .5 * uBloomK + texture(uTrail, uv).rgb * uTrailK;
  // лучи от света сквозь облака, гряды и туман
  if (uRays > 0.) c += texture(uRaySrc, uv).rgb * uRays;
  // киношный блик: горизонтальная полоса через самое горячее
  if (uStreak > 0.) {
    vec3 sb = vec3(0.);
    for (int i = -14; i <= 14; i++) { float k = float(i); sb += texture(uBloom, uv + vec2(k * .011, 0.)).rgb * exp(-abs(k) * .2); }
    c += sb * uStreak * .085;
  }
  float l = dot(c, vec3(.299, .587, .114));
  l = 1. - exp(-l * 1.25);
  l = mix(l, l * l * (3. - 2. * l), .35);
  // меню слева и виджеты справа: мир под ними чуть темнее
  float side = mix(1. - uMenuShade, 1., smoothstep(.04, .48, uv.x));
  vec2 a = uv * vec2(ar, 1.);
  float corner = exp(-pow(length((a - vec2(ar - .16, .12)) * vec2(.85, 1.6)) / .2, 2.)) + exp(-pow(length((a - vec2(ar - .12, .94)) * vec2(.9, 2.)) / .14, 2.));
  float vig = smoothstep(1.3 - .55 * uSqueeze, .35 - .25 * uSqueeze, length((uv - .5) * vec2(1.15, 1.)));
  l *= side * mix(.55 - .5 * uSqueeze, 1., vig) * (1. - uCornerShade * min(corner, 1.));
  // титр, выкованный огнём
  float txt = 0.;
  vec2 fc = frag / uPx;
  if (uLkA.w > 0.) {
    vec2 lp = (fc - uLk.xy) / uLk.zw;
    if (lp.x > -.03 && lp.x < 1.03 && lp.y > -.03 && lp.y < 1.03) {
      vec2 tuv = vec2(lp.x, 1. - lp.y);
      vec3 m = texture(uMask, tuv).rgb;
      vec3 mb = textureLod(uMask, tuv, 3.).rgb;
      vec3 mbb = textureLod(uMask, tuv, 5.).rgb;
      float ft = uLkA.x;
      // линия: загорается из середины и горит
      float rp = smoothstep(0., .75, ft);
      float ron = smoothstep(rp * .5 + .015, rp * .5 - .01, abs(lp.x - .5)) * step(0., ft);
      float rhot = exp(-max(ft, 0.) * 1.1);
      float above = (uLkM.z - tuv.y) * uLk.w;
      float tongue = 0.;
      if (above > -2. && above < 44.) {
        float n = fbm2(vec2(fc.x * .05, above * .07 - uTime * 3.2));
        tongue = smoothstep((6. + 26. * n * n) * (.25 + rhot), 0., above) * step(0., above) * n * 1.5 * rhot;
      }
      float rule = (m.b * (1. + 2.2 * rhot) + mb.b * (.45 + 2.4 * rhot)) * ron + tongue * ron * smoothstep(0., .02, mbb.b + mb.b);
      // слово поднимается из линии раскалённым фронтом и остывает
      float y01 = (tuv.y - uLkM.x) / (uLkM.y - uLkM.x);
      float wp = clamp((ft - .3) / 1.15, 0., 1.);
      float front = 1.08 - wp * 1.25 + .05 * gn2(vec2(lp.x * 28., ft * 2.5));
      float ab = front - y01;
      float vis = smoothstep(.015, -.025, ab) * step(0., ft - .3);
      float heat = exp(-max(-ab, 0.) * 2.6) * vis * (1. - smoothstep(1.3, 2.8, ft));
      float word = m.r * vis * (.93 + 2.4 * heat) + mb.r * (.16 * vis + 1.3 * heat) + mbb.r * .1 * vis;
      float lick = mb.r * smoothstep(.16, 0., ab) * step(0., ab) * pow(fbm2(vec2(lp.x * 46., ab * 24. - uTime * 6.)), 2.) * 3. * (1. - wp * .6) * step(0., ft - .3);
      float kick = (m.g * .85 + mb.g * .12) * uLkA.z;
      txt = (word + lick + rule + kick) * uLkA.y * uLkA.w;
    }
  }
  // пламя под словом, на которое навели
  txt += flameLine(fc, uHov0, uHovA.x) + flameLine(fc, uHov1, uHovA.y);
  l = 1. - (1. - l) * (1. - min(txt, 1.));
  l += (hq(frag, 7.) - .5) / 255.;   // только округление: полуступень яркости, неподвижно (без «зерна»)
  o = vec4(vec3(max(l, 0.) * uFade), 1.);
}`;
