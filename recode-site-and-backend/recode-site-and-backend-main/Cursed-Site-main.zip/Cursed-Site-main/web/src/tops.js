"use strict";
/* ================================================================================================ the best (23.10.2026)
   The members first by a count (/api/top, tops.rs): hours in Cursed, hours in Recode, badges, the forum's posts, the
   likes on their look. The first three stand apart, the rest down to the fiftieth below them, and where the one looking
   stands when they are further. */

const TP = { by: 'hours' };
const TP_TABS = [
  ['hours', ['Time in Cursed', 'Время в Cursed'], (v) => L(`${grp3(v)} h`, `${grp3(v)} ч`)],
  ['recode', ['Time in Recode', 'Время в Recode'], (v) => L(`${grp3(v)} h`, `${grp3(v)} ч`)],
  ['badges', ['Badges', 'Значки'], (v) => grp3(v)],
  ['posts', ['Forum', 'Форум'], (v) => grp3(v)],
  ['likes', ['Looks', 'Образы'], (v) => grp3(v)],
];
/** The word under a number of the first three: "hours", "часа". */
const TP_UNIT = {
  hours: (n) => L(n === 1 ? 'hour' : 'hours', plural(n, 'час', 'часа', 'часов')), recode: (n) => L(n === 1 ? 'hour' : 'hours', plural(n, 'час', 'часа', 'часов')),
  badges: (n) => L(n === 1 ? 'badge' : 'badges', plural(n, 'значок', 'значка', 'значков')), posts: (n) => L(n === 1 ? 'post' : 'posts', plural(n, 'сообщение', 'сообщения', 'сообщений')),
  likes: (n) => L(n === 1 ? 'like' : 'likes', plural(n, 'оценка', 'оценки', 'оценок')),
};

function viewTop() {
  const tab = TP_TABS.find((t) => t[0] === TP.by) || TP_TABS[0];
  const tabs = `<div class="tp-tabs">${TP_TABS.map(([k, n]) => `<button class="w small ${TP.by === k ? 'on' : ''}" data-tp-by="${k}">${esc(L(...n))}</button>`).join('')}</div>`;
  const c = ask('top?by=' + tab[0]);
  if (waiting(c)) return tabs + `<div class="tp-list">${ghosts(3)}</div>`;
  if (!c.ok) return tabs + trouble(c);
  const items = c.data.items.filter((x) => x.card), say = tab[2], unit = TP_UNIT[tab[0]];
  if (!items.length) return tabs + `<div class="empty">${L('No one yet.', 'Пока никого.')}</div>`;
  const me_ = state.user ? state.user.login : '';
  const who = (x) => `<span class="tp-name" translate="no">${pfx(x.card)}${esc(x.card.login)}</span>`;
  const href = (x) => '#/u/' + encodeURIComponent(x.card.login);
  const podium = items.slice(0, 3).map((x, i) => `<a class="tp-pod tp-p${i + 1}${x.card.login === me_ ? ' tp-me' : ''}" href="${href(x)}" data-key="tp-${tab[0]}-${x.card.uid}" style="--k:${i}">
      <span class="tp-rk num">${x.rank}</span>${head(x.card.login, 56)}${who(x)}<b class="tp-v num">${grp3(x.value)}</b><span class="tp-u">${esc(unit(x.value))}</span></a>`).join('');
  const rows = items.slice(3).map((x, i) => `<a class="tp-row${x.card.login === me_ ? ' tp-me' : ''}" href="${href(x)}" data-key="tp-${tab[0]}-${x.card.uid}" style="--k:${Math.min(i, 20) + 3}">
      <span class="tp-rk num">${x.rank}</span>${head(x.card.login, 28)}${who(x)}<b class="tp-v num">${say(x.value)}</b></a>`).join('');
  const m = c.data.me;
  const mine = m ? `<div class="tp-row tp-me tp-mine" data-key="tp-mine-${tab[0]}"><span class="tp-rk num">${m.rank}</span>${head(me_, 28)}<span class="tp-name" translate="no">${state.user && state.user.card ? pfx(state.user.card) : ''}${esc(me_)}</span><span class="tp-you">${L('you', 'вы')}</span><b class="tp-v num">${say(m.value)}</b></div>` : '';
  return tabs + `<div class="tp-pods">${podium}</div>${rows ? `<div class="tp-list">${rows}</div>` : ''}${mine}`;
}
MEMBERS_ONLY.add('top');
document.addEventListener('click', (e) => {
  const b = e.target.closest && e.target.closest('[data-tp-by]');
  if (!b || !b.closest('.r-win')) return;
  TP.by = b.dataset.tpBy;
  World.Snd.tick(.7);
  render(true);
});
