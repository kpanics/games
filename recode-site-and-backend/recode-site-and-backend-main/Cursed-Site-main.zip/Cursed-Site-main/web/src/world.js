"use strict";
/* =====================================================================================
   МИР ПОД САЙТОМ — тот же, что в меню Recode: долина, река, гряды, зарево за седловиной, белый огонь.
   Шейдеры — из превью запуска (src.html) один в один, их вставляет build.py. Здесь своё: страницы — места в этом
   мире (камера плывёт между ними), первый заход — вступление клиента, огонь под словом, на которое навели.
   ===================================================================================== */


const World = (() => {
const QS = new URLSearchParams(location.search);
const REDUCED = matchMedia("(prefers-reduced-motion: reduce)").matches;
const TL = {
  gatherFrom: .25, ignite: 1.95, growTo: 3.0, fovTo: 4.0,
  forge: 3.75, kick: 4.85,
  tiltFrom: 6.2, tiltTo: 9.8, setTo: 11.4,
  glideFrom: 6.6, glideTo: 8.8, build: 8.5,
  menuFrom: 8.9, side: 9.8, live: 10.6, settle: 11.6,
};
const HOLD_AT = TL.tiltFrom - .35;
const TAN27 = Math.tan(27 * Math.PI / 180);
const clamp01 = x => Math.min(1, Math.max(0, x));
const smooth = (a, b, x) => { const k = clamp01((x - a) / (b - a)); return k * k * (3 - 2 * k); };
const smoother = (a, b, x) => { const k = clamp01((x - a) / (b - a)); return k * k * k * (k * (k * 6 - 15) + 10); };
const easeOut = (a, b, x) => { const k = clamp01((x - a) / (b - a)); return 1 - Math.pow(1 - k, 3); };
const V = {
  add: (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]],
  sub: (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]],
  mul: (a, s) => [a[0] * s, a[1] * s, a[2] * s],
  dot: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2],
  cross: (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]],
  norm: a => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; },
};
const dirYP = (yaw, pitch) => { const cp = Math.cos(pitch); return [Math.sin(yaw) * cp, Math.sin(pitch), Math.cos(yaw) * cp]; };
const riverX = z => 7 * Math.sin(z * .012) + 3 * Math.sin(z * .031 + 1.3);
const LOGO = { yaw: -.07, dist: 600, size: .46, startElev: .5 + .366 * .46, endElev: -.34 };
const look = { x: 0, y: 0, tx: 0, ty: 0 };

/* ---- места: куда смотрит камера на каждой странице ----
   dz — вперёд по реке, dy — выше/ниже, yaw/pitch — поворот, fov — угол, shade — темнее слева (под меню),
   rshade — темнее справа (под колонкой справа), corner — тени под углами справа, fade — весь мир темнее (под стеклом окна),
   lock — подпись RECODE слева внизу, cur — свет курсора, look — мир чуть следует за мышью */
const ST = {
  home: { dz: 0,   dy: 0,   yaw: 0,    pitch: 0,     fov: 1,    shade: .72, rshade: 0,   corner: .7, fade: 1,   lock: 1, cur: 1,  look: 1 },
  buy:  { dz: 46,  dy: -6,  yaw: .035, pitch: .028,  fov: .88,  shade: .62, rshade: .55, corner: 0,  fade: 1,   lock: 1, cur: 1,  look: 1 },
  done: { dz: 92,  dy: -9,  yaw: .05,  pitch: .05,   fov: .8,   shade: .6,  rshade: 0,   corner: .4, fade: 1,   lock: 1, cur: 1,  look: 1 },
  free: { dz: -16, dy: 3,   yaw: -.62, pitch: -.04,  fov: 1,    shade: .74, rshade: 0,   corner: .5, fade: 1,   lock: 1, cur: 1,  look: 1 },
  auth: { dz: 8,   dy: 4,   yaw: .06,  pitch: .4,    fov: 1.08, shade: .55, rshade: 0,   corner: .3, fade: 1,   lock: 1, cur: 1,  look: .6 },
  lost: { dz: 24,  dy: -7,  yaw: .02,  pitch: -.3,   fov: 1,    shade: .55, rshade: 0,   corner: .3, fade: 1,   lock: 1, cur: 1,  look: 1 },
  wardrobe: { dz: 30, dy: 1, yaw: -.05, pitch: -.015, fov: .94, shade: .62, rshade: .62, corner: .2, fade: .86, lock: 1, cur: .6, look: .5 },
  app:  { dz: -8,  dy: 6,   yaw: 0,    pitch: -.03,  fov: 1,    shade: 0,   rshade: 0,   corner: 0,  fade: .62, lock: 0, cur: .4, look: .4 },
};
const S = { v: { ...ST.home }, from: { ...ST.home }, to: { ...ST.home }, at: -1e9, dur: 1.9, name: "home" };
function station(name, instant, dur){
  const to = ST[name] || ST.home;
  if (S.name === name && !instant) return;
  S.name = name; S.from = { ...S.v }; S.to = { ...to }; S.at = performance.now() / 1000; S.dur = instant ? 0 : dur || 2.1;
  if (instant) S.v = { ...to };
}
/* ---- приход (23.10, вместо ролика запуска): мир проступает из темноты, камера опускается к месту страницы с высоты
   и издалека, свет за седловиной вспыхивает, когда долина видна. Ждёт, пока мир соберётся: в темноте нечему плыть. ---- */
const ARR = { want: false, done: false, cb: null };
function arriveNow(){
  ARR.done = true;
  const to = ST[S.name] || ST.home;
  if (ARR.want && !REDUCED) {
    S.v = { ...to, dz: to.dz - 38, dy: to.dy + 9, pitch: to.pitch + .13, fov: to.fov * 1.16, shade: to.shade * .25, rshade: to.rshade * .25, corner: to.corner * .2, lock: 0 };
    S.from = { ...S.v }; S.to = { ...to }; S.at = performance.now() / 1000; S.dur = 2.9;
    lockMul.v = 0; lockMul.to = 1;
    setTimeout(() => { glowFx.pulse = Math.max(glowFx.pulse, .55); }, 520);
  }
  if (ARR.cb) { const cb = ARR.cb; ARR.cb = null; try { cb(); } catch (e) { console.error(e); } }
}
function stepStation(now){
  const k = S.dur <= 0 ? 1 : smoother(0, 1, (now - S.at) / S.dur);
  for (const key in S.to) S.v[key] = S.from[key] + (S.to[key] - S.from[key]) * k;
}

/* ---- камера: во вступлении — как в клиенте; потом стоит на месте страницы и дышит ---- */
function camera(t, aspect){
  const s = S.v;
  const k = smoother(TL.tiltFrom, TL.tiltTo, t);
  const z = 12 * Math.sin(t * .0045) - 9 * (1 - smoother(TL.tiltFrom, TL.tiltTo + .8, t)) + s.dz;
  const pos = [riverX(z) * .85 - 1, 22 + 12 * (1 - k) + .35 * Math.sin(t * .23) + s.dy, z];
  const m = smooth(TL.tiltTo - .4, TL.settle, t);
  const yaw = LOGO.yaw * (1 - k) + (.018 * Math.sin(t * .05) + look.x * s.look) * m + s.yaw * m;
  const pitch = .5 + (-.085 - .5) * k + (.008 * Math.sin(t * .071) + look.y * s.look) * m + s.pitch * m;
  const fwd = dirYP(yaw, pitch);
  const right = V.norm([-fwd[2], 0, fwd[0]]);
  const up = V.cross(right, fwd);
  const base = Math.max(TAN27, .42 / aspect);
  return { pos, fwd, right, up, tanH: base * (.32 + .68 * smoother(TL.ignite - .2, TL.fovTo, t)) * (1 + (s.fov - 1) * m), aspect };
}
function logoAt(t, cam){
  const k = smoother(TL.tiltFrom + .15, TL.setTo, t);
  const elev = LOGO.startElev + (LOGO.endElev - LOGO.startElev) * k;
  const dir = dirYP(LOGO.yaw, elev);
  const c = V.add(cam.pos, V.mul(dir, LOGO.dist));
  const N = V.mul(dir, -1);
  const U = V.norm(V.sub([0, 1, 0], V.mul(N, N[1])));
  const R = V.cross(U, N);
  return { c, N, U, R, s: 2 * LOGO.dist * Math.tan(LOGO.size / 2), elev };
}
function lightAt(t, L){
  const ig = t - TL.ignite;
  const lit = smooth(TL.ignite - .05, TL.growTo, t);
  const k = clamp01(ig / (TL.growTo - TL.ignite));
  const grow = ig < 0 ? 0 : 1.12 * (1 - Math.pow(1 - k, 3)) + .12 * Math.sin(Math.PI * Math.min(1, k * 1.15)) * (1 - .6 * k);
  const gather = clamp01((t - TL.gatherFrom) / (TL.ignite - TL.gatherFrom));
  return {
    gather, ign: ig, grow,
    ember: (.55 + 1.1 * gather * gather) * (1 - .75 * lit),
    flash: ig >= 0 ? Math.exp(-ig * 3.2) : 0,
    logo: lit * (.72 + .28 * smooth(TL.ignite + .6, TL.fovTo, t)),
    sun: 1.05 * lit * smooth(-.06, .14, L.elev),
    glow: (.45 + .55 * lit) * (1 - .5 * smooth(.05, -.3, L.elev)) * lit,
    rim: 2.6 * Math.exp(-Math.pow((L.elev - .07) / .1, 2)) * smooth(TL.tiltFrom, TL.tiltFrom + 1.2, t),
  };
}

/* =====================================================================================
   GL
   ===================================================================================== */
let canvas = null, gl = null, R = null, PAR = null;
function compile(type, src){
  const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
  return s;
}
function uniformsOf(p){
  const found = {}; const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
  for (let i = 0; i < n; i++) { const a = gl.getActiveUniform(p, i); found[a.name] = gl.getUniformLocation(p, a.name); }
  return new Proxy(found, { get: (o, k) => (k in o ? o[k] : null) });
}
function program(vs, fs){
  const p = gl.createProgram(); gl.attachShader(p, compile(gl.VERTEX_SHADER, vs)); gl.attachShader(p, compile(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
  return { p, u: uniformsOf(p), done: true };
}
// мир собирается в фоне, пока горит лого (KHR_parallel_shader_compile): страница не замирает
function startProgram(vs, fs){
  const p = gl.createProgram();
  for (const [type, src] of [[gl.VERTEX_SHADER, vs], [gl.FRAGMENT_SHADER, fs]]) { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); gl.attachShader(p, s); }
  gl.linkProgram(p);
  return { p, u: null, done: false, failed: false };
}
function programReady(P, block){
  if (P.done || P.failed) return P.done;
  if (!block && PAR && !gl.getProgramParameter(P.p, PAR.COMPLETION_STATUS_KHR)) return false;
  if (!gl.getProgramParameter(P.p, gl.LINK_STATUS)) { console.error(gl.getProgramInfoLog(P.p)); P.failed = true; return false; }
  P.u = uniformsOf(P.p); P.done = true; return true;
}
function target(w, h, fmt){
  const t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.texImage2D(gl.TEXTURE_2D, 0, fmt.internal, w, h, 0, gl.RGBA, fmt.type, null);
  const f = gl.createFramebuffer(); gl.bindFramebuffer(gl.FRAMEBUFFER, f);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, t, 0);
  return { t, f, w, h };
}
function dropTarget(x){ gl.deleteTexture(x.t); gl.deleteFramebuffer(x.f); }
// сайта поверх больше, чем меню в клиенте: огонь под выбранным пунктом и тень справа — две правки шейдера сборки
const COMP = FS_COMP
  .replace("uniform vec2 uHovA;", "uniform vec2 uHovA; uniform vec4 uSel; uniform float uSelA, uRShade;")
  .replace("txt += flameLine(fc, uHov0, uHovA.x) + flameLine(fc, uHov1, uHovA.y);", "txt += flameLine(fc, uHov0, uHovA.x) + flameLine(fc, uHov1, uHovA.y) + flameLine(fc, uSel, uSelA) * .6;")
  .replace("float side = mix(1. - uMenuShade, 1., smoothstep(.04, .48, uv.x));", "float side = mix(1. - uMenuShade, 1., smoothstep(.04, .48, uv.x)) * mix(1. - uRShade, 1., smoothstep(.97, .55, uv.x));");
if (!COMP.includes("uSelA) * .6") || !COMP.includes("uRShade, 1.")) throw new Error("FS_COMP changed: the site's patches no longer apply");
function initGL(){
  const float = !!gl.getExtension("EXT_color_buffer_float");
  PAR = gl.getExtension("KHR_parallel_shader_compile");
  R = {
    fmt: float ? { internal: gl.RGBA16F, type: gl.HALF_FLOAT } : { internal: gl.RGBA8, type: gl.UNSIGNED_BYTE },
    sky: program(VS_TRI, sceneSrc(0)), world: startProgram(VS_TRI, sceneSrc(1)), part: program(VS_PART, FS_PART),
    down: program(VS_TRI, FS_DOWN), up: program(VS_TRI, FS_UP), comp: program(VS_TRI, COMP), rays: program(VS_TRI, FS_RAYS),
    vao: gl.createVertexArray(), scale: QS.has("scale") ? +QS.get("scale") : .8, w: 0, h: 0, rt: null,
  };
  const H = program(VS_TRI, FS_HEIGHT);
  R.hm = target(384, 768, { internal: gl.RGBA8, type: gl.UNSIGNED_BYTE });
  gl.bindTexture(gl.TEXTURE_2D, R.hm.t); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.useProgram(H.p); gl.bindVertexArray(R.vao); gl.bindFramebuffer(gl.FRAMEBUFFER, R.hm.f); gl.viewport(0, 0, 384, 768);
  gl.drawArrays(gl.TRIANGLES, 0, 3);
  const plain = (internal, format, px) => {
    const t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texImage2D(gl.TEXTURE_2D, 0, internal, 1, 1, 0, format, gl.UNSIGNED_BYTE, px);
    for (const [k, v] of [[gl.TEXTURE_MIN_FILTER, gl.LINEAR], [gl.TEXTURE_MAG_FILTER, gl.LINEAR], [gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE], [gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE]]) gl.texParameteri(gl.TEXTURE_2D, k, v);
    return t;
  };
  R.mask = plain(gl.RGBA8, gl.RGBA, new Uint8Array([0, 0, 0, 255]));
  R.logoBase = plain(gl.R8, gl.RED, new Uint8Array([0]));
}
function loadLogoBase(src){
  return new Promise(res => {
    const img = new Image();
    img.onload = () => { if (R) { gl.bindTexture(gl.TEXTURE_2D, R.logoBase); gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1); gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, gl.RED, gl.UNSIGNED_BYTE, img); } res(); };
    img.onerror = () => res();
    img.src = src;
  });
}
function resize(){
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const cw = Math.max(1, Math.round(canvas.clientWidth * dpr)), ch = Math.max(1, Math.round(canvas.clientHeight * dpr));
  if (canvas.width !== cw || canvas.height !== ch) { canvas.width = cw; canvas.height = ch; }
  const cap = Math.min(1, Math.sqrt(1.6e6 / (cw * ch)));
  const w = Math.max(64, Math.round(cw * R.scale * cap)), h = Math.max(36, Math.round(ch * R.scale * cap));
  if (R.rt && R.w === w && R.h === h) return;
  if (R.rt) [R.rt.scene, R.rt.part, R.rt.rays, ...R.rt.mips].forEach(dropTarget);
  const mips = []; let mw = w, mh = h;
  for (let i = 0; i < 5; i++) { mw = Math.max(1, mw >> 1); mh = Math.max(1, mh >> 1); mips.push(target(mw, mh, R.fmt)); }
  R.rt = { scene: target(w, h, R.fmt), part: target(w, h, R.fmt), rays: target(Math.max(1, w >> 2), Math.max(1, h >> 2), R.fmt), mips };
  R.w = w; R.h = h;
}

const glowFx = { boost: 0, target: 0, pulse: 0 };
let sceneFade = 1;
const fx = { flashC: 0, nextFlash: 0, flashAt: -99 };
const cursor = { x: .62, y: .55, sx: .62, sy: .55, on: 0, ton: 0 };
function toScreen(p, cam){
  const d = V.sub(p, cam.pos), zc = V.dot(d, cam.fwd);
  if (zc < .5) return null;
  return { x: V.dot(d, cam.right) / (zc * cam.tanH * cam.aspect) * .5 + .5, y: V.dot(d, cam.up) / (zc * cam.tanH) * .5 + .5, z: zc };
}
// курсор — маленький огонь в мире: точка на луче под ним, в ~26 блоках от камеры
function cursorLight(t, cam){
  const nx = cursor.sx * 2 - 1, ny = 1 - cursor.sy * 2;
  const d = V.norm(V.add(cam.fwd, V.add(V.mul(cam.right, nx * cam.tanH * cam.aspect), V.mul(cam.up, ny * cam.tanH))));
  const p = V.add(cam.pos, V.mul(d, 26));
  return [p[0], Math.max(p[1], 11), p[2], cursor.on * smooth(TL.live, TL.settle + .6, t) * .9 * S.v.cur];
}

/* ---- титр: CURSED PRESENTS / RECODE, куётся во вступлении, потом — подпись слева внизу ---- */
const LK = { tex: false, cw: 1, ch: 1, wordTop: 0, wordBot: 0, ruleY: 0, ruleUp: 0, left: 0, wordW: 1, kickTop: 0, from: null, to: null };
function buildMask(){
  if (!R) return;
  const WORD = 256, KICK = 40, PAD = 64;
  const cv = document.createElement("canvas"); const x = cv.getContext("2d");
  const wordFont = `300 ${WORD}px "Sofia Sans Extra Condensed", Oswald, Impact, sans-serif`;
  const kickFont = `300 ${KICK}px "Martian Mono", Consolas, monospace`;
  const lay = (font, text, spacing) => { x.font = font; let w = 0; const xs = []; for (const c of text) { xs.push(w); w += x.measureText(c).width + spacing; } return { xs, w: w - spacing }; };
  const word = lay(wordFont, "RECODE", WORD * .26), kick = lay(kickFont, "CURSED PRESENTS", KICK * .62);
  x.font = wordFont; const asc = x.measureText("RECODE").actualBoundingBoxAscent || WORD * .7;
  const W = Math.ceil(Math.max(word.w, kick.w) + PAD * 2);
  const kickBase = PAD + KICK * .8, wordTop = kickBase + 58, wordBase = wordTop + asc, ruleY = wordBase + 56, H = Math.ceil(ruleY + 6 + PAD);
  cv.width = W; cv.height = H;
  x.fillStyle = "#000"; x.fillRect(0, 0, W, H); x.textBaseline = "alphabetic";
  const left = (W - word.w) / 2;
  x.font = kickFont; x.fillStyle = "#0f0"; [..."CURSED PRESENTS"].forEach((c, i) => x.fillText(c, left + kick.xs[i], kickBase));
  x.font = wordFont; x.fillStyle = "#f00"; [..."RECODE"].forEach((c, i) => x.fillText(c, left + word.xs[i], wordBase));
  x.fillStyle = "#00f"; x.fillRect(left, ruleY, word.w, 5);
  gl.bindTexture(gl.TEXTURE_2D, R.mask);
  gl.pixelStorei(gl.UNPACK_ALIGNMENT, 4);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, gl.RGBA, gl.UNSIGNED_BYTE, cv);
  gl.generateMipmap(gl.TEXTURE_2D);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
  Object.assign(LK, { tex: true, cw: W, ch: H, wordTop: (wordBase - asc) / H, wordBot: wordBase / H, ruleY: (ruleY + 2.5) / H, ruleUp: 1 - (ruleY + 2.5) / H, left, wordW: word.w, kickTop: (kickBase - KICK * .8) / H });
  layoutLockup();
}
// во вступлении — по центру; потом — подпись слева внизу, линия над строкой #foot
function layoutLockup(){
  if (!LK.tex) return;
  const W = innerWidth, H = innerHeight;
  const sI = Math.min((W * (W > H ? .38 : .8)) / LK.wordW, (H * .32) / LK.ch);
  const sF = Math.max(16, Math.min(34, H * .03)) / 256 * (W < 760 ? .9 : 1);
  const topI = H * .5 + Math.max(22, H * .045) - LK.kickTop * LK.ch * sI;
  LK.from = { s: sI, cx: W / 2, cy: topI + LK.ch * sI / 2 };
  const foot = document.getElementById("foot");
  const fr = foot ? foot.getBoundingClientRect() : { top: H - 40 };
  const left = (W < 760 ? 20 : W * .062) - LK.left * sF;
  const top = fr.top - Math.max(8, H * .01) - (LK.ruleY * LK.ch + 4) * sF;
  LK.to = { s: sF, cx: left + LK.cw * sF / 2, cy: top + LK.ch * sF / 2 };
}
function lockupState(t, lt){
  if (!LK.from) return { rect: [0, 0, 1, 1], lit: 0, kick: 0, sparks: 0 };
  const k = smoother(TL.glideFrom, TL.glideTo, t);
  const s = LK.from.s * Math.pow(LK.to.s / LK.from.s, k);
  const cx = LK.from.cx + (LK.to.cx - LK.from.cx) * k, cy = LK.from.cy + (LK.to.cy - LK.from.cy) * k;
  const w = LK.cw * s, h = LK.ch * s;
  return {
    rect: [cx - w / 2, innerHeight - (cy + h / 2), w, h],
    lit: Math.max(.25 + .75 * (lt ? lt.logo : 1), k),
    kick: smooth(TL.kick, TL.kick + .9, t) * (1 - smooth(TL.glideFrom, TL.glideFrom + .8, t)),
    sparks: smooth(TL.forge, TL.forge + .2, t) * (1 - smooth(TL.forge + 1.6, TL.forge + 2.8, t)),
  };
}

/* ---- огонь под словом: линия загорается слева направо, слово светлеет, мир отвечает заревом ---- */
const flames = [];
const sel = { el: null, a: 0, last: [0, 0, 0, 0] };
function rectOf(el, p){
  const hl = el.querySelector(":scope .r-hl") || el;
  const r = hl.getBoundingClientRect();
  if (!el.isConnected || r.width < 2 || r.bottom < 0 || r.top > innerHeight) return null;
  return [r.left, innerHeight - r.bottom + .5, r.right, p];
}
function tickFlames(dt){
  for (const f of flames) { if (!f.dying && f.el.isConnected) f.p += (1 - f.p) * Math.min(1, dt * 3.6); else f.a -= dt / .5; }
  for (let i = flames.length - 1; i >= 0; i--) if (flames[i].a <= 0 || flames.length - i > 2) flames.splice(i, 1);
  const want = sel.el && sel.el.isConnected ? 1 : 0;
  sel.a += (want - sel.a) * Math.min(1, dt * 3);
}
function hover(el){
  flames.forEach(f => f.dying = true);
  flames.push({ el, p: 0, a: 1, dying: false });
  glowFx.target = .14;
}
function leave(el){
  flames.forEach(f => { if (f.el === el) f.dying = true; });
  if (!flames.some(f => !f.dying)) glowFx.target = 0;
}
function calm(){ flames.forEach(f => f.dying = true); glowFx.target = 0; }
function tickFlashes(t, now){
  if (t < TL.settle) { fx.flashC = 0; return; }
  if (!fx.nextFlash) fx.nextFlash = now + 4 + Math.random() * 5;
  if (now >= fx.nextFlash) { fx.flashAt = now; fx.nextFlash = now + 7 + Math.random() * 9; }
  const x = now - fx.flashAt;
  const pulse = y => y < 0 ? 0 : Math.exp(-y * 6.5) * (1 - Math.exp(-y * 45));
  fx.flashC = (pulse(x) + .55 * pulse(x - .2) + .3 * pulse(x - .45)) * .9;
}

let snapWant = null;
const lockMul = { v: 1, to: 1 };
const appear = { at: -1, from: 0 };
function render(t, life){
  const aspect = R.w / R.h;
  const cam = camera(t, aspect);
  const L = logoAt(t, cam), lt = lightAt(t, L);
  const needWorld = t >= TL.tiltFrom - .05;
  const worldOk = needWorld && programReady(R.world, false);
  // мир ещё собирается (первый заход не на главную): пока темно, потом он проявляется
  if (needWorld && !worldOk) { gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.viewport(0, 0, canvas.width, canvas.height); gl.clearColor(0, 0, 0, 1); gl.clear(gl.COLOR_BUFFER_BIT); return; }
  if (worldOk && appear.at < 0) { appear.at = life; if (!ARR.done && (ARR.want || ARR.cb)) arriveNow(); }
  const P0 = worldOk ? R.world : R.sky;
  const lk = lockupState(t, lt);
  const cw = canvas.clientWidth, ch = canvas.clientHeight;
  gl.bindVertexArray(R.vao); gl.disable(gl.BLEND);
  // 1) небо, лого, мир
  let P = P0; gl.useProgram(P.p);
  gl.bindFramebuffer(gl.FRAMEBUFFER, R.rt.scene.f); gl.viewport(0, 0, R.w, R.h);
  gl.uniform2f(P.u.uRes, R.w, R.h); gl.uniform1f(P.u.uTime, life);
  gl.uniform1f(P.u.uGrow, lt.grow); gl.uniform1f(P.u.uEmber, lt.ember); gl.uniform1f(P.u.uLogoI, lt.logo);
  gl.uniform1f(P.u.uSun, lt.sun); gl.uniform1f(P.u.uGlow, lt.glow); gl.uniform1f(P.u.uBoost, glowFx.boost + glowFx.pulse); gl.uniform1f(P.u.uZO, -64);
  gl.uniform1f(P.u.uGather, lt.gather); gl.uniform1f(P.u.uBeat, 0);
  gl.uniform3f(P.u.uReach, 0, 0, 0); gl.uniform1f(P.u.uIgn, lt.ign); gl.uniform1f(P.u.uFlash, lt.flash); gl.uniform1f(P.u.uFlashC, fx.flashC); gl.uniform1f(P.u.uRim, lt.rim);
  gl.uniform4fv(P.u.uCur, cursorLight(t, cam));
  gl.uniform3fv(P.u.uCam, cam.pos); gl.uniform3fv(P.u.uRight, cam.right); gl.uniform3fv(P.u.uUp, cam.up); gl.uniform3fv(P.u.uFwd, cam.fwd);
  gl.uniform1f(P.u.uTanH, cam.tanH); gl.uniform1f(P.u.uAspect, aspect);
  gl.uniform3fv(P.u.uLC, L.c); gl.uniform3fv(P.u.uLR, L.R); gl.uniform3fv(P.u.uLU, L.U); gl.uniform3fv(P.u.uLN, L.N); gl.uniform1f(P.u.uLS, L.s);
  gl.activeTexture(gl.TEXTURE3); gl.bindTexture(gl.TEXTURE_2D, R.hm.t); gl.uniform1i(P.u.uHM, 3);
  gl.activeTexture(gl.TEXTURE4); gl.bindTexture(gl.TEXTURE_2D, R.logoBase); gl.uniform1i(P.u.uLogoBase, 4);
  gl.drawArrays(gl.TRIANGLES, 0, 3);
  // 2) искры: с куемого титра, из-за гор, с горящей линии под курсором
  P = R.part; gl.useProgram(P.p);
  gl.bindFramebuffer(gl.FRAMEBUFFER, R.rt.part.f); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
  gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE);
  gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, R.rt.scene.t); gl.uniform1i(P.u.uScene, 0); gl.uniform1i(P.u.uHasDepth, R.fmt.type === gl.HALF_FLOAT ? 1 : 0);
  gl.uniform1f(P.u.uTime, life); gl.uniform1f(P.u.uH, R.h); gl.uniform1f(P.u.uIgn, lt.ign);
  gl.uniform1f(P.u.uEmbers, smooth(TL.growTo - .8, TL.growTo + .6, t) * S.v.fade); gl.uniform1f(P.u.uSet, smooth(TL.tiltTo - .4, TL.setTo, t));
  gl.uniform3fv(P.u.uCam, cam.pos); gl.uniform3fv(P.u.uRight, cam.right); gl.uniform3fv(P.u.uUp, cam.up); gl.uniform3fv(P.u.uFwd, cam.fwd);
  gl.uniform1f(P.u.uTanH, cam.tanH); gl.uniform1f(P.u.uAspect, aspect);
  gl.uniform3fv(P.u.uLC, L.c); gl.uniform3fv(P.u.uLR, L.R); gl.uniform3fv(P.u.uLU, L.U); gl.uniform1f(P.u.uLS, L.s);
  gl.uniform2f(P.u.uRes, cw, ch); gl.uniform1f(P.u.uPx, R.w / cw);
  gl.uniform4fv(P.u.uLk, lk.rect); gl.uniform2f(P.u.uRule, LK.ruleUp, LK.wordW / LK.cw * .5); gl.uniform1f(P.u.uForge, Math.max(0, t - TL.forge)); gl.uniform1f(P.u.uForgeA, lk.sparks);
  const hf = flames.length ? flames[flames.length - 1] : null, hr = hf ? rectOf(hf.el, hf.p) : null;
  gl.uniform4fv(P.u.uHov, hr || [0, 0, 0, 0]); gl.uniform1f(P.u.uHovA, hr ? hf.a * smooth(.1, .5, hf.p) : 0);
  gl.drawArrays(gl.POINTS, 0, REDUCED ? 260 : 680);
  gl.disable(gl.BLEND);
  // где свет на экране и сколько лучей (лучи — только во вступлении)
  const menuK = smooth(TL.menuFrom - .6, TL.live, t);
  const srcW = V.add(L.c, V.add(V.mul(L.R, .009 * L.s), V.mul(L.U, -.366 * L.s)));
  const ls = toScreen(V.add(V.mul(srcW, 1 - smooth(TL.tiltFrom, TL.tiltTo, t)), V.mul(L.c, smooth(TL.tiltFrom, TL.tiltTo, t))), cam);
  const lsr = ls ? L.s * .5 / (ls.z * cam.tanH) * .5 : .2;
  const raySrc = { x: ls ? ls.x : .5, y: ls ? ls.y : .5, r: Math.max(lsr, .12) };
  const burning = smooth(TL.ignite, TL.ignite + .6, t);
  const setting = smooth(TL.tiltFrom + 1, TL.tiltTo, t) * (1 - smooth(TL.setTo, TL.settle + 1, t));
  const wide = smooth(TL.ignite + .8, TL.fovTo, t);
  const rayStrength = !ls ? 0 : Math.max(0, burning * (.16 + .06 * wide + .34 * lt.flash) + setting * .38 - .1 * menuK);
  // 3) свечение
  const M = R.rt.mips;
  P = R.down; gl.useProgram(P.p);
  for (let i = 0; i < M.length; i++) {
    const src = i === 0 ? R.rt.scene : M[i - 1];
    gl.bindFramebuffer(gl.FRAMEBUFFER, M[i].f); gl.viewport(0, 0, M[i].w, M[i].h);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, src.t); gl.uniform1i(P.u.uA, 0);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, R.rt.part.t); gl.uniform1i(P.u.uB, 1);
    gl.uniform2f(P.u.uSrcTexel, 1 / src.w, 1 / src.h); gl.uniform2f(P.u.uDst, M[i].w, M[i].h); gl.uniform1i(P.u.uFirst, i === 0 ? 1 : 0);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }
  P = R.up; gl.useProgram(P.p); gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE);
  for (let i = M.length - 1; i > 0; i--) {
    gl.bindFramebuffer(gl.FRAMEBUFFER, M[i - 1].f); gl.viewport(0, 0, M[i - 1].w, M[i - 1].h);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, M[i].t); gl.uniform1i(P.u.uA, 0);
    gl.uniform2f(P.u.uSrcTexel, 1 / M[i].w, 1 / M[i].h); gl.uniform2f(P.u.uDst, M[i - 1].w, M[i - 1].h);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }
  gl.disable(gl.BLEND);
  if (rayStrength > 0) {
    P = R.rays; gl.useProgram(P.p);
    gl.bindFramebuffer(gl.FRAMEBUFFER, R.rt.rays.f); gl.viewport(0, 0, R.rt.rays.w, R.rt.rays.h);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, M[0].t); gl.uniform1i(P.u.uSrc, 0);
    gl.uniform2f(P.u.uDst, R.rt.rays.w, R.rt.rays.h); gl.uniform2f(P.u.uLS, raySrc.x, raySrc.y); gl.uniform1f(P.u.uLSr, raySrc.r); gl.uniform1f(P.u.uTime, life);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }
  // 4) на экран: блик, титр, огонь под словом
  P = R.comp; gl.useProgram(P.p);
  gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.viewport(0, 0, canvas.width, canvas.height);
  gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, R.rt.scene.t); gl.uniform1i(P.u.uScene, 0);
  gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, R.rt.part.t); gl.uniform1i(P.u.uPart, 1);
  gl.activeTexture(gl.TEXTURE2); gl.bindTexture(gl.TEXTURE_2D, M[0].t); gl.uniform1i(P.u.uBloom, 2);
  gl.activeTexture(gl.TEXTURE3); gl.bindTexture(gl.TEXTURE_2D, R.mask); gl.uniform1i(P.u.uMask, 3);
  gl.activeTexture(gl.TEXTURE5); gl.bindTexture(gl.TEXTURE_2D, R.rt.rays.t); gl.uniform1i(P.u.uRaySrc, 5);
  gl.activeTexture(gl.TEXTURE6); gl.bindTexture(gl.TEXTURE_2D, R.rt.part.t); gl.uniform1i(P.u.uTrail, 6);
  gl.uniform1f(P.u.uTrailK, 0); gl.uniform1f(P.u.uSqueeze, 0);
  gl.uniform2f(P.u.uRes, canvas.width, canvas.height); gl.uniform1f(P.u.uTime, life); gl.uniform1f(P.u.uPx, canvas.width / cw);
  gl.uniform1f(P.u.uMenuShade, S.v.shade * menuK); gl.uniform1f(P.u.uRShade, S.v.rshade * menuK);
  gl.uniform1f(P.u.uCornerShade, canvas.width > canvas.height ? S.v.corner * menuK : 0); gl.uniform1f(P.u.uFade, sceneFade * S.v.fade * (appear.from ? (ARR.want && !REDUCED ? smoother(.05, 1.7, life - appear.at) : smooth(0, .9, life - appear.at)) : 1));
  gl.uniform2f(P.u.uLS, raySrc.x, raySrc.y); gl.uniform1f(P.u.uLSr, raySrc.r);
  gl.uniform1f(P.u.uRays, rayStrength);
  gl.uniform1f(P.u.uStreak, burning * (.18 + .1 * wide + .55 * lt.flash) * (1 - .5 * menuK));
  gl.uniform1f(P.u.uHeat, 0); gl.uniform1f(P.u.uBloomK, 1);
  gl.uniform4fv(P.u.uLk, lk.rect); gl.uniform4f(P.u.uLkA, t - TL.forge, lk.lit, lk.kick, LK.tex ? (t < TL.settle ? 1 : S.v.lock) * lockMul.v : 0); gl.uniform3f(P.u.uLkM, LK.wordTop, LK.wordBot, LK.ruleY);
  const f0 = flames[flames.length - 1], f1 = flames[flames.length - 2];
  const r0 = f0 ? rectOf(f0.el, f0.p) : null, r1 = f1 ? rectOf(f1.el, f1.p) : null;
  gl.uniform4fv(P.u.uHov0, r0 || [0, 0, 0, 0]); gl.uniform4fv(P.u.uHov1, r1 || [0, 0, 0, 0]);
  gl.uniform2f(P.u.uHovA, r0 ? f0.a : 0, r1 ? f1.a : 0);
  const rs = sel.el ? rectOf(sel.el, 1) : null;
  if (rs) sel.last = rs;
  gl.uniform4fv(P.u.uSel, sel.last); gl.uniform1f(P.u.uSelA, sel.a * (rs || !sel.el ? 1 : 0));
  gl.drawArrays(gl.TRIANGLES, 0, 3);
  if (snapWant) { const cb = snapWant; snapWant = null; try { cb(canvas); } catch (e) { console.error(e); } }
}

/* =====================================================================================
   ЗВУК: щелчок под рукой, треск и ковка во вступлении, музыка меню
   ===================================================================================== */
const Snd = (() => {
  let ctx = null, out = null, wet = null, nb = null;
  const M = { bytes: null, buf: null, src: null, ctl: null, start: 0, offset: 0, playing: false, wanted: false, paused: false, timer: 0, level: .05 };
  const ok = () => ctx && ctx.state === "running";
  const T = () => ctx.currentTime;
  function decodeMusic(){
    if (!ctx || !M.bytes || M.buf) return;
    const b = M.bytes; M.bytes = null;
    ctx.decodeAudioData(b).then(buf => { M.buf = buf; if (M.wanted && !M.paused && !M.playing) startMusic(M.offset, 3); }).catch(() => {});
  }
  function stopSrc(fade){
    if (!M.src) return;
    const s = M.src, g = M.ctl; M.src = null; M.playing = false; s.onended = null;
    g.gain.cancelScheduledValues(T()); g.gain.setValueAtTime(g.gain.value, T()); g.gain.setTargetAtTime(0, T(), Math.max(.02, fade / 3.5));
    try { s.stop(T() + fade + .05); } catch (e) {}
  }
  function startMusic(offset, fadeIn){
    if (!ctx || !M.buf) return;
    stopSrc(.3); clearTimeout(M.timer);
    const dur = M.buf.duration; offset = Math.max(0, Math.min(offset, dur - 1));
    const s = ctx.createBufferSource(); s.buffer = M.buf;
    const end = ctx.createGain(), g = ctx.createGain();
    s.connect(end); end.connect(g); g.connect(out);
    const t0 = T() + .03;
    g.gain.setValueAtTime(0, t0); g.gain.setTargetAtTime(M.level, t0, fadeIn / 3.2);
    const left = dur - offset, fo = Math.min(6, left * .45);
    end.gain.setValueAtTime(1, t0); end.gain.setValueAtTime(1, t0 + left - fo); end.gain.setTargetAtTime(0, t0 + left - fo, fo / 3.6);
    s.start(t0, offset);
    M.src = s; M.ctl = g; M.start = t0 - offset; M.playing = true;
    s.onended = () => {
      if (M.src !== s) return;
      M.src = null; M.playing = false; M.offset = 0;
      if (M.wanted && !M.paused) M.timer = setTimeout(() => { if (M.wanted && !M.paused && !M.playing) startMusic(0, 6); }, 2200);
    };
  }
  function musicPos(){ if (!ctx || !M.buf) return M.offset; return M.playing ? Math.min(T() - M.start, M.buf.duration) : M.offset; }
  function init(){
    if (ctx) { if (ctx.state === "suspended") ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    try { ctx = new AC(); } catch (e) { ctx = null; return; }
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14; comp.knee.value = 12; comp.ratio.value = 4; comp.attack.value = .004; comp.release.value = .25;
    out = ctx.createGain(); out.gain.value = .85; out.connect(comp); comp.connect(ctx.destination);
    const len = Math.floor(ctx.sampleRate * 3.4), ir = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let c = 0; c < 2; c++) { const d = ir.getChannelData(c); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3.2) * Math.min(1, i / 240); }
    const conv = ctx.createConvolver(); conv.buffer = ir;
    wet = ctx.createGain(); wet.connect(conv);
    const wg = ctx.createGain(); wg.gain.value = .5; conv.connect(wg); wg.connect(out);
    const n = Math.floor(ctx.sampleRate * 3);
    nb = ctx.createBuffer(1, n, ctx.sampleRate);
    const w = nb.getChannelData(0); for (let i = 0; i < n; i++) w[i] = Math.random() * 2 - 1;
    decodeMusic();
  }
  function noise(){ const s = ctx.createBufferSource(); s.buffer = nb; s.loop = true; return s; }
  function send(node, dry, rev){ if (dry > 0) { const g = ctx.createGain(); g.gain.value = dry; node.connect(g); g.connect(out); } if (rev > 0) { const g = ctx.createGain(); g.gain.value = rev; node.connect(g); g.connect(wet); } }
  function env(t0, pts){ const g = ctx.createGain(); g.gain.setValueAtTime(.0001, t0); for (const [dt, v, ex] of pts) ex ? g.gain.exponentialRampToValueAtTime(Math.max(v, .0001), t0 + dt) : g.gain.linearRampToValueAtTime(v, t0 + dt); return g; }
  function filt(type, f, q){ const x = ctx.createBiquadFilter(); x.type = type; x.frequency.value = f; if (q) x.Q.value = q; return x; }
  function osc(type, f){ const o = ctx.createOscillator(); o.type = type; o.frequency.value = f; return o; }
  return {
    init, ok,
    prefetch(url){ fetch(url).then(r => r.ok ? r.arrayBuffer() : null).then(b => { if (b) { M.bytes = b; decodeMusic(); } }).catch(() => {}); },
    musicToggle(){
      init();
      if (M.playing) { M.offset = musicPos(); M.paused = true; stopSrc(.6); return false; }
      M.paused = false; M.wanted = true; if (M.buf) startMusic(M.offset, 1.4); return true;
    },
    musicRestart(){ init(); M.paused = false; M.wanted = true; M.offset = 0; if (M.buf) { stopSrc(.35); setTimeout(() => startMusic(0, 1.4), 380); } },
    musicPos, musicLen: () => M.buf ? M.buf.duration : 0, musicPlaying: () => M.playing, musicWanted: () => M.wanted && !M.paused,
    crackle(amp){
      if (!ok()) return; const t0 = T() + Math.random() * .02, len = .006 + Math.random() * .02;
      const s = noise(), hp = filt("highpass", 1400 + Math.random() * 2200), g = env(t0, [[.001, amp], [len, .0001, true]]);
      s.connect(hp); hp.connect(g); send(g, 1, .15); s.start(t0); s.stop(t0 + len + .02);
    },
    whoosh(dur){
      if (!ok()) return; const t0 = T();
      const s = noise(), bp = filt("bandpass", 300, 1.6);
      bp.frequency.setValueAtTime(300, t0); bp.frequency.exponentialRampToValueAtTime(2400, t0 + dur * .5); bp.frequency.exponentialRampToValueAtTime(500, t0 + dur);
      const g = env(t0, [[dur * .35, .22], [dur, .0001, true]]); s.connect(bp); bp.connect(g); send(g, 1, .5); s.start(t0); s.stop(t0 + dur + .05);
    },
    shimmer(){
      if (!ok()) return; const t0 = T();
      [[329.6, .03], [493.9, .026], [659.3, .022], [987.8, .014], [1318.5, .009]].forEach(([f, a], i) => {
        const o = osc("sine", f); o.detune.value = (Math.random() - .5) * 8;
        const g = env(t0 + i * .06, [[1.3, a], [5.5, .0001, true]]); o.connect(g); send(g, .6, 1.1); o.start(t0 + i * .06); o.stop(t0 + 6);
      });
    },
    tick(k = 1){
      if (!ok()) return; const t0 = T();
      const o = osc("sine", 2300), g = env(t0, [[.002, .025 * k], [.05, .0001, true]]); o.connect(g); send(g, 1, .2); o.start(t0); o.stop(t0 + .06);
      const s = noise(), hp = filt("highpass", 6500), sg = env(t0, [[.001, .0175 * k], [.012, .0001, true]]); s.connect(hp); hp.connect(sg); send(sg, 1, .1); s.start(t0); s.stop(t0 + .03);
    },
  };
})();

/* =====================================================================================
   ЦИКЛ
   ===================================================================================== */
const BOOT = performance.now();
let T0 = BOOT, last = BOOT, lastDraw = 0, intro = false, ready = false, onTick = null;
const fired = new Set();
const once = (k, fn) => { if (!fired.has(k)) { fired.add(k); fn(); } };
const tl = () => (performance.now() - T0) / 1000;
const drawTimes = [];
function adapt(fdt){
  drawTimes.push(fdt); if (drawTimes.length > 50) drawTimes.shift();
  if (drawTimes.length < 50) return;
  const avg = drawTimes.reduce((a, b) => a + b, 0) / drawTimes.length;
  // меньше 50 кадров — мир грубее; ровные 60 — чуть точнее, но не выше .9
  if (avg > 1 / 48 && R.scale > .4) { R.scale = Math.max(.4, R.scale - .06); drawTimes.length = 0; resize(); }
  else if (avg < 1 / 58.5 && R.scale < .9) { R.scale = Math.min(.9, R.scale + .03); drawTimes.length = 0; resize(); }
}
function introSound(t, dt){
  if (!intro) return;
  if (t >= TL.forge && t < TL.forge + 1) once("forge", () => { Snd.whoosh(.9); for (let i = 0; i < 12; i++) setTimeout(() => Snd.crackle(.08 + Math.random() * .14), i * 45); });
  if (t >= TL.forge + .3 && t < TL.forge + 1.3) once("word", () => Snd.shimmer());
  const rate = t > TL.ignite && t < TL.tiltFrom + 1.5 ? 7 * (1 - smooth(TL.tiltFrom - 1, TL.tiltFrom + 1.5, t)) : 0;
  if (rate > 0 && Math.random() < rate * dt) Snd.crackle(.05 + Math.random() * .11);
}
function frame(){
  const now = performance.now(); const elapsed = now - last; const dt = Math.min(.1, elapsed / 1000); last = now;
  // вступление ждёт, пока мир соберётся: лого горит спокойно
  if (R && tl() > HOLD_AT && tl() < TL.tiltFrom + .3 && !R.world.done && !R.world.failed && !programReady(R.world, !PAR)) T0 += elapsed;
  const t = tl();
  stepStation(now / 1000);
  look.x += (look.tx - look.x) * Math.min(1, dt * 1.8); look.y += (look.ty - look.y) * Math.min(1, dt * 1.8);
  cursor.sx += (cursor.x - cursor.sx) * Math.min(1, dt * 5); cursor.sy += (cursor.y - cursor.sy) * Math.min(1, dt * 5);
  cursor.on += (cursor.ton - cursor.on) * Math.min(1, dt * 2);
  glowFx.boost += (glowFx.target - glowFx.boost) * Math.min(1, dt * 2.2);
  glowFx.pulse *= Math.exp(-dt * 2.2);
  lockMul.v += (lockMul.to - lockMul.v) * Math.min(1, dt * 4);
  tickFlames(dt);
  tickFlashes(t, now / 1000);
  introSound(t, dt);
  if (onTick) onTick(t, dt);
  // не чаще 60 кадров на любом мониторе; за стеклом окна мир размыт — ему хватает 30
  const every = (S.name === "app" || S.name === "wardrobe") && now / 1000 - S.at > S.dur ? 32 : 15.5;
  if (R && ready && now - lastDraw >= every) {
    if (lastDraw && every < 20) adapt((now - lastDraw) / 1000);
    lastDraw = now;
    render(t, (now - BOOT) / 1000);
  }
  requestAnimationFrame(frame);
}

addEventListener("pointermove", e => {
  const x = e.clientX / innerWidth, y = e.clientY / innerHeight;
  look.tx = (clamp01(x) - .5) * .05; look.ty = -(clamp01(y) - .5) * .028;
  cursor.x = x; cursor.y = y; cursor.ton = 1;
}, { passive: true });
document.documentElement.addEventListener("pointerleave", () => { cursor.ton = 0; });
addEventListener("resize", () => { if (R) resize(); layoutLockup(); });

return {
  TL, smooth, smoother, easeOut, clamp01, Snd,
  // canvas, лого (data:), играть ли вступление, секунда ролика для проверочного кадра
  init(cv, logo, playIntro, at){
    canvas = cv;
    gl = canvas.getContext("webgl2", { antialias: false, alpha: false, depth: false, stencil: false, powerPreference: "high-performance" });
    if (!gl) return false;
    try { initGL(); resize(); } catch (e) { console.error(e); R = null; return false; }
    intro = !!playIntro && !REDUCED;
    T0 = performance.now() - (at != null ? at : intro ? 0 : TL.settle + 1.5) * 1000;
    appear.from = !intro && (at == null || at >= TL.tiltFrom) ? 1 : 0;
    const fonts = Promise.race([
      document.fonts ? Promise.all([document.fonts.load('300 64px "Sofia Sans Extra Condensed"'), document.fonts.load('300 20px "Martian Mono"'), document.fonts.ready]) : null,
      new Promise(r => setTimeout(r, 2200)),
    ]);
    Promise.all([fonts, loadLogoBase(logo)]).then(() => { buildMask(); ready = true; });
    requestAnimationFrame(frame);
    return true;
  },
  get ok(){ return !!R; },
  get ready(){ return ready; },
  get loaded(){ return ready && !!R && (R.world.done || R.world.failed); },
  t: tl,
  set onTick(fn){ onTick = fn; },
  station, get stationName(){ return S.name; },
  // the coming: `cb` when the world is seen (at once if it already is); `play` false: no glide, only the fade
  arrive(play, cb, still){
    ARR.want = !!play; ARR.cb = cb || null;
    // a still of the valley stands in until the world is ready (the page fades one into the other): no fade of its own
    if (still) appear.from = 0;
    if (appear.at >= 0 && !ARR.done) arriveNow();
    else if (!R) { ARR.done = true; if (cb) cb(); }
  },
  skip(){ T0 = performance.now() - TL.settle * 1000; intro = false; ["forge", "word"].forEach(k => fired.add(k)); },
  replay(){ T0 = performance.now(); intro = !REDUCED; fired.clear(); station("home", true); },
  hover, leave, calm,
  select(el){ sel.el = el || null; },
  pulse(k = .7){ glowFx.pulse = Math.max(glowFx.pulse, k); fx.flashAt = performance.now() / 1000 - .05; },
  fade(v){ sceneFade = v; },
  lockup(v){ lockMul.to = v; },
  layoutLockup,
  snap(cb){ snapWant = cb; },
};
})();
