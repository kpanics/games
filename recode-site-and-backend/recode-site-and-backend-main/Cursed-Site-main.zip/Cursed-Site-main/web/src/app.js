
// The words of the market: what a pack can change (as the server reads it), resolutions, versions.
const RES = ['16x', '32x', '64x', '128x+'];
const CHANGE_NAMES = {
  blocks: 'Blocks', items: 'Items', gui: 'Interface', sounds: 'Sounds', fonts: 'Fonts', ctm: 'Connected textures', emissive: 'Emissive textures',
  entities: 'Mobs', armor: 'Armour', sky: 'Sky', particles: 'Particles', models: 'Models', cem: 'Entity models', cit: 'Custom items',
  animated: 'Animations', languages: 'Languages', texts: 'Texts', shaders: 'Core shaders', effects: 'Effect icons', paintings: 'Paintings',
  maps: 'Maps', colours: 'Colours',
};
const MAIN_CHANGES = ['blocks', 'items', 'gui', 'sounds', 'fonts', 'ctm', 'emissive', 'entities'];




// The client's real list of changes (native/assets/changelog.txt), shown on the home page the way the main menu shows it.
const CHANGELOG = { version: '0.1.0', state: 'in development', lines: [
  'The eyes open on the desktop before the game window exists',
  'Title card while the game loads, then a flight through a letter',
  'Frameless window with a panel that slides down from the top edge',
  'Main menu: the eclipse, accounts, last server, this list',
] };


// How a ban works. The steps come from what the law requires of a one-sided measure; the grounds and the lengths are not decided.
const LADDER = [
  ['Warning', 'A message with the reason. Nothing is switched off.'],
  ['Suspension', 'For a stated time. The account and its packs stay; signing in does not work.'],
  ['Closure', 'The account is closed and its fingerprint remembered. At once for the gravest things.'],
  ['Appeal', '14 days to answer the message; an answer within 10.'],
];

// Who the header shows when nobody is signed in (it never is: the members' pages need an account).
const ME = { member: { name: 'Lunuca', uid: 0 } };
const OPEN_UNTIL = '10 January';

// The rules: one short page in plain words (in place of Terms and Privacy).
const DOCS_RU = {
  rules: {
    title: 'Правила', version: 'Обновлено 27 / 09 / 2026',
    sections: [
      ['Клиент', ['Cursed даётся как есть: без обещаний, что он всегда работает или вам подходит, и без ответственности за то, что он сломает. Вам должно быть 14 лет или больше.']],
      ['Ваш аккаунт', ['Он только ваш: пароль никому не давайте. Аккаунт, нарушающий эти правила, могут закрыть, и вам скажут почему.']],
      ['Что вы загружаете', ['Загруженное остаётся вашим. Загружая, вы разрешаете Cursed хранить это и выдавать участникам — всем или только тем, у кого ваши коды доступа. Загружайте только то, что сделали сами или можете распространять. Если что-то ваше загрузил кто-то другой, напишите .lunuca в Discord, и это уберут.']],
      ['Нельзя', ['Читы, реклама и украденная работа — в маркете, на форуме, где угодно на сайте.']],
      ['Изменения', ['Эти правила могут меняться; дата выше меняется вместе с ними.']],
    ],
  },
};
const DOCS = {
  rules: {
    title: 'Rules', version: 'Last updated 26 / 09 / 2026',
    sections: [
      ['The client', ['Cursed comes as is: no promise that it always works or suits you, and no liability for what it breaks. You must be 14 or older.']],
      ['Your account', ['It’s yours alone: keep the password to yourself. An account that breaks these rules can be closed, and you’ll be told why.']],
      ['What you upload', ['What you upload stays yours. By uploading you let Cursed store it and give it to members — to everyone, or only to those with your access codes. Upload only what you made or may share. If something of yours was uploaded by someone else, write to .lunuca on Discord and it comes down.']],
      ['Not allowed', ['Cheats, adverts and stolen work — in the Market, on the forum, anywhere on the site.']],
      ['Changes', ['These rules may change; the date above changes with them.']],
    ],
  },
};
const OPEN_DECISIONS = [];

// Small things drawn by hand: the eight-by-eight heads and the one chart.
function hashStr(text) { let h = 2166136261; for (const c of String(text)) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }
function rng(seed) { let s = (seed >>> 0) || 1; return () => (s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296; }
function hsl(h, s, l) {
  h = ((h % 360) + 360) % 360; s = Math.min(Math.max(s, 0), 1); l = Math.min(Math.max(l, 0), 1);
  const c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = l - c / 2;
  const [r, g, b] = h < 60 ? [c, x, 0] : h < 120 ? [x, c, 0] : h < 180 ? [0, c, x] : h < 240 ? [0, x, c] : h < 300 ? [x, 0, c] : [c, 0, x];
  return [(r + m) * 255, (g + m) * 255, (b + m) * 255];
}

// One block, `cell` pixels wide, into the image data. `smooth` is how hand-painted it looks: a 16x pack is

// A Minecraft head is eight pixels by eight. So is this.
function drawHead(canvas) {
  const name = canvas.dataset.head, r = rng(hashStr(name));
  canvas.width = 8; canvas.height = 8;
  const g = canvas.getContext('2d');
  const kinds = [
    null, null, null,                                                                       // a person, three times as likely as anything else
    { skin: [92, 148, 78], hair: [60, 104, 54], eye: [20, 24, 20] },                          // zombie
    { skin: [206, 208, 206], hair: [168, 170, 168], eye: [36, 36, 40] },                      // skeleton
    { skin: [22, 20, 28], hair: [12, 10, 16], eye: [214, 120, 255] },                         // enderman
    { skin: [226, 138, 60], hair: [250, 244, 236], eye: [40, 28, 20] },                       // fox
    { skin: [120, 124, 140], hair: [70, 74, 92], eye: [102, 105, 245] },                      // robot
    { skin: [238, 178, 196], hair: [250, 226, 234], eye: [70, 40, 60] },                      // pig pink
  ];
  const kindOf = name === 'Lunuca' ? null : kinds[Math.floor(r() * kinds.length)];
  const skin = kindOf ? kindOf.skin : hsl(18 + r() * 18, 0.35 + r() * 0.2, 0.42 + r() * 0.34), hair = kindOf ? kindOf.hair : hsl(r() * 360, 0.25 + r() * 0.5, 0.12 + r() * 0.5);
  const eye = name === 'Lunuca' ? [191, 192, 231] : kindOf ? kindOf.eye : hsl(180 + r() * 120, 0.5, 0.55);
  const put = (x, y, c) => { g.fillStyle = `rgb(${c[0] | 0},${c[1] | 0},${c[2] | 0})`; g.fillRect(x, y, 1, 1); };
  const fringe = Math.floor(r() * 3);
  for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) {
    const isHair = y < 2 || (y === 2 && (x < 1 + fringe || x > 6 - fringe)) || ((x === 0 || x === 7) && y < 5);
    put(x, y, isHair ? hair : skin.map((v) => v * (y > 5 ? 0.94 : 1)));
  }
  if (!kindOf) { put(1, 4, [250, 250, 250]); put(6, 4, [250, 250, 250]); }
  put(2, 4, eye); put(5, 4, eye);
  put(3, 6, skin.map((v) => v * 0.72)); put(4, 6, skin.map((v) => v * 0.72));
}

function drawSpark(canvas, values) {
  const dpr = Math.min(window.devicePixelRatio || 1, 2), W = canvas.clientWidth, H = canvas.clientHeight;
  canvas.width = W * dpr; canvas.height = H * dpr;
  const g = canvas.getContext('2d'); g.scale(dpr, dpr);
  const max = Math.max(...values), step = W / (values.length - 1), y = (v) => H - 6 - (v / max) * (H - 14);
  g.beginPath(); values.forEach((v, i) => (i ? g.lineTo(i * step, y(v)) : g.moveTo(0, y(v))));
  g.strokeStyle = '#E9E9EB'; g.lineWidth = 1.4; g.stroke();
  g.lineTo(W, H); g.lineTo(0, H); g.closePath();
  const grad = g.createLinearGradient(0, 0, 0, H); grad.addColorStop(0, 'rgba(255,255,255,0.22)'); grad.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = grad; g.fill();
  g.fillStyle = '#FFFFFF'; g.fillRect(W - 6, y(values[values.length - 1]) - 3, 6, 6);
}

// The eclipse, the glitching title and the eyes (10.10.2026: gone): the site lives in the world of Recode's menu (world.js).

// The screens. One page routed by the hash, so every screen of the site can be opened, linked and clicked.
const $app = document.getElementById('app');
const state = {
  route: 'home', arg: '', role: 'guest', openReg: false, back: '', gate: false, jump: false, pvOpen: false,
  get signedIn() { return this.role !== 'guest'; },
  m: { kind: '', res: '', fits: false, sort: 'trending', page: 1 }, q: '', qLive: '', hiding: '', edit: null,
  fq: '', fqLive: '', fcat: '', fedit: 0, fedittext: '', freport: null, fhide: '', fdone: '', fmsg: '', freply: {}, frename: false, frenametext: '', fnew: { category: '', title: '', body: '', msg: '' }, rhide: 0,
  shot: 0, openCode: 0, vis: 'private', doc: 'rules', notes: true,
};
// What each screen asks of whoever opens it: nothing, or an account. Moderation is hers alone (see render).
const MEMBERS_ONLY = new Set(['market', 'pack', 'author', 'forum', 'dashboard', 'upload', 'admin']);
const need = (route) => (MEMBERS_ONLY.has(route) ? 'member' : 'guest');
const RANK = { guest: 0, member: 1 };
const me = () => (state.user ? { name: state.user.login, uid: state.user.uid_text || state.user.uid } : ME.member);
const GAME = '1.21.11';
const fmt = (n) => (n >= 1000 ? (n / 1000).toFixed(n >= 10000 ? 0 : 1).replace(/\.0$/, '').replace('.', LANG === 'ru' ? ',' : '.') + (LANG === 'ru' ? ' тыс.' : 'k') : String(n));
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const typeName = { pack: 'Resource pack', shader: 'Shader', look: 'Look' };
// Members' own avatars, as every answer of the server that names someone tells them (by login, lower case).
const AV = {};
// Whose avatar is the head of their skin (the client sent it): drawn pixel-sharp, and "back to the head" is not offered.
const AVSKIN = new Set();
function learnAv(v) {
  if (!v || typeof v !== 'object') return;
  if (Array.isArray(v)) { v.forEach(learnAv); return; }
  if (typeof v.login === 'string' && 'avatar' in v) {
    const k = v.login.toLowerCase();
    if (v.avatar && v.avatar.url) { AV[k] = v.avatar.url; if (v.avatar.skin) AVSKIN.add(k); else AVSKIN.delete(k); } else { delete AV[k]; AVSKIN.delete(k); }
  }
  for (const k in v) if (v[k] && typeof v[k] === 'object') learnAv(v[k]);
}
const head = (name, size) => {
  const k = String(name).toLowerCase(), u = AV[k];
  return u ? `<img class="head av${AVSKIN.has(k) ? ' skin' : ''}" src="${esc(u)}" data-login="${esc(name)}" alt="" decoding="async" style="width:${size}px;height:${size}px" aria-hidden="true">`
    : `<canvas class="head" data-head="${esc(name)}" style="width:${size}px;height:${size}px" aria-hidden="true"></canvas>`;
};

// ---- the language --------------------------------------------------------------------------------------------------
let LANG = (() => {
  try { const s = localStorage.getItem('cursed.lang'); if (s === 'ru' || s === 'en') return s; } catch (e) { /* no storage */ }
  return /^(ru|uk|be|kk)\b/i.test(navigator.language || '') ? 'ru' : 'en';
})();
const RU = { "Teammates": "Поиск тиммейтов", "Looking for people to play with: the server, the mode, what you are good at.": "Ищешь, с кем играть: напиши сервер, режим и что умеешь.", "(shown where there is no banner)": "(виден, когда нет баннера)", "(your name, your music, your marks)": "(ваш ник, музыка и отметки)", "/ Edit": "/ Изменить", "/ New thread": "/ Новая тема", "/ New version": "/ Новая версия", "/ Resource packs": "/ Ресурспаки", "/ Shaders": "/ Шейдеры", "10+ characters": "От 10 символов", "10+ characters. Every other device gets signed out.": "От 10 символов. На остальных устройствах вход сбросится.", "2 to 16 Latin letters, digits, _ . -, with a letter": "2–16 латинских букв, цифр, _ . -, хотя бы одна буква", "A banner: PNG, JPEG, WebP or GIF up to 12 MB, cut to 3:1 from the middle (1500×500). A GIF stays animated, here and in the game.": "Баннер: PNG, JPEG, WebP или GIF до 12 МБ, обрезается до 3:1 по центру (1500×500). GIF остаётся анимированным — и здесь, и в игре.", "A friend's login": "Логин друга", "A name or an address: @name, t.me/name, youtube.com/@name. An empty one is not shown.": "Ник или адрес: @name, t.me/name, youtube.com/@name. Пустые не показываются.", "A pack": "Пак", "A post": "Сообщение", "A resource pack or a shader pack. The site checks every file in it, leaves out what the game never reads and keeps a clean copy.": "Ресурспак или шейдерпак. Сайт проверит каждый файл, выкинет то, что игра не читает, и сохранит чистую копию.", "A resource pack: it goes in resourcepacks.": "Ресурспак: кладётся в папку resourcepacks.", "A secret: found by doing.": "Секрет: находится делом.", "A shader pack: it goes in shaderpacks.": "Шейдерпак: кладётся в папку shaderpacks.", "A thread": "Тема", "About": "Описание", "About me": "О себе", "Accent": "Акцент", "Accept": "Принять", "Accept request": "Принять заявку", "Account": "Аккаунт", "Add a friend": "Добавить друга", "Add friend": "Добавить в друзья", "Add pictures": "Добавить картинки", "Add screenshots": "Добавить скриншоты", "All of them": "Все", "Ambient occlusion": "Затенение", "Animations": "Анимации", "Announcements": "Объявления", "Anti-aliasing": "Сглаживание", "Armour": "Броня", "Artist": "Исполнитель", "Aurora": "Северное сияние", "Avatar": "Аватар", "Back": "Назад", "Back to the market": "Назад в маркет", "Back to the page": "Назад к странице", "Backdrop": "Фон", "Badges": "Значки", "Beta": "Бета", "Block": "Заблокировать", "Blocked": "Заблокированные", "Blocks": "Блоки", "Bloom": "Свечение", "Bugs": "Баги", "Bugs and questions.": "Баги и вопросы.", "By name": "По названию", "Cancel": "Отмена", "Categories": "Разделы", "Category": "Раздел", "Change": "Сменить", "Change password": "Сменить пароль", "Change the banner": "Сменить баннер", "Chats": "Переписки", "Checked": "Проверка", "Checking every file in it…": "Проверяю каждый файл…", "Choose another file": "Выбрать другой файл", "Close": "Закрыть", "Closed": "Закрыто", "Clouds": "Облака", "Colored light": "Цветной свет", "Colours": "Цвета", "Common": "Обычный", "Configs": "Конфиги", "Connected textures": "Соединённые текстуры", "Copied": "Скопировано", "Copy": "Скопировать", "Core shaders": "Core-шейдеры", "Cover": "Обложка", "Create account": "Создать аккаунт", "Current password": "Текущий пароль", "Custom items": "Кастомные предметы", "Dashboard": "Кабинет", "Decline": "Отклонить", "Delete": "Удалить", "Delete it for good": "Удалить насовсем", "Delete it?": "Удалить?", "Delete the pack": "Удалить пак", "Depth of field": "Глубина резкости", "Details": "Описание", "Dismiss": "Отклонить", "Download": "Скачать", "Download Cursed": "Скачать Cursed", "Draft": "Черновик", "Draft: only you see it": "Черновик: видите только вы", "Drop a .zip here": "Перетащите .zip сюда", "E-mail": "Почта", "Edit": "Изменить", "Edit profile": "Изменить профиль", "Effect icons": "Иконки эффектов", "Emissive textures": "Светящиеся текстуры", "Entity models": "Модели сущностей", "Epic": "Эпический", "Every version goes with it.": "Вместе с ним удалятся все версии.", "Everyone": "Все", "Everything": "Всё", "Everything else.": "Всё остальное.", "File": "Файл", "Files": "Файлы", "Fonts": "Шрифты", "For Windows 10 and 11.": "Для Windows 10 и 11.", "Forum": "Форум", "Friends": "Друзья", "From the game: press F2, then “To the gallery”. Or add them in your profile.": "Из игры: F2, потом «В галерею». Или добавьте их в профиле.", "Game": "Игра", "Gone already": "Уже удалено", "Group": "Группа", "Help": "Помощь", "Hidden": "Скрыт", "Hidden by moderation": "Скрыто модерацией", "Hidden by moderation.": "Скрыто модерацией.", "Hidden packs": "Скрытые паки", "Hidden packs ·": "Скрытые паки ·", "Hide": "Скрыть", "Hide it": "Скрыть", "Highest role": "Высшая роль", "I accept the": "Принимаю", "I forgot it": "Забыл пароль", "Ideas": "Идеи", "In the archive": "В архиве", "In the game": "В игре", "In the market, for every member.": "В маркете, для всех участников.", "Interface": "Интерфейс", "Invite": "Пригласить", "It leaves the market at once; its files go after 30 days.": "Он сразу уйдёт из маркета, а файлы удалятся через 30 дней.", "Items": "Предметы", "Its name": "Название", "It’s mine, or I hold the rights to it.": "Это моё, или у меня есть на это права.", "Join": "Вступить", "Keep it": "Оставить", "Kept to yourself until you publish it.": "Только у вас, пока не опубликуете.", "Kind": "Тип", "Languages": "Языки", "Latest": "Последнее", "Legendary": "Легендарный", "Link": "Ссылка", "Links": "Ссылки", "Listen": "Слушать", "Login": "Логин", "Login or e-mail": "Логин или почта", "Login: 3–16 of a–z, 0–9 and _.": "Логин: 3–16 символов из a–z, 0–9 и _.", "Look": "Оформление", "Looking for a team, AFK, streaming…": "Ищу тиммейтов, AFK, стримлю…", "Make a link": "Создать ссылку", "Make cover": "Сделать обложкой", "Make the group": "Создать группу", "Making packs": "Создание паков", "Maps": "Карты", "Mark all read": "Прочитать все", "Market": "Маркет", "Market: packs and shaders": "Маркет: паки и шейдеры", "Member since": "С нами с", "Members": "Участники", "Members only. Sign in to continue.": "Только для участников. Войдите, чтобы продолжить.", "Message": "Написать", "Messages": "Сообщения", "Mobs": "Мобы", "Models": "Модели", "Moderation": "Модерация", "More": "Дальше", "Most taken this week": "Чаще всего берут на этой неделе", "Most used": "Популярные", "Motion blur": "Размытие в движении", "Move to": "Перенести в", "Music": "Музыка", "Mute": "Без звука", "Muted": "Без звука", "My packs": "Мои паки", "My page": "Моя страница", "Mythic": "Мифический", "Name": "Название", "New era of Minecraft clients": "Новая эра клиентов Minecraft", "New group": "Новая группа", "New link": "Новая ссылка", "New password": "Новый пароль", "New thread": "Новая тема", "New version": "Новая версия", "Newest": "Новые", "Newest packs": "Новые паки", "News": "Новости", "No account?": "Нет аккаунта?", "No connection. Try again.": "Нет связи. Попробуйте ещё раз.", "No open reports.": "Открытых жалоб нет.", "No song on your profile.": "В профиле нет песни.", "No such member": "Нет такого участника", "No threads yet.": "Тем пока нет.", "Nobody": "Никто", "None": "Нет", "Not found": "Не найдено", "Not found.": "Не найдено.", "Not made by, or affiliated with, Mojang or Microsoft.": "Не создан Mojang или Microsoft и не связан с ними.", "Not taken:": "Не принята:", "Not yours": "Это не ваше", "Notes on this version": "Заметки к версии", "Nothing found.": "Ничего не нашлось.", "Nothing here yet.": "Здесь пока пусто.", "Nothing hidden.": "Ничего не скрыто.", "Nothing in the market yet.": "В маркете пока пусто.", "Nothing it names": "Ничего не заявлено", "Nothing published yet.": "Пока ничего не опубликовано.", "Nothing uploaded yet.": "Вы пока ничего не загрузили.", "Nothing yet. Replies, mentions and badges show up here.": "Пока пусто. Здесь появятся ответы, упоминания и значки.", "Nothing yet. Start the first thread.": "Пока пусто. Начните первую тему.", "Notifications": "Уведомления", "Now": "Сейчас", "Off topic": "Обо всём", "Older": "Раньше", "Older messages": "Раньше", "On the site": "На сайте", "On the site — the bell and a note in the corner. In the game — a note in its corner. Windows — a notification of Windows while the game is not in front.": "На сайте — колокольчик и плашка в углу. В игре — плашка в углу игры. Windows — уведомление Windows, пока игра не на переднем плане.", "One line about it": "Одной строкой", "Online": "Онлайн", "Only moderation can bring it back.": "Вернуть его может только модерация.", "Only you see this.": "Это видите только вы.", "Only you see this. What you hide, its author is told why.": "Это видите только вы. Автор скрытого увидит причину.", "Only you. Access codes come later.": "Только вы. Коды доступа появятся позже.", "Open": "Открыть", "Open the market": "Открыть маркет", "Options": "Опции", "Order": "Порядок", "Out, for whoever may see it.": "Выложен для всех, кому он виден.", "Overview": "Обзор", "PNG, JPEG or WebP, up to 12 MB each, at least 320 px on the short side; up to 12. The first is the cover unless you choose one.": "PNG, JPEG или WebP, до 12 МБ каждая, от 320 px по короткой стороне; до 12 штук. Первая становится обложкой, если не выбрать другую.", "PNG, JPEG, WebP or GIF, up to 6 MB. It is cut square from the middle; a GIF stays animated, here and in the game.": "PNG, JPEG, WebP или GIF, до 6 МБ. Обрезается квадратом по центру; GIF остаётся анимированным — и здесь, и в игре.", "Pack": "Пак", "Packs": "Паки", "Packs and shaders made by members.": "Паки и шейдеры от участников.", "Paintings": "Картины", "Particles": "Частицы", "Password": "Пароль", "Password changed. Every other device is signed out.": "Пароль изменён. На остальных устройствах вход сброшен.", "Password: 10 characters or more.": "Пароль: от 10 символов.", "Picture": "Картинка", "Pictures": "Картинки", "Pin": "Закрепить", "Pinned": "Закреплено", "Plain text: > quotes, @login, `code`, links.": "Простой текст: > цитаты, @логин, `код`, ссылки.", "Play": "Слушать", "Post": "Отправить", "Prefix": "Префикс", "Privacy": "Приватность", "Private": "Приватный", "Profile": "Профиль", "Profiles": "Профили", "Programs": "Программы", "Public": "Публичный", "Publish": "Опубликовать", "Published": "Опубликован", "Publishing…": "Публикую…", "Questions.": "Вопросы.", "Rare": "Редкий", "React": "Реакция", "Read from its files.": "Прочитано из файлов пака.", "Read from the file. The market keeps a clean copy of it.": "Прочитано из файла. Маркет хранит его чистую копию.", "Recently updated": "Недавно обновлённые", "Reflections": "Отражения", "Register": "Регистрация", "Registration is closed.": "Регистрация закрыта.", "Registration opens soon.": "Регистрация скоро откроется.", "Releases, requests, feedback.": "Релизы, запросы, отзывы.", "Remove": "Убрать", "Remove it": "Убрать", "Remove the song": "Убрать песню", "Rename": "Переименовать", "Replace": "Заменить", "Replies": "Ответы", "Reply": "Ответить", "Report": "Пожаловаться", "Report it": "Отправить жалобу", "Reported. Thank you.": "Жалоба отправлена. Спасибо.", "Reports ·": "Жалобы ·", "Requests": "Заявки", "Resolution": "Разрешение", "Resource pack": "Ресурспак", "Resource packs": "Ресурспаки", "Roles": "Роли", "Rules": "Правила", "Save": "Сохранить", "Save as a draft": "Сохранить черновиком", "Save the names": "Сохранить названия", "Saved.": "Сохранено.", "Say something of yourself:": "Расскажите о себе:", "Screenshots": "Скриншоты", "Screenshots from the game. The first is the cover.": "Скриншоты из игры. Первый станет обложкой.", "Screenshots.": "Скриншоты.", "Search": "Поиск", "Search the forum": "Поиск по форуму", "Sections": "Разделы", "See my profile": "Мой профиль", "Send": "Отправить", "Send a request": "Отправить заявку", "Sent": "Отправленные", "Sessions": "Входы", "Settings": "Настройки", "Shader": "Шейдер", "Shaders": "Шейдеры", "Shadows": "Тени", "Show my hours in Cursed": "Показывать мои часы в Cursed", "Show the server I play on": "Показывать сервер, на котором я играю", "Show what I listen to in the client": "Показывать, что я слушаю в клиенте", "Show when I am online": "Показывать, когда я в сети", "Showcase": "Витрина", "Sign in": "Войти", "Sign out": "Выйти", "Sign out everywhere else": "Выйти на всех остальных", "Signed out everywhere else.": "Вы вышли на всех остальных устройствах.", "Site": "Сайт", "Sky": "Небо", "Something broken: you hear when it is fixed.": "Что-то сломалось: вы узнаете, когда починят.", "Something went wrong. Try again.": "Что-то пошло не так. Попробуйте ещё раз.", "Song title": "Название песни", "Sound": "Звук", "Sounds": "Звуки", "Staff": "Персонал", "State": "Статус", "Status": "Статус", "Support": "Поддержка", "Take back": "Отозвать", "Take it down": "Удаление", "Taken back by its author.": "Удалено автором.", "Text": "Текст", "Texts": "Тексты", "Textures": "Текстуры", "That e-mail already has an account.": "На эту почту уже есть аккаунт.", "That e-mail doesn’t look right.": "Эта почта выглядит неправильно.", "That login is taken.": "Этот логин занят.", "That pack isn’t yours.": "Это не ваш пак.", "That picture is over 6 MB.": "Картинка больше 6 МБ.", "That role is not yours to give.": "Эту роль выдавать не вам.", "The archive is bigger than 250 MB.": "Архив больше 250 МБ.", "The badges shown first on your profile. Pick up to six.": "Значки, которые видны первыми в профиле. До шести.", "The check": "Проверка", "The current password is wrong.": "Текущий пароль неверный.", "The file": "Файл", "The forum": "Форум", "The market": "Маркет", "The pack": "Пак", "The site’s own": "Как у сайта", "Their login on the site": "Логин на сайте", "This isn’t a zip archive.": "Это не zip-архив.", "This pack is gone, private, or never was.": "Этот пак удалён, приватный или его не было.", "This thread is closed.": "Тема закрыта.", "This thread is gone, hidden, or never was.": "Эта тема удалена, скрыта или её не было.", "Threads": "Темы", "Tick the box first: only what is yours may go up.": "Сначала отметьте галочку: выкладывать можно только своё.", "Title": "Заголовок", "Too many changes today. Try tomorrow.": "Слишком много смен за сегодня. Попробуй завтра.", "Too many tries. Wait a minute.": "Слишком много попыток. Подождите минуту.", "Too many uploads. Wait a while.": "Слишком много загрузок. Подождите немного.", "Too many wrong tries. Wait a quarter of an hour.": "Слишком много неверных попыток. Подождите четверть часа.", "Tools, formats, CTM, emissive.": "Инструменты, форматы, CTM, emissive.", "Trending": "В тренде", "Turn off": "Выключить", "Unblock": "Разблокировать", "Unhide": "Вернуть", "Unmute": "Со звуком", "Unpacked": "Распакованный", "Unpin": "Открепить", "Until you choose your own, it is the head of your skin: the client sends it.": "Пока не выбрана своя, стоит голова вашего скина — её передаёт клиент.", "Up to 10 MB and 10 minutes. Its title and artist come from its tags. Or a SoundCloud track:": "До 10 МБ и 10 минут. Название и исполнитель берутся из тегов файла. Или трек с SoundCloud:", "Updates.": "Новости.", "Upload": "Загрузить", "Upload a banner": "Загрузить баннер", "Upload a pack": "Загрузить пак", "Upload an MP3": "Загрузить MP3", "Uploading…": "Загрузка…", "Use it": "Поставить", "Use the head again": "Вернуть голову", "Use the skin’s head again": "Вернуть голову скина", "Users": "Пользователи", "Version": "Версия", "Versions": "Версии", "Voice message": "Голосовое сообщение", "Volumetric light": "Объёмный свет", "Water": "Вода", "Waving plants": "Колышущиеся растения", "Wet surfaces": "Мокрые поверхности", "What Cursed could have: vote for it.": "Чего не хватает в Cursed: голосуйте за идеи.", "What changed": "Что изменилось", "What is wrong with it?": "Что с ним не так?", "What it changes": "Что меняет", "What it does": "Что умеет", "What you hear of, and where": "О чём и где сообщать", "What you hide, its author is told why.": "Автор скрытого узнаёт причину.", "Where you are signed in": "Где выполнен вход", "Who may write to you": "Кто может вам писать", "Who sees it": "Кто видит", "Who you are, what you play, what you make.": "Кто вы, во что играете, что делаете.", "Why (its author sees this)": "Причина (её увидит автор)", "Windows": "Windows", "Words": "Текст", "Worlds": "Миры", "Wrong login or password.": "Неверный логин или пароль.", "Yes": "Да", "You hold no role with a prefix yet.": "У вас пока нет роли с префиксом.", "You were signed out. Sign in again.": "Вы вышли из аккаунта. Войдите снова.", "Your own colour": "Свой цвет", "Your packs": "Ваши паки", "Your reply": "Ваш ответ", "a Linux program": "программа для Linux", "a SoundCloud track: https://soundcloud.com/artist/track": "трек SoundCloud: https://soundcloud.com/artist/track", "a Windows program": "программа для Windows", "a broken zip64 archive": "сломанный архив zip64", "a colour as #RRGGBB": "цвет как #RRGGBB", "a file in the archive is damaged": "файл в архиве повреждён", "a file in the archive is damaged (its checksum doesn't match)": "файл в архиве повреждён (не сходится контрольная сумма)", "a file in the archive is shorter than it says": "файл в архиве короче заявленного", "a file inflates to more than it says (a zip bomb)": "файл распаковывается больше заявленного (zip-бомба)", "a file is bigger than the archive": "файл больше самого архива", "a file is named one way in the list and another in its header": "файл назван в списке одним именем, а в заголовке другим", "a file name that is empty or too long": "пустое или слишком длинное имя файла", "a file of at most 10 MB": "файл не больше 10 МБ", "a file of at most 12 MB": "файл не больше 12 МБ", "a file's header disagrees with the list of files": "заголовок файла расходится со списком файлов", "a link to something outside the pack": "ссылка на что-то вне пака", "a name of 2 to 48 characters": "название от 2 до 48 символов", "a new thread every 30 seconds, and 6 an hour at most": "новая тема — раз в 30 секунд и не больше 6 в час", "a new version has to be the same kind of pack": "новая версия должна быть того же типа, что и пак", "a path that leads out of the pack": "путь, ведущий за пределы пака", "a picture is up to 12 MB": "картинка — до 12 МБ", "a piece is up to 8 MB, and no more than was announced": "кусок — до 8 МБ и не больше заявленного", "a post every 8 seconds, and 40 an hour at most": "сообщение — раз в 8 секунд и не больше 40 в час", "a post of 1 to 10 000 characters": "сообщение от 1 до 10 000 символов", "a post, a thread or a pack": "сообщение, тема или пак", "a prefix of a role you hold": "префикс роли, которая у вас есть", "a program (Java class or macOS)": "программа (класс Java или macOS)", "a program inside the pack": "программа внутри пака", "a title of 4 to 120 characters": "заголовок от 4 до 120 символов", "a version: up to 16 of 0–9, a–z, . - + _": "версия: до 16 символов из 0–9, a–z, . - + _", "an archive split over several files": "архив, разбитый на несколько файлов", "an empty piece": "пустой кусок", "another version": "другая версия", "archives inside the pack": "архивы внутри пака", "at most six of your own badges": "не больше шести своих значков", "choose a file": "выберите файл", "edited": "изменено", "end": "энд", "files outside assets/ (the game doesn't look there)": "файлы вне assets/ (игра туда не смотрит)", "files the game never reads": "файлы, которые игра не читает", "folders in assets/ with names the game can't use": "папки в assets/ с именами, которые игра не может использовать", "folders outside shaders/ (the game doesn't look there)": "папки вне shaders/ (игра туда не смотрит)", "fonts that aren't fonts": "шрифты, которые не шрифты", "junk (system and editor files)": "мусор (системные файлы и файлы редакторов)", "loose files at the top": "лишние файлы в корне", "made for Iris: parts of it may not run on OptiFine": "сделан для Iris: часть может не работать на OptiFine", "names Windows can't have": "имена, недопустимые в Windows", "names that aren't readable text": "имена, которые не читаются как текст", "names the game can't use (capital letters, spaces…)": "имена, которые игра не может использовать (заглавные буквы, пробелы…)", "names used \\ instead of /": "в именах стоял \\ вместо /", "nether": "незер", "never shown to anyone": "никому не показывается", "newer versions": "новых версий", "no such backdrop": "нет такого фона", "no such category": "такого раздела нет", "no such emoji": "нет такого эмодзи", "no such network": "нет такой сети", "no such setting": "нет такой настройки", "not a zip archive": "это не zip-архив", "not a zip archive (or something is glued after its end)": "это не zip-архив (или к его концу что-то приклеено)", "nothing in the pack is something the game reads": "в паке нет ничего, что читает игра", "only Cursed posts announcements": "объявления публикует только Cursed", "or": "или", "other": "другие", "overworld": "верхний мир", "pack.mcmeta has no \"pack\" section": "в pack.mcmeta нет раздела \"pack\"", "pack.mcmeta isn't JSON the game can read": "pack.mcmeta — не тот JSON, который прочитает игра", "pictures that don't decode": "картинки, которые не читаются", "public or private": "публичный или приватный", "say what is wrong with it": "напишите, что не так", "scripts": "скрипты", "send a PNG, JPEG or WebP picture": "нужна картинка PNG, JPEG или WebP", "send a PNG, JPEG, WebP or GIF": "пришли PNG, JPEG, WebP или GIF", "send a picture": "пришли картинку", "single files over 128 MB": "отдельные файлы больше 128 МБ", "something is hidden in front of the archive": "перед архивом что-то спрятано", "sounds that aren't Ogg": "звуки не в формате Ogg", "ten reports a day at most": "не больше десяти жалоб в день", "text files over 8 MB": "текстовые файлы больше 8 МБ", "text files that are binary inside": "текстовые файлы с двоичным содержимым", "that upload isn't ready (or isn't yours)": "эта загрузка не готова (или не ваша)", "that version number is taken": "такой номер версии уже есть", "the GIF has no frames": "в GIF нет кадров", "the GIF has too many frames (at most 2000)": "в GIF слишком много кадров (не больше 2000)", "the GIF has too many frames (at most 96)": "в GIF слишком много кадров (не больше 96)", "the GIF is too big (at most 4096 px a side)": "GIF слишком большой (не больше 4096 px по стороне)", "the archive is encrypted": "архив зашифрован", "the archive is packed with a method Minecraft can't read (make it a plain zip)": "архив сжат способом, который Minecraft не читает (сделайте обычный zip)", "the archive's list of files has something extra in it": "в списке файлов архива есть лишнее", "the archive's list of files is broken": "список файлов архива сломан", "the archive's list of files is not where it says (something is hidden inside)": "список файлов архива не там, где указано (внутри что-то спрятано)", "the archive's list of files points at nothing": "список файлов архива указывает в пустоту", "the archive's list of files points outside it": "список файлов архива указывает за его пределы", "the check broke down: upload it again": "проверка сломалась: загрузите ещё раз", "the clean copy couldn't be read back": "не удалось прочитать чистую копию", "the clean copy couldn't be stored": "не удалось сохранить чистую копию", "the file arrived damaged: upload it again": "файл пришёл повреждённым: загрузите его ещё раз", "the head is 8×8 RGBA, as hex": "голова — 8×8 RGBA, в hex", "the head is empty": "голова пустая", "the opening post of a thread with replies stays: edit it instead": "первое сообщение темы с ответами удалить нельзя: измените его", "the pack was hidden by moderation": "пак скрыт модерацией", "the picture can't be read": "картинка не читается", "the picture can’t be read": "картинку не прочитать", "the picture is over 6 MB": "картинка больше 6 МБ", "the picture is too narrow": "картинка слишком узкая", "the picture is too narrow for a square": "картинка слишком вытянутая для квадрата", "the picture is too small (at least 32 px)": "картинка слишком маленькая (нужно хотя бы 32 px)", "the picture is too small (at least 320 px on its short side)": "картинка слишком маленькая (нужно от 320 px по короткой стороне)", "the picture is too small for a banner (at least 300×100)": "картинка мала для баннера (нужно хотя бы 300×100)", "the server couldn't make room for the check": "серверу не хватило места для проверки", "the server is out of room for uploads right now": "на сервере сейчас нет места для загрузок", "the shaders folder has no shader programs in it": "в папке shaders нет шейдерных программ", "the song is over 10 minutes": "песня длиннее 10 минут", "the upload is gone: upload it again": "загрузка потерялась: загрузите ещё раз", "there is no song to name": "нет песни, чтобы её назвать", "there's nothing in assets/: the pack changes nothing in the game": "в assets/ пусто: пак ничего не меняет в игре", "this UID is taken": "этот UID занят", "this is neither a resource pack (no pack.mcmeta at its top) nor a shader pack (no shaders folder)": "это ни ресурспак (нет pack.mcmeta в корне), ни шейдерпак (нет папки shaders)", "this is not an MP3": "это не MP3", "this thread is closed": "тема закрыта", "this upload has all its pieces": "эта загрузка уже получена целиком", "two files in the archive share the same bytes (a zip bomb)": "два файла архива используют одни и те же байты (zip-бомба)", "two files with the same name": "два файла с одинаковым именем", "unreadable": "не читается", "you have reported this already": "вы уже пожаловались на это", "your gallery holds 200 screenshots: take some away first": "в галерее уже 200 скриншотов: сначала уберите лишние", "your uploads take all of your 300 MB: take some away first": "ваши загрузки заняли все 300 МБ: сначала уберите лишнее", "· up to 250 MB": "· до 250 МБ" };
// Phrases with numbers and names in them.
const RU_RULES = [
  [/^(\d+) of (\d+)$/, (m, a, b) => `${a} из ${b}`],
  [/^For (\S+)$/, (m, v) => `Для ${v}`],
  [/^for (.+)$/, (m, v) => `для ${tr(v)}`],
  [/^made for (.+?): Minecraft (\S+) will say it's for another version( \(most of it usually still works\))?$/, (m, v, g, w) => `сделан для ${tr(v)}: Minecraft ${g} скажет, что он для другой версии${w ? ' (обычно почти всё работает)' : ''}`],
  [/^made for (.+)$/, (m, v) => `сделан для ${tr(v)}`],
  [/^a version newer than (\S+) \(format (\d+)\)$/, (m, v, f) => `версии новее ${v} (формат ${f})`],
  [/^Publish (.+)$/, (m, v) => `Опубликовать ${v}`],
  [/^(\d+) more$/, (m, n) => `ещё ${n}`],
  [/^Adding pictures: (\d+) of (\d+)$/, (m, a, b) => `Добавляю картинки: ${a} из ${b}`],
  [/^(\S+) and newer$/, (m, v) => `${v} и новее`],
  [/^format (\d+)$/, (m, n) => `формат ${n}`],
  [/^formats (\d+)–(\d+)$/, (m, a, b) => `форматы ${a}–${b}`],
  [/^Hidden by moderation: (.+)$/, (m, why) => `Скрыто модерацией: ${why}`],
  [/^Picture (\d+)$/, (m, n) => `Картинка ${n}`],
  [/^Download (.+)$/, (m, v) => `Скачать ${v}`],
  [/^Edit (.+)$/, (m, v) => `Изменить ${v}`],
  [/^the picture doesn't decode \((.+)\)$/, (m, e) => `картинка не читается (${e})`],
  [/^the archive ends early or can't be read \((.+)\)$/, (m, e) => `архив обрывается или не читается (${e})`],
  [/^the clean copy couldn't be written \((.+)\)$/, (m, e) => `не удалось записать чистую копию (${e})`],
  [/^the pack was inside a folder \((.+)\)$/, (m, f) => `пак лежал внутри папки (${f})`],
  [/^made for (.+): Minecraft (\S+) will say it's for another version \(most of it usually still works\)$/, (m, v, g) => `сделан для ${tr(v)}: Minecraft ${g} скажет, что он для другой версии (обычно почти всё работает)`],
  [/^pack\.mcmeta doesn't say its versions the way (\S+) wants: (.+)$/, (m, g, why) => `pack.mcmeta указывает версии не так, как ждёт ${g}: ${why}`],
  [/^(\d+) textures over (\d+) px: (\d+) MB of the pack$/, (m, n, px, s) => `${n} ${plural(+n, 'текстура', 'текстуры', 'текстур')} больше ${px} px: ${s} МБ пака`],
  [/^(\d+) JSON files the game may not read: (.+)$/, (m, n, list) => `${n} ${plural(+n, 'JSON-файл', 'JSON-файла', 'JSON-файлов')}, которые игра может не прочитать: ${list}`],
  [/^the archive is bigger than (\d+) MB$/, (m, n) => `архив больше ${n} МБ`],
  [/^the pack is bigger than (\d+) MB unpacked$/, (m, n) => `пак больше ${n} МБ в распакованном виде`],
  [/^more than (\d+) files$/, (m, n) => `больше ${n} файлов`],
  [/^too many files \(the most is (\d+)\)$/, (m, n) => `слишком много файлов (не больше ${n})`],
  [/^(.+) inside the pack, named like something else$/, (m, w) => `${tr(w)} внутри пака под видом другого файла`],
  [/^up to (\d+) (uploads a day|uploads at once|packs|pictures)$/, (m, n, w) => `не больше ${n} ${{ 'uploads a day': 'загрузок в день', 'uploads at once': 'загрузок одновременно', packs: 'паков', pictures: 'картинок' }[w]}`],
  [/^a pack can be up to (\d+) MB$/, (m, n) => `пак — не больше ${n} МБ`],
  [/^(.+): (.+)$/, (m, a, b) => (RU[b] ? `${a}: ${RU[b]}` : m)],
];
function plural(n, one, few, many) {
  const a = Math.abs(n) % 100, b = a % 10;
  return a > 10 && a < 20 ? many : b > 1 && b < 5 ? few : b === 1 ? one : many;
}
const L = (en, ru) => (LANG === 'ru' ? ru : en);
function tr(s) {
  if (LANG !== 'ru' || !s) return s;
  if (RU[s] !== undefined) return RU[s];
  for (const [re, f] of RU_RULES) { const m = s.match(re); if (m) return f(...m); }
  return s;
}
const cap = (s) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : s);
// The words of a drawn screen into Russian: text, placeholders, labels. Not in [translate="no"], code or fields.
function translate(root) {
  if (LANG !== 'ru' || !root) return;
  const skip = (el) => el && el.closest('[translate="no"], script, style, textarea, code, .mono');
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const nodes = [];
  for (let n; (n = walker.nextNode());) nodes.push(n);
  for (const n of nodes) {
    const s = n.nodeValue, k = s.trim();
    if (!k || !/[A-Za-z]/.test(k) || skip(n.parentElement)) continue;
    const r = tr(k);
    if (r !== k) n.nodeValue = s.replace(k, r);
  }
  for (const el of [root, ...root.querySelectorAll('[placeholder], [aria-label], [title]')]) {
    if (!el.getAttribute || skip(el)) continue;
    for (const a of ['placeholder', 'aria-label', 'title']) { const v = el.getAttribute(a); if (v) { const r = tr(v); if (r !== v) el.setAttribute(a, r); } }
  }
}
function setLang(l) {
  LANG = l;
  try { localStorage.setItem('cursed.lang', l); } catch (e) { /* not kept */ }
  document.documentElement.lang = l;
  const sound = document.getElementById('sound');
  if (sound) sound.setAttribute('aria-label', L('Sound', 'Звук'));
  render(true);
}

// ---- asking the server: what it said, by what was asked; asked again after 20 s. A screen shows what it has and
// asks for the rest; the answer draws the screen again if it is still up.
const got = new Map();
function ask(path) {
  let c = got.get(path);
  if (!c || (!c.pending && performance.now() - c.at > 20000)) {
    const route = location.hash;
    const pending = api(path).then((r) => {
      got.set(path, { at: performance.now(), ok: r.ok, data: r.data, error: r.error, status: r.status });
      if (location.hash === route) render(true);
    });
    c = { ...(c || {}), pending };
    got.set(path, c);
  }
  return c;
}
const forget = (...prefixes) => { for (const k of [...got.keys()]) if (prefixes.some((p) => k.startsWith(p))) got.delete(k); };
const waiting = (c) => c.data === undefined && !c.error;

const mb = (n) => { const s = n >= 1e6 ? (n / 1e6).toFixed(n >= 1e7 ? 0 : 1) + L(' MB', ' МБ') : Math.max(1, Math.round((n || 0) / 1e3)) + L(' KB', ' КБ'); return LANG === 'ru' ? s.replace('.', ',') : s; };
const ago = (s) => {
  const d = Math.max(0, Date.now() / 1000 - s);
  if (d < 3600) return Math.max(1, Math.round(d / 60)) + L(' min ago', ' мин назад');
  if (d < 86400) return Math.round(d / 3600) + L(' h ago', ' ч назад');
  if (d < 86400 * 30) return Math.round(d / 86400) + L(' d ago', ' дн. назад');
  return new Date(s * 1000).toLocaleDateString(L('en-GB', 'ru-RU'), { day: 'numeric', month: 'short', year: 'numeric' });
};
const users = (n) => `${fmt(n)} ${L(n === 1 ? 'user' : 'users', plural(n, 'пользователь', 'пользователя', 'пользователей'))}`;
const packHref = (p) => `#/pack/${p.slug}`;
const packKind = (p) => (p.kind === 'shaderpack' ? 'Shader' : (p.tags && p.tags.resolution) || 'Resource pack');
const versionsShort = (v) => (/newer than/.test(v) ? 'newer versions' : v);

// A pack's picture: its cover, else its own icon (pack.png, kept pixel-sharp), else its first letter.
function cover(p, big) {
  if (p.cover) return `<img src="${big ? p.cover.big : p.cover.small}" alt="" loading="lazy">`;
  return `<span class="tile">${p.icon ? `<img src="${p.icon}" alt="">` : `<b>${esc(p.title.slice(0, 1))}</b>`}</span>`;
}
function card(p) {
  const g = p.kind === 'resourcepack' && p.tags && p.tags.game;
  const other = g && g.fits === false ? `<span class="ash">${g.versions ? 'for ' + esc(versionsShort(g.versions)) : 'another version'}</span>` : '';
  return `<a class="card" href="${packHref(p)}">${cover(p)}
    <div class="body"><div class="t" translate="no">${esc(p.title)}</div>
    <div class="m"><span class="k">${packKind(p)}</span><span translate="no">${esc(p.author.login)}</span><span class="num">${users(p.users)}</span>${other}</div></div></a>`;
}
const ghosts = (n) => `<div class="grid">${'<div class="card ghost"><span class="tile"></span><div class="body"><div class="t">&nbsp;</div><div class="m">&nbsp;</div></div></div>'.repeat(n)}</div>`;
const trouble = (c) => `<div class="empty">${c.status === 404 ? 'Not found.' : SAY[c.error] || SAY.busy}</div>`;

// ------------------------------------------------------------------------------------------------ home
function viewHome() {
  const top = state.signedIn ? ask('market') : null, three = top && top.ok ? top.data.items.slice(0, 3) : [];
  return `<section class="hero">
      <canvas class="sky" id="fx-eclipse" aria-hidden="true"></canvas>
      <div class="title">
        <h1 class="sr">Cursed</h1>
        <canvas class="wordmark" id="fx-word" aria-hidden="true"></canvas><div class="fallback" aria-hidden="true">CURSED</div>
        <p class="subline">New era of Minecraft clients</p>
      </div>
      <div class="hero-foot"><div class="acts">${state.signedIn ? `<a class="w menu lead" href="#/dashboard/overview">Dashboard</a><a class="w menu" href="#/market">Market</a>`
        : `<a class="w menu lead" href="#/register">Register</a><a class="w menu" href="#/signin">Sign in</a>`}</div>
      </div>
    </section>

    ${three.length ? `<section class="market-scene">
      <div class="head-row"><div class="say" style="display:flex;flex-direction:column;gap:22px"><h2 class="big">The market</h2>
        <p class="lede">Packs and shaders made by members.</p></div>
        <a class="w lead" href="#/market">Open the market</a></div>
      <div class="islands">${three.map(card).join('')}</div>
    </section>` : ''}`;
}

// ---------------------------------------------------------------------------------------------- market
// The shop window: kinds, resolutions, only-for-this-game, words, order, pages. The first pack of the plain view
// (nothing chosen, nothing searched) is shown big.
function viewMarket() {
  const s = state.m;
  const qs = new URLSearchParams();
  if (s.kind) qs.set('kind', s.kind);
  if (s.res && s.kind !== 'shaderpack') qs.set('res', s.res);
  if (s.fits) qs.set('fits', '1');
  if (s.sort !== 'trending') qs.set('sort', s.sort);
  if (state.qLive) qs.set('q', state.qLive);
  if (s.page > 1) qs.set('page', s.page);
  const c = ask('market' + (qs.toString() ? '?' + qs : ''));
  const tab = (id, name) => `<button class="w ${s.kind === id ? 'on' : ''}" data-kind="${id}">${name}</button>`;
  let body;
  if (waiting(c)) body = ghosts(6);
  else if (!c.ok) body = trouble(c);
  else {
    const { items, total, per_page: per } = c.data;
    const plain = !s.kind && !s.res && !s.fits && !state.qLive && s.sort === 'trending' && s.page === 1;
    const first = plain && items[0] && items[0].cover ? items[0] : null, rest = first ? items.slice(1) : items;
    const pages = Math.ceil(total / per);
    body = (first ? `<a class="feature" href="${packHref(first)}">${cover(first, true)}
          <div class="say"><span class="st cream">${first.users ? 'Most taken this week' : 'Newest'}</span><h2 class="big" translate="no">${esc(first.title)}</h2>${first.blurb ? `<p class="lede" translate="no">${esc(first.blurb)}</p>` : ''}
          <div class="card"><div class="m" style="margin:0"><span class="k">${packKind(first)}</span><span translate="no">${esc(first.author.login)}</span><span class="num">${users(first.users)}</span></div></div></div></a>` : '')
      + (rest.length ? `<div class="grid">${rest.map(card).join('')}</div>` : first ? ''
        : `<div class="empty">${plain ? 'Nothing here yet.' : 'Nothing found.'}<a class="w small" href="#/upload" style="margin-left:18px">Upload a pack</a></div>`)
      + (pages > 1 ? `<div class="acts pager">${s.page > 1 ? `<button class="w" data-page="${s.page - 1}">Back</button>` : ''}<span class="ash num">${s.page} of ${pages}</span>${s.page < pages ? `<button class="w" data-page="${s.page + 1}">More</button>` : ''}</div>` : '');
  }
  return `<h1 class="sr">Market</h1>
    <div class="tabs" role="tablist">${tab('', 'Everything')}${tab('resourcepack', 'Resource packs')}${tab('shaderpack', 'Shaders')}
      <span class="right">${s.kind !== 'shaderpack' ? RES.map((r) => `<button class="${s.res === r ? 'on' : ''}" data-res="${r}">${r}</button>`).join('') : ''}<button class="${s.fits ? 'on' : ''}" data-fits="1">For ${GAME}</button></span></div>
    <div class="market"><div>
      <div class="tools">
        <div style="flex:1"><label class="sr" for="q">Search</label><input class="in" id="q" type="search" placeholder="Search" value="${esc(state.q)}"></div>
        <div style="flex:none;width:200px"><label class="sr" for="sort">Order</label><select class="in" id="sort">
          ${[['trending', 'Trending'], ['users', 'Most used'], ['new', 'Newest'], ['updated', 'Recently updated'], ['name', 'By name']].map(([v, n]) => `<option value="${v}" ${s.sort === v ? 'selected' : ''}>${n}</option>`).join('')}</select></div>
        <a class="w lead" href="#/upload" style="flex:none">Upload</a>
      </div>
      ${body}
    </div></div>`;
}

// ------------------------------------------------------------------------------------------- pack page
// A pack's page: its pictures, what it is and changes (read from its files), its versions, the archive's numbers.
// Its author edits it or adds a version; she can hide it (the author is told why).
function viewPack(arg) {
  const [slug, sub] = String(arg || '').split('/');
  if (sub === 'edit') return viewEdit(slug);
  const c = ask('packs/' + encodeURIComponent(slug));
  if (waiting(c)) return `<section class="pk"><div class="say"><div class="crumb"><a href="#/market">Market</a></div><h1 class="giant ghost-t">&nbsp;</h1></div><div class="stage"><span class="tile big ghost"></span></div></section>`;
  if (!c.ok) return `<div class="page-head"><h1 class="giant">Not found</h1><p class="ash">This pack is gone, private, or never was.</p><div><a class="w" href="#/market">Back to the market</a></div></div>`;
  const p = c.data, f = p.facts || {}, shader = p.kind === 'shaderpack', g = f.game || {};
  const shots = p.pictures, n = Math.min(state.shot, Math.max(shots.length - 1, 0));
  const stage = shots.length
    ? `<img src="${shots[n].big}" alt="">${shots[n].caption ? `<p class="cap" translate="no">${esc(shots[n].caption)}</p>` : ''}
      ${shots.length > 1 ? `<div class="thumbs">${shots.map((s, i) => `<button class="${i === n ? 'on' : ''}" data-shot="${i}" aria-label="Picture ${i + 1}"><img src="${s.small}" alt=""></button>`).join('')}</div>` : ''}`
    : `<span class="tile big">${p.icon ? `<img src="${p.icon}" alt="">` : ''}</span>`;
  const status = p.state === 'hidden' ? `<span class="st cream">Hidden by moderation${p.hidden_why ? ': ' + esc(p.hidden_why) : ''}</span>`
    : p.state === 'draft' ? '<span class="st warn">Draft: only you see it</span>' : p.visibility === 'private' ? '<span class="st warn">Private</span>' : '';
  const hiding = state.hiding === p.slug;
  const mod = p.moderator && !p.mine ? (p.state === 'hidden' ? `<button class="w menu" data-unhide="${p.slug}">Unhide</button>` : hiding ? '' : `<button class="w menu" data-hide="${p.slug}">Hide</button>`) : '';
  const present = new Set(f.changes || []);
  const changes = shader
    ? `<ul class="changes">${(f.features || []).map((x) => `<li class="y">${esc(x)}</li>`).join('') || '<li>Nothing it names</li>'}</ul>`
    : `<ul class="changes">${[...MAIN_CHANGES, ...[...present].filter((x) => !MAIN_CHANGES.includes(x))].map((x) => `<li class="${present.has(x) ? 'y' : ''}">${CHANGE_NAMES[x] || esc(x)}</li>`).join('')}</ul>`;
  const rows = [['Files', `<span class="num">${fmt(f.files || 0)}</span>`], ['Unpacked', mb(f.unpacked)], ['Download', mb(p.size)]];
  if (shader) rows.push(['Programs', `<span class="num">${f.programs || 0}</span>`], ['Options', `<span class="num">${f.options || 0}</span>`],
    ['Worlds', (f.dimensions || []).map(tr).join(', ') || '—'], ['Profiles', `<span translate="no">${esc((f.profiles || []).join(', ')) || '—'}</span>`], ['Languages', `<span translate="no">${esc((f.languages || []).join(', ')) || '—'}</span>`]);
  else rows.push(['Resolution', f.resolution || '—'], ['Textures', `<span class="num">${fmt(f.textures || 0)}</span>`], ['Sounds', `<span class="num">${f.sounds || 0}</span>`],
    ['Game', g.versions ? `${esc(tr(g.versions))}${g.fits ? '' : ` <span class="ash">(${L('not', 'не')} ${GAME})</span>`}` : '<span class="ash">unreadable</span>']);
  return `<section class="pk">
      <div class="say">
        <div class="crumb"><a href="#/market">Market</a> / ${shader ? 'Shaders' : 'Resource packs'}</div>
        <h1 class="giant ${p.title.length > 22 ? 'long' : ''}" translate="no">${esc(p.title)}</h1>
        <div class="by"><a href="#/author/${encodeURIComponent(p.author.login)}" translate="no">${head(p.author.login, 24)} ${esc(p.author.login)}</a><span class="cream">${packKind(p)}</span>${!shader && g.fits === false ? `<span class="st warn">${g.versions ? 'made for ' + esc(versionsShort(g.versions)) : 'another version'}</span>` : ''}${status}</div>
        <p class="facts num">${users(p.users)} · v${esc(p.version || '—')}, ${ago(p.released || p.updated)} · ${mb(p.size)}</p>
        ${p.blurb ? `<p class="lede" translate="no">${esc(p.blurb)}</p>` : ''}
        <div class="acts" style="margin-top:10px"><a class="w menu lead" href="/api/packs/${p.slug}/download" download>Download</a>${mod}</div>
        ${p.mine ? `<div class="acts own"><a class="w small" href="#/pack/${p.slug}/edit">Edit</a><a class="w small" href="#/upload/${p.slug}">New version</a></div>`
          : p.state === 'published' ? `<div class="acts own">${state.freport && state.freport.kind === 'pack' && state.freport.id === p.id ? '' : `<button class="w small" data-freport="pack:${p.id}">Report</button>`}${state.fmsg && state.freport === null && state.fdone === 'pack:' + p.id ? `<span class="hint ok" style="margin:0">${esc(state.fmsg)}</span>` : ''}</div>
            ${state.freport && state.freport.kind === 'pack' && state.freport.id === p.id ? inlineAsk('f-report-why', 'What is wrong with it?', 'Report it', 'pack:' + p.id, 'freport-go') : ''}` : ''}
        ${hiding ? `<div class="form hide-form"><input class="in" id="hide-why" maxlength="200" placeholder="Why (its author sees this)"><div class="acts"><button class="w small lead" data-hide-go="${p.slug}">Hide it</button><button class="w small" data-hide-no="1">Keep it</button></div></div>` : ''}
        <p class="hint">${shader ? 'A shader pack: it goes in shaderpacks.' : 'A resource pack: it goes in resourcepacks.'}</p>
      </div>
      <div class="stage">${stage}</div>
    </section>
    <div class="cols">
      <div class="stack">
        ${p.about ? `<div class="block prose"><h2 class="sec">About</h2><div translate="no">${p.about.split(/\n{2,}/).map((t) => `<p>${esc(t).replace(/\n/g, '<br>')}</p>`).join('')}</div></div>` : ''}
        <div class="block"><h2 class="sec">Versions</h2><div class="rows ver">${p.versions.map((v) => `<div><a class="v" href="/api/packs/${p.slug}/download?v=${encodeURIComponent(v.number)}" download title="Download ${esc(v.number)}">${esc(v.number)}</a><span translate="no">${esc(v.changelog) || '<span class="ash">—</span>'}</span><span class="d">${ago(v.created)}</span></div>`).join('')}</div></div>
        ${p.mine ? checkNotes(f) : ''}
      </div>
      <div class="stack">
        <div class="block"><h2 class="sec">${shader ? 'What it does' : 'What it changes'}</h2>${changes}<p class="hint">Read from its files.</p></div>
        <div class="block"><h2 class="sec">In the archive</h2>${kv(rows)}</div>
      </div>
    </div>`;
}

// What the check did to its latest version, for its author: fixed, left out, worth knowing.
function checkNotes(f) {
  const fixed = f.fixed || [], dropped = Object.entries(f.dropped || {}), warn = f.warnings || [];
  if (!fixed.length && !dropped.length && !warn.length) return '';
  const left = dropped.reduce((s, [, d]) => s + d.count, 0);
  return `<div class="block"><h2 class="sec">The check</h2><ul class="found">
      ${fixed.map((x) => `<li><span class="yes">✓</span><span>${L('Fixed: ', 'Исправлено: ')}${esc(tr(x))}</span></li>`).join('')}
      ${dropped.length ? `<li><span class="note">!</span><span>${L(`Left out ${left} ${left === 1 ? 'file' : 'files'}`, `Выкинуто ${left} ${plural(left, 'файл', 'файла', 'файлов')}`)}: ${dropped.map(([why, d]) => `${esc(tr(why))} (${d.count})`).join(', ')}.
        <br><span class="ash">${dropped.flatMap(([, d]) => d.some).slice(0, 6).map(esc).join(' · ')}</span></span></li>` : ''}
      ${warn.map((x) => `<li><span class="note">!</span><span>${esc(cap(tr(x)))}</span></li>`).join('')}
    </ul><p class="hint">Only you see this.</p></div>`;
}

// Its author's editor: the words, who sees it, published or not, the pictures, and taking it down.
function viewEdit(slug) {
  const c = ask('packs/' + encodeURIComponent(slug));
  if (waiting(c)) return '<div class="page-head"><h1 class="giant ghost-t">&nbsp;</h1></div>';
  if (!c.ok || !c.data.mine) return `<div class="page-head"><h1 class="giant">Not yours</h1><div><a class="w" href="#/dashboard/packs">My packs</a></div></div>`;
  const p = c.data;
  if (!state.edit || state.edit.slug !== slug) state.edit = { slug, title: p.title, blurb: p.blurb, about: p.about, visibility: p.visibility, state: p.state === 'hidden' ? null : p.state, msg: '', bad: false, sure: false };
  const e = state.edit;
  const pick = (field, v, name) => `<button class="w menu ${e[field] === v ? 'on' : ''}" data-set="${field}" data-v="${v}">${name}</button>`;
  return `<div class="dash">${rail('packs')}<div>
    <div class="crumb"><a href="${packHref(p)}" translate="no">${esc(p.title)}</a> / Edit</div>
    <h1 class="sr">Edit ${esc(p.title)}</h1>
    <div class="sections">
      <div class="block"><h2 class="sec">Words</h2><div class="form" style="max-width:720px">
        <div><label class="lab" for="e-title">Name</label><input class="in" id="e-title" data-e="title" maxlength="48" value="${esc(e.title)}"></div>
        <div><label class="lab" for="e-blurb">One line about it</label><input class="in" id="e-blurb" data-e="blurb" maxlength="120" value="${esc(e.blurb)}"></div>
        <div><label class="lab" for="e-about">About</label><textarea class="in" id="e-about" data-e="about" maxlength="4000" rows="7">${esc(e.about)}</textarea></div></div></div>
      <div class="two">
        <div class="block"><h2 class="sec">Who sees it</h2><div class="choice"><div class="acts">${pick('visibility', 'public', 'Public')}${pick('visibility', 'private', 'Private')}</div>
          <p>${e.visibility === 'public' ? 'In the market, for every member.' : 'Only you. Access codes come later.'}</p></div></div>
        <div class="block"><h2 class="sec">Published</h2><div class="choice"><div class="acts">${p.state === 'hidden' ? '<span class="st cream">Hidden by moderation</span>' : pick('state', 'published', 'Yes') + pick('state', 'draft', 'Draft')}</div>
          <p>${p.state === 'hidden' ? esc(p.hidden_why || 'Only moderation can bring it back.') : e.state === 'published' ? 'Out, for whoever may see it.' : 'Kept to yourself until you publish it.'}</p></div></div>
      </div>
      <div class="block"><div class="acts"><button class="w menu lead" id="e-save">Save</button><a class="w menu" href="${packHref(p)}">Back to the page</a></div>
        <p class="hint ${e.bad ? 'bad' : 'ok'}" id="e-msg" role="status">${esc(e.msg)}</p></div>
      <div class="block"><h2 class="sec">Pictures</h2><div class="shots-up">
        ${p.pictures.map((s) => `<div class="shot"><img src="${s.small}" alt=""><span class="shot-acts">${p.cover && p.cover.big === s.big ? '<span class="st cream">Cover</span>' : `<button class="w small" data-cover="${s.id}">Make cover</button>`}<button class="w small" data-unpic="${s.id}">Remove</button></span></div>`).join('')}
        ${p.pictures.length < 12 ? `<label class="add">Add pictures<input type="file" id="e-pics" accept="image/png,image/jpeg,image/webp" multiple hidden></label>` : ''}</div>
        <p class="hint" id="e-pic-msg">PNG, JPEG or WebP, up to 12 MB each, at least 320 px on the short side; up to 12. The first is the cover unless you choose one.</p></div>
      <div class="block"><h2 class="sec">Take it down</h2>
        <div class="acts">${e.sure ? `<button class="w menu" id="e-delete-yes">Delete it for good</button><button class="w menu" id="e-delete-no">Keep it</button>` : '<button class="w menu" id="e-delete">Delete the pack</button>'}</div>
        <p class="hint">${e.sure ? 'It leaves the market at once; its files go after 30 days.' : 'Every version goes with it.'}</p></div>
    </div></div></div>`;
}

// An author's page: what they published, most taken first.
function viewAuthor(login) {
  const c = ask('market?author=' + encodeURIComponent(login) + '&sort=users');
  const items = c.ok ? c.data.items : [], total = items.reduce((s, p) => s + p.users, 0);
  const uid = items[0] ? (items[0].author.uid_text || items[0].author.uid) : null, name = items[0] ? items[0].author.login : login;
  return `<div class="page-head" style="flex-direction:row;align-items:center;gap:clamp(20px,3vw,44px);flex-wrap:wrap">${head(name, 112)}
      <div style="display:flex;flex-direction:column;gap:10px"><h1 class="giant" translate="no">${esc(name)}</h1>
      <p class="ash num">${uid !== null ? `UID ${uid} · ` : ''}${c.ok ? `${L(`${c.data.total} published`, `${c.data.total} ${plural(c.data.total, 'пак', 'пака', 'паков')}`)} · ${users(total)}` : '&nbsp;'}</p></div></div>
    <div class="wrap" style="margin-top:20px">${waiting(c) ? ghosts(3) : !c.ok ? trouble(c) : items.length ? `<div class="grid">${items.map(card).join('')}</div>` : '<div class="empty">Nothing published yet.</div>'}</div>`;
}

// ------------------------------------------------------------------------------------------ the door
function viewRegister() {
  return `<section class="door">
    <div class="form-side"><h1 class="big">Register</h1>${refInvite()}
      <form class="form" id="reg" novalidate>
        <div><label class="lab" for="login">Login</label><input class="in" id="login" autocomplete="username" maxlength="16"><p class="hint" id="login-h">3–16: a–z, 0–9, _</p></div>
        <div><label class="lab" for="email">E-mail</label><input class="in" id="email" type="email" autocomplete="email" placeholder="never shown to anyone"></div>
        <div><label class="lab" for="pass">Password</label><input class="in" id="pass" type="password" autocomplete="new-password"><p class="hint" id="pass-h">10+ characters</p></div>
        <div class="ticks">
          <label class="tick"><input type="checkbox" id="t-terms"><span>I accept the <a href="#/docs/rules">Rules</a>.</span></label>
        </div>
        <div class="acts" style="margin-top:8px"><button class="w menu lead" id="reg-go" type="submit" disabled>Create account</button><a class="w" href="#/signin">Sign in</a></div>
        <p class="hint" id="reg-msg" role="status"></p>
      </form></div>
    <div class="eye-side"><canvas id="fx-eyes" aria-hidden="true"></canvas></div>
  </section>`;
}
function viewSignin() {
  return `<section class="door">
    <div class="form-side"><h1 class="big">Sign in</h1>
      ${state.gate ? '<p class="st cream">Members only. Sign in to continue.</p>' : ''}
      <form class="form" id="signin">
        <div><label class="lab" for="s-login">Login or e-mail</label><input class="in" id="s-login" autocomplete="username"></div>
        <div><label class="lab" for="s-pass">Password</label><input class="in" id="s-pass" type="password" autocomplete="current-password"></div>
        <div class="acts" style="margin-top:8px"><button class="w menu lead" type="submit">Sign in</button><a class="w" href="#/signin">I forgot it</a></div>
        <p class="hint" id="signin-msg" role="status"></p>
      </form>
      <p class="hint">No account? <a class="w small" href="#/register" style="margin-left:10px">Register</a></p></div>
    <div class="eye-side"><canvas id="fx-eyes" data-open="1" aria-hidden="true"></canvas></div>
  </section>`;
}

// ------------------------------------------------------------------------------------------ dashboard
function rail(active) {
  const link = (id, name, to) => `<a class="w ${active === id ? 'on' : ''}" href="#/${to || 'dashboard/' + id}">${name}</a>`;
  return `<nav class="rail" aria-label="Dashboard">${link('overview', 'Overview')}${link('news', 'News', 'news')}${link('packs', 'My packs')}
    <span class="gap"></span>${link('upload', 'Upload', 'upload')}${link('page', 'My page', 'u/' + encodeURIComponent(me().name))}${refsRail(link)}<span class="gap"></span>${link('profile', 'Profile')}${link('configs', 'Configs')}${link('notify', 'Notifications')}${link('sessions', 'Sessions')}<span class="gap"></span>${link('support', 'Support', 'support')}${state.user && (state.user.admin || (state.user.perms || []).includes('staff.panel')) ? `<span class="gap"></span>${link('admin', 'Staff', 'admin')}` : ''}</nav>`;
}
const when = (s) => new Date(s * 1000).toLocaleDateString(L('en-GB', 'ru-RU'), { day: 'numeric', month: 'long', year: 'numeric' });
const masked = (e) => { const [l, d] = String(e || '').split('@'); return l && d ? l.slice(0, 2) + '••••@' + d : '—'; };
const account = () => { const u = state.user; return u ? [['Login', `<span translate="no">${esc(u.login)}</span>`], ['UID', uidCell(u)], ['E-mail', `<span translate="no">${esc(masked(u.email))}</span>${u.email_confirmed ? `<span class="r-ok" data-tip="${L('Confirmed', 'Подтверждена')}" aria-label="${L('Confirmed', 'Подтверждена')}"></span>` : ''} <button class="w small ${state.emOpen ? 'on' : ''}" id="em-open" style="margin-left:10px">${L('Change', 'Сменить')}</button>`], ['Member since', when(u.since)]] : [['Login', '—']]; };
const uidCell = (u) => `<span class="num" translate="no">${esc(String(u.uid_text || u.uid))}</span>${u.uid_self ? ` <button class="w small ${state.uidOpen ? 'on' : ''}" id="uid-open" style="margin-left:10px">${L('Change', 'Сменить')}</button>` : ''}${u.uid_self && state.uidOpen ? uidForm(u) : ''}`;
const uidForm = (u) => `<form class="form" id="uid-form" style="margin-top:14px;max-width:420px">
          <div><input class="in" id="uid-text" maxlength="16" autocomplete="off" spellcheck="false" placeholder="${L('Text UID', 'Текстовый UID')}" value="${esc(u.uid_text || '')}">
          <p class="hint">${L(`2–16 Latin letters, digits, _ . -, with a letter. Empty: the number again (${u.uid}).`, `2–16 латинских букв, цифр, _ . -, хотя бы одна буква. Пусто — снова номер (${u.uid}).`)}</p></div>
          <div class="acts"><button class="w lead" type="submit">${L('Save', 'Сохранить')}</button></div><p class="hint" id="uid-msg" role="status"></p></form>`;
async function newTextUid(f) {
  const msg = document.getElementById('uid-msg'), go = f.querySelector('button[type="submit"]');
  go.disabled = true; msg.textContent = ''; msg.className = 'hint';
  const r = await api('me/uid', { text: document.getElementById('uid-text').value.trim() });
  go.disabled = false;
  if (r.ok) { state.user.uid_text = r.data.uid_text || null; if (state.user.card) state.user.card.uid_text = state.user.uid_text; state.uidOpen = false; render(true); return; }
  msg.textContent = r.error === 'taken' ? L('This UID is taken.', 'Этот UID занят.') : r.error === 'format' ? L('2–16 Latin letters, digits, _ . -, with a letter.', '2–16 латинских букв, цифр, _ . -, хотя бы одна буква.') : SAY[r.error] || SAY.busy;
  msg.className = 'hint bad';
}
// Another e-mail (hers, 11.10.2026): the new one and the password again.
const emForm = () => `<form class="form" id="em" style="margin-top:24px;max-width:420px">
          <div><label class="lab" for="em-new">${L('New e-mail', 'Новая почта')}</label><input class="in" id="em-new" type="email" autocomplete="email" maxlength="254" spellcheck="false"></div>
          <div><label class="lab" for="em-pass">${L('Password', 'Пароль')}</label><input class="in" id="em-pass" type="password" autocomplete="current-password"><p class="hint">${L('Your current password, to be sure it is you.', 'Текущий пароль — чтобы убедиться, что это вы.')}</p></div>
          <div class="acts"><button class="w lead" type="submit">${L('Save', 'Сохранить')}</button></div><p class="hint" id="em-msg" role="status"></p></form>`;
async function newEmail(f) {
  const msg = document.getElementById('em-msg'), go = f.querySelector('button[type="submit"]');
  go.disabled = true; msg.textContent = ''; msg.className = 'hint';
  const r = await api('email', { email: document.getElementById('em-new').value.trim(), password: document.getElementById('em-pass').value, lang: LANG });
  go.disabled = false;
  if (r.ok) {
    state.user.email = r.data.email; state.user.email_confirmed = false; state.emSent = !!state.user.mail; state.emOpen = false; state.emDone = true;
    render(true);
    setTimeout(() => { state.emDone = false; render(true); }, 4000);
    return;
  }
  if (r.error === 'signed-out') { signOut(); location.hash = '#/signin'; return; }
  msg.textContent = r.error === 'wrong' ? L('The password is wrong.', 'Неверный пароль.') : r.error === 'same-email' ? L('That is your e-mail already.', 'Это и так ваша почта.')
    : tr(SAY[r.error] || SAY.busy);
  msg.className = 'hint bad';
}
const pwForm = () => `<form class="form" id="pw" style="margin-top:24px;max-width:420px">
          <div><label class="lab" for="pw-cur">Current password</label><input class="in" id="pw-cur" type="password" autocomplete="current-password"></div>
          <div><label class="lab" for="pw-new">New password</label><input class="in" id="pw-new" type="password" autocomplete="new-password"><p class="hint">10+ characters. Every other device gets signed out.</p></div>
          <div class="acts"><button class="w lead" type="submit">Save</button></div><p class="hint" id="pw-msg" role="status"></p></form>`;
const SAY = {
  login: 'Login: 3–16 of a–z, 0–9 and _.', email: 'That e-mail doesn’t look right.', password: 'Password: 10 characters or more.',
  'login-taken': 'That login is taken.', 'email-taken': 'That e-mail already has an account.', closed: 'Registration is closed.',
  wrong: 'Wrong login or password.', wait: 'Too many wrong tries. Wait a quarter of an hour.', slow: 'Too many tries. Wait a minute.',
  full: 'The beta is full.', banned: 'This account is banned.',
  offline: 'No connection. Try again.', busy: 'Something went wrong. Try again.', 'signed-out': 'You were signed out. Sign in again.',
};
// One call to the server. Its answers are JSON; nginx's own page (too many tries) is not, and counts as "slow".
async function api(path, body, method) {
  let r;
  try {
    r = await fetch('/api/' + path, body === undefined && !method ? { credentials: 'same-origin', cache: 'no-store' }
      : { method: method || 'POST', credentials: 'same-origin', cache: 'no-store', headers: { 'Content-Type': 'application/json' }, body: body === null ? undefined : JSON.stringify(body) });
  } catch (e) { return { ok: false, error: 'offline' }; }
  let data = {};
  try { data = await r.json(); } catch (e) { /* not JSON */ }
  if (r.ok) learnAv(data);
  return r.ok ? { ok: true, data } : { ok: false, status: r.status, error: data.error || (r.status === 429 ? 'slow' : 'busy'), message: data.message, reason: data.reason, until: data.until };
}
// Whether this browser was signed in last time (the session cookie itself can't be read here): if it was, the first
// screen waits for the server's answer, so a member never sees the guest's page first.
const hinted = () => { try { return localStorage.getItem('cursed.in') === '1'; } catch (e) { return false; } };
const hint = (on) => { try { if (on) localStorage.setItem('cursed.in', '1'); else localStorage.removeItem('cursed.in'); } catch (e) { /* not kept */ } };
function signIn(u) { state.user = u; state.role = 'member'; hint(true); setUnread(u.unread || 0); socialStart(); socialMeta(); }
function signOut() { state.user = null; state.role = 'guest'; state.pwOpen = false; state.emOpen = false; hint(false); socialStop(); }
// The door's forms: register, or sign in; on a wrong answer the eyes blink and say why.
const bannedWords = (r) => L('This account is banned', 'Этот аккаунт забанен') + (r.reason ? ': ' + r.reason : '') + '. '
  + (r.until ? L('Until ', 'До ') + new Date(r.until * 1000).toLocaleString(L('en-GB', 'ru-RU'), { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }) + '.' : L('For good.', 'Навсегда.'));
async function enter(f) {
  const reg = f.id === 'reg', go = f.querySelector('button[type="submit"]'), msg = document.getElementById(reg ? 'reg-msg' : 'signin-msg');
  const val = (id) => document.getElementById(id).value;
  go.disabled = true; msg.textContent = ''; msg.className = 'hint';
  const r = reg ? await api('register', { login: val('login').trim(), email: val('email').trim(), password: val('pass'), key: state.route === 'register' ? state.arg : '', ref: refCode(), lang: LANG })
    : await api('login', { login: val('s-login').trim(), password: val('s-pass') });
  if (!r.ok) {
    go.disabled = false;
    msg.textContent = r.error === 'banned' ? bannedWords(r) : r.error === 'full' ? L('The beta is full: no places left.', 'Места в бете закончились.') : r.error === 'ip-limit' ? L('Too many accounts from this IP.', 'С этого IP создано слишком много аккаунтов.') : tr(SAY[r.error] || SAY.busy); msg.className = 'hint bad';
    if (state.eyes) state.eyes.blink();
    return;
  }
  if (reg) refDone();
  const who = await api('me');
  signIn(who.ok ? who.data : r.data);
  const target = '#/' + (reg || !state.back ? 'dashboard/overview' : state.back);
  state.back = '';
  if (location.hash === target) render(); else location.hash = target;
}
async function newPassword(f) {
  const msg = document.getElementById('pw-msg'), go = f.querySelector('button[type="submit"]');
  go.disabled = true; msg.textContent = ''; msg.className = 'hint';
  const r = await api('password', { current: document.getElementById('pw-cur').value, new: document.getElementById('pw-new').value });
  go.disabled = false;
  if (r.ok) {
    state.pwOpen = false;
    const open = document.getElementById('pw-open'); if (open) open.classList.remove('on');
    f.outerHTML = '<p class="hint ok" style="margin-top:24px">Password changed. Every other device is signed out.</p>';
    return;
  }
  if (r.error === 'signed-out') { signOut(); location.hash = '#/signin'; return; }
  msg.textContent = tr(r.error === 'wrong' ? 'The current password is wrong.' : SAY[r.error] || SAY.busy); msg.className = 'hint bad';
}
const kv = (rows) => `<dl class="kv">${rows.map(([k, v]) => `<div><dt>${k}</dt><dd>${v}</dd></div>`).join('')}</dl>`;
function dashOverview() {
  const m = me();
  return `<h1 class="sr">Overview</h1><div class="sections">
      <div class="two">
        ${state.user && state.user.tester ? `<div class="block"><h2 class="sec">Cursed</h2><p class="hint">For Windows 10 and 11.</p><div class="acts"><a class="w menu lead" href="/api/dist/loader" id="get-loader">Download Cursed</a></div></div>` : ''}
        <div class="block"><h2 class="sec">Account</h2>${kv(account())}
          <div class="acts"><button class="w small ${state.pwOpen ? 'on' : ''}" id="pw-open">Change password</button><button class="w small" id="signout">Sign out</button></div>${state.pwOpen ? pwForm() : ''}</div>
        <div class="block"><h2 class="sec">Your packs</h2>${yourPacks()}</div>
      </div>
      ${avatarBlock()}
    </div>`;
}
// The avatar: theirs, or the head of their skin (the client sends it), or the head of their login; a new one dropped on
// it or chosen, or the skin's head back.
function avatarBlock() {
  const m = me(), k = String(m.name).toLowerCase(), own = !!AV[k] && !AVSKIN.has(k), busy = state.avBusy;
  return `<div class="block avatar-block ${busy ? 'busy' : ''}" id="av-drop"><h2 class="sec">Avatar</h2>
        <div class="av-row"><div class="av-big">${head(m.name, 112)}</div>
          <div class="av-say"><p class="hint">PNG, JPEG, WebP or GIF, up to 6 MB. It is cut square from the middle; a GIF stays animated, here and in the game.</p>
            <p class="hint">Until you choose your own, it is the head of your skin: the client sends it.</p>
            <div class="acts"><label class="w small lead" for="av-file">${busy ? 'Uploading…' : own ? 'Change' : 'Upload'}</label><input id="av-file" type="file" accept="image/png,image/jpeg,image/webp,image/gif" hidden>${own ? '<button class="w small" id="av-reset">Use the skin’s head again</button>' : ''}</div>
            <p class="hint" id="av-msg" role="status">${esc(state.avMsg || '')}</p></div></div></div>`;
}
async function sendAvatar(file) {
  if (!file || state.avBusy) return;
  if (file.size > 6 * 1024 * 1024) { state.avMsg = tr('That picture is over 6 MB.'); render(true); return; }
  state.avBusy = true; state.avMsg = ''; render(true);
  let r = null, data = {};
  try {
    r = await fetch('/api/avatar', { method: 'POST', credentials: 'same-origin', cache: 'no-store', headers: { 'Content-Type': file.type || 'application/octet-stream' }, body: file });
    try { data = await r.json(); } catch (e) { /* not JSON */ }
  } catch (e) { r = null; }
  state.avBusy = false;
  if (r && r.ok) {
    learnAv({ login: me().name, avatar: data.avatar });
    if (state.user) state.user.avatar = data.avatar;
    state.avMsg = '';
    forget('forum', 'market', 'packs', 'me/packs');
  } else if (r && r.status === 401) { signOut(); location.hash = '#/signin'; return; }
  else state.avMsg = r ? (data.error === 'picture' && data.message ? tr('Not taken:') + ' ' + tr(data.message) : r.status === 429 ? tr('Too many changes today. Try tomorrow.') : SAY.busy) : SAY.offline;
  render(true);
}
async function dropAvatar() {
  const r = await api('avatar', null, 'DELETE');
  // What is left is the skin's head (or none): the site says which.
  if (r.ok) { const left = r.data && r.data.avatar || null; learnAv({ login: me().name, avatar: left }); if (state.user) state.user.avatar = left; forget('forum', 'market', 'packs', 'me/packs'); }
  state.avMsg = r.ok ? '' : SAY[r.error] || SAY.busy;
  render(true);
}
// A few of mine, for the overview.
function yourPacks() {
  const c = ask('me/packs');
  if (waiting(c)) return '<div class="rows"><div>&nbsp;</div></div>';
  if (!c.ok) return trouble(c);
  const items = c.data.items;
  if (!items.length) return '<p class="ash">Nothing uploaded yet.</p><div class="acts"><a class="w lead" href="#/upload">Upload a pack</a></div>';
  return `<div class="rows mine">${items.slice(0, 5).map((p) => `<a href="${packHref(p)}"><b translate="no">${esc(p.title)}</b>${stateOf(p)}<span class="d num">${users(p.users)}</span></a>`).join('')}</div>
    <div class="acts">${items.length > 5 ? '<a class="w small" href="#/dashboard/packs">All of them</a>' : ''}<a class="w small" href="#/upload">Upload a pack</a></div>`;
}
const stateOf = (p) => (p.state === 'hidden' ? '<span class="st cream">Hidden</span>' : p.state === 'draft' ? '<span class="st warn">Draft</span>' : p.visibility === 'private' ? '<span class="st warn">Private</span>' : '<span class="st ok">Published</span>');
function dashPacks() {
  const c = ask('me/packs');
  if (waiting(c)) return `<h1 class="sr">My packs</h1><div class="sections">${ghosts(3)}</div>`;
  if (!c.ok) return trouble(c);
  const items = c.data.items;
  if (!items.length) return '<h1 class="sr">My packs</h1><div class="sections"><div class="block"><p class="lede">Nothing uploaded yet.</p><div class="acts"><a class="w lead" href="#/upload">Upload a pack</a></div></div></div>';
  return `<h1 class="sr">My packs</h1><div class="sections"><div class="block"><div class="scroll-x"><table><thead><tr><th>Pack</th><th>Kind</th><th>Version</th><th>State</th><th class="r">Users</th><th></th></tr></thead><tbody>
      ${items.map((p) => `<tr><td><a href="${packHref(p)}"><b translate="no">${esc(p.title)}</b></a></td><td class="ash">${packKind(p)}</td><td class="mono">${esc(p.version || '—')}</td><td>${stateOf(p)}</td><td class="r num">${fmt(p.users)}</td>
        <td class="acts-c"><a class="w small" href="#/upload/${p.slug}">New version</a><a class="w small" href="#/pack/${p.slug}/edit">Edit</a></td></tr>`).join('')}
    </tbody></table></div><div class="acts"><a class="w lead" href="#/upload">Upload a pack</a></div></div></div>`;
}
function viewDashboard(tab) {
  if (String(tab || '').split('/')[0] === 'refs') return `<div class="dash">${rail('refs')}<div>${viewRefs(String(tab).split('/').slice(1).join('/'))}</div></div>`;
  const body = { overview: dashOverview, packs: dashPacks, profile: dashProfile, configs: dashConfigs, notify: dashNotify, sessions: dashSessions }[tab] || dashOverview;
  return `<div class="dash">${rail(tab || 'overview')}<div>${body()}</div></div>`;
}

// --------------------------------------------------------------------------------------------- upload
// Uploading: a .zip in 8 MB pieces (a broken connection resumes, even after a reload, from where the server says it
// is), the server's check read out in words, the details, pictures, publishing. With a pack's slug: its next version.
const UP = { phase: 'pick', target: '', file: null, id: '', size: 0, sent: 0, result: null, error: '', fields: {}, pics: [], msg: '', bad: false, stop: false };
const upKey = 'cursed.upload';
function resetUpload(target) {
  UP.pics.forEach((x) => URL.revokeObjectURL(x.url));
  Object.assign(UP, { phase: 'pick', target, file: null, id: '', size: 0, sent: 0, result: null, error: '', fields: {}, pics: [], msg: '', bad: false, stop: true });
}
const nextNumber = (v) => { const m = String(v || '').match(/^(.*?)(\d+)(\D*)$/); return m ? m[1] + (Number(m[2]) + 1) + m[3] : '1.1'; };
function upProgress() {
  const bar = document.getElementById('up-bar'), text = document.getElementById('up-state');
  if (bar) bar.style.transform = `scaleX(${UP.size ? UP.sent / UP.size : 0})`;
  if (text && UP.phase === 'sending') text.innerHTML = `${L('Sending', 'Отправка')} · <span class="num">${Math.floor((100 * UP.sent) / (UP.size || 1))}%</span> ${L('of', 'из')} ${mb(UP.size)}`;
}
async function upSend(file) {
  resetUpload(UP.target);
  Object.assign(UP, { file, size: file.size, phase: 'sending', stop: false });
  const refuse = (message) => { Object.assign(UP, { phase: 'refused', result: { message } }); render(true); };
  if (file.size > 250 * 1024 * 1024) return refuse('The archive is bigger than 250 MB.');
  const head4 = new Uint8Array(await file.slice(0, 4).arrayBuffer());
  if (head4[0] !== 0x50 || head4[1] !== 0x4b) return refuse('This isn’t a zip archive.');
  render(true);
  // The same file as last time, not finished: go on from where the server is.
  let saved = null;
  try { saved = JSON.parse(localStorage.getItem(upKey) || 'null'); } catch (e) { saved = null; }
  if (saved && saved.name === file.name && saved.size === file.size && saved.modified === file.lastModified) {
    const s = await api('uploads/' + saved.id);
    if (s.ok && s.data.state === 'receiving') Object.assign(UP, { id: saved.id, sent: s.data.received });
  }
  let chunk = 8 * 1024 * 1024;
  if (!UP.id) {
    const r = await api('uploads', { name: file.name, size: file.size });
    if (!r.ok) return refuse(r.message || SAY[r.error] || SAY.busy);
    Object.assign(UP, { id: r.data.id, sent: 0 });
    chunk = r.data.chunk;
    try { localStorage.setItem(upKey, JSON.stringify({ id: UP.id, name: file.name, size: file.size, modified: file.lastModified })); } catch (e) { /* not kept */ }
  }
  upProgress();
  let tries = 0;
  while (UP.sent < UP.size) {
    if (UP.stop || UP.file !== file) return;
    let res;
    try {
      res = await fetch(`/api/uploads/${UP.id}?at=${UP.sent}`, { method: 'PUT', credentials: 'same-origin', headers: { 'Content-Type': 'application/octet-stream' }, body: file.slice(UP.sent, Math.min(UP.size, UP.sent + chunk)) });
    } catch (e) {
      res = null;
    }
    let data = {};
    try { data = res ? await res.json() : {}; } catch (e) { /* not JSON */ }
    if (res && res.ok) {
      UP.sent = data.received;
      tries = 0;
      upProgress();
      continue;
    }
    if (res && res.status === 409 && typeof data.received === 'number') { UP.sent = data.received; continue; }
    if (res && res.status < 500 && res.status !== 429) return refuse(data.message || SAY[data.error] || SAY.busy);
    if (++tries > 6) return refuse(SAY.offline);
    await new Promise((ok) => setTimeout(ok, 800 * tries));
  }
  try { localStorage.removeItem(upKey); } catch (e) { /* nothing */ }
  UP.phase = 'checking';
  render(true);
  while (UP.phase === 'checking' && UP.file === file) {
    await new Promise((ok) => setTimeout(ok, 700));
    const s = await api('uploads/' + UP.id);
    if (!s.ok || (s.data.state !== 'ready' && s.data.state !== 'refused')) continue;
    UP.result = s.data.result;
    UP.phase = s.data.state;
    if (UP.phase === 'ready') {
      const pack = UP.target && got.get('packs/' + encodeURIComponent(UP.target));
      const last = pack && pack.ok ? pack.data.version : '';
      // "Ashfall v1.4.zip": the name without its version, the version into its field.
      const named = String(UP.result.title).match(/^(.*?)[\s_-]+v(\d+(?:\.\d+){0,3}[a-z]?)$/i);
      UP.fields = { title: named ? named[1] : UP.result.title, blurb: '', about: '', number: UP.target ? nextNumber(last) : named ? named[2] : '1.0', changelog: '', visibility: 'public', mine: false };
    }
    render(true);
  }
}
function upFound(r) {
  const f = r.facts, g = f.game || {}, shader = r.kind === 'shaderpack';
  const li = (ok, text) => `<li><span class="${ok ? 'yes' : 'note'}">${ok ? '✓' : '!'}</span><span>${text}</span></li>`;
  const dropped = Object.entries(f.dropped || {}), left = dropped.reduce((s, [, d]) => s + d.count, 0);
  const what = shader ? (f.features || []).map(tr).join(', ') : (f.changes || []).map((x) => tr(CHANGE_NAMES[x] || x).toLowerCase()).join(', ');
  const lines = [li(true, L(`${shader ? 'A shader pack' : 'A resource pack'} · safe · <span class="num">${fmt(f.files)}</span> files, ${mb(f.unpacked)} unpacked`,
    `${shader ? 'Шейдерпак' : 'Ресурспак'} · безопасен · <span class="num">${fmt(f.files)}</span> ${plural(f.files, 'файл', 'файла', 'файлов')}, ${mb(f.unpacked)} в распакованном виде`))];
  if (!shader) lines.push(g.fits ? li(true, L(`Built for ${GAME}`, `Для ${GAME}`)) : li(false, g.versions ? L(`Made for ${esc(g.versions)}: ${GAME} will call it another version`, `Сделан для ${esc(tr(g.versions))}: ${GAME} назовёт его паком для другой версии`) : L('pack.mcmeta doesn’t say its versions the way the game wants', 'pack.mcmeta указывает версии не так, как ждёт игра')));
  if (what || f.resolution) lines.push(li(true, `${f.resolution ? `<b>${f.resolution}</b>` : ''}${f.resolution && what ? ' · ' : ''}${esc(what)}${shader && f.options ? ` · <span class="num">${f.options}</span> ${L('options', plural(f.options, 'опция', 'опции', 'опций'))}` : ''}`));
  (f.fixed || []).forEach((x) => lines.push(li(true, L('Fixed: ', 'Исправлено: ') + esc(tr(x)))));
  if (left) lines.push(li(false, `${L(`Left out ${left} ${left === 1 ? 'file' : 'files'}`, `Выкинуто ${left} ${plural(left, 'файл', 'файла', 'файлов')}`)}: ${dropped.map(([why, d]) => `${esc(tr(why))} (${d.count})`).join(', ')}`));
  (f.warnings || []).filter((x) => !/^made for|doesn't say its versions/.test(x)).forEach((x) => lines.push(li(false, esc(cap(tr(x))))));
  return `<ul class="found">${lines.join('')}</ul><p class="hint">Read from the file. The market keeps a clean copy of it.</p>`;
}
function viewUpload(arg) {
  const target = arg || '';
  if (UP.target !== target && UP.phase !== 'sending' && UP.phase !== 'checking') resetUpload(target);
  const t = target ? ask('packs/' + encodeURIComponent(target)) : null, pack = t && t.ok ? t.data : null;
  if (t && !waiting(t) && (!t.ok || !t.data.mine)) return `<div class="dash">${rail('upload')}<div><div class="empty">That pack isn’t yours.</div></div></div>`;
  const at = { pick: 0, sending: 0, checking: 1, refused: 1, ready: 2, publishing: 3 }[UP.phase];
  const steps = ['File', 'Checked', 'Details', 'Publish'].map((s, i) => `<span class="${i < at ? 'done' : i === at ? 'now' : ''}">${s}</span>`).join('');
  const r = UP.result, fl = UP.fields, file = UP.file;
  let body;
  if (UP.phase === 'pick') {
    body = `<div class="block"><h2 class="sec">The file</h2>
      <label class="drop" id="up-drop"><input type="file" id="up-file" accept=".zip,application/zip,application/x-zip-compressed" hidden>
        <span class="big">Drop a .zip here</span><span class="ash">or <span class="w small lead">choose a file</span> · up to 250 MB</span></label>
      <p class="hint">A resource pack or a shader pack. The site checks every file in it, leaves out what the game never reads and keeps a clean copy.</p></div>`;
  } else if (UP.phase === 'sending' || UP.phase === 'checking') {
    body = `<div class="block"><h2 class="sec">The file</h2>
      <div class="file"><span class="mono">${esc(file.name)}</span><span class="ash">${mb(UP.size)}</span>${UP.phase === 'sending' ? '<button class="w small" id="up-cancel">Cancel</button>' : ''}</div>
      <div class="meter ${UP.phase === 'checking' ? 'busy' : ''}"><i id="up-bar"></i></div>
      <p class="hint" id="up-state">${UP.phase === 'checking' ? 'Checking every file in it…' : ''}</p></div>`;
  } else if (UP.phase === 'refused') {
    body = `<div class="block"><h2 class="sec">The file</h2>${file ? `<div class="file"><span class="mono">${esc(file.name)}</span></div>` : ''}
      <ul class="found"><li><span class="note">✕</span><span>${esc(cap(tr(r.message)))}${r.path ? `<br><span class="mono ash">${esc(r.path)}</span>` : ''}</span></li></ul>
      <div class="acts"><button class="w lead" id="up-again">Choose another file</button></div></div>`;
  } else {
    const wrongKind = pack && r.kind !== pack.kind;
    const pics = UP.pics.map((x, i) => `<div class="shot"><img src="${x.url}" alt=""><span class="shot-acts"><button class="w small" data-unpick="${i}">Remove</button></span></div>`).join('');
    body = `<div class="two">
        <div class="block"><h2 class="sec">The file</h2><div class="file"><span class="mono">${esc(file.name)}</span><span class="ash">${mb(r.size)} ${L('clean', 'после проверки')}</span><button class="w small" id="up-again">Replace</button></div>${upFound(r)}</div>
        ${pack ? `<div class="block"><h2 class="sec">The pack</h2>${kv([['Name', esc(pack.title)], ['Now', 'v' + esc(pack.version || '—')], ['Kind', packKind(pack)]])}</div>`
          : `<div class="block"><h2 class="sec">Who sees it</h2><div class="choice"><div class="acts"><button class="w menu ${fl.visibility === 'public' ? 'on' : ''}" data-upvis="public">Public</button><button class="w menu ${fl.visibility === 'private' ? 'on' : ''}" data-upvis="private">Private</button></div>
            <p>${fl.visibility === 'public' ? 'In the market, for every member.' : 'Only you. Access codes come later.'}</p></div></div>`}
      </div>
      ${wrongKind ? `<div class="block"><ul class="found"><li><span class="note">✕</span><span>${L(`This is ${r.kind === 'shaderpack' ? 'a shader pack' : 'a resource pack'}, and <span translate="no">${esc(pack.title)}</span> is ${pack.kind === 'shaderpack' ? 'a shader pack' : 'a resource pack'}: a new version has to be the same kind.`, `Это ${r.kind === 'shaderpack' ? 'шейдерпак' : 'ресурспак'}, а <span translate="no">${esc(pack.title)}</span> — ${pack.kind === 'shaderpack' ? 'шейдерпак' : 'ресурспак'}: новая версия должна быть того же типа.`)}</span></li></ul></div>` : `
      <div class="block"><h2 class="sec">Details</h2><div class="form" style="max-width:720px">
        ${pack ? '' : `<div><label class="lab" for="u-title">Name</label><input class="in" id="u-title" data-f="title" maxlength="48" value="${esc(fl.title)}"></div>
        <div><label class="lab" for="u-blurb">One line about it</label><input class="in" id="u-blurb" data-f="blurb" maxlength="120" value="${esc(fl.blurb)}"></div>
        <div><label class="lab" for="u-about">About</label><textarea class="in" id="u-about" data-f="about" maxlength="4000" rows="5">${esc(fl.about)}</textarea></div>`}
        <div><label class="lab" for="u-number">Version</label><input class="in mono" id="u-number" data-f="number" maxlength="16" value="${esc(fl.number)}"></div>
        <div><label class="lab" for="u-log">${pack ? 'What changed' : 'Notes on this version'}</label><textarea class="in" id="u-log" data-f="changelog" maxlength="2000" rows="3">${esc(fl.changelog)}</textarea></div></div></div>
      ${pack ? '' : `<div class="block"><h2 class="sec">Pictures</h2><div class="shots-up">${pics}${UP.pics.length < 12 ? `<label class="add">Add pictures<input type="file" id="up-pics" accept="image/png,image/jpeg,image/webp" multiple hidden></label>` : ''}</div>
        <p class="hint">Screenshots from the game. The first is the cover.</p></div>`}
      <div class="block"><label class="tick"><input type="checkbox" id="up-mine" ${fl.mine ? 'checked' : ''}><span>It’s mine, or I hold the rights to it.</span></label>
        <div class="acts" style="margin-top:14px">${UP.phase === 'publishing' ? '<span class="st cream">Publishing…</span>'
          : `<button class="w menu lead" id="up-publish">Publish${pack ? ' ' + esc(fl.number) : ''}</button>${pack ? '' : '<button class="w menu" id="up-draft">Save as a draft</button>'}`}</div>
        <p class="hint ${UP.bad ? 'bad' : ''}" id="up-msg" role="status">${esc(UP.msg)}</p></div>`}`;
  }
  return `<div class="dash">${rail('upload')}<div>
    <h1 class="sr">Upload</h1>${pack ? `<div class="crumb"><a href="${packHref(pack)}" translate="no">${esc(pack.title)}</a> / New version</div>` : ''}
    <div class="steps" style="margin-top:${pack ? 18 : 0}px">${steps}</div>
    <div class="sections">${body}</div></div></div>`;
}
async function upPublish(draft) {
  const fl = UP.fields, say = (m) => { UP.msg = m; UP.bad = true; render(true); };
  if (!fl.mine) return say('Tick the box first: only what is yours may go up.');
  UP.phase = 'publishing';
  UP.msg = '';
  render(true);
  const r = UP.target
    ? await api(`packs/${encodeURIComponent(UP.target)}/versions`, { upload: UP.id, number: fl.number, changelog: fl.changelog })
    : await api('packs', { upload: UP.id, title: fl.title, blurb: fl.blurb, about: fl.about, visibility: fl.visibility, number: fl.number, changelog: fl.changelog, publish: !draft });
  if (!r.ok) {
    UP.phase = 'ready';
    return say(r.message || SAY[r.error] || SAY.busy);
  }
  const slug = r.data.slug;
  for (let i = 0; i < UP.pics.length; i++) {
    UP.msg = `Adding pictures: ${i + 1} of ${UP.pics.length}`;
    UP.bad = false;
    const m = document.getElementById('up-msg');
    if (m) m.textContent = tr(UP.msg);
    try { await fetch(`/api/packs/${slug}/pictures`, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/octet-stream' }, body: UP.pics[i].file }); } catch (e) { /* the pack is up; a picture can be added later */ }
  }
  forget('market', 'packs/', 'me/');
  resetUpload('');
  location.hash = '#/pack/' + slug;
}

// ------------------------------------------------------------------------------ forum, moderation, documents
// ---- the forum --------------------------------------------------------------------------------------------------
// The forum's screens are social/forum.js (03.10.2026); what the market's reports share with them stays here.
const sq = (colour) => `<i style="background:${colour || 'var(--dim)'}"></i>`;
const catOf = (cats, id) => (cats || []).find((c) => c.id === id) || { id, name: id, colour: 'var(--dim)' };
// A small question asked in place (why hide it, what is wrong with it), with its two answers.
const inlineAsk = (id, placeholder, yes, target, go) => `<div class="form hide-form"><input class="in" id="${id}" maxlength="200" placeholder="${placeholder}"><div class="acts"><button class="w small lead" data-${go}="${target}">${yes}</button><button class="w small" data-fask-no="1">Cancel</button></div></div>`;

// The first moderation: reports, and packs newest and hidden; tabs of the staff's panel now (social/admin.js).
function adminModeration(tab) {
  const t = ['reports', 'hidden', 'new'].includes(tab) ? tab : 'reports';
  const reports = ask('reports'), hidden = ask('market?state=hidden');
  const nr = reports.ok ? reports.data.items.length : 0, nh = hidden.ok ? hidden.data.total : 0;
  let body;
  if (t === 'reports') {
    body = waiting(reports) ? ghosts(2) : !reports.ok ? trouble(reports) : !reports.data.items.length ? '<div class="empty">No open reports.</div>'
      : `<div>${reports.data.items.map((r) => {
          const a = r.about || {}, gone = !a.title && !a.text;
          const link = r.kind === 'pack' ? (a.slug ? `#/pack/${a.slug}` : '') : a.thread ? `#/forum/t/${a.thread}` : '';
          const what = { post: 'A post', thread: 'A thread', pack: 'A pack' }[r.kind];
          return `<div class="report"><div><span class="st ${r.kind === 'pack' ? 'ok' : 'cream'}">${what}</span>
            <h3 translate="no">${gone ? '<span class="ash">Gone already</span>' : esc(a.title || '')}</h3>${a.text ? `<p translate="no">${esc(a.text)}</p>` : ''}
            <p class="ash when">${L('By', 'Автор:')} <span translate="no">${esc(a.author ? a.author.login : '—')}</span>. ${L('Reported by', 'Жалоба от')} <span translate="no">${esc(r.by.login)}</span> · ${ago(r.created)}: “<span translate="no">${esc(r.why)}</span>”</p>
            ${state.rhide === r.id ? inlineAsk('r-why', 'Why (its author sees this)', 'Hide it', String(r.id), 'rhide-go') : ''}</div>
            <div class="acts">${link ? `<a class="w small" href="${link}">Open</a>` : ''}${gone ? '' : `<button class="w small" data-rhide="${r.id}">Hide it</button>`}<button class="w small" data-rdismiss="${r.id}">Dismiss</button></div></div>`;
        }).join('')}</div>`;
  } else {
    const c = t === 'hidden' ? hidden : ask('market?sort=new');
    body = waiting(c) ? ghosts(3) : !c.ok ? trouble(c) : c.data.items.length ? `<div class="grid">${c.data.items.map(card).join('')}</div>` : `<div class="empty">${t === 'hidden' ? 'Nothing hidden.' : 'Nothing in the market yet.'}</div>`;
  }
  const sub = t === 'reports' ? `<p class="hint">What you hide, its author is told why.</p>` : `<div class="acts"><a class="w small ${t === 'new' ? 'on' : ''}" href="#/admin/packs">Newest packs</a><a class="w small ${t === 'hidden' ? 'on' : ''}" href="#/admin/packs/hidden">Hidden packs · <span class="num">${nh}</span></a></div>`;
  const _nr = nr;
  return `${sub}<div class="sections">${body}</div>`;
}
function viewDocs(which) {
  const key = DOCS[which] ? which : 'rules', doc = (LANG === 'ru' && DOCS_RU[key]) || DOCS[key];
  const slug = (s) => s.toLowerCase().replace(/[^a-z]+/g, '-');
  const mark = (s) => esc(s).replace(/\{[^}]+\}/g, (m) => `<span class="yours">${m}</span>`);
  const para = (p) => (Array.isArray(p) ? `<ul>${p.map((li) => `<li>${mark(li)}</li>`).join('')}</ul>` : `<p>${mark(p)}</p>`);
  return `<h1 class="sr">${doc.title}</h1>
    <div class="tabs" style="padding-bottom:30px">${Object.entries(DOCS).map(([k, d]) => `<a class="w ${k === key ? 'on' : ''}" href="#/docs/${k}">${tr(d.title)}</a>`).join('')}</div>
    <div class="legal"><nav aria-label="Sections" translate="no">${doc.sections.map(([t], i) => `<a href="#/docs/${key}" data-jump="${slug(t)}">${i + 1}. ${t}</a>`).join('')}</nav>
      <div class="text" translate="no"><p class="status" style="margin-bottom:34px">${doc.version}</p>
      ${doc.sections.map(([t, ps], i) => `<h2 id="${slug(t)}">${i + 1}. ${t}</h2>${ps.map(para).join('')}`).join('')}</div></div>`;
}

// --------------------------------------------------------------------------------- shell and routing
function shell(inner) {
  const path = state.route + (state.arg ? '/' + state.arg : '');
  const nav = (r, name) => `<a class="w ${state.route === r && !state.gate ? 'on' : ''}" href="#/${r}">${name}</a>`;
  const m = me();
  return `<header class="bar"><a class="brand" data-t="CURSED" href="#/home">CURSED</a>
      <nav aria-label="Site">${state.signedIn ? nav('market', 'Market') + nav('forum', 'Forum') + navFriends() + nav('dashboard', 'Dashboard') : ''}</nav>
      <div class="who"><span class="lang" translate="no"><button class="w small ${LANG === 'en' ? 'on' : ''}" data-lang="en" aria-label="English">EN</button><button class="w small ${LANG === 'ru' ? 'on' : ''}" data-lang="ru" aria-label="Русский">RU</button></span>${state.signedIn ? `${bell()}<a class="me" href="#/u/${encodeURIComponent(m.name)}"><span translate="no"><b>${state.user && state.user.card ? pfx(state.user.card) : ''}${m.name}</b><span>UID ${m.uid}</span></span>${head(m.name, 36)}</a>`
        : (state.route === 'home' ? '' : `<a class="w small" href="#/signin">Sign in</a><a class="w small lead" href="#/register">Register</a>`)}</div></header>
    <main>${inner}</main>
    <footer><span class="brand" data-t="CURSED">CURSED</span><span>Not made by, or affiliated with, Mojang or Microsoft.</span>
      <span class="links">${state.signedIn ? '<a href="#/market">Market</a><a href="#/forum">Forum</a>' : ''}<a href="#/docs/rules">Rules</a></span></footer>`;
}

function render(keepScroll) {
  const [route, ...rest] = (location.hash.replace(/^#\/?/, '') || 'home').split('/');
  const changed = route !== state.route || rest.join('/') !== state.arg;
  state.route = route; state.arg = rest.join('/');
  const wanted = need(route, state.arg);
  state.gate = false;
  if (RANK[state.role] < RANK[wanted]) {
    if (state.jump) state.role = 'member';
    else if (state.role === 'guest') { state.gate = true; state.back = route + (state.arg ? '/' + state.arg : ''); }
  }
  state.jump = false;
  if (route === 'admin' && state.signedIn && !(state.user && (state.user.admin || (state.user.perms || []).includes('staff.panel')))) { location.hash = '#/dashboard/overview'; return; }
  if (changed) state.shot = 0;
  const views = { home: viewHome, market: viewMarket, pack: viewPack, author: viewProfile, register: viewRegister, signin: viewSignin,
    dashboard: viewDashboard, upload: viewUpload, forum: viewForum, admin: viewAdmin, docs: viewDocs, license: viewDocs, u: viewProfile, notifications: viewNotifications, badges: viewBadges, friends: viewFriends, support: viewSupport, news: viewNews };
  // The field being typed in keeps its focus and caret through a redraw (a search's answer arrives mid-word).
  const was = document.activeElement, keep = was && was.id && $app.contains(was) ? [was.id, was.selectionStart, was.selectionEnd] : null;
  FX.pauseAll();
  $app.innerHTML = shell((state.gate ? viewSignin : views[route] || viewNotFound)(state.arg));
  $app.querySelectorAll('canvas[data-head]').forEach(drawHead);
  if (changed && !keepScroll) window.scrollTo(0, 0);
  wire();
  socialWire();
  refsWire();
  light();
  solidBar();
  translate($app);
  if (keep) {
    const el = document.getElementById(keep[0]);
    if (el) { el.focus({ preventScroll: true }); try { el.setSelectionRange(keep[1], keep[2]); } catch (e) { /* not a text field */ } }
  }
}

// The living pictures of whichever screen is up (each made once and kept: see FX).
const DOOR_EYES = { open: 0, scale: 0.25, y: 0.5 };
const glitchBrand = (dur) => { document.querySelectorAll('.brand').forEach((b) => { b.classList.add('glitch'); setTimeout(() => b.classList.remove('glitch'), dur * 1000); }); };
const PICTURES = { eclipse: (c) => FX.eclipse(c), word: (c) => FX.wordmark(c, glitchBrand), 'door-eyes': (c, opt) => FX.eyes(c, opt || { ...DOOR_EYES }) };
function light() {
  const sky = FX.place(document.getElementById('fx-eclipse'), 'eclipse', PICTURES.eclipse);
  const word = FX.place(document.getElementById('fx-word'), 'word', PICTURES.word);
  // A first visit compiles the eclipse for a few seconds: the title waits for it, and arrives with it.
  if (sky && word && !sky.shown) sky.onlit = () => { if (word.again) word.again(); };
  const eyes = document.getElementById('fx-eyes');
  state.eyes = null;
  if (eyes) {
    const door = eyes.closest('.door');
    const opt = door ? { ...DOOR_EYES, open: eyes.dataset.open ? 1 : 0 } : { open: 0, openOnShow: true, scale: 0.40 };
    state.eyes = FX.place(eyes, door ? 'door-eyes' : 'eyes', (c) => (door ? PICTURES['door-eyes'](c, opt) : FX.eyes(c, opt)), opt);
    if (door && state.eyes && !opt.open) syncForm();
  }
  // The pictures of the other screens compile ahead (the eclipse takes some 3 s cold, the eyes 4), so a click to them
  // shows them at once; only once this screen's own run steadily (on a slow machine, after its quality has settled).
  if (!state.signedIn) FX.steady(() => { for (const key in PICTURES) FX.warm(key, PICTURES[key]); });
}

let searchTimer = 0;
function wire() {
  const on = (sel, ev, fn) => $app.querySelectorAll(sel).forEach((el) => bindOnce(el, ev, 'w1|' + sel, (e) => fn(el, e)));
  const m = state.m, go = () => { m.page = 1; render(true); };
  on('[data-lang]', 'click', (b) => { if (b.dataset.lang !== LANG) setLang(b.dataset.lang); });
  on('[data-copy]', 'click', (b) => { try { navigator.clipboard.writeText(b.dataset.copy); } catch (e) {} b.textContent = tr('Copied'); });
  on('[data-jump]', 'click', (a, e) => { e.preventDefault(); const el = document.getElementById(a.dataset.jump); if (el) el.scrollIntoView({ block: 'start', behavior: 'smooth' }); });
  // The shop window.
  on('[data-kind]', 'click', (b) => { m.kind = b.dataset.kind; go(); });
  on('[data-res]', 'click', (b) => { m.res = m.res === b.dataset.res ? '' : b.dataset.res; go(); });
  on('[data-fits]', 'click', () => { m.fits = !m.fits; go(); });
  on('[data-page]', 'click', (b) => { m.page = Number(b.dataset.page); render(true); toTop(); });
  on('#sort', 'change', (s) => { m.sort = s.value; go(); });
  on('#q', 'input', (q) => {
    state.q = q.value;
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => { state.qLive = state.q.trim(); go(); }, 320);
  });
  // A pack's page.
  on('[data-shot]', 'click', (b) => { state.shot = Number(b.dataset.shot); render(true); });
  on('[data-hide]', 'click', (b) => { state.hiding = b.dataset.hide; render(true); const i = document.getElementById('hide-why'); if (i) i.focus(); });
  on('[data-hide-no]', 'click', () => { state.hiding = ''; render(true); });
  on('[data-hide-go]', 'click', async (b) => {
    const why = (document.getElementById('hide-why') || {}).value || '';
    await api(`packs/${b.dataset.hideGo}/hide`, { why });
    state.hiding = '';
    forget('market', 'packs/');
    render(true);
  });
  on('[data-unhide]', 'click', async (b) => { await api(`packs/${b.dataset.unhide}/unhide`, {}); forget('market', 'packs/'); render(true); });
  // Its editor.
  const e = state.edit;
  on('[data-e]', 'input', (el) => { e[el.dataset.e] = el.value; });
  on('[data-set]', 'click', (b) => { e[b.dataset.set] = b.dataset.v; render(true); });
  on('#e-save', 'click', async () => {
    const r = await api(`packs/${e.slug}`, { title: e.title, blurb: e.blurb, about: e.about, visibility: e.visibility, ...(e.state ? { state: e.state } : {}) }, 'PATCH');
    Object.assign(e, r.ok ? { msg: 'Saved.', bad: false } : { msg: r.message || SAY[r.error] || SAY.busy, bad: true });
    if (r.ok) { forget('market', 'packs/', 'me/'); got.set('packs/' + encodeURIComponent(e.slug), { at: performance.now(), ok: true, data: r.data }); }
    render(true);
  });
  on('#e-pics', 'change', async (input) => {
    const msg = document.getElementById('e-pic-msg'), files = [...input.files];
    for (let i = 0; i < files.length; i++) {
      if (msg) msg.textContent = tr(`Adding pictures: ${i + 1} of ${files.length}`);
      const res = await fetch(`/api/packs/${e.slug}/pictures`, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/octet-stream' }, body: files[i] }).catch(() => null);
      if (!res || !res.ok) {
        let d = {};
        try { d = await res.json(); } catch (x) { /* not JSON */ }
        if (msg) { msg.textContent = `${files[i].name}: ${tr(d.message || SAY[d.error] || SAY.busy)}`; msg.className = 'hint bad'; }
        break;
      }
    }
    forget('packs/', 'market', 'me/');
    render(true);
  });
  on('[data-cover]', 'click', async (b) => { await api(`packs/${e.slug}/pictures`, { cover: Number(b.dataset.cover) }, 'PATCH'); forget('packs/', 'market', 'me/'); render(true); });
  on('[data-unpic]', 'click', async (b) => { await api(`packs/${e.slug}/pictures/${b.dataset.unpic}`, null, 'DELETE'); forget('packs/', 'market', 'me/'); render(true); });
  on('#e-delete', 'click', () => { e.sure = true; render(true); });
  on('#e-delete-no', 'click', () => { e.sure = false; render(true); });
  on('#e-delete-yes', 'click', async () => { await api(`packs/${e.slug}`, null, 'DELETE'); forget('packs/', 'market', 'me/'); state.edit = null; location.hash = '#/dashboard/packs'; });
  // Uploading.
  const drop = document.getElementById('up-drop');
  if (drop) {
    ['dragenter', 'dragover'].forEach((t) => bindOnce(drop, t, 'up-a', (ev) => { ev.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach((t) => bindOnce(drop, t, 'up-b', () => drop.classList.remove('over')));
    bindOnce(drop, 'drop', 'up-c', (ev) => { ev.preventDefault(); const f = ev.dataTransfer.files[0]; if (f) upSend(f); });
  }
  on('#up-file', 'change', (input) => { if (input.files[0]) upSend(input.files[0]); });
  on('#up-cancel', 'click', () => { UP.stop = true; if (UP.id) api(`uploads/${UP.id}`, null, 'DELETE'); try { localStorage.removeItem(upKey); } catch (x) { /* nothing */ } resetUpload(UP.target); render(true); });
  on('#up-again', 'click', () => { resetUpload(UP.target); render(true); });
  on('[data-f]', 'input', (el) => { UP.fields[el.dataset.f] = el.value; });
  on('#up-mine', 'change', (el) => { UP.fields.mine = el.checked; });
  on('[data-upvis]', 'click', (b) => { UP.fields.visibility = b.dataset.upvis; render(true); });
  on('#up-pics', 'change', (input) => {
    for (const f of [...input.files].slice(0, 12 - UP.pics.length)) UP.pics.push({ file: f, url: URL.createObjectURL(f) });
    render(true);
  });
  on('[data-unpick]', 'click', (b) => { const [x] = UP.pics.splice(Number(b.dataset.unpick), 1); if (x) URL.revokeObjectURL(x.url); render(true); });
  on('#up-publish', 'click', () => upPublish(false));
  on('#up-draft', 'click', () => upPublish(true));
  if (UP.phase === 'sending') upProgress();
  // The forum.
  let forumTimer = 0;
  on('#fq', 'input', (q) => {
    state.fq = q.value;
    clearTimeout(forumTimer);
    forumTimer = setTimeout(() => { state.fqLive = state.fq.trim(); render(true); }, 320);
  });
  const threadId = () => Number(String(state.arg).split('/')[1]);
  const again = () => { forget('forum', 'reports'); render(true); };
  on('[data-fdel]', 'click', async (b) => {
    if (b.dataset.sure !== '1') { b.dataset.sure = '1'; b.textContent = tr('Delete it?'); return; }
    const r = await api(`forum/posts/${b.dataset.fdel}`, null, 'DELETE');
    if (!r.ok && r.error === 'first') { state.fmsg = r.message; render(true); return; }
    forget('forum');
    const t = got.get(`forum/threads/${threadId()}`);
    render(true);
    if (t && !t.ok) location.hash = '#/forum';
  });
  on('[data-freport]', 'click', (b) => { const [kind, id] = b.dataset.freport.split(':'); state.freport = { kind, id: Number(id) }; state.fhide = ''; render(true); const i = document.getElementById('f-report-why'); if (i) i.focus(); });
  on('[data-fhide]', 'click', (b) => { state.fhide = b.dataset.fhide; state.freport = null; render(true); const i = document.getElementById('f-hide-why'); if (i) i.focus(); });
  on('[data-fask-no]', 'click', () => { state.freport = null; state.fhide = ''; state.rhide = 0; render(true); });
  on('[data-freport-go]', 'click', async (b) => {
    const [kind, id] = b.dataset.freportGo.split(':');
    const r = await api('reports', { kind, id: Number(id), why: (document.getElementById('f-report-why') || {}).value || '' });
    state.freport = null;
    state.fdone = kind + ':' + id;
    state.fmsg = tr(r.ok ? 'Reported. Thank you.' : r.message || SAY[r.error] || SAY.busy);
    render(true);
  });
  on('[data-fhide-go]', 'click', async (b) => {
    const [kind, id] = b.dataset.fhideGo.split(':');
    await api(`forum/${kind === 'post' ? 'posts' : 'threads'}/${id}/hide`, { why: (document.getElementById('f-hide-why') || {}).value || '' });
    state.fhide = '';
    again();
  });
  on('[data-funhide]', 'click', async (b) => { const [kind, id] = b.dataset.funhide.split(':'); await api(`forum/${kind === 'post' ? 'posts' : 'threads'}/${id}/unhide`, {}); again(); });
  on('[data-fpin]', 'click', async (b) => { await api(`forum/threads/${threadId()}`, { pinned: b.dataset.fpin === '1' }, 'PATCH'); again(); });
  on('[data-flock]', 'click', async (b) => { await api(`forum/threads/${threadId()}`, { locked: b.dataset.flock === '1' }, 'PATCH'); again(); });
  on('#f-move', 'change', async (s) => { await api(`forum/threads/${threadId()}`, { category: s.value }, 'PATCH'); again(); });
  on('[data-frename]', 'click', () => {
    const [, t] = [...got.entries()].find(([k, v]) => k.startsWith(`forum/threads/${threadId()}`) && v.ok) || [];
    state.frename = true; state.frenametext = t ? t.data.title : '';
    render(true);
  });
  on('#f-title', 'input', (el) => { state.frenametext = el.value; });
  on('[data-frename-no]', 'click', () => { state.frename = false; render(true); });
  on('[data-frename-go]', 'click', async () => { const r = await api(`forum/threads/${threadId()}`, { title: state.frenametext }, 'PATCH'); if (r.ok) state.frename = false; again(); });
  // Moderation's reports.
  on('[data-rhide]', 'click', (b) => { state.rhide = Number(b.dataset.rhide); render(true); const i = document.getElementById('r-why'); if (i) i.focus(); });
  on('[data-rhide-go]', 'click', async (b) => { await api(`reports/${b.dataset.rhideGo}/close`, { action: 'hide', why: (document.getElementById('r-why') || {}).value || '' }); state.rhide = 0; forget('reports', 'market', 'packs/', 'forum'); render(true); });
  on('[data-rdismiss]', 'click', async (b) => { await api(`reports/${b.dataset.rdismiss}/close`, { action: 'dismiss' }); forget('reports'); render(true); });
  // The account.
  on('form#reg, form#signin', 'submit', (f, ev) => { ev.preventDefault(); enter(f); });
  on('form#pw', 'submit', (f, ev) => { ev.preventDefault(); newPassword(f); });
  on('#pw-open', 'click', () => { state.pwOpen = !state.pwOpen; if (state.pwOpen) state.emOpen = false; render(true); });
  on('#em-open', 'click', () => { state.emOpen = !state.emOpen; if (state.emOpen) state.pwOpen = false; render(true); });
  on('form#em', 'submit', (f, ev) => { ev.preventDefault(); newEmail(f); });
  on('#uid-open', 'click', () => { state.uidOpen = !state.uidOpen; render(true); });
  on('form#uid-form', 'submit', (f, ev) => { ev.preventDefault(); newTextUid(f); });
  on('#signout', 'click', async () => { await api('logout', {}); signOut(); got.clear(); location.hash = '#/home'; });
  on('#av-file', 'change', (i) => { const f = i.files && i.files[0]; i.value = ''; sendAvatar(f); });
  on('#av-reset', 'click', () => dropAvatar());
  on('#av-drop', 'dragover', (b, e) => { e.preventDefault(); b.classList.add('over'); });
  on('#av-drop', 'dragleave', (b) => b.classList.remove('over'));
  on('#av-drop', 'drop', (b, e) => { e.preventDefault(); b.classList.remove('over'); const f = e.dataTransfer && e.dataTransfer.files[0]; if (f) sendAvatar(f); });
  wireRegister();
}

// The eyes on the door crack open as the form fills and open wide once all of it is right.
function formDone() {
  const login = document.getElementById('login'), email = document.getElementById('email'), pass = document.getElementById('pass'), rules = document.getElementById('t-terms');
  if (!login) return [0, 4];
  return [[/^[A-Za-z0-9_]{3,16}$/.test(login.value), email.value.includes('@'), pass.value.length >= 10, rules.checked].filter(Boolean).length, 4];
}
function syncForm() {
  if (!state.eyes) return;
  const [n, all] = formDone(), whole = n === all;
  state.eyes.setOpen(whole ? 1 : (n / all) * 0.16, whole ? 0.75 : 0.25);
}
function wireRegister() {
  if (!document.getElementById('reg')) return;
  const login = document.getElementById('login'), loginH = document.getElementById('login-h');
  const pass = document.getElementById('pass'), passH = document.getElementById('pass-h'), email = document.getElementById('email'), go = document.getElementById('reg-go');
  const terms = document.getElementById('t-terms');
  const check = () => { const [n, all] = formDone(); go.disabled = n !== all; syncForm(); };
  bindOnce(login, 'input', 'reg', () => {
    const ok = /^[A-Za-z0-9_]{3,16}$/.test(login.value);
    loginH.className = 'hint ' + (login.value && !ok ? 'bad' : '');
    loginH.textContent = tr('3–16: a–z, 0–9, _');
    check();
  });
  bindOnce(pass, 'input', 'reg', () => {
    const ok = pass.value.length >= 10;
    passH.className = 'hint ' + (ok ? 'ok' : '');
    passH.textContent = tr(!pass.value || ok ? '10+ characters' : `${10 - pass.value.length} more`);
    check();
  });
  [terms, email].forEach((el) => bindOnce(el, 'input', 'reg', check));
}

// ================================================================================================= people (02.10.2026)
// What every screen of people shares: the live line (one stream from the server: notifications, presence), the bell
// and its count, the notes that come and go in the corner, and how a person is drawn — their prefix, their name in
// their accent, their status with its emoji. Built into app.js before its start (build.py), so the screens below are
// known to the router; the router itself is told of them by a few swaps.

const SOC = { live: null, unread: 0, retry: 0, notes: [], noteId: 0, meta: null, playing: null };
MEMBERS_ONLY.add('u').add('notifications').add('badges');

// ---- drawing a person

/** One of the pack's emoji (an animated GIF); small ones from the small set. */
const emo = (id, size) => (id ? `<img class="emo" src="/e/${size > 40 ? '' : 's/'}${esc(id)}.gif" alt="" width="${size}" height="${size}" decoding="async" aria-hidden="true">` : '');
/** A role's prefix: its word in its colour, a hairline of it under the word. */
const pfx = (p) => (p && p.prefix ? `<span class="pfx" style="--c:${esc(p.prefix.colour)}" title="${esc(L(p.prefix.en, p.prefix.ru))}" translate="no">${esc(p.prefix.text)}</span>` : '');
const profHref = (login) => `#/u/${encodeURIComponent(login)}`;
/** A person's name as a link to their profile: in their accent, their prefix before it. */
const nm = (p, opts) => {
  if (!p) return '<span class="ash">—</span>';
  const o = opts || {};
  const name = `<b translate="no"${p.accent ? ` style="color:${esc(p.accent)}"` : ''}>${esc(p.login)}</b>`;
  return `<a class="who-name" href="${profHref(p.login)}">${o.noPrefix ? '' : pfx(p)}${name}</a>${o.status && p.status ? statusOf(p.status) : ''}`;
};
const statusOf = (s) => (s && (s.text || s.emoji) ? `<span class="status">${emo(s.emoji, 18)}<span translate="no">${esc(s.text || '')}</span></span>` : '');
/** The dot of where someone is: in the game (indigo), on the site (glow). */
const dot = (online) => (online ? `<i class="here ${online}" title="${online === 'game' ? tr('In the game') : tr('On the site')}"></i>` : '');

// ---- an avatar whose picture is not there

// Its file lost (04.10: sequwi's), or not made again yet: the head of the login takes its place, here and from now on
// (the server forgets such an avatar too, and the client's next word of the skin makes it again).
document.addEventListener('error', (e) => {
  const img = e.target;
  if (!(img instanceof HTMLImageElement) || !img.classList.contains('av') || !img.dataset.login) return;
  const login = img.dataset.login, k = login.toLowerCase();
  delete AV[k]; AVSKIN.delete(k);
  const c = document.createElement('canvas');
  c.className = 'head'; c.dataset.head = login; c.style.cssText = img.style.cssText; c.setAttribute('aria-hidden', 'true');
  img.replaceWith(c);
  drawHead(c);
}, true);

// ---- the live line

function socialStart() {
  if (SOC.live || !state.user) return;
  let es;
  try { es = new EventSource('/api/live'); } catch (e) { return; }
  SOC.live = es;
  frStart();
  es.onmessage = (m) => { let ev; try { ev = JSON.parse(m.data); } catch (e) { return; } heard(ev); };
  es.onopen = () => { SOC.retry = 0; };
  es.onerror = () => {
    // The browser tries again by itself; after the server says "signed out" it stops, and so do we.
    if (es.readyState === EventSource.CLOSED) {
      SOC.live = null;
      if (state.user) setTimeout(socialStart, Math.min(30000, 1000 * 2 ** SOC.retry++));
    }
  };
}
function socialStop() {
  if (SOC.live) SOC.live.close();
  if (FR.rec) frRecStop(false);
  FR.chat = null; frUnread(0);
  SOC.live = null; SOC.unread = 0;
  stopMusic();
}
function setUnread(n) {
  SOC.unread = Math.max(0, n | 0);
  document.querySelectorAll('.bell').forEach((b) => {
    b.classList.toggle('lit', SOC.unread > 0);
    const c = b.querySelector('.count'); if (c) c.textContent = SOC.unread > 99 ? '99+' : SOC.unread || '';
  });
  document.title = (SOC.unread ? `(${SOC.unread}) ` : '') + 'Cursed';
}
function heard(ev) {
  if (frHeard(ev)) return;
  if (ev.t === 'hello') { setUnread(ev.unread); return; }
  if (ev.t === 'unread') { setUnread(ev.unread); return; }
  if (ev.t === 'note') {
    setUnread(ev.unread);
    forget('notifications');
    if (ev.site !== false) toast(ev.n);
    if (state.route === 'notifications') render(true);
    return;
  }
  if (ev.t === 'presence' && state.route === 'u') { forget('u/'); render(true); }
  if (ev.t === 'ticket') { forget('tickets'); if (state.route === 'support') render(true); }
}

// ---- notifications: their words, where they lead

/** What a notification says, and where it leads: [line (HTML), href, emoji]. */
function noteWords(n) {
  const d = n.data || {}, a = n.actor ? `<b translate="no">${esc(n.actor.login)}</b>` : '', t = `<span translate="no">${L('“', '«')}${esc(d.title || '')}${L('”', '»')}</span>`;
  const thread = d.thread ? `#/forum/t/${d.thread}/${d.page || 1}` : '#/forum';
  switch (n.kind) {
    case 'reply': return [L(`${a} replied in ${t}`, `Ответ от ${a} в ${t}`), thread, 'c_chat'];
    case 'mention': return [L(`${a} mentioned you in ${t}`, `Упоминание от ${a} в ${t}`), thread, 'c_bell'];
    case 'moderation':
      if (d.what === 'warning') return [L(`A warning from Cursed’s staff: “${esc(d.why || '')}”`, `Предупреждение от персонала Cursed: «${esc(d.why || '')}»`), '#/notifications', 'c_warn'];
      if (d.what === 'mute') return [L(`You can’t post on the forum until ${esc(new Date(d.until * 1000).toLocaleString('en-GB', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }))}: “${esc(d.why || '')}”`, `Писать на форуме нельзя до ${esc(new Date(d.until * 1000).toLocaleString('ru-RU', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }))}: «${esc(d.why || '')}»`), '#/forum', 'c_lock'];
      return [L(`Your ${d.what === 'thread' ? 'thread' : 'post'} in ${t} was hidden: “${esc(d.why || '')}”`, `Ваш${d.what === 'thread' ? 'а тема' : ' пост'} в ${t} скрыт${d.what === 'thread' ? 'а' : ''}: «${esc(d.why || '')}»`), thread, 'c_gavel'];
    case 'forum': {
      if (d.status === 'released') return [L(`Your bug ${t} is fixed in build ${esc(d.build)}: update the client`, `Ваш баг ${t} исправлен в сборке ${esc(d.build)}: обновите клиент`), thread, 'c_check'];
      if (d.status === 'answer') return [L(`Your reply in ${t} is marked as the answer`, `Ваш ответ в ${t} отмечен как решение`), thread, 'c_check'];
      if (d.category === 'bugs' && d.status === 'fixed') return [L(`Your bug ${t} is fixed: the fix comes with the next build`, `Ваш баг ${t} исправлен: исправление войдёт в следующую сборку`), thread, 'c_check'];
      const st = (d.category === 'bugs' ? BUG_ST : IDEA_ST)[d.status] || [d.status, d.status];
      return [d.category === 'bugs' ? L(`Your bug ${t}: ${esc(st[0].toLowerCase())}`, `Ваш баг ${t}: ${esc(st[1].toLowerCase())}`) : L(`Your idea ${t}: ${esc(st[0].toLowerCase())}`, `Ваша идея ${t}: ${esc(st[1].toLowerCase())}`), thread, d.category === 'bugs' ? 'c_warn' : 'c_gem'];
    }
    case 'report': return [d.outcome === 'hide' ? L('Your report was heard: it is hidden now.', 'Ваша жалоба принята: это скрыто.') : L('Your report was looked at and dismissed.', 'Вашу жалобу рассмотрели и отклонили.'), '#/forum', 'c_shield'];
    case 'badge': return [L(`A new badge: <b>${esc(d.en || '')}</b>`, `Новый значок: <b>${esc(d.ru || '')}</b>`), `#/u/${encodeURIComponent(me().name)}`, d.icon || 'c_gem'];
    case 'friend': return [d.accepted ? L(`${a} accepted your friend request`, `${a} теперь в ваших друзьях`) : L(`${a} wants to be friends`, `${a} хочет добавить вас в друзья`), d.accepted ? '#/friends/people' : '#/friends/people', 'c_team'];
    case 'group': return [L(`${a} invites you to ${t}`, `${a} зовёт вас в группу ${t}`), '#/friends', 'c_team'];
    case 'message': return [`${a}<span translate="no">: ${esc(d.text || '')}</span>`, `#/friends/c/${d.chat}`, 'c_chat'];
    case 'ticket': {
      const w = d.what || '', st = w.startsWith('state:') ? w.slice(6) : '';
      const line = w === 'new' ? L(`${a} opened a ticket: ${t}`, `${a} открывает обращение: ${t}`)
        : w === 'reply' ? L(`${a} answered in ${t}`, `Ответ от ${a} в ${t}`)
        : w === 'assigned' ? L(`${a} gave you a ticket: ${t}`, `${a} передаёт вам обращение: ${t}`)
        : w === 'device-reset' ? L(`Your computer is freed: ${t}`, `Привязка к компьютеру сброшена: ${t}`)
        : st === 'closed' ? L(`Your ticket is closed: ${t}`, `Обращение закрыто: ${t}`)
        : st ? L(`${t}: ${esc((TK_STATES_STAFF[st] || [st])[0].toLowerCase())}`, `${t}: ${esc((TK_STATES_STAFF[st] || [st, st])[1].toLowerCase())}`)
        : L(`Something new in ${t}`, `Новое в обращении ${t}`);
      return [line, `#/support/t/${d.ticket}`, 'c_chat'];
    }
    case 'role': return [L(`You are <b>${esc(d.en || '')}</b> now`, `Теперь вы — <b>${esc(d.ru || '')}</b>`), `#/u/${encodeURIComponent(me().name)}`, 'c_crown'];
    default: return [esc(d.text || L('Something happened.', 'Что-то случилось.')), typeof d.href === 'string' && d.href.startsWith('#/') ? d.href : '#/notifications', 'c_bell'];
  }
}

// ---- notes in the corner (a notification as it comes)

function toast(n) {
  const [line, href, icon] = noteWords(n);
  const id = ++SOC.noteId;
  SOC.notes.push({ id, line, href, icon, actor: n.actor, nid: n.id });
  drawNotes();
  setTimeout(() => { SOC.notes = SOC.notes.filter((x) => x.id !== id); drawNotes(); }, 7000);
}
function drawNotes() {
  let box = document.getElementById('notes');
  if (!box) { box = document.createElement('div'); box.id = 'notes'; box.setAttribute('aria-live', 'polite'); document.body.appendChild(box); }
  const shown = new Set([...box.children].map((c) => Number(c.dataset.id)));
  for (const el of [...box.children]) if (!SOC.notes.some((x) => x.id === Number(el.dataset.id))) { el.classList.add('out'); setTimeout(() => el.remove(), 320); }
  for (const x of SOC.notes.slice(-4)) {
    if (shown.has(x.id)) continue;
    const a = document.createElement('a');
    a.className = 'note'; a.dataset.id = x.id; a.href = x.href;
    a.innerHTML = `${x.actor ? head(x.actor.login, 34) : emo(x.icon, 34)}<span>${x.line}</span>`;
    a.addEventListener('click', () => { if (x.nid) api('notifications/read', { ids: [x.nid] }); SOC.notes = SOC.notes.filter((y) => y.id !== x.id); drawNotes(); });
    box.appendChild(a);
    a.querySelectorAll('canvas[data-head]').forEach(drawHead);
    translate(a);
  }
}

/** The bell in the bar: lit, with its count, while something waits unread. */
// A ring of glass the avatar's size next to it, a line bell in it (the site's icons' hand); the count a cream pill on its
// shoulder (her word 04.10: the emoji bell stood apart and out of proportion).
const bell = () => `<a class="bell ${SOC.unread ? 'lit' : ''}" href="#/notifications" aria-label="Notifications" title="Notifications"><svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M6.2 16.6V11a5.8 5.8 0 0 1 11.6 0v5.6l1.6 2.1H4.6z"/><path d="M10 20.6a2.1 2.1 0 0 0 4 0"/></svg><span class="count num">${SOC.unread > 99 ? '99+' : SOC.unread || ''}</span></a>`;

// ---- the list of notifications

function viewNotifications() {
  const c = ask('notifications');
  const more = SOC.notesMore || [];
  const items = c.ok ? c.data.items.concat(more) : [];
  const row = (n) => {
    const [line, href, icon] = noteWords(n);
    return `<a class="nrow ${n.read ? '' : 'unread'}" href="${esc(href)}" data-note="${n.id}">${n.actor ? head(n.actor.login, 40) : `<span class="ico">${emo(icon, 40)}</span>`}
      <span class="nl"><span>${line}</span><span class="ash">${ago(n.created)}</span></span></a>`;
  };
  return `<div class="page-head"><h1 class="giant">Notifications</h1></div>
    <div class="wrap notes-page">
      <div class="acts" style="margin-bottom:22px"><button class="w small" id="notes-all" ${SOC.unread ? '' : 'disabled'}>Mark all read</button><a class="w small" href="#/dashboard/notify">Settings</a></div>
      ${waiting(c) ? '<div class="nlist ghost-rows"><div></div><div></div><div></div></div>' : !c.ok ? trouble(c)
        : items.length ? `<div class="nlist">${items.map(row).join('')}</div>${(more.length ? SOC.notesMoreLeft : c.data.more) ? '<div class="acts" style="margin-top:24px"><button class="w small" id="notes-more">Older</button></div>' : ''}`
        : '<div class="empty">Nothing yet. Replies, mentions and badges show up here.</div>'}
    </div>`;
}

// ---- the badges

const RARITY = ['Common', 'Rare', 'Epic', 'Legendary', 'Mythic'];
const rarityName = (r) => tr(RARITY[r] || RARITY[0]);
/** A badge's rarity at its level (a badge of levels climbs). */
const rarityAt = (b, level) => (b.levels && b.levels.length ? (b.levels[Math.max(0, (level || 1) - 1)] || b.levels[0]).rarity : b.rarity);
const badgeName = (b) => L(b.en, b.ru);
function badgeTile(b, mine, big) {
  const r = rarityAt(b, mine && mine.level);
  const lvl = b.levels && b.levels.length > 1 && mine ? `<span class="lvl num">${mine.level}</span>` : '';
  return `<button class="bdg r${r} ${mine ? 'has' : 'not'} ${big ? 'bdg-l' : ''}" data-badge="${esc(b.id)}" title="${esc(badgeName(b))}">
      <span class="gem">${emo(b.icon, big ? 64 : 44)}${lvl}</span><span class="bn">${esc(badgeName(b))}</span></button>`;
}
function badgeCard(b, mine) {
  const r = rarityAt(b, mine && mine.level);
  const levels = b.levels && b.levels.length > 1 ? `<p class="ash">${L('Levels', 'Уровни')}: ${b.levels.map((l, i) => `<span class="${mine && mine.level > i ? 'cream' : ''}">${fmt(l.at)}</span>`).join(' · ')}</p>` : '';
  return `<div class="bdg-card r${r}">${emo(b.icon, 96)}<div><h3 class="sec">${esc(badgeName(b))}</h3>
      <p>${esc(L(b.about_en, b.about_ru))}</p>${levels}
      <p class="ash">${rarityName(r)} · ${L(`${b.share}% of players have it`, `есть у ${String(b.share).replace('.', ',')}% игроков`)}${mine ? ` · ${L('received', 'получен')} ${when(mine.at)}` : ''}</p></div></div>`;
}
function viewBadges() {
  const c = ask('badges'), mine = ask('u/' + encodeURIComponent(me().name));
  if (waiting(c)) return `<div class="page-head"><h1 class="giant">Badges</h1></div><div class="wrap">${ghosts(2)}</div>`;
  if (!c.ok) return trouble(c);
  const have = {}; if (mine.ok) for (const b of mine.data.badges) have[b.id] = b;
  const open = state.badgeOpen && c.data.badges.find((b) => b.id === state.badgeOpen);
  const count = Object.keys(have).length;
  return `<div class="page-head"><h1 class="giant">Badges</h1><p class="ash num">${L(`${count} of ${c.data.badges.length} collected`, `Собрано ${count} из ${c.data.badges.length}`)}</p></div>
    <div class="wrap">${open ? badgeCard(open, have[open.id]) : ''}<div class="bdgs grid-b">${c.data.badges.map((b) => badgeTile(b, have[b.id])).join('')}</div></div>`;
}

// ---- the profile's music (one plays at a time; leaving the page stops it)

function stopMusic() {
  const p = SOC.playing;
  if (!p) return;
  if (p.audio) p.audio.pause();
  if (p.frame) p.frame.remove();
  cancelAnimationFrame(p.raf || 0);
  SOC.playing = null;
  document.querySelectorAll('.player.on').forEach((el) => el.classList.remove('on'));
}
function playMusic(btn) {
  const m = SOC.profileMusic;
  if (!m) return;
  if (SOC.playing && SOC.playing.btn === btn) { stopMusic(); return; }
  stopMusic();
  const box = btn.closest('.player');
  if (m.kind === 'file') {
    const audio = new Audio(m.url);
    audio.volume = 0.7;
    audio.play().catch(() => {});
    SOC.playing = { audio, btn };
    box.classList.add('on');
    const bar = box.querySelector('.prog i');
    const tick = () => { if (!SOC.playing || SOC.playing.audio !== audio) return; if (bar && audio.duration) bar.style.transform = `scaleX(${audio.currentTime / audio.duration})`; SOC.playing.raf = requestAnimationFrame(tick); };
    tick();
    audio.addEventListener('ended', stopMusic);
  } else {
    // SoundCloud plays in its own (hidden) player; this page says play and stop.
    const f = document.createElement('iframe');
    f.className = 'sc-frame'; f.allow = 'autoplay';
    f.src = 'https://w.soundcloud.com/player/?url=' + encodeURIComponent(m.url) + '&auto_play=true&visual=false&show_artwork=false';
    document.body.appendChild(f);
    SOC.playing = { frame: f, btn };
    box.classList.add('on');
  }
}
window.addEventListener('hashchange', () => { if (!/^#\/(u|author)\//.test(location.hash)) stopMusic(); });

// ---- a member's profile (#/u/<login>; the old #/author/<login> comes here too)

/** The networks, as the profile draws them: a small mark each (drawn here, in the site's own line), and its address. */
const NETS = {
  discord: ['Discord', null, '<path d="M7 7.5c3.3-1.6 6.7-1.6 10 0 1.3 2.4 2 5 2 8-1.4 1.1-2.9 1.8-4.5 2.2l-.9-1.6m-7.2 0-.9 1.6C3.9 17.3 2.4 16.6 1 15.5c0-3 .7-5.6 2-8z" transform="translate(2 0)"/><circle cx="9.6" cy="12.6" r="1.3" fill="currentColor" stroke="none"/><circle cx="14.4" cy="12.6" r="1.3" fill="currentColor" stroke="none"/>'],
  telegram: ['Telegram', (h) => 'https://t.me/' + h, '<path d="M3 11.5 20.5 4.5l-3 15-5.2-4.4-3 2.9.4-4.5L17 7.8l-9.6 5.6z"/>'],
  youtube: ['YouTube', (h) => 'https://www.youtube.com/' + h, '<rect x="2.5" y="5.5" width="19" height="13" rx="4"/><path d="M10 9.2v5.6l4.8-2.8z" fill="currentColor" stroke="none"/>'],
  twitch: ['Twitch', (h) => 'https://www.twitch.tv/' + h, '<path d="M4.5 3.5h15v10l-4 4h-4l-3 3v-3h-4z"/><path d="M11 8v4M15 8v4"/>'],
  tiktok: ['TikTok', (h) => 'https://www.tiktok.com/@' + h, '<path d="M13 3.5v11.5a3.5 3.5 0 1 1-3.5-3.5"/><path d="M13 3.5c.4 2.6 2.2 4.4 5 4.6"/>'],
  vk: ['VK', (h) => 'https://vk.com/' + h, '<path d="M3.5 7.5c.3 5.6 3.4 9 8.2 9h.5v-3.4c1.9.2 3.3 1.6 3.9 3.4h2.5c-.8-2.6-2.7-4.1-3.8-4.6 1.2-.7 2.8-2.4 3.2-4.4h-2.3c-.5 1.6-1.9 3.1-3.5 3.3V7.5H9.9v6.3c-1.6-.4-3.3-2.4-3.6-6.3z"/>'],
  steam: ['Steam', (h) => 'https://steamcommunity.com/' + h, '<circle cx="15.5" cy="9" r="3.5"/><circle cx="8.5" cy="16" r="2.6"/><path d="M2.5 13.5 6.2 15m4.6.6 2.4-3.8"/>'],
  github: ['GitHub', (h) => 'https://github.com/' + h, '<path d="M9 19c-4.5 1.4-4.5-2.2-6.5-2.7M15 21.5v-3.4c0-1 .1-1.4-.5-2 2.8-.3 5.5-1.4 5.5-6a4.7 4.7 0 0 0-1.3-3.2 4.3 4.3 0 0 0-.1-3.2s-1-.3-3.4 1.3a11.6 11.6 0 0 0-6.1 0C6.7 3.4 5.7 3.7 5.7 3.7a4.3 4.3 0 0 0-.1 3.2 4.7 4.7 0 0 0-1.3 3.2c0 4.6 2.7 5.7 5.5 6-.6.6-.6 1.2-.5 2v3.4"/>'],
  soundcloud: ['SoundCloud', (h) => 'https://soundcloud.com/' + h, '<path d="M8 17V9.5M5 17v-5M2.5 17v-3M11 17V7.5c4.6-1.3 7.7 1.4 8 4.5a3 3 0 0 1-.5 5z"/>'],
  site: ['Site', (h) => h, '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.8 3.8 5.8 3.8 9s-1.2 6.2-3.8 9c-2.6-2.8-3.8-5.8-3.8-9s1.2-6.2 3.8-9z"/>'],
};
const netMark = (id) => `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${NETS[id][2]}</svg>`;
function socialLinks(s) {
  const out = [];
  for (const id of Object.keys(NETS)) {
    const v = s && s[id];
    if (!v) continue;
    const [name, href] = NETS[id];
    // Discord has no address of a person: the name is shown, and copied on a click.
    out.push(href ? `<a class="net" href="${esc(href(v))}" target="_blank" rel="noopener noreferrer nofollow" title="${esc(name)}: ${esc(v)}">${netMark(id)}<span class="sr">${esc(name)}</span></a>`
      : `<button class="net" data-copy="${esc(v)}" title="${esc(name)}: ${esc(v)}">${netMark(id)}<span class="sr">${esc(name)}</span></button>`);
  }
  return out.length ? `<div class="nets" translate="no">${out.join('')}</div>` : '';
}

const THEME_NAMES = { eclipse: ['Eclipse', 'Затмение'], void: ['Void', 'Пустота'], aurora: ['Aurora', 'Сияние'], ember: ['Ember', 'Угли'], frost: ['Frost', 'Иней'], bloom: ['Bloom', 'Цветение'] };
const ACCENTS = ['#BFC0E7', '#6669F5', '#F2F1CB', '#E5484D', '#F0629B', '#E8B04B', '#4FC3B5', '#7BD88F', '#59A5F5', '#B583F5', '#FF8A4C', '#FFFFFF'];
const hours = (h) => L(`${fmt(h)} h`, `${fmt(h)} ч`);

function viewProfile(arg) {
  const login = decodeURIComponent(String(arg || '').split('/')[0] || me().name);
  const c = ask('u/' + encodeURIComponent(login));
  if (waiting(c)) return `<div class="prof"><div class="prof-banner theme-eclipse ghost"></div><div class="wrap prof-top"><div class="prof-av ghost-av"></div></div></div>`;
  if (!c.ok) return `<div class="page-head"><h1 class="giant">${c.status === 404 ? 'No such member' : 'Profile'}</h1></div><div class="wrap">${trouble(c)}</div>`;
  const p = c.data, who = p.person, own = p.viewer.self;
  SOC.profileMusic = p.music;
  const acc = who.accent || '#E9E9EB';
  const packs = ask('market?author=' + encodeURIComponent(who.login) + '&sort=users');
  // A banner whose file is not there: the theme's own picture instead of a broken one (its icon showed in the corner).
  const banner = p.banner ? `<img src="${esc(p.banner.url)}" alt="" decoding="async" onerror="this.parentElement.classList.remove('has');this.remove()">` : '';
  const pres = p.presence || {};
  const where = pres.online ? `<p class="presence">${dot(pres.online)}<span>${pres.online === 'game' ? tr('In the game') : tr('On the site')}</span>${pres.server ? `<span class="ash" translate="no">· ${esc(pres.server)}</span>` : ''}${pres.listening ? `<span class="listening">${emo('c_play', 18)}<span translate="no">${esc(pres.listening.title)}${pres.listening.artist ? ' — ' + esc(pres.listening.artist) : ''}</span></span>` : ''}</p>` : '';
  const have = {}; for (const b of p.badges) have[b.id] = b;
  const cat = ask('badges'), defs = cat.ok ? cat.data.badges : [];
  const def = (id) => defs.find((b) => b.id === id);
  const shown = (p.showcase.length ? p.showcase : p.badges.slice(-6).map((b) => b.id)).map(def).filter(Boolean);
  const music = p.music ? `<div class="player" style="--acc:${esc(acc)}"><button class="play" data-play aria-label="Listen"><i></i></button>
      <div class="pl"><b translate="no">${esc(p.music.title || L('Untitled', 'Без названия'))}</b><span class="ash" translate="no">${esc(p.music.artist || '')}${p.music.kind === 'soundcloud' ? ' · SoundCloud' : ''}</span><span class="prog"><i></i></span></div>
      <span class="eq" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></span></div>` : '';
  const stats = [[p.stats.posts, L('posts', plural(p.stats.posts, 'пост', 'поста', 'постов'))], [p.stats.threads, L('threads', plural(p.stats.threads, 'тема', 'темы', 'тем'))], [p.stats.packs, L('packs', plural(p.stats.packs, 'пак', 'пака', 'паков'))]];
  if (p.stats.hours !== null && p.stats.hours !== undefined) stats.push([p.stats.hours, L('hours in Cursed', plural(p.stats.hours, 'час в Cursed', 'часа в Cursed', 'часов в Cursed'))]);
  return `<div class="prof" style="--acc:${esc(acc)}">
    <div class="prof-banner theme-${esc(p.theme || 'eclipse')} ${banner ? 'has' : ''}">${banner}</div>
    <div class="wrap prof-top">
      <div class="prof-av">${head(who.login, 132)}${dot(pres.online)}</div>
      <div class="prof-name">
        <p class="prefix-line">${pfx(who)}<span class="ash num" translate="no">UID ${esc(String(who.uid_text || who.uid))}</span></p>
        <h1 class="giant" translate="no" style="color:var(--acc)">${esc(who.login)}</h1>
        ${who.status ? `<p class="status big-status">${emo(who.status.emoji, 24)}<span translate="no">${esc(who.status.text || '')}</span></p>` : ''}
        ${where}
      </div>
      <div class="prof-acts acts">${own ? '<a class="w lead" href="#/dashboard/profile">Edit profile</a><a class="w" href="#/badges">Badges</a><a class="w" href="#/friends/people">Friends</a>' : relationActs(p)}</div>
    </div>
    <div class="wrap prof-body">
      <div class="prof-side">
        ${music}
        ${socialLinks(p.socials)}
        <div class="prof-stats">${stats.map(([n, w]) => `<div><b class="num">${fmt(n)}</b><span>${w}</span></div>`).join('')}</div>
        <p class="ash joined">${L('With Cursed since', 'В Cursed с')} ${when(p.since)}</p>
      </div>
      <div class="prof-main">
        ${p.about ? `<div class="block"><h2 class="sec">About me</h2><div class="prose" translate="no">${prose(p.about)}</div></div>` : own ? '<div class="block"><h2 class="sec">About me</h2><p class="ash">Say something of yourself: <a class="w small" href="#/dashboard/profile">Edit profile</a></p></div>' : ''}
        ${p.badges.length ? `<div class="block"><h2 class="sec">Badges <span class="ash num">${p.badges.length}</span></h2>
          <div class="bdgs showcase">${shown.map((b) => badgeTile(b, have[b.id], true)).join('')}</div>
          ${p.badges.length > shown.length ? `<div class="bdgs rest">${p.badges.filter((b) => !shown.some((s) => s.id === b.id)).map((b) => def(b.id)).filter(Boolean).map((b) => badgeTile(b, have[b.id])).join('')}</div>` : ''}
          ${state.badgeOpen && def(state.badgeOpen) ? badgeCard(def(state.badgeOpen), have[state.badgeOpen]) : ''}</div>` : ''}
        ${p.shots.length || own ? `<div class="block"><h2 class="sec">Screenshots <span class="ash num">${p.shots.length}</span></h2>
          ${p.shots.length ? `<div class="shots">${p.shots.map((s, i) => `<button class="shot-t" data-shot-open="${i}"><img src="${esc(s.thumb)}" alt="" loading="lazy"></button>`).join('')}</div>` : '<p class="ash">From the game: press F2, then “To the gallery”. Or add them in your profile.</p>'}</div>` : ''}
        ${packs.ok && packs.data.items.length ? `<div class="block"><h2 class="sec">Packs <span class="ash num">${packs.data.items.length}</span></h2><div class="grid">${packs.data.items.map(card).join('')}</div></div>` : ''}
      </div>
    </div>
    ${state.shotOpen !== undefined && p.shots[state.shotOpen] ? `<div class="lightbox" id="lightbox"><img src="${esc(p.shots[state.shotOpen].url)}" alt=""><button class="w small lb-close" id="lb-close">Close</button>
      ${state.shotOpen > 0 ? '<button class="lb-prev" data-shot-step="-1" aria-label="Previous">‹</button>' : ''}${state.shotOpen < p.shots.length - 1 ? '<button class="lb-next" data-shot-step="1" aria-label="Next">›</button>' : ''}</div>` : ''}
  </div>`;
}

// ---- the dashboard's new pages: the profile as its member dresses it, the notifications they want, their sessions

const PRIV = [['online', 'Show when I am online'], ['listening', 'Show what I listen to in the client'], ['server', 'Show the server I play on'], ['hours', 'Show my hours in Cursed']];

/** The draft of the profile being edited: made from the profile once, kept while the page is up. */
function draft(p) {
  if (!state.pe || state.pe.of !== p.person.uid) {
    state.pe = {
      of: p.person.uid, about: p.about || '', status_text: p.status_text || '', status_emoji: p.status_emoji || '', accent: p.accent || '', theme: p.theme || 'eclipse',
      socials: { ...(p.socials || {}) }, privacy: { ...(p.privacy || {}) }, prefix: p.prefix_choice || 'auto', showcase: [...(p.showcase || [])], msg: '', bad: false, busy: '',
    };
  }
  return state.pe;
}

function dashProfile() {
  const c = ask('u/' + encodeURIComponent(me().name)), cat = ask('badges');
  if (waiting(c)) return `<h1 class="sr">Profile</h1><div class="sections">${ghosts(2)}</div>`;
  if (!c.ok) return trouble(c);
  const p = c.data, d = draft(p), roles = (SOC.meta ? SOC.meta.roles : []).filter((r) => (p.roles || []).includes(r.id));
  const defs = cat.ok ? cat.data.badges : [], mine = p.badges.map((b) => [defs.find((x) => x.id === b.id), b]).filter(([x]) => x);
  const busy = (k) => d.busy === k;
  const pick = (name, on, label, extra) => `<button class="w small ${on ? 'on' : ''}" ${name} ${extra || ''}>${label}</button>`;
  return `<h1 class="sr">Profile</h1><div class="sections pe" style="--acc:${esc(d.accent || '#E9E9EB')}">
    <div class="block pe-look">
      <h2 class="sec">Look</h2>
      <div class="pe-banner theme-${esc(d.theme)} ${p.banner ? 'has' : ''}" id="banner-drop">${p.banner ? `<img src="${esc(p.banner.url)}" alt="">` : ''}
        <span class="pe-name" translate="no">${head(me().name, 64)}<b style="color:var(--acc)">${esc(me().name)}</b></span></div>
      <p class="hint">A banner: PNG, JPEG, WebP or GIF up to 12 MB, cut to 3:1 from the middle (1500×500). A GIF stays animated, here and in the game.</p>
      <div class="acts"><label class="w small lead" for="banner-file">${busy('banner') ? 'Uploading…' : p.banner ? 'Change the banner' : 'Upload a banner'}</label><input id="banner-file" type="file" accept="image/png,image/jpeg,image/webp,image/gif" hidden>${p.banner ? '<button class="w small" id="banner-drop-it">Remove it</button>' : ''}</div>
      <p class="lab">Backdrop <span class="ash">(shown where there is no banner)</span></p>
      <div class="acts themes">${Object.keys(THEME_NAMES).map((t) => `<button class="theme-chip theme-${t} ${d.theme === t ? 'on' : ''}" data-theme="${t}" title="${esc(L(...THEME_NAMES[t]))}"><span>${L(...THEME_NAMES[t])}</span></button>`).join('')}</div>
      <p class="lab">Accent <span class="ash">(your name, your music, your marks)</span></p>
      <div class="acts swatches">${ACCENTS.map((a) => `<button class="sw ${d.accent.toUpperCase() === a ? 'on' : ''}" data-accent="${a}" style="--c:${a}" aria-label="${a}"></button>`).join('')}
        <label class="sw-own"><span class="sr">Your own colour</span><input class="in mono" id="accent-own" maxlength="7" placeholder="#RRGGBB" value="${esc(ACCENTS.includes(d.accent.toUpperCase()) ? '' : d.accent)}"></label>
        <button class="w small ${d.accent ? '' : 'on'}" data-accent="">The site’s own</button></div>
    </div>

    <div class="block">
      <h2 class="sec">Status</h2>
      <div class="pe-status"><input class="in" id="status-text" maxlength="60" placeholder="Looking for a team, AFK, streaming…" value="${esc(d.status_text)}"></div>
      <div class="emoji-pick">${['', ...(SOC.meta ? SOC.meta.emoji : [])].map((e) => `<button class="${d.status_emoji === e ? 'on' : ''}" data-status-emoji="${esc(e)}" title="${esc(e || tr('None'))}">${e ? emo(e, 28) : '<span class="none">—</span>'}</button>`).join('')}</div>
    </div>

    <div class="block">
      <h2 class="sec">About</h2>
      <textarea class="in" id="about" maxlength="1000" rows="5" placeholder="Who you are, what you play, what you make.">${esc(d.about)}</textarea>
      <p class="hint num"><span id="about-n">${d.about.length}</span> / 1000</p>
    </div>

    <div class="block">
      <h2 class="sec">Music</h2>
      ${p.music ? `<div class="pe-music"><p class="hint">${p.music.kind === 'soundcloud' ? `SoundCloud: <a href="${esc(p.music.url)}" target="_blank" rel="noopener noreferrer" translate="no">${esc(p.music.url)}</a>` : L('Your own MP3', 'Свой MP3') + ` · <span class="num">${Math.round((p.music.ms || 0) / 1000)} ${L('s', 'с')}</span>`}</p>
        <div class="two-in"><input class="in" id="music-title" maxlength="80" placeholder="Song title" value="${esc(p.music.title || '')}"><input class="in" id="music-artist" maxlength="80" placeholder="Artist" value="${esc(p.music.artist || '')}"></div>
        <div class="acts"><button class="w small" id="music-names">Save the names</button><button class="w small" id="music-drop">Remove the song</button></div></div>` : '<p class="ash">No song on your profile.</p>'}
      <div class="acts"><label class="w small lead" for="music-file">${busy('music') ? 'Uploading…' : 'Upload an MP3'}</label><input id="music-file" type="file" accept="audio/mpeg,.mp3" hidden></div>
      <p class="hint">Up to 10 MB and 10 minutes. Its title and artist come from its tags. Or a SoundCloud track:</p>
      <div class="two-in"><input class="in" id="sc-url" placeholder="https://soundcloud.com/artist/track"><button class="w small" id="sc-set">Use it</button></div>
    </div>

    <div class="block">
      <h2 class="sec">Prefix</h2>
      <div class="acts">${pick('data-prefix="auto"', d.prefix === 'auto', 'Highest role')}${pick('data-prefix="none"', d.prefix === 'none', 'None')}${roles.map((r) => pick(`data-prefix="${esc(r.id)}"`, d.prefix === r.id, `<span class="pfx" style="--c:${esc(r.colour)}" translate="no">${esc(r.prefix)}</span>`)).join('')}</div>
      ${roles.length ? '' : '<p class="ash">You hold no role with a prefix yet.</p>'}
    </div>

    ${mine.length ? `<div class="block">
      <h2 class="sec">Showcase <span class="ash num">${d.showcase.length} / 6</span></h2>
      <p class="hint">The badges shown first on your profile. Pick up to six.</p>
      <div class="bdgs pe-show">${mine.map(([b, m]) => badgeTile(b, m).replace('class="badge', `class="bdg ${d.showcase.includes(b.id) ? 'picked' : ''}`).replace('data-badge=', 'data-show=')).join('')}</div>
    </div>` : ''}

    <div class="block">
      <h2 class="sec">Links</h2>
      <div class="nets-edit">${Object.keys(NETS).map((id) => `<label class="net-in">${netMark(id)}<span class="sr">${NETS[id][0]}</span><input class="in" data-net="${id}" placeholder="${esc(NETS[id][0])}" value="${esc(d.socials[id] || '')}" translate="no"></label>`).join('')}</div>
      <p class="hint">A name or an address: @name, t.me/name, youtube.com/@name. An empty one is not shown.</p>
    </div>

    <div class="block">
      <h2 class="sec">Privacy</h2>
      <div class="ticks">${PRIV.map(([k, w]) => `<label class="tick"><input type="checkbox" data-priv="${k}" ${d.privacy[k] ? 'checked' : ''}><span>${w}</span></label>`).join('')}</div>
      <p class="lab">Who may write to you</p>
      <div class="acts">${[['all', 'Everyone'], ['friends', 'Friends'], ['none', 'Nobody']].map(([k, w]) => pick(`data-dm="${k}"`, (d.privacy.dm || 'friends') === k, w)).join('')}</div>
    </div>

    <div class="block">
      <h2 class="sec">Screenshots <span class="ash num">${p.shots.length}</span></h2>
      <div class="acts"><label class="w small lead" for="shot-file">${busy('shot') ? 'Uploading…' : 'Add screenshots'}</label><input id="shot-file" type="file" accept="image/png,image/jpeg,image/webp" multiple hidden></div>
      ${p.shots.length ? `<div class="shots edit">${p.shots.map((s) => `<span class="shot-t"><img src="${esc(s.thumb)}" alt="" loading="lazy"><button class="w small" data-shot-drop="${esc(s.id)}">Remove</button></span>`).join('')}</div>` : ''}
    </div>

    <div class="pe-save"><button class="w menu lead" id="pe-save">Save</button><a class="w" href="#/u/${encodeURIComponent(me().name)}">See my profile</a><span class="hint ${d.bad ? 'bad' : 'ok'}" id="pe-msg" role="status">${esc(d.msg)}</span></div>
  </div>`;
}

function dashNotify() {
  const c = ask('me/notify');
  if (waiting(c)) return `<h1 class="sr">Notifications</h1><div class="sections">${ghosts(1)}</div>`;
  if (!c.ok) return trouble(c);
  const box = (k, ch) => `<input type="checkbox" data-np="${esc(k.kind)}:${ch}" ${k[ch] ? 'checked' : ''} aria-label="${esc(ch)}">`;
  return `<h1 class="sr">Notifications</h1><div class="sections"><div class="block">
    <h2 class="sec">What you hear of, and where</h2>
    <p class="hint">On the site — the bell and a note in the corner. In the game — a note in its corner. Windows — a notification of Windows while the game is not in front.</p>
    <div class="scroll-x"><table class="np"><thead><tr><th></th><th>Site</th><th>Game</th><th>Windows</th></tr></thead><tbody>
      ${c.data.kinds.map((k) => `<tr><td>${esc(L(k.en, k.ru))}</td><td>${box(k, 'site')}</td><td>${box(k, 'game')}</td><td>${box(k, 'push')}</td></tr>`).join('')}
    </tbody></table></div><p class="hint" id="np-msg" role="status"></p></div></div>`;
}

function dashSessions() {
  const c = ask('me/sessions');
  if (waiting(c)) return `<h1 class="sr">Sessions</h1><div class="sections">${ghosts(1)}</div>`;
  if (!c.ok) return trouble(c);
  const kind = (k) => ({ web: L('Site', 'Сайт'), loader: L('Loader', 'Лоудер'), client: L('Game', 'Игра') }[k] || k);
  const list = c.data.sessions;
  return `<h1 class="sr">Sessions</h1><div class="sections"><div class="block">
    <h2 class="sec">Where you are signed in</h2>
    <div class="rows sessions">${list.map((s) => `<div><b translate="no">${esc(s.label)}</b><span class="st ${s.current ? 'cream' : 'ok'}">${s.current ? L('This one', 'Этот') : kind(s.kind)}</span>
      <span class="d ash">${L('last used', 'был')} ${ago(s.seen)} · ${L('since', 'с')} ${when(s.created)}</span>${s.current ? '' : `<button class="w small" data-end="${esc(s.id)}">Sign out</button>`}</div>`).join('')}</div>
    ${list.length > 1 ? '<div class="acts" style="margin-top:22px"><button class="w lead" id="end-others">Sign out everywhere else</button></div>' : ''}
    <p class="hint" id="end-msg" role="status"></p></div>${dashDevice()}</div>`;
}

// ---- uploads of the profile (raw bodies, as the avatar)

async function sendRaw(path, file, kind) {
  const d = state.pe;
  if (d) { d.busy = kind; d.msg = ''; d.bad = false; }
  render(true);
  let r = null, data = {};
  try {
    r = await fetch('/api/' + path, { method: 'POST', credentials: 'same-origin', cache: 'no-store', headers: { 'Content-Type': file.type || 'application/octet-stream' }, body: file });
    try { data = await r.json(); } catch (e) { /* not JSON */ }
  } catch (e) { r = null; }
  if (d) d.busy = '';
  if (r && r.status === 401) { signOut(); location.hash = '#/signin'; return false; }
  if (!(r && r.ok) && d) { d.msg = r ? (data.message ? tr('Not taken:') + ' ' + tr(data.message) : r.status === 429 ? tr('Too many uploads. Wait a while.') : SAY.busy) : SAY.offline; d.bad = true; }
  forget('u/');
  render(true);
  return !!(r && r.ok);
}

async function saveProfile() {
  const d = state.pe;
  if (!d) return;
  const own = document.getElementById('accent-own');
  if (own && own.value.trim()) d.accent = own.value.trim();
  const r = await api('me/profile', { about: d.about, status_text: d.status_text, status_emoji: d.status_emoji, accent: d.accent, theme: d.theme, socials: d.socials, privacy: d.privacy, prefix: d.prefix, showcase: d.showcase }, 'PATCH');
  d.bad = !r.ok;
  d.msg = r.ok ? tr('Saved.') : r.message ? tr(r.message) : SAY[r.error] || SAY.busy;
  if (r.ok) { forget('u/', 'forum', 'me'); const m = await api('me'); if (m.ok) signIn(m.data); }
  render(true);
}

// ---- what the people's screens do (wired after the app's own)

function socialWire() {
  const on = (sel, ev, fn) => $app.querySelectorAll(sel).forEach((el) => bindOnce(el, ev, 'w2|' + sel, (e) => fn(el, e)));
  // The notifications.
  on('#notes-all', 'click', async () => { const r = await api('notifications/read', { all: true }); if (r.ok) { setUnread(0); forget('notifications'); SOC.notesMore = null; render(true); } });
  on('[data-note]', 'click', (a) => { api('notifications/read', { ids: [Number(a.dataset.note)] }); forget('notifications'); });
  on('#notes-more', 'click', async () => {
    const c = got.get('notifications'), all = (c && c.ok ? c.data.items : []).concat(SOC.notesMore || []);
    const r = await api('notifications?before=' + all[all.length - 1].id);
    if (r.ok) { SOC.notesMore = (SOC.notesMore || []).concat(r.data.items); SOC.notesMoreLeft = r.data.more; render(true); }
  });
  // The badges.
  on('[data-badge]', 'click', (b) => { state.badgeOpen = state.badgeOpen === b.dataset.badge ? '' : b.dataset.badge; render(true); });
  // The profile.
  on('[data-play]', 'click', (b) => playMusic(b));
  on('[data-shot-open]', 'click', (b) => { state.shotOpen = Number(b.dataset.shotOpen); render(true); });
  on('#lb-close', 'click', () => { state.shotOpen = undefined; render(true); });
  on('#lightbox', 'click', (el, e) => { if (e.target === el) { state.shotOpen = undefined; render(true); } });
  on('[data-shot-step]', 'click', (b) => { state.shotOpen += Number(b.dataset.shotStep); render(true); });
  // The profile's editor.
  const d = state.pe;
  if (d) {
    on('[data-theme]', 'click', (b) => { d.theme = b.dataset.theme; render(true); });
    on('[data-accent]', 'click', (b) => { d.accent = b.dataset.accent; render(true); });
    on('#accent-own', 'change', (i) => { if (/^#[0-9a-f]{6}$/i.test(i.value.trim())) { d.accent = i.value.trim().toUpperCase(); render(true); } });
    on('[data-status-emoji]', 'click', (b) => { d.status_emoji = b.dataset.statusEmoji; render(true); });
    on('#status-text', 'input', (i) => { d.status_text = i.value; });
    on('#about', 'input', (t) => { d.about = t.value; const n = document.getElementById('about-n'); if (n) n.textContent = t.value.length; });
    on('[data-prefix]', 'click', (b) => { d.prefix = b.dataset.prefix; render(true); });
    on('[data-show]', 'click', (b) => {
      const id = b.dataset.show, i = d.showcase.indexOf(id);
      if (i >= 0) d.showcase.splice(i, 1); else if (d.showcase.length < 6) d.showcase.push(id);
      render(true);
    });
    on('[data-net]', 'input', (i) => { d.socials[i.dataset.net] = i.value; });
    on('[data-priv]', 'change', (i) => { d.privacy[i.dataset.priv] = i.checked; });
    on('[data-dm]', 'click', (b) => { d.privacy.dm = b.dataset.dm; render(true); });
    on('#pe-save', 'click', saveProfile);
    on('#banner-file', 'change', (i) => { if (i.files[0]) sendRaw('me/banner', i.files[0], 'banner'); });
    on('#banner-drop-it', 'click', async () => { await api('me/banner', null, 'DELETE'); forget('u/'); render(true); });
    on('#banner-drop', 'dragover', (el, e) => { e.preventDefault(); el.classList.add('over'); });
    on('#banner-drop', 'dragleave', (el) => el.classList.remove('over'));
    on('#banner-drop', 'drop', (el, e) => { e.preventDefault(); el.classList.remove('over'); const f = e.dataTransfer.files[0]; if (f) sendRaw('me/banner', f, 'banner'); });
    on('#music-file', 'change', (i) => { if (i.files[0]) sendRaw('me/music', i.files[0], 'music'); });
    on('#music-names', 'click', async () => {
      const r = await api('me/music', { title: document.getElementById('music-title').value, artist: document.getElementById('music-artist').value }, 'PATCH');
      d.msg = r.ok ? tr('Saved.') : tr(r.message || SAY.busy); d.bad = !r.ok; forget('u/'); render(true);
    });
    on('#music-drop', 'click', async () => { await api('me/music', null, 'DELETE'); forget('u/'); render(true); });
    on('#sc-set', 'click', async () => {
      const r = await api('me/music', { soundcloud: document.getElementById('sc-url').value }, 'PATCH');
      d.msg = r.ok ? tr('Saved.') : tr(r.message || SAY.busy); d.bad = !r.ok; forget('u/'); render(true);
    });
    on('#shot-file', 'change', async (i) => { for (const f of [...i.files]) { if (!(await sendRaw('me/shots', f, 'shot'))) break; } });
    on('[data-shot-drop]', 'click', async (b) => { await api('me/shots/' + b.dataset.shotDrop, null, 'DELETE'); forget('u/'); render(true); });
  }
  // The notifications wanted.
  on('[data-np]', 'change', async (i) => {
    const [kind, ch] = i.dataset.np.split(':');
    const r = await api('me/notify', { [kind]: { [ch]: i.checked } }, 'PUT');
    const msg = document.getElementById('np-msg'); if (msg) { msg.textContent = tr(r.ok ? 'Saved.' : SAY.busy); msg.className = 'hint ' + (r.ok ? 'ok' : 'bad'); }
    forget('me/notify');
  });
  // The sessions.
  on('[data-end]', 'click', async (b) => { await api('me/sessions/' + b.dataset.end, null, 'DELETE'); forget('me/sessions'); render(true); });
  on('#end-others', 'click', async () => {
    const r = await api('me/sessions/others', {});
    forget('me/sessions'); render(true);
    const msg = document.getElementById('end-msg'); if (msg && r.ok) { msg.textContent = tr('Signed out everywhere else.'); msg.className = 'hint ok'; }
  });
  friendsWire();
  configsWire();
  forumWire();
  supportWire();
  deviceWire();
  adminWire();
}

/** What the people's screens need of the server before they draw (the roles, the emoji). */
async function socialMeta() {
  if (SOC.meta) return;
  const r = await api('people/meta');
  if (r.ok) { SOC.meta = r.data; if (state.route === 'dashboard' || state.route === 'u') render(true); }
}

// ================================================================================================ friends (03.10.2026)
// Friends and conversations (#/friends): the list of conversations and the invitations to groups on the left; on the
// right the one open (#/friends/c/<id>), the friends and their requests (#/friends/people), a new group
// (#/friends/new), a group's link (#/friends/join/<code>). An open conversation lives in FR.chat and is changed in
// place by the live line: a message is added without drawing the page again, so what is being typed stays as it is.

const FR = { chat: null, unread: 0, typingAt: 0, rec: null, ng: null, add: '', addMsg: '', panel: false, react: 0, del: 0, report: 0, reportWhy: '', pic: null, plays: null };
MEMBERS_ONLY.add('friends');

/** At the sign-in: how many messages wait unread (the bar's count). */
function frStart() {
  api('chats').then((r) => { if (r.ok) { got.set('chats', { at: performance.now(), ok: true, data: r.data }); frUnread(r.data.unread); } });
}
function frUnread(n) {
  FR.unread = Math.max(0, n | 0);
  document.querySelectorAll('.nav-fr .nb').forEach((b) => { b.textContent = FR.unread ? (FR.unread > 99 ? '99+' : FR.unread) : ''; });
}
const navFriends = () => `<a class="w nav-fr ${state.route === 'friends' && !state.gate ? 'on' : ''}" href="#/friends">Friends<span class="nb num">${FR.unread ? (FR.unread > 99 ? '99+' : FR.unread) : ''}</span></a>`;
const frHref = (id) => `#/friends/c/${id}`;
const mine = (m) => m && m.author && state.user && m.author.uid === state.user.uid;
/** A group's picture, or its first letter on the dark. */
const groupAv = (c, size) => (c.avatar && c.avatar.url ? `<img class="g-av" src="${esc(c.avatar.url)}" alt="" style="width:${size}px;height:${size}px" decoding="async">`
  : `<span class="g-av g-letter" style="width:${size}px;height:${size}px;font-size:${Math.round(size * 0.42)}px" translate="no">${esc((c.title || '?').slice(0, 1).toUpperCase())}</span>`);
const chatAv = (c, size) => (c.kind === 'dm' && c.other ? `<span class="c-av">${head(c.other.login, size)}${dot(c.other.presence && c.other.presence.online)}</span>` : groupAv(c, size));
const chatName = (c) => (c.kind === 'dm' && c.other ? `${pfx(c.other)}<b translate="no"${c.other.accent ? ` style="color:${esc(c.other.accent)}"` : ''}>${esc(c.other.login)}</b>` : `<b translate="no">${esc(c.title)}</b>`);
/** A time of a message: the hour today, the day before that. */
const clock = (s) => {
  const d = new Date(s * 1000), now = new Date();
  return d.toDateString() === now.toDateString() ? d.toLocaleTimeString(L('en-GB', 'ru-RU'), { hour: '2-digit', minute: '2-digit' })
    : d.toLocaleDateString(L('en-GB', 'ru-RU'), { day: 'numeric', month: 'short' });
};
const dayOf = (s) => new Date(s * 1000).toDateString();
const dayWords = (s) => {
  const d = new Date(s * 1000), today = new Date(), y = new Date(Date.now() - 86400000);
  if (d.toDateString() === today.toDateString()) return L('Today', 'Сегодня');
  if (d.toDateString() === y.toDateString()) return L('Yesterday', 'Вчера');
  return d.toLocaleDateString(L('en-GB', 'ru-RU'), { day: 'numeric', month: 'long', year: d.getFullYear() === today.getFullYear() ? undefined : 'numeric' });
};
/** Small marks of the composer, drawn in the site's own line (the pack's emoji have no microphone). */
const frIcon = (d) => `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
const ICON_PICTURE = '<rect x="3" y="5" width="18" height="14" rx="3"/><circle cx="9" cy="10" r="1.6"/><path d="m4.5 17 5-5 4 4 2.5-2.5 3.5 3.5"/>';
const ICON_MIC = '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21M8.5 21h7"/>';
const secs = (ms) => { const s = Math.round((ms || 0) / 1000); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };

/** What a group's history says happened; with names, and without guessing anyone's gender in Russian. */
function sysWords(b) {
  if (!b) return '';
  const who = `<b translate="no">${esc(b.who || '')}</b>`, whom = `<b translate="no">${esc(b.whom || '')}</b>`, t = `<span translate="no">${L('“', '«')}${esc(b.title || '')}${L('”', '»')}</span>`;
  switch (b.what) {
    case 'created': return L(`${who} made the group ${t}`, `Группа ${t} создана · ${who}`);
    case 'joined': return L(`${who} joined${b.link ? ' by the link' : ''}`, `Новый участник: ${who}${b.link ? ' (по ссылке)' : ''}`);
    case 'left': return L(`${who} left`, `Выход из группы: ${who}`);
    case 'removed': return L(`${who} removed ${whom}`, `Исключение из группы: ${whom} · ${who}`);
    case 'title': return L(`${who} renamed the group ${t}`, `Новое название: ${t} · ${who}`);
    case 'avatar': return L(`${who} changed the group's picture`, `Новая картинка группы · ${who}`);
    case 'pinned': return L(`${who} pinned a message`, `Закреплено сообщение · ${who}`);
    case 'admin': return L(`${who} made ${whom} an admin`, `Новый админ: ${whom} · ${who}`);
    case 'unadmin': return L(`${who} took admin from ${whom}`, `Больше не админ: ${whom} · ${who}`);
    default: return '';
  }
}
/** A message's words: escaped, its addresses made links, its lines kept. */
function frText(s) {
  return esc(s).replace(/\bhttps?:\/\/[^\s<>"]+/g, (u) => `<a href="${u}" target="_blank" rel="noopener noreferrer nofollow">${u}</a>`).replace(/\n/g, '<br>');
}
/** A message in one line (the list, a quote, a note). */
const frBrief = (m) => (!m ? '' : m.deleted ? L('Message removed', 'Сообщение удалено') : m.kind === 'picture' ? L('Picture', 'Картинка') : m.kind === 'voice' ? L('Voice message', 'Голосовое')
  : m.kind === 'system' ? sysWords(m.system || m.body).replace(/<[^>]+>/g, '') : (m.text !== undefined ? m.text : m.body) || '');

// ---- the left: conversations and invitations

function frRail(list, sub, open) {
  const reqs = ask('friends'), incoming = reqs.ok ? reqs.data.incoming.length : 0;
  const tabs = `<div class="fr-tabs"><a class="w ${sub !== 'people' && sub !== 'new' ? 'on' : ''}" href="#/friends">Chats</a><a class="w ${sub === 'people' ? 'on' : ''}" href="#/friends/people">Friends${incoming ? `<span class="nb num">${incoming}</span>` : ''}</a>
    <a class="w small ${sub === 'new' ? 'on' : ''}" href="#/friends/new" title="New group">+ ${L('Group', 'Группа')}</a></div>`;
  if (waiting(list)) return tabs + '<div class="fr-list ghost-rows"><div></div><div></div><div></div></div>';
  if (!list.ok) return tabs + trouble(list);
  const inv = list.data.invites.map((i) => `<div class="fr-inv">${groupAv(i, 40)}<span class="fr-l"><span>${L(`${esc(i.by.login)} invites you`, `${esc(i.by.login)} зовёт вас`)}</span><b translate="no">${esc(i.title)}</b><span class="ash num">${i.members} ${L('in it', plural(i.members, 'участник', 'участника', 'участников'))}</span></span>
      <span class="acts"><button class="w small lead" data-inv-join="${i.chat}">Join</button><button class="w small" data-inv-no="${i.chat}">Decline</button></span></div>`).join('');
  const rows = list.data.chats.map((c) => {
    const last = c.last, own = last && state.user && last.uid === state.user.uid;
    const line = last ? `${own ? L('You: ', 'Вы: ') : c.kind === 'group' && last.author && last.kind !== 'system' ? `<span translate="no">${esc(last.author)}:</span> ` : ''}<span translate="no">${esc(frBrief(last))}</span>` : `<span class="ash">${L('No messages yet', 'Пока без сообщений')}</span>`;
    return `<a class="fr-row ${c.id === open ? 'on' : ''} ${c.unread ? 'unread' : ''}" href="${frHref(c.id)}">${chatAv(c, 44)}
      <span class="fr-l"><span class="fr-top">${chatName(c)}${c.muted ? '<span class="muted" title="Muted">·</span>' : ''}<span class="t num">${last ? clock(last.created) : ''}</span></span>
      <span class="fr-last">${line}</span></span>${c.unread ? `<span class="pill num">${c.unread > 99 ? '99+' : c.unread}</span>` : ''}</a>`;
  }).join('');
  return tabs + (inv ? `<div class="fr-invs">${inv}</div>` : '') + `<div class="fr-list">${rows || `<p class="empty-s ash">${L('No conversations yet. Write to a friend from their profile or from Friends.', 'Пока нет переписок. Напишите другу — из его профиля или во вкладке «Друзья».')}</p>`}</div>`;
}

// ---- the page

function viewFriends(arg) {
  const [sub, x] = String(arg || '').split('/');
  const list = ask('chats');
  const open = sub === 'c' ? Number(x) : 0;
  let main;
  if (open) main = frChat(open, list);
  else if (sub === 'people') main = frPeople();
  else if (sub === 'new') main = frNew();
  else if (sub === 'join') main = frJoin(x);
  else main = `<div class="fr-empty"><span class="big-emo r-emp">${ic('chat')}</span><h1 class="big">Friends</h1><p class="ash">${L('Pick a conversation on the left, or start one with a friend.', 'Выберите переписку слева или начните новую с другом.')}</p>
      <div class="acts"><a class="w lead" href="#/friends/people">Friends</a><a class="w" href="#/friends/new">New group</a></div></div>`;
  if (!open) FR.chat = null;
  return `<h1 class="sr">Friends</h1><div class="fr ${open || sub ? 'deep' : ''} ${FR.panel && open ? 'with-panel' : ''}"><aside class="fr-rail">${frRail(list, sub, open)}</aside><section class="fr-main">${main}</section></div>`;
}

// ---- one conversation

function frLoad(id) {
  const ch = { id, messages: null, more: false, people: [], meta: null, draft: (FR.drafts && FR.drafts[id]) || '', reply: null, edit: null, stick: true, typing: {}, failed: false };
  FR.chat = ch;
  FR.panel = false;
  api(`chats/${id}`).then((r) => {
    if (FR.chat !== ch) return;
    if (!r.ok) { ch.failed = r.status || true; render(true); return; }
    ch.messages = r.data.messages; ch.more = r.data.more; ch.people = r.data.people; ch.meta = r.data.chat;
    frRead();
    render(true);
  });
}
/** What is open is read (while the page is in front). */
function frRead() {
  const ch = FR.chat;
  if (!ch || !ch.messages || !ch.messages.length || document.visibilityState !== 'visible') return;
  const top = ch.messages[ch.messages.length - 1].id;
  if (ch.meta && ch.meta.read_upto >= top) return;
  if (ch.meta) ch.meta.read_upto = top;
  api(`chats/${ch.id}/read`, { upto: top });
  const got_ = got.get('chats');
  if (got_ && got_.ok) { const c = got_.data.chats.find((x) => x.id === ch.id); if (c) c.unread = 0; }
}
document.addEventListener('visibilitychange', () => { if (state.route === 'friends') frRead(); });

function frChat(id, list) {
  if (!FR.chat || FR.chat.id !== id) frLoad(id);
  const ch = FR.chat;
  if (ch.failed) return `<div class="fr-empty"><h1 class="big">${ch.failed === 404 ? L('Not here', 'Не найдено') : L('Not loaded', 'Не загрузилось')}</h1><p class="ash">${ch.failed === 404 ? L('This conversation is gone, or you are not in it.', 'Этой переписки нет или вы в ней не состоите.') : SAY.busy}</p><a class="w" href="#/friends">Friends</a></div>`;
  const c = ch.meta || (list.ok && list.data.chats.find((x) => x.id === id));
  if (!c || !ch.messages) return '<div class="fr-chat"><div class="fr-head ghost-t">&nbsp;</div><div class="fr-msgs ghost-rows"><div></div><div></div><div></div></div></div>';
  const pres = c.other && c.other.presence;
  const sub = c.kind === 'dm' ? (pres && pres.online ? `${dot(pres.online)}<span>${pres.online === 'game' ? tr('In the game') : tr('On the site')}</span>${pres.listening ? `<span class="listening">${emo('c_play', 16)}<span translate="no">${esc(pres.listening.title)}</span></span>` : ''}` : (c.other && c.other.status ? statusOf(c.other.status) : ''))
    : `<span class="num">${c.members} ${L('members', plural(c.members, 'участник', 'участника', 'участников'))}</span>`;
  const headName = c.kind === 'dm' ? `<a href="${profHref(c.other.login)}" class="fr-hname">${chatName(c)}</a>` : `<button class="fr-hname" data-panel>${chatName(c)}</button>`;
  const pinned = c.pinned ? `<button class="fr-pin" data-jump-msg="${c.pinned.id}">${emo('c_wings', 18)}<span class="ash">${L('Pinned', 'Закреплено')}:</span><span translate="no">${esc(frBrief(c.pinned))}</span>${c.kind === 'dm' || c.role !== 'member' ? '<span class="x" data-unpin title="Unpin">×</span>' : ''}</button>` : '';
  const typing = Object.entries(ch.typing).filter(([, t]) => Date.now() - t.at < 5000).map(([, t]) => t.login);
  return `<div class="fr-chat">
    <div class="fr-head"><a class="w small fr-back" href="#/friends" aria-label="Back">‹</a>${chatAv(c, 40)}<span class="fr-l">${headName}<span class="fr-sub">${sub}</span></span>
      <span class="acts"><button class="w small" data-mute>${c.muted ? 'Unmute' : 'Mute'}</button>${c.kind === 'group' ? `<button class="w small ${FR.panel ? 'on' : ''}" data-panel>Members</button>` : ''}</span></div>
    ${pinned}
    <div class="fr-msgs" id="fr-msgs">${ch.more ? '<div class="fr-older"><button class="w small" id="fr-older">Older messages</button></div>' : ''}${frMsgs(ch, c)}</div>
    <div class="fr-typing" id="fr-typing">${typing.length ? `<span translate="no">${esc(typing.join(', '))}</span> ${L(typing.length > 1 ? 'are typing…' : 'is typing…', 'печатает…')}` : ''}</div>
    ${frComposer(ch, c)}
  </div>${FR.panel && c.kind === 'group' ? frPanel(ch, c) : ''}${FR.pic ? `<div class="lightbox" id="fr-lightbox"><img src="${esc(FR.pic)}" alt=""><button class="w small lb-close" id="fr-lb-close">Close</button></div>` : ''}`;
}

function frMsgs(ch, c) {
  let out = '', prev = null;
  const lastMine = [...ch.messages].reverse().find((m) => mine(m) && !m.deleted && m.kind !== 'system');
  for (const m of ch.messages) {
    if (!prev || dayOf(prev.created) !== dayOf(m.created)) out += `<div class="fr-day"><span>${dayWords(m.created)}</span></div>`;
    out += frMsg(m, prev, ch, c, lastMine && lastMine.id === m.id);
    prev = m;
  }
  return out || `<p class="empty-s ash">${L('Say hello.', 'Напишите первым.')}</p>`;
}

function frMsg(m, prev, ch, c, lastOwn) {
  if (m.kind === 'system') return `<div class="fr-sys" data-msg="${m.id}">${sysWords(m.body)}</div>`;
  const own = mine(m);
  const run = prev && prev.kind !== 'system' && prev.author && m.author && prev.author.uid === m.author.uid && m.created - prev.created < 300 && dayOf(prev.created) === dayOf(m.created) && !m.reply;
  const who = m.author || { login: '—' };
  let body;
  if (m.deleted) body = `<p class="fr-gone">${L('Message removed', 'Сообщение удалено')}</p>`;
  else if (m.kind === 'picture') body = `<button class="fr-picture" data-pic="${esc(m.media.gif || m.media.url)}"><img src="${esc(m.media.gif || m.media.thumb)}" alt="" loading="lazy" style="aspect-ratio:${m.media.w}/${m.media.h}"></button>`;
  else if (m.kind === 'voice') body = frVoice(m);
  else body = `<p class="fr-text" translate="no">${frText(m.body)}</p>`;
  const quote = m.reply ? `<button class="fr-quote" data-jump-msg="${m.reply.id}"><b translate="no">${esc(m.reply.author || '')}</b><span translate="no">${esc(frBrief(m.reply))}</span></button>` : '';
  const reacts = (m.reactions || []).map((r) => `<button class="fr-react ${state.user && r.uids.includes(state.user.uid) ? 'on' : ''}" data-react="${m.id}:${esc(r.emoji)}">${emo(r.emoji, 20)}<span class="num">${r.uids.length}</span></button>`).join('');
  const canPin = !m.deleted && (c.kind === 'dm' || c.role !== 'member');
  const canDel = !m.deleted && (own || (c.kind === 'group' && c.role !== 'member'));
  const tools = m.deleted ? '' : `<span class="fr-tools">
      <button data-reply="${m.id}" title="Reply">${L('Reply', 'Ответить')}</button><button data-react-open="${m.id}" title="React">${emo('c_heart', 16)}</button>
      ${own && m.kind === 'text' ? `<button data-edit="${m.id}">${L('Edit', 'Изменить')}</button>` : ''}${canPin ? `<button data-pin="${m.id}">${L('Pin', 'Закрепить')}</button>` : ''}
      ${canDel ? `<button data-del="${m.id}" class="${FR.del === m.id ? 'sure' : ''}">${FR.del === m.id ? L('Remove?', 'Удалить?') : L('Remove', 'Удалить')}</button>` : ''}${!own ? `<button data-report="${m.id}">${L('Report', 'Пожаловаться')}</button>` : ''}</span>`;
  const picker = FR.react === m.id ? `<div class="fr-picker">${(SOC.meta ? SOC.meta.emoji : []).map((e) => `<button data-react="${m.id}:${esc(e)}">${emo(e, 26)}</button>`).join('')}</div>` : '';
  const report = FR.report === m.id ? `<div class="fr-reporting"><input class="in" id="fr-report-why" maxlength="300" placeholder="What is wrong with it?" value="${esc(FR.reportWhy)}"><button class="w small lead" id="fr-report-go">Report</button><button class="w small" id="fr-report-no">Cancel</button></div>` : '';
  const read = lastOwn && c.kind === 'dm' && c.their_read >= m.id ? `<span class="fr-read">${L('Read', 'Прочитано')}</span>` : '';
  return `<div class="fr-msg ${own ? 'own' : ''} ${run ? 'run' : ''}" data-msg="${m.id}">
    ${run ? '<span class="fr-gap"></span>' : `<a class="fr-who" href="${profHref(who.login)}">${head(who.login, 36)}</a>`}
    <div class="fr-b">${run ? '' : `<div class="fr-name">${nm(who)}<span class="ash num">${clock(m.created)}</span></div>`}
      ${quote}${body}${m.edited && !m.deleted ? `<span class="fr-edited ash">${L('edited', 'изменено')}</span>` : ''}${reacts ? `<div class="fr-reacts">${reacts}</div>` : ''}${read}${picker}${report}</div>${tools}</div>`;
}

function frVoice(m) {
  const playing = FR.plays && FR.plays.id === m.id;
  return `<div class="fr-voice ${playing ? 'on' : ''}" data-voice="${m.id}"><button class="play" data-voice-play="${m.id}" data-src="${esc(m.media.url)}" aria-label="Play"><i></i></button>
    <span class="vbar"><i style="transform:scaleX(${playing ? FR.plays.at || 0 : 0})"></i></span><span class="num ash">${secs(m.media.ms)}</span></div>`;
}

function frComposer(ch, c) {
  if (c.kind === 'dm' && c.other && c.other.blocked) return '';
  const bar = ch.edit ? `<div class="fr-bar">${L('Editing', 'Правка')}<span class="ash" translate="no">${esc(ch.edit.body.slice(0, 80))}</span><button class="x" id="fr-bar-x" title="Cancel">×</button></div>`
    : ch.reply ? `<div class="fr-bar">${L('Reply to', 'Ответ')} <b translate="no">${esc(ch.reply.author || '')}</b><span class="ash" translate="no">${esc(frBrief(ch.reply))}</span><button class="x" id="fr-bar-x" title="Cancel">×</button></div>` : '';
  const rec = FR.rec && FR.rec.chat === ch.id;
  return `<div class="fr-compose ${rec ? 'rec' : ''}" id="fr-compose">${bar}
    <div class="fr-row-in">${rec ? `<span class="rec-dot"></span><span class="num" id="fr-rec-t">${secs(Date.now() - FR.rec.at)}</span><span class="ash">${L('Recording…', 'Запись…')}</span><span class="gap"></span><button class="w small" id="fr-rec-no">Cancel</button><button class="w small lead" id="fr-rec-go">Send</button>`
      : `<label class="fr-attach" title="Picture">${frIcon(ICON_PICTURE)}<input type="file" id="fr-file" accept="image/png,image/jpeg,image/webp,image/gif" hidden></label>
      <textarea class="in" id="fr-in" rows="1" maxlength="2000" placeholder="${c.kind === 'dm' ? L('Message', 'Сообщение') : L('Message the group', 'Сообщение группе')}">${esc(ch.draft)}</textarea>
      ${navigator.mediaDevices && window.MediaRecorder ? `<button class="fr-mic" id="fr-mic" title="Voice message">${frIcon(ICON_MIC)}</button>` : ''}<button class="w small lead" id="fr-send">Send</button>`}</div>
    <p class="hint" id="fr-msg" role="status"></p></div>`;
}

// ---- a group's members, invitations, link, name, picture

function frPanel(ch, c) {
  const manage = c.role !== 'member';
  const people = ch.people.map((p) => `<div class="fr-member">${head(p.login, 32)}<span class="fr-l">${nm(p)}<span class="ash">${p.role === 'owner' ? L('owner', 'владелец') : p.role === 'admin' ? L('admin', 'админ') : ''}</span></span>
      ${state.user && p.uid !== state.user.uid ? `<span class="acts">${c.role === 'owner' ? `<button class="w small" data-rank="${esc(p.login)}:${p.role === 'admin' ? 0 : 1}">${p.role === 'admin' ? L('Unadmin', 'Снять админа') : L('Admin', 'Сделать админом')}</button>` : ''}
        ${(c.role === 'owner' || (c.role === 'admin' && p.role === 'member')) ? `<button class="w small" data-kick="${esc(p.login)}">${L('Remove', 'Исключить')}</button>` : ''}</span>` : ''}</div>`).join('');
  const link = c.link ? `${location.origin}/#/friends/join/${c.link}` : '';
  return `<aside class="fr-panel"><h2 class="sec">Members <span class="ash num">${c.members}</span></h2>
    ${manage ? `<div class="fr-invite"><input class="in" id="fr-invite-in" placeholder="A friend's login"><button class="w small lead" id="fr-invite-go">Invite</button></div><p class="hint" id="fr-invite-msg" role="status"></p>` : ''}
    <div class="fr-members">${people}</div>
    ${manage ? `<h2 class="sec">Group</h2>
      <div class="fr-invite"><input class="in" id="fr-title-in" maxlength="40" value="${esc(c.title)}"><button class="w small" id="fr-title-go">Rename</button></div>
      <div class="acts"><label class="w small" for="fr-av-file">Picture</label><input type="file" id="fr-av-file" accept="image/png,image/jpeg,image/webp,image/gif" hidden></div>
      <p class="lab">Link</p>${link ? `<p class="mono fr-link" translate="no">${esc(link)}</p><div class="acts"><button class="w small" data-copy="${esc(link)}">Copy</button><button class="w small" id="fr-link-new">New link</button><button class="w small" id="fr-link-off">Turn off</button></div>`
        : '<div class="acts"><button class="w small" id="fr-link-new">Make a link</button></div>'}` : ''}
    <div class="acts fr-leave"><button class="w small bad" id="fr-leave">${FR.leaving ? L('Leave for good?', 'Точно выйти?') : L('Leave the group', 'Выйти из группы')}</button></div></aside>`;
}

// ---- friends and requests

function frPeople() {
  const c = ask('friends');
  if (waiting(c)) return `<div class="fr-people">${'<div class="ghost-rows"><div></div><div></div></div>'}</div>`;
  if (!c.ok) return trouble(c);
  const d = c.data;
  const person = (x, acts) => `<div class="fr-person">${head(x.person.login, 40)}<span class="fr-l">${nm(x.person, { status: true })}${x.presence && x.presence.online ? `<span class="fr-sub">${dot(x.presence.online)}<span>${x.presence.online === 'game' ? tr('In the game') : tr('On the site')}</span>${x.presence.listening ? `<span class="listening">${emo('c_play', 16)}<span translate="no">${esc(x.presence.listening.title)}</span></span>` : ''}${x.presence.server ? `<span class="ash" translate="no">· ${esc(x.presence.server)}</span>` : ''}</span>` : ''}</span><span class="acts">${acts}</span></div>`;
  const online = d.friends.filter((f) => f.presence && f.presence.online), away = d.friends.filter((f) => !(f.presence && f.presence.online));
  const fr = (f) => person(f, `<button class="w small lead" data-dm="${esc(f.person.login)}">Message</button><button class="w small ${FR.unfriend === f.person.login ? 'on' : ''}" data-remove-friend="${esc(f.person.login)}">${FR.unfriend === f.person.login ? L('Remove?', 'Удалить?') : L('Remove', 'Удалить')}</button>`);
  return `<div class="fr-people">
    <div class="block"><h2 class="sec">Add a friend</h2><div class="fr-invite"><input class="in" id="fr-add-in" placeholder="Their login on the site" value="${esc(FR.add)}"><button class="w small lead" id="fr-add-go">Send a request</button></div>
      <p class="hint ${FR.addBad ? 'bad' : 'ok'}" id="fr-add-msg" role="status">${esc(FR.addMsg)}</p></div>
    ${d.incoming.length ? `<div class="block"><h2 class="sec">Requests <span class="ash num">${d.incoming.length}</span></h2>${d.incoming.map((x) => person(x, `<button class="w small lead" data-accept="${esc(x.person.login)}">Accept</button><button class="w small" data-unfriend="${esc(x.person.login)}">Decline</button>`)).join('')}</div>` : ''}
    <div class="block"><h2 class="sec">Friends <span class="ash num">${d.friends.length}</span></h2>
      ${d.friends.length ? (online.length ? `<p class="lab">${L('Online', 'В сети')} · <span class="num">${online.length}</span></p>${online.map(fr).join('')}` : '') + (away.length ? `<p class="lab">${L('Away', 'Не в сети')} · <span class="num">${away.length}</span></p>${away.map(fr).join('')}` : '')
        : `<p class="ash">${L('No friends yet. Send a request by their login, or from their profile.', 'Друзей пока нет. Отправьте заявку по логину или из профиля.')}</p>`}</div>
    ${d.outgoing.length ? `<div class="block"><h2 class="sec">Sent <span class="ash num">${d.outgoing.length}</span></h2>${d.outgoing.map((x) => person(x, `<button class="w small" data-unfriend="${esc(x.person.login)}">Take back</button>`)).join('')}</div>` : ''}
    ${d.blocked.length ? `<div class="block"><h2 class="sec">Blocked <span class="ash num">${d.blocked.length}</span></h2>${d.blocked.map((x) => person(x, `<button class="w small" data-unblock="${esc(x.person.login)}">Unblock</button>`)).join('')}</div>` : ''}
  </div>`;
}

// ---- a new group, a group's link

function frNew() {
  const c = ask('friends');
  const ng = FR.ng || (FR.ng = { title: '', pick: [], msg: '' });
  const friends = c.ok ? c.data.friends : [];
  return `<div class="fr-people"><div class="block"><h2 class="sec">New group</h2>
    <div class="fr-invite"><input class="in" id="ng-title" maxlength="40" placeholder="Its name" value="${esc(ng.title)}"></div>
    <p class="lab">${L('Invite friends', 'Пригласить друзей')} <span class="ash num">${ng.pick.length} / 49</span></p>
    <div class="fr-picks">${friends.map((f) => `<button class="fr-pick ${ng.pick.includes(f.person.login) ? 'on' : ''}" data-ng-pick="${esc(f.person.login)}">${head(f.person.login, 32)}<span translate="no">${esc(f.person.login)}</span></button>`).join('') || `<p class="ash">${L('No friends to invite yet: a group can start with you alone and get a link.', 'Пока некого звать: группа может начаться с вас одного и получить ссылку.')}</p>`}</div>
    <div class="acts" style="margin-top:22px"><button class="w lead" id="ng-go">Make the group</button><a class="w" href="#/friends">Cancel</a></div><p class="hint bad" id="ng-msg" role="status">${esc(ng.msg)}</p></div></div>`;
}

function frJoin(code) {
  const c = ask('chats/link/' + encodeURIComponent(code || ''));
  if (waiting(c)) return '<div class="fr-empty ghost-t">&nbsp;</div>';
  if (!c.ok) return `<div class="fr-empty"><h1 class="big">${L('No such link', 'Ссылка не работает')}</h1><p class="ash">${L('It was turned off, or made anew.', 'Её выключили или заменили новой.')}</p><a class="w" href="#/friends">Friends</a></div>`;
  return `<div class="fr-empty">${groupAv(c.data, 96)}<h1 class="big" translate="no">${esc(c.data.title)}</h1><p class="ash num">${c.data.members} ${L('members', plural(c.data.members, 'участник', 'участника', 'участников'))}</p>
    <div class="acts">${c.data.in ? `<a class="w lead" href="${frHref(c.data.chat)}">Open</a>` : `<button class="w lead" data-link-join="${esc(code)}">Join</button>`}<a class="w" href="#/friends">Friends</a></div><p class="hint bad" id="join-msg" role="status"></p></div>`;
}

// ---- the live line's words for conversations and friends (core.js `heard` asks here first)

function frHeard(ev) {
  const ch = FR.chat, here = state.route === 'friends';
  switch (ev.t) {
    case 'friends': forget('friends'); if (here || state.route === 'u') render(true); return true;
    case 'chats': forget('chats'); if (here) render(true); return true;
    case 'config': case 'configs': case 'config_gone': case 'config_active':
      forget('configs'); if (state.route === 'dashboard' && state.arg.startsWith('configs')) render(true); return true;
    case 'presence': if (here) { forget('friends', 'chats'); render(true); } return false;
    case 'msg': {
      if (ev.unread !== undefined) frUnread(ev.unread);
      const open = ch && ch.id === ev.chat && ch.messages;
      if (open && !ch.messages.some((m) => m.id === ev.message.id)) {
        ch.messages.push(ev.message);
        if (ev.message.author) delete ch.typing[ev.message.author.uid];
        if (ch.meta) ch.meta.last = { ...ev.message, text: ev.message.body };
        frRead();
      }
      forget('chats');
      if (here) frRedraw(!open);
      if (ev.game && !(open && document.visibilityState === 'visible' && here)) {
        const m = ev.message;
        toast({ kind: 'message', actor: m.author, data: { chat: ev.chat, text: frBrief({ ...m, text: m.body }) }, id: 0 });
      }
      return true;
    }
    case 'msg_edit': case 'react': case 'msg_del': {
      if (ch && ch.id === ev.chat && ch.messages) {
        const m = ch.messages.find((x) => x.id === (ev.message ? ev.message.id : ev.id));
        if (m) {
          if (ev.t === 'msg_edit') Object.assign(m, ev.message);
          else if (ev.t === 'react') m.reactions = ev.reactions;
          else Object.assign(m, { deleted: true, body: null, media: null, reactions: [] });
        }
        if (here) frRedraw(false);
      }
      if (ev.t === 'msg_del') forget('chats');
      return true;
    }
    case 'read': {
      if (ev.unread !== undefined) frUnread(ev.unread);
      if (ch && ch.id === ev.chat && ch.meta && state.user && ev.uid !== state.user.uid) { ch.meta.their_read = Math.max(ch.meta.their_read || 0, ev.upto); if (here) frRedraw(false); }
      return true;
    }
    case 'typing': {
      if (ch && ch.id === ev.chat) { ch.typing[ev.uid] = { login: ev.login, at: Date.now() }; frTyping(); setTimeout(frTyping, 5200); }
      return true;
    }
    case 'chat': {
      if (ev.unread !== undefined) frUnread(ev.unread);
      if (ch && ch.id === ev.chat.id) ch.meta = ev.chat;
      forget('chats');
      if (here) render(true);
      return true;
    }
  }
  return false;
}

/** The open conversation drawn again where it changed: its messages (and the list), the composer left as it is. */
function frRedraw(listToo) {
  const ch = FR.chat, box = document.getElementById('fr-msgs');
  if (!box || !ch || !ch.messages) { render(true); return; }
  const c = ch.meta || {};
  const atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 80;
  morphInner(box, (ch.more ? '<div class="fr-older"><button class="w small" id="fr-older">Older messages</button></div>' : '') + frMsgs(ch, c), true);
  box.querySelectorAll('canvas[data-head]').forEach(drawHead);
  translate(box);
  frWireMsgs(box);
  if (atBottom || ch.stick) box.scrollTop = box.scrollHeight;
  if (listToo) {
    const rail = document.querySelector('.fr-rail');
    if (rail) { morphInner(rail, frRail(ask('chats'), 'c', ch.id), true); rail.querySelectorAll('canvas[data-head]').forEach(drawHead); translate(rail); frWireRail(rail); }
  }
}
function frTyping() {
  const ch = FR.chat, el = document.getElementById('fr-typing');
  if (!ch || !el) return;
  const t = Object.values(ch.typing).filter((x) => Date.now() - x.at < 5000).map((x) => x.login);
  el.innerHTML = t.length ? `<span translate="no">${esc(t.join(', '))}</span> ${L(t.length > 1 ? 'are typing…' : 'is typing…', 'печатает…')}` : '';
}

// ---- sending

async function frSend() {
  const ch = FR.chat, input = document.getElementById('fr-in');
  if (!ch || !input) return;
  const body = input.value.trim();
  if (!body) return;
  const msg = document.getElementById('fr-msg');
  let r;
  if (ch.edit) r = await api(`chats/${ch.id}/messages/${ch.edit.id}`, { body }, 'PATCH');
  else r = await api(`chats/${ch.id}/messages`, { body, reply_to: ch.reply ? ch.reply.id : null });
  if (!r.ok) { if (msg) { msg.textContent = frFault(r); msg.className = 'hint bad'; } return; }
  if (!ch.edit && r.data.message && !ch.messages.some((m) => m.id === r.data.message.id)) ch.messages.push(r.data.message);
  ch.draft = ''; ch.reply = null; ch.edit = null; ch.stick = true;
  if (FR.drafts) delete FR.drafts[ch.id];
  render(true);
  const i = document.getElementById('fr-in'); if (i) i.focus();
}
const frFault = (r) => (r.error === 'friends' ? L('They take messages from friends only.', 'Этот человек принимает сообщения только от друзей.') : r.error === 'closed' ? L('They take no messages.', 'Этот человек не принимает сообщения.')
  : r.error === 'blocked' ? L('One of you has blocked the other.', 'Один из вас заблокировал другого.') : r.error === 'slow' ? L('Too fast: wait a few seconds.', 'Слишком быстро: подождите пару секунд.') : tr(r.message || SAY[r.error] || SAY.busy));

/** A picture or a voice message sent as it is (the body is the file). */
async function frSendFile(path, blob, type) {
  const ch = FR.chat;
  if (!ch) return;
  const msg = document.getElementById('fr-msg');
  if (msg) { msg.textContent = L('Sending…', 'Отправка…'); msg.className = 'hint'; }
  let r = null, data = {};
  try {
    r = await fetch('/api/' + path, { method: 'POST', credentials: 'same-origin', cache: 'no-store', headers: { 'Content-Type': type || blob.type || 'application/octet-stream' }, body: blob });
    try { data = await r.json(); } catch (e) { /* not JSON */ }
  } catch (e) { r = null; }
  if (r && r.ok) {
    learnAv(data);
    if (data.message && !ch.messages.some((m) => m.id === data.message.id)) ch.messages.push(data.message);
    ch.reply = null; ch.stick = true;
    render(true);
  } else if (msg) { msg.textContent = r ? frFault({ error: data.error || (r.status === 429 ? 'slow' : 'busy'), message: data.message }) : SAY.offline; msg.className = 'hint bad'; }
}

/** A voice message: recorded with the browser's own recorder (Opus), three minutes at most, sent on "Send". */
async function frRecord() {
  const ch = FR.chat;
  if (!ch || FR.rec) return;
  let stream;
  try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); } catch (e) {
    const msg = document.getElementById('fr-msg'); if (msg) { msg.textContent = L('The browser gave no microphone.', 'Браузер не дал микрофон.'); msg.className = 'hint bad'; }
    return;
  }
  const type = ['audio/webm;codecs=opus', 'audio/ogg;codecs=opus', 'audio/webm'].find((t) => MediaRecorder.isTypeSupported(t)) || '';
  const rec = new MediaRecorder(stream, type ? { mimeType: type, audioBitsPerSecond: 32000 } : undefined);
  const parts = [];
  FR.rec = { chat: ch.id, at: Date.now(), rec, stream, send: false };
  rec.ondataavailable = (e) => { if (e.data.size) parts.push(e.data); };
  rec.onstop = () => {
    const r = FR.rec;
    FR.rec = null;
    stream.getTracks().forEach((t) => t.stop());
    clearInterval(r.timer);
    if (r.send) {
      const blob = new Blob(parts, { type: rec.mimeType || type });
      const ms = Date.now() - r.at;
      frSendFile(`chats/${r.chat}/voice?ms=${ms}`, blob, (rec.mimeType || type).split(';')[0]);
    } else render(true);
  };
  rec.start(250);
  FR.rec.timer = setInterval(() => {
    const t = document.getElementById('fr-rec-t'); if (t && FR.rec) t.textContent = secs(Date.now() - FR.rec.at);
    if (FR.rec && Date.now() - FR.rec.at > 179000) frRecStop(true);
  }, 250);
  render(true);
}
function frRecStop(send) { if (!FR.rec) return; FR.rec.send = send; FR.rec.rec.stop(); }

/** One voice message plays at a time. */
function frPlay(btn) {
  const id = Number(btn.dataset.voicePlay);
  if (FR.plays && FR.plays.id === id) { FR.plays.audio.pause(); FR.plays = null; frRedraw(false); return; }
  if (FR.plays) FR.plays.audio.pause();
  const audio = new Audio(btn.dataset.src);
  FR.plays = { id, audio, at: 0 };
  audio.play().catch(() => { FR.plays = null; frRedraw(false); });
  const tick = () => {
    if (!FR.plays || FR.plays.audio !== audio) return;
    if (audio.duration && isFinite(audio.duration)) FR.plays.at = audio.currentTime / audio.duration;
    const bar = document.querySelector(`[data-voice="${id}"] .vbar i`); if (bar) bar.style.transform = `scaleX(${FR.plays.at})`;
    requestAnimationFrame(tick);
  };
  audio.addEventListener('ended', () => { if (FR.plays && FR.plays.audio === audio) { FR.plays = null; frRedraw(false); } });
  tick();
  frRedraw(false);
}

// ---- what the screens do

function frWireMsgs(root) {
  const on = (sel, ev, fn) => root.querySelectorAll(sel).forEach((el) => bindOnce(el, ev, 'w3|' + sel, (e) => fn(el, e)));
  const ch = FR.chat;
  if (!ch) return;
  const find = (id) => ch.messages.find((m) => m.id === Number(id));
  on('#fr-older', 'click', async () => {
    const box = document.getElementById('fr-msgs'), from = box ? box.scrollHeight - box.scrollTop : 0;
    const r = await api(`chats/${ch.id}?before=${ch.messages[0].id}`);
    if (!r.ok) return;
    ch.messages = r.data.messages.concat(ch.messages); ch.more = r.data.more; ch.stick = false;
    frRedraw(false);
    const b = document.getElementById('fr-msgs'); if (b) b.scrollTop = b.scrollHeight - from;
  });
  on('[data-reply]', 'click', (b) => { const m = find(b.dataset.reply); ch.reply = { id: m.id, author: m.author && m.author.login, kind: m.kind, text: m.body }; ch.edit = null; render(true); const i = document.getElementById('fr-in'); if (i) i.focus(); });
  on('[data-edit]', 'click', (b) => { const m = find(b.dataset.edit); ch.edit = { id: m.id, body: m.body }; ch.reply = null; ch.draft = m.body; render(true); const i = document.getElementById('fr-in'); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } });
  on('[data-react-open]', 'click', (b) => { const id = Number(b.dataset.reactOpen); FR.react = FR.react === id ? 0 : id; frRedraw(false); });
  on('[data-react]', 'click', (b) => { const [id, e] = b.dataset.react.split(':'); FR.react = 0; api(`chats/${ch.id}/messages/${id}/react`, { emoji: e }); });
  on('[data-pin]', 'click', (b) => api(`chats/${ch.id}/pin`, { message: Number(b.dataset.pin) }));
  on('[data-del]', 'click', async (b) => {
    const id = Number(b.dataset.del);
    if (FR.del !== id) { FR.del = id; frRedraw(false); setTimeout(() => { if (FR.del === id) { FR.del = 0; frRedraw(false); } }, 4000); return; }
    FR.del = 0;
    await api(`chats/${ch.id}/messages/${id}`, null, 'DELETE');
  });
  on('[data-report]', 'click', (b) => { FR.report = Number(b.dataset.report); FR.reportWhy = ''; frRedraw(false); const i = document.getElementById('fr-report-why'); if (i) i.focus(); });
  on('#fr-report-why', 'input', (i) => { FR.reportWhy = i.value; });
  on('#fr-report-no', 'click', () => { FR.report = 0; frRedraw(false); });
  on('#fr-report-go', 'click', async () => {
    const r = await api(`chats/${ch.id}/messages/${FR.report}/report`, { why: FR.reportWhy });
    FR.report = 0; frRedraw(false);
    const msg = document.getElementById('fr-msg'); if (msg) { msg.textContent = r.ok ? L('Sent to Cursed’s staff. They see only this message and the ten before it.', 'Отправлено персоналу Cursed. Он видит только это сообщение и десять перед ним.') : frFault(r); msg.className = 'hint ' + (r.ok ? 'ok' : 'bad'); }
  });
  on('[data-pic]', 'click', (b) => { FR.pic = b.dataset.pic; render(true); });
  on('[data-voice-play]', 'click', (b) => frPlay(b));
  on('[data-jump-msg]', 'click', (b, e) => {
    if (e.target.closest('[data-unpin]')) return;
    const el = document.querySelector(`.fr-msg[data-msg="${b.dataset.jumpMsg}"]`);
    if (el) { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); el.classList.add('lit'); setTimeout(() => el.classList.remove('lit'), 1600); }
  });
}
function frWireRail(root) {
  const on = (sel, ev, fn) => root.querySelectorAll(sel).forEach((el) => bindOnce(el, ev, 'w4|' + sel, (e) => fn(el, e)));
  on('[data-inv-join]', 'click', async (b) => { const r = await api(`chats/${b.dataset.invJoin}/join`, {}); forget('chats'); if (r.ok) location.hash = frHref(r.data.chat.id); else render(true); });
  on('[data-inv-no]', 'click', async (b) => { await api(`chats/${b.dataset.invNo}/invites/me`, null, 'DELETE'); forget('chats'); render(true); });
}

function friendsWire() {
  if (state.route !== 'friends' && state.route !== 'u') return;
  const on = (sel, ev, fn) => $app.querySelectorAll(sel).forEach((el) => bindOnce(el, ev, 'w5|' + sel, (e) => fn(el, e)));
  // Anywhere: write to someone, befriend, accept, part, block.
  on('[data-dm]', 'click', async (b) => {
    const r = await api('chats/dm', { login: b.dataset.dm });
    if (r.ok) { forget('chats'); location.hash = frHref(r.data.chat.id); return; }
    const msg = document.getElementById('fr-add-msg') || document.getElementById('rel-msg'); if (msg) { msg.textContent = frFault(r); msg.className = 'hint bad'; }
  });
  on('[data-befriend]', 'click', async (b) => { const r = await api('friends', { login: b.dataset.befriend }); const msg = document.getElementById('rel-msg'); if (!r.ok && msg) { msg.textContent = frFault(r); msg.className = 'hint bad'; } forget('friends', 'u/'); render(true); });
  on('[data-accept]', 'click', async (b) => { await api(`friends/${encodeURIComponent(b.dataset.accept)}/accept`, {}); forget('friends', 'u/'); render(true); });
  // A request declined or taken back at once; a friendship ends on a second press (the first asks "Remove?").
  on('[data-unfriend]', 'click', async (b) => { await api(`friends/${encodeURIComponent(b.dataset.unfriend)}`, null, 'DELETE'); forget('friends', 'u/'); render(true); });
  on('[data-remove-friend]', 'click', async (b) => {
    const login = b.dataset.removeFriend;
    if (FR.unfriend !== login) { FR.unfriend = login; render(true); setTimeout(() => { if (FR.unfriend === login) { FR.unfriend = ''; render(true); } }, 4000); return; }
    FR.unfriend = '';
    await api(`friends/${encodeURIComponent(login)}`, null, 'DELETE'); forget('friends', 'u/', 'chats'); render(true);
  });
  on('[data-block]', 'click', async (b) => { const r = await api('blocks', { login: b.dataset.block }); const msg = document.getElementById('rel-msg'); if (!r.ok && msg) { msg.textContent = frFault(r); msg.className = 'hint bad'; return; } forget('friends', 'u/', 'chats'); render(true); });
  on('[data-unblock]', 'click', async (b) => { await api(`blocks/${encodeURIComponent(b.dataset.unblock)}`, null, 'DELETE'); forget('friends', 'u/'); render(true); });
  if (state.route !== 'friends') return;
  const ch = FR.chat;
  frWireRail($app);
  // Friends: a request by login.
  on('#fr-add-in', 'input', (i) => { FR.add = i.value; });
  on('#fr-add-in', 'keydown', (i, e) => { if (e.key === 'Enter') document.getElementById('fr-add-go').click(); });
  on('#fr-add-go', 'click', async () => {
    const login = FR.add.trim();
    if (!login) return;
    const r = await api('friends', { login });
    FR.addBad = !r.ok;
    FR.addMsg = r.ok ? (r.data.state === 'friends' ? L('You are friends now.', 'Теперь вы друзья.') : L('Request sent.', 'Заявка отправлена.')) : r.status === 404 ? L('No member with that login.', 'Нет участника с таким логином.') : r.error === 'self' ? L('That is you.', 'Это вы.') : frFault(r);
    if (r.ok) FR.add = '';
    forget('friends'); render(true);
  });
  // A new group.
  const ng = FR.ng;
  if (ng) {
    on('#ng-title', 'input', (i) => { ng.title = i.value; });
    on('[data-ng-pick]', 'click', (b) => { const l = b.dataset.ngPick, i = ng.pick.indexOf(l); if (i >= 0) ng.pick.splice(i, 1); else if (ng.pick.length < 49) ng.pick.push(l); render(true); });
    on('#ng-go', 'click', async () => {
      const r = await api('chats/groups', { title: ng.title, invite: ng.pick });
      if (r.ok) { FR.ng = null; forget('chats'); location.hash = frHref(r.data.chat.id); } else { ng.msg = frFault(r); render(true); }
    });
  }
  on('[data-link-join]', 'click', async (b) => {
    const r = await api('chats/link/' + encodeURIComponent(b.dataset.linkJoin), {});
    if (r.ok) { forget('chats'); location.hash = frHref(r.data.chat.id); } else { const m = document.getElementById('join-msg'); if (m) m.textContent = frFault(r); }
  });
  if (!ch) return;
  frWireMsgs($app);
  // The messages stay at the bottom while they are read there; scrolled up, they stay where they are.
  const box = document.getElementById('fr-msgs');
  if (box) {
    if (ch.stick) box.scrollTop = box.scrollHeight; else if (ch.scroll !== undefined) box.scrollTop = ch.scroll;
    bindOnce(box, 'scroll', 'fr', () => { ch.scroll = box.scrollTop; ch.stick = box.scrollHeight - box.scrollTop - box.clientHeight < 80; });
    bindOnce(box, 'dragover', 'fr', (e) => { e.preventDefault(); box.classList.add('over'); });
    bindOnce(box, 'dragleave', 'fr', () => box.classList.remove('over'));
    bindOnce(box, 'drop', 'fr', (e) => { e.preventDefault(); box.classList.remove('over'); const f = [...e.dataTransfer.files].find((x) => x.type.startsWith('image/')); if (f) frSendFile(`chats/${ch.id}/pictures${ch.reply ? '?reply_to=' + ch.reply.id : ''}`, f); });
  }
  on('#fr-in', 'input', (t) => {
    ch.draft = t.value; (FR.drafts || (FR.drafts = {}))[ch.id] = t.value;
    t.style.height = 'auto'; t.style.height = Math.min(180, t.scrollHeight) + 'px';
    if (t.value && Date.now() - FR.typingAt > 3000) { FR.typingAt = Date.now(); api(`chats/${ch.id}/typing`, {}); }
  });
  on('#fr-in', 'keydown', (t, e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); frSend(); }
    if (e.key === 'Escape' && (ch.reply || ch.edit)) { ch.reply = null; if (ch.edit) ch.draft = ''; ch.edit = null; render(true); }
    if (e.key === 'ArrowUp' && !t.value) { const m = [...ch.messages].reverse().find((x) => mine(x) && x.kind === 'text' && !x.deleted); if (m) { e.preventDefault(); ch.edit = { id: m.id, body: m.body }; ch.draft = m.body; render(true); } }
  });
  on('#fr-in', 'paste', (t, e) => {
    const f = [...(e.clipboardData ? e.clipboardData.files : [])].find((x) => x.type.startsWith('image/'));
    if (f) { e.preventDefault(); frSendFile(`chats/${ch.id}/pictures${ch.reply ? '?reply_to=' + ch.reply.id : ''}`, f); }
  });
  const inp = document.getElementById('fr-in'); if (inp && inp.value) { inp.style.height = 'auto'; inp.style.height = Math.min(180, inp.scrollHeight) + 'px'; }
  on('#fr-send', 'click', frSend);
  on('#fr-bar-x', 'click', () => { ch.reply = null; if (ch.edit) ch.draft = ''; ch.edit = null; render(true); });
  on('#fr-file', 'change', (i) => { if (i.files[0]) frSendFile(`chats/${ch.id}/pictures${ch.reply ? '?reply_to=' + ch.reply.id : ''}`, i.files[0]); });
  on('#fr-mic', 'click', frRecord);
  on('#fr-rec-go', 'click', () => frRecStop(true));
  on('#fr-rec-no', 'click', () => frRecStop(false));
  on('#fr-lb-close', 'click', () => { FR.pic = null; render(true); });
  on('#fr-lightbox', 'click', (el, e) => { if (e.target === el) { FR.pic = null; render(true); } });
  on('[data-unpin]', 'click', (el, e) => { e.stopPropagation(); api(`chats/${ch.id}/pin`, { message: null }); });
  on('[data-mute]', 'click', () => api(`chats/${ch.id}`, { muted: !(ch.meta && ch.meta.muted) }, 'PATCH'));
  on('[data-panel]', 'click', () => { FR.panel = !FR.panel; FR.leaving = false; render(true); });
  // A group's panel.
  on('#fr-invite-go', 'click', async () => {
    const i = document.getElementById('fr-invite-in'), r = await api(`chats/${ch.id}/invites`, { login: i.value.trim() });
    const m = document.getElementById('fr-invite-msg');
    if (m) { m.textContent = r.ok ? L('Invited.', 'Приглашение отправлено.') : r.status === 404 ? L('No member with that login.', 'Нет участника с таким логином.') : r.error === 'member' ? L('Already in the group.', 'Уже в группе.') : r.error === 'friends' ? L('Only friends can be invited.', 'Пригласить можно только друзей.') : frFault(r); m.className = 'hint ' + (r.ok ? 'ok' : 'bad'); }
    if (r.ok) i.value = '';
  });
  on('#fr-title-go', 'click', () => api(`chats/${ch.id}`, { title: document.getElementById('fr-title-in').value }, 'PATCH'));
  on('#fr-av-file', 'change', (i) => { if (i.files[0]) fetch(`/api/chats/${ch.id}/avatar`, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': i.files[0].type }, body: i.files[0] }); });
  on('#fr-link-new', 'click', () => api(`chats/${ch.id}/link`, { on: true }));
  on('#fr-link-off', 'click', () => api(`chats/${ch.id}/link`, { on: false }));
  on('[data-rank]', 'click', (b) => { const [login, admin] = b.dataset.rank.split(':'); api(`chats/${ch.id}/members/${encodeURIComponent(login)}/role`, { admin: admin === '1' }).then(() => frLoad(ch.id)); });
  on('[data-kick]', 'click', (b) => api(`chats/${ch.id}/members/${encodeURIComponent(b.dataset.kick)}`, null, 'DELETE').then(() => frLoad(ch.id)));
  on('#fr-leave', 'click', async () => {
    if (!FR.leaving) { FR.leaving = true; render(true); return; }
    FR.leaving = false;
    await api(`chats/${ch.id}/members/me`, null, 'DELETE');
    FR.chat = null; FR.panel = false; forget('chats'); location.hash = '#/friends';
  });
}

/** The friends' part of a profile: befriend, accept, write, block. */
function relationActs(p) {
  const r = p.relation, who = p.person.login;
  if (!r || !state.user) return '';
  const canWrite = !r.blocked && !r.blocks_me && (p.dm === 'all' || (p.dm !== 'none' && r.friends) || (state.user.perms || []).length);
  const friend = r.friends ? `<button class="w small" data-remove-friend="${esc(who)}">${FR.unfriend === who ? L('Remove?', 'Удалить?') : L('Remove friend', 'Удалить из друзей')}</button>`
    : r.asks ? `<button class="w lead" data-accept="${esc(who)}">Accept request</button>` : r.asked ? `<button class="w small" data-unfriend="${esc(who)}">${L('Take back the request', 'Отозвать заявку')}</button>`
    : r.blocked || r.blocks_me ? '' : `<button class="w lead" data-befriend="${esc(who)}">Add friend</button>`;
  return `${canWrite ? `<button class="w ${r.friends ? 'lead' : ''}" data-dm="${esc(who)}">Message</button>` : ''}${friend}
    ${r.blocked ? `<button class="w small" data-unblock="${esc(who)}">Unblock</button>` : p.person.staff ? '' : `<button class="w small bad" data-block="${esc(who)}">Block</button>`}<span class="hint" id="rel-msg" role="status"></span>`;
}

// ================================================================================================ configs (03.10.2026)
// The dashboard's Configs: the member's configs of the cloud (the client runs by the active one and sends its changes)
// and those shared with them; which one is in use, codes with a number of activations, who uses them, taken back;
// a code someone gave, typed in. The settings themselves are the client's: they are changed in the game.

const CFG = { open: 0, msg: '', bad: false, limit: 10, code: '', sure: '' };

function dashConfigs() {
  const c = ask('configs');
  if (waiting(c)) return `<h1 class="sr">Configs</h1><div class="sections">${ghosts(1)}</div>`;
  if (!c.ok) return trouble(c);
  const d = c.data, all = d.mine.concat(d.shared);
  if (!CFG.open || !all.some((x) => x.id === CFG.open)) CFG.open = d.active || (all[0] && all[0].id) || 0;
  const row = (x) => `<button class="cfg-row ${x.id === CFG.open ? 'on' : ''} ${x.active ? 'active' : ''}" data-cfg="${x.id}"><b translate="no">${esc(x.name)}</b>
      <span class="ash">${x.own ? ago(x.updated) + (x.access ? L(` · ${x.access} using`, ` · пользуются: ${x.access}`) : '') : L('from ', 'от ') + esc(x.owner.login)}</span>${x.active ? `<span class="cfg-in">${L('In use', 'Включён')}</span>` : ''}</button>`;
  const x = all.find((y) => y.id === CFG.open);
  let detail = `<p class="ash">${L('Your settings live in the cloud: the same on every computer you play on. A new config is made in the game, of the settings as they are.', 'Ваши настройки живут в облаке: одни и те же на любом компьютере. Новый конфиг делается в игре — из текущих настроек.')}</p>`;
  if (x) {
    const acc = x.own && x.access ? ask(`configs/${x.id}/access`) : null;
    detail = `<div class="cfg-head"><h2 class="big" translate="no">${esc(x.name)}</h2>${x.active ? `<span class="cfg-in">${L('In use', 'Включён')}</span>` : `<button class="w lead" data-cfg-use="${x.id}">${L('Run by it', 'Включить')}</button>`}</div>
      <p class="ash">${x.own ? '' : L('From ', 'От ') + `<b translate="no">${esc(x.owner.login)}</b> · `}${L('changed', 'изменён')} ${ago(x.updated)} · ${mb(x.bytes)}</p>
      ${x.own ? `<div class="block"><h2 class="sec">Name</h2><div class="fr-invite"><input class="in" id="cfg-name" maxlength="40" value="${esc(x.name)}"><button class="w small" id="cfg-rename">Rename</button></div></div>
      <div class="block"><h2 class="sec">${L('Share', 'Поделиться')}</h2>
        <p class="hint">${L('A code runs it for whoever types it in, as many times as you allow; you take it back whenever you like.', 'По коду конфиг включается у того, кто его введёт, — столько раз, сколько разрешите; забрать доступ можно в любой момент.')}</p>
        <div class="fr-invite"><label class="lab">${L('Activations', 'Активаций')}</label><input class="in num" id="cfg-limit" type="number" min="1" max="10000" value="${CFG.limit}" style="max-width:120px"><button class="w small lead" id="cfg-code">${L('Make a code', 'Создать код')}</button></div>
        ${x.codes.length ? `<div class="cfg-codes">${x.codes.map((k) => `<div class="cfg-code"><b class="mono cream" translate="no">${esc(k.code)}</b><span class="ash num">${k.uses} / ${k.max_uses}</span><span class="acts"><button class="w small" data-copy="${esc(k.code)}">Copy</button><button class="w small" data-cfg-revoke="${esc(k.code)}">${L('Take back', 'Забрать')}</button></span></div>`).join('')}</div>` : ''}
      </div>
      ${acc ? `<div class="block"><h2 class="sec">${L('Using it', 'Пользуются')} <span class="ash num">${x.access}</span></h2>${waiting(acc) ? '' : acc.ok ? acc.data.people.map((p) => `<div class="fr-person">${head(p.person.login, 32)}<span class="fr-l">${nm(p.person)}<span class="ash">${esc(p.code)} · ${p.active ? L('runs by it now', 'включён сейчас') : L('has it', 'есть доступ')}</span></span><span class="acts"><button class="w small" data-cfg-kick="${esc(p.person.login)}">${L('Take back', 'Забрать')}</button></span></div>`).join('') : trouble(acc)}</div>` : ''}`
        : `<p class="hint">${L('Someone else’s config: you run by it, its owner changes it.', 'Чужой конфиг: вы играете с ним, а меняет его владелец.')}</p>`}
      <div class="acts" style="margin-top:26px"><button class="w small bad" data-cfg-delete="${x.id}">${CFG.sure === String(x.id) ? L('Sure?', 'Точно?') : x.own ? L('Delete the config', 'Удалить конфиг') : L('Remove it from mine', 'Убрать у себя')}</button></div>`;
  }
  return `<h1 class="sr">Configs</h1><div class="sections cfg">
    <div class="cfg-side">
      <div class="block"><h2 class="sec">${L('A code', 'Код')}</h2><div class="fr-invite"><input class="in mono" id="cfg-redeem-in" maxlength="12" placeholder="XXXX-XXXX" value="${esc(CFG.code)}" translate="no"><button class="w small lead" id="cfg-redeem">${L('Take', 'Взять')}</button></div></div>
      <div class="block"><h2 class="sec">${L('Mine', 'Мои')} <span class="ash num">${d.mine.length} / ${d.most}</span></h2>${d.mine.map(row).join('') || `<p class="ash">${L('None yet: the game makes the first one of your settings.', 'Пока нет: первый сделает игра — из ваших настроек.')}</p>`}</div>
      ${d.shared.length ? `<div class="block"><h2 class="sec">${L('Shared with me', 'Поделились со мной')}</h2>${d.shared.map(row).join('')}</div>` : ''}
    </div>
    <div class="cfg-main">${detail}<p class="hint ${CFG.bad ? 'bad' : 'ok'}" id="cfg-msg" role="status">${esc(CFG.msg)}</p></div>
  </div>`;
}

function configsWire() {
  if (state.route !== 'dashboard') return;
  const on = (sel, ev, fn) => $app.querySelectorAll(sel).forEach((el) => bindOnce(el, ev, 'w6|' + sel, (e) => fn(el, e)));
  const said = (r, ok) => { CFG.bad = !r.ok; CFG.msg = r.ok ? ok : r.error === 'used' ? L('This code has no activations left.', 'У этого кода закончились активации.') : r.error === 'revoked' ? L('This code was taken back.', 'Этот код отозван.')
    : r.error === 'own' ? L('This config is yours.', 'Это ваш конфиг.') : r.error === 'code' || r.status === 404 ? L('No such code.', 'Такого кода нет.') : r.error === 'last' ? L('The last config of yours stays.', 'Последний ваш конфиг остаётся.') : tr(r.message || SAY[r.error] || SAY.busy); forget('configs'); render(true); };
  on('[data-cfg]', 'click', (b) => { CFG.open = Number(b.dataset.cfg); CFG.sure = ''; CFG.msg = ''; render(true); });
  on('[data-cfg-use]', 'click', async (b) => said(await api(`configs/${b.dataset.cfgUse}/active`, {}), L('In use: the game takes it at once.', 'Включён: игра подхватит сразу.')));
  on('#cfg-rename', 'click', async () => said(await api(`configs/${CFG.open}`, { name: document.getElementById('cfg-name').value }, 'PATCH'), L('Renamed.', 'Переименовано.')));
  on('#cfg-limit', 'input', (i) => { CFG.limit = Number(i.value) || 1; });
  on('#cfg-code', 'click', async () => said(await api(`configs/${CFG.open}/codes`, { max_uses: CFG.limit }), L('A code made: give it to whom you like.', 'Код создан: отдайте его кому хотите.')));
  on('[data-cfg-revoke]', 'click', async (b) => said(await api(`configs/${CFG.open}/codes/${encodeURIComponent(b.dataset.cfgRevoke)}`, null, 'DELETE'), L('Taken back.', 'Доступ забран.')));
  on('[data-cfg-kick]', 'click', async (b) => { const r = await api(`configs/${CFG.open}/access/${encodeURIComponent(b.dataset.cfgKick)}`, null, 'DELETE'); forget(`configs/${CFG.open}/access`); said(r, L('Taken back.', 'Доступ забран.')); });
  on('[data-cfg-delete]', 'click', async (b) => {
    if (CFG.sure !== b.dataset.cfgDelete) { CFG.sure = b.dataset.cfgDelete; render(true); return; }
    CFG.sure = '';
    const r = await api(`configs/${b.dataset.cfgDelete}`, null, 'DELETE');
    if (r.ok) CFG.open = 0;
    said(r, L('Deleted.', 'Удалено.'));
  });
  on('#cfg-redeem-in', 'input', (i) => { CFG.code = i.value; });
  on('#cfg-redeem', 'click', async () => {
    const r = await api('configs/redeem', { code: CFG.code });
    if (r.ok) { CFG.code = ''; CFG.open = r.data.config.id; }
    said(r, L('The config is yours to run by: the game takes it at once.', 'Конфиг ваш и уже включён: игра подхватит сразу.'));
  });
}

// ================================================================================================ the forum (03.10.2026)
// The forum's second floor (site/server/src/forum2.rs): bugs with their status (and "fixed in build N"), ideas voted
// for, questions with the answer marked; posts with formatting, pictures pasted or dropped in, YouTube cards, the
// pack's emoji as reactions, the history of edits; threads followed; @logins offered while they are typed; drafts kept
// in this browser; staff warn and mute. These screens replace the first forum's (build.py keeps of it only what the
// market's reports share).

const FO = { filter: {}, sort: {}, react: 0, hist: 0, history: null, staff: '', staffWhy: '', staffMin: 60, preview: {}, mention: null, uploaded: {}, uploading: 0, pic: null, edit: 0, editText: '', msg: '', bad: false, drafts: {} };
try { FO.drafts = JSON.parse(localStorage.getItem('cursed.forum.drafts') || '{}') || {}; } catch (e) { FO.drafts = {}; }
let foKeep = 0;
/** A draft of this browser's: read (no value), or kept (an empty one forgotten). */
function foDraft(key, value) {
  if (value === undefined) return FO.drafts[key] || '';
  if (value) FO.drafts[key] = value; else delete FO.drafts[key];
  clearTimeout(foKeep);
  foKeep = setTimeout(() => { try { localStorage.setItem('cursed.forum.drafts', JSON.stringify(FO.drafts)); } catch (e) { /* not kept */ } }, 300);
  return value;
}

// ---- statuses

const BUG_ST = { new: ['New', 'Новый'], confirmed: ['Confirmed', 'Подтверждён'], fixed: ['Fixed', 'Исправлен'], wontfix: ['Won’t be fixed', 'Не будет исправлен'], duplicate: ['Duplicate', 'Дубликат'] };
const IDEA_ST = { open: ['Open', 'Открыта'], planned: ['Planned', 'В планах'], doing: ['In the works', 'В работе'], done: ['Done', 'Сделано'], declined: ['Declined', 'Отклонена'] };
const stOf = (cat) => (cat === 'bugs' ? BUG_ST : cat === 'ideas' ? IDEA_ST : {});
const stTone = (s) => ({ confirmed: 'cream', planned: 'cream', doing: 'cream', fixed: 'ok', done: 'ok', solved: 'ok', wontfix: 'warn', declined: 'warn' })[s] || 'dim';
function stChip(t) {
  if (!t.status || t.status === 'open') return '';
  let s = stOf(t.category)[t.status] ? L(...stOf(t.category)[t.status]) : t.status === 'solved' ? L('Solved', 'Решено') : '';
  if (t.category === 'bugs' && t.status === 'fixed') s = t.fixed_in ? L(`Fixed in build ${t.fixed_in}`, `Исправлен в сборке ${t.fixed_in}`) : L('Fixed: comes with the next build', 'Исправлен: войдёт в следующую сборку');
  return s ? `<span class="st ${stTone(t.status)}">${s}</span>` : '';
}
const votesWord = (n) => L(`${n} ${n === 1 ? 'vote' : 'votes'}`, `${n} ${plural(n, 'голос', 'голоса', 'голосов')}`);

// ---- a post, drawn

const YT_ID = /(?:youtube\.com\/(?:watch\?(?:[^\s&]*&(?:amp;)?)*v=|shorts\/|embed\/)|youtu\.be\/)([A-Za-z0-9_-]{11})(?![A-Za-z0-9_-])/g;
/** A post as its author typed it, drawn: paragraphs, quotes, **bold**, *italic*, ||spoilers||, `code` and ``` blocks,
 *  links, @logins, pictures on lines of their own, YouTube cards under it. Escaped first: nothing typed becomes HTML. */
function prose(text, post) {
  const pics = Object.assign({}, FO.uploaded, (post && post.pictures) || {});
  const kept = [];
  const keep = (html) => `\u0001${kept.push(html) - 1}\u0002`;
  const inline = (s) => {
    s = s.replace(/`([^`\n]+)`/g, (m, c) => keep(`<code>${c}</code>`));
    s = s.replace(/\bhttps?:\/\/[^\s<\u0001\u0002]+[^\s<.,;:!?)\]'"\u0001\u0002]/g, (u) => keep(`<a href="${u}" target="_blank" rel="noopener nofollow ugc">${u}</a>`));
    s = s.replace(/(^|[\s(])@([A-Za-z0-9_]{3,16})\b/g, (m, pre, who) => `${pre}${keep(`<a class="at" href="${profHref(who)}">@${who}</a>`)}`);
    s = s.replace(/\|\|(.+?)\|\|/g, (m, x) => `<span class="spoiler" tabindex="0" role="button" aria-label="${L('Spoiler', 'Спойлер')}">${x}</span>`);
    s = s.replace(/\*\*(?!\s)(.+?)\*\*/g, '<b>$1</b>');
    s = s.replace(/(^|[^*\w])\*(?![\s*])(.+?)\*(?!\w)/g, '$1<i>$2</i>');
    return s;
  };
  const out = [];
  esc(text).split(/```(?:[a-z0-9+-]*\n)?([\s\S]*?)```/).forEach((part, i) => {
    if (i % 2) { out.push(`<pre><code>${part.replace(/\n$/, '')}</code></pre>`); return; }
    for (const block of part.split(/\n{2,}/)) {
      let para = [], quote = [];
      const flushP = () => { if (para.length) out.push(`<p>${para.join('<br>')}</p>`); para = []; };
      const flushQ = () => { if (quote.length) out.push(`<blockquote>${quote.join('<br>')}</blockquote>`); quote = []; };
      for (const l of block.split('\n')) {
        const pic = l.trim().match(/^\[img:([0-9a-f]{16})\]$/);
        if (pic) {
          flushP(); flushQ();
          const p = pics[pic[1]];
          out.push(p ? `<button class="fo-pic" data-fo-pic="${esc(p.url)}" aria-label="${L('Open the picture', 'Открыть картинку')}"><img src="${esc(p.url)}"${p.thumb ? ` srcset="${esc(p.thumb)} 480w, ${esc(p.url)} ${p.w}w" sizes="(max-width: 700px) 90vw, 620px"` : ''} alt="" loading="lazy" style="aspect-ratio:${p.w}/${p.h}"></button>` : `<p class="ash fo-pic-gone">${L('A picture', 'Картинка')}</p>`);
        } else if (l.startsWith('&gt;')) { flushP(); quote.push(inline(l.replace(/^&gt; ?/, ''))); } else { flushQ(); para.push(inline(l)); }
      }
      flushP(); flushQ();
    }
  });
  let html = out.join('');
  for (let k = 0; k < 3 && /\u0001\d+\u0002/.test(html); k++) html = html.replace(/\u0001(\d+)\u0002/g, (m, n) => kept[n]);
  const cards = post && post.cards ? [...new Set([...String(text).matchAll(YT_ID)].map((m) => m[1]))].filter((v) => post.cards[v]) : [];
  return html + cards.map((v) => { const c = post.cards[v]; return `<a class="fo-card" href="https://www.youtube.com/watch?v=${v}" target="_blank" rel="noopener nofollow">${c.thumb ? `<img src="${esc(c.thumb)}" alt="" loading="lazy">` : ''}<span><b>${esc(c.title)}</b><span class="ash">${esc(c.author)}${c.author ? ' · ' : ''}YouTube</span></span></a>`; }).join('');
}

// ---- the editor: a box with its tools, the @ list, the preview

const QUOTE_ICON = '<path d="M5 7h5v5c0 2.8-1.6 4.6-4.5 5.5M14 7h5v5c0 2.8-1.6 4.6-4.5 5.5"/>';
const SPOILER_ICON = '<path d="M2.5 12s3.5-6.5 9.5-6.5S21.5 12 21.5 12s-3.5 6.5-9.5 6.5S2.5 12 2.5 12Z"/><path d="m4 4 16 16"/>';
function editor(id, value, rows, placeholder) {
  const tool = (act, label, inner) => `<button type="button" class="fo-tool" data-fo-tool="${act}" data-for="${id}" title="${label}" aria-label="${label}">${inner}</button>`;
  const on = FO.preview[id];
  return `<div class="fo-editor ${on ? 'previewing' : ''}" data-editor="${id}">
    <div class="fo-tools">${tool('bold', L('Bold', 'Жирный'), '<b>B</b>')}${tool('italic', L('Italic', 'Курсив'), '<i>I</i>')}${tool('spoiler', L('Spoiler', 'Спойлер'), frIcon(SPOILER_ICON))}${tool('code', L('Code', 'Код'), '<span class="mono">&lt;/&gt;</span>')}${tool('quote', L('Quote', 'Цитата'), frIcon(QUOTE_ICON))}${tool('picture', L('A picture', 'Картинка'), frIcon(ICON_PICTURE))}
      <span class="gap"></span><button type="button" class="fo-tool fo-prev" data-fo-preview="${id}">${on ? L('Write', 'Писать') : L('Preview', 'Как будет')}</button></div>
    <textarea class="in" id="${id}" rows="${rows}" maxlength="10000" placeholder="${esc(placeholder || L('**Bold**, *italic*, ||spoiler||, `code`, > quote, @login. Paste or drop a picture.', '**Жирный**, *курсив*, ||спойлер||, `код`, > цитата, @логин. Картинку можно вставить или перетащить.'))}">${esc(value)}</textarea>
    ${on ? `<div class="fo-preview prose post-body" translate="no">${prose(value) || `<p class="ash">${L('Nothing yet.', 'Пока пусто.')}</p>`}</div>` : ''}
    <div class="fo-mention" role="listbox" hidden></div><p class="hint fo-up" role="status"></p>
  </div>`;
}

// ---- the list of threads

function topicRow(t, cats, rowStyle) {
  const c = catOf(cats, t.category);
  const marks = `${stChip(t)}${t.category === 'ideas' ? `<span class="st cream">${votesWord(t.votes || 0)}</span>` : ''}${t.pinned ? '<span class="st cream">Pinned</span>' : ''}${t.locked ? '<span class="st warn">Closed</span>' : ''}${t.state === 'hidden' ? '<span class="st cream">Hidden</span>' : ''}`;
  const last = t.last && t.last.by && t.replies > 0 ? `<span class="last-by">${head(t.last.by.login, 18)}<span class="u-link" data-u="${esc(t.last.by.login)}" translate="no">${esc(t.last.by.login)}</span></span>` : '';
  return `<a class="topic ${t.unread ? 'unread' : ''}" href="#/forum/t/${t.id}"${rowStyle || ''}>${head(t.author.login, 40)}<span><b translate="no">${esc(t.title)}</b>
      <span class="in-cat">${sq(c.colour)}<span>${esc(c.name)}</span> · ${pfx(t.author)}<span class="u-link" data-u="${esc(t.author.login)}" translate="no"${t.author.accent ? ` style="color:${esc(t.author.accent)}"` : ''}>${esc(t.author.login)}</span>${marks}</span></span>
      <span class="n num"><b>${t.replies}</b><span class="when">${last}${ago(t.last.at)}</span></span></a>`;
}
function forumTabs(active) {
  const tab = (id, name, to) => `<a class="w ${active === id ? 'on' : ''}" href="#/forum${to}">${name}</a>`;
  return `<div class="tabs" style="padding-bottom:26px">${tab('index', 'Categories', '')}${tab('latest', 'Latest', '/latest')}
    <span class="right forum-tools"><label class="sr" for="fq">Search the forum</label><input class="in" id="fq" type="search" placeholder="Search the forum" value="${esc(state.fq)}"><a class="w lead" href="#/forum/new${state.fcat ? '/' + state.fcat : ''}">New thread</a></span></div>`;
}
const FILTERS = {
  bugs: [['', 'All', 'Все'], ...Object.entries(BUG_ST).map(([k, v]) => [k, ...v])],
  ideas: [['', 'All', 'Все'], ...Object.entries(IDEA_ST).map(([k, v]) => [k, ...v])],
  help: [['', 'All', 'Все'], ['unsolved', 'Waiting for an answer', 'Ждут ответа'], ['solved', 'Solved', 'Решённые']],
};
const SORTS = [['top', 'Most votes', 'Больше голосов'], ['new', 'Newest', 'Новые'], ['', 'Active', 'Активные']];

function viewForum(arg) {
  const [part, x, y] = String(arg || '').split('/');
  if (part === 't') return viewThread(Number(x), Number(y) || 0);
  if (part === 'new') return viewNewThread(x || '');
  state.fcat = part === 'c' ? x : '';
  const front = ask('forum');
  const cats = front.ok ? front.data.categories : [];
  const el = f3Enter('forum/' + String(arg || ''));
  const list = (c, none) => (waiting(c) ? '<div class="rows"><div>&nbsp;</div></div>' : !c.ok ? trouble(c) : c.data.items.length ? c.data.items.map((t, i) => topicRow(t, cats, f3Row(i, el))).join('') : `<div class="empty">${none}</div>`);
  if (state.fqLive) {
    const c = ask('forum/threads?q=' + encodeURIComponent(state.fqLive));
    return `<h1 class="sr">Forum</h1>${forumTabs('search')}<div class="forum-one">${list(c, 'Nothing found.')}</div>`;
  }
  if (part === 'c' || part === 'latest') {
    const page = Number(part === 'c' ? y : x) || 1;
    const status = part === 'c' ? FO.filter[x] || '' : '', sort = part === 'c' && x === 'ideas' ? (FO.sort.ideas === undefined ? 'top' : FO.sort.ideas) : '';
    const c = ask(`forum/threads?${part === 'c' ? 'cat=' + encodeURIComponent(x) + '&' : ''}page=${page}${status ? '&status=' + status : ''}${sort ? '&sort=' + sort : ''}`);
    const cat = part === 'c' ? catOf(cats, x) : null;
    const pages = c.ok ? Math.ceil(c.data.total / c.data.per_page) : 1;
    const base = part === 'c' ? `#/forum/c/${x}/` : '#/forum/latest/';
    const filters = cat && FILTERS[x] ? `<div class="acts fo-filter">${FILTERS[x].map(([k, en, ru]) => `<button class="w small ${status === k ? 'on' : ''}" data-fo-filter="${x}:${k}">${L(en, ru)}</button>`).join('')}
        ${x === 'ideas' ? `<span class="gap"></span>${SORTS.map(([k, en, ru]) => `<button class="w small ${sort === k ? 'on' : ''}" data-fo-sort="${k}">${L(en, ru)}</button>`).join('')}` : ''}</div>` : '';
    return `<h1 class="sr">${cat ? esc(cat.name) : 'Latest'}</h1>${forumTabs(part === 'c' ? 'cat' : 'latest')}
      ${cat ? `<div class="forum-head"><h2 class="big">${sq(cat.colour)}${esc(cat.name)}</h2><p class="ash">${esc(cat.about || '')}</p>${filters}</div>` : ''}
      <div class="forum-one${f3Cls(el)}">${list(c, status ? L('Nothing with this status.', 'С таким статусом ничего нет.') : 'No threads yet.')}
      ${pages > 1 ? `<div class="acts pager">${page > 1 ? `<a class="w" href="${base}${page - 1}">Back</a>` : ''}<span class="ash num">${page} of ${pages}</span>${page < pages ? `<a class="w" href="${base}${page + 1}">More</a>` : ''}</div>` : ''}</div>`;
  }
  if (waiting(front)) return `<h1 class="sr">Forum</h1>${forumTabs('index')}<div class="forum"><div class="rows"><div>&nbsp;</div></div><div></div></div>`;
  if (!front.ok) return trouble(front);
  const f = front.data;
  const threads = f.categories.reduce((n, c) => n + (c.threads || 0), 0), posts = f.categories.reduce((n, c) => n + (c.posts || 0), 0);
  const lastOf = (id) => f.latest.find((t) => t.category === id);
  const fact = (n, en, ru1, ru2, ru5) => `<span><b class="num">${fmt(n)}</b>${L(en, plural(n, ru1, ru2, ru5))}</span>`;
  return `<h1 class="sr">Forum</h1>${forumTabs('index')}
    <div class="f3-facts${f3Cls(el)}">${fact(threads, threads === 1 ? 'thread' : 'threads', 'тема', 'темы', 'тем')}${fact(posts, posts === 1 ? 'post' : 'posts', 'сообщение', 'сообщения', 'сообщений')}${fact(f.online.length, 'online now', 'сейчас онлайн', 'сейчас онлайн', 'сейчас онлайн')}
      <span class="heads" translate="no">${f.online.slice(0, 24).map((o) => `<a href="${profHref(o.login)}" data-u="${esc(o.login)}">${head(o.login, 28)}</a>`).join('')}${f.online.length > 24 ? `<span class="more num">+${f.online.length - 24}</span>` : ''}</span></div>
    <div class="forum${f3Cls(el)}">
      <div><div class="colhead"><span>Category</span><span>Threads</span></div>
        ${f.categories.map((c, i) => {
          const t = lastOf(c.id);
          return `<a class="cat" href="#/forum/c/${c.id}"${f3Row(i, el)}><h3>${sq(c.colour)}${esc(c.name)}</h3><p>${esc(c.about)}</p>${t ? `<span class="cat-last">${head(t.author.login, 18)}<b translate="no">${esc(t.title)}</b></span>` : ''}<span class="n num"><b>${c.threads}</b>${c.last_at ? ago(c.last_at) : '—'}</span></a>`;
        }).join('')}</div>
      <div><div class="colhead"><span>Latest</span><span>Replies</span></div>
        ${f.latest.length ? f.latest.map((t, i) => topicRow(t, f.categories, f3Row(i + 3, el))).join('') : '<div class="empty" style="padding:40px 0">Nothing yet. Start the first thread.</div>'}</div>
    </div>`;
}

// ---- a thread

/** The thread on screen, as last answered. */
function foThread() {
  const id = Number(String(state.arg).split('/')[1]);
  const [, t] = [...got.entries()].find(([k, v]) => (k === `forum/threads/${id}` || k.startsWith(`forum/threads/${id}?`)) && v.ok) || [];
  return t ? t.data : null;
}

function foPost(t, p, n, mod, mineThread) {
  const me_ = state.user && state.user.uid;
  const editing = FO.edit === p.id, first = n === 1, answer = t.solution === p.id;
  const reporting = state.freport && state.freport.kind === 'post' && state.freport.id === p.id, hiding = state.fhide === 'post:' + p.id;
  let body;
  if (p.state === 'deleted') body = '<p class="ash">Taken back by its author.</p>';
  else if (p.state === 'hidden' && !p.body) body = '<p class="ash">Hidden by moderation.</p>';
  else if (editing) body = `<div class="form post-form">${editor('fo-edit', FO.editText, 6)}<div class="acts"><button class="w small lead" data-fo-save="${p.id}" data-submit-for="fo-edit">Save</button><button class="w small" data-fo-cancel="1">Cancel</button></div></div>`;
  else body = `${p.state === 'hidden' ? `<p class="st cream">Hidden by moderation${p.hidden_why ? ': ' + esc(p.hidden_why) : ''}</p>` : ''}<div class="prose post-body" translate="no">${prose(p.body, p)}</div>`;
  const reacts = (p.reactions || []).map((r) => `<button class="fr-react ${r.uids.includes(me_) ? 'on' : ''}" data-fo-react="${p.id}:${esc(r.emoji)}">${emo(r.emoji, 20)}<span class="num">${r.uids.length}</span></button>`).join('');
  const picker = FO.react === p.id ? `<div class="fr-picker">${(SOC.meta ? SOC.meta.emoji : []).map((e) => `<button data-fo-react="${p.id}:${esc(e)}">${emo(e, 26)}</button>`).join('')}</div>` : '';
  const canAnswer = t.category === 'help' && !first && (mineThread || mod) && p.state === 'shown';
  const acts = p.state === 'shown' && !editing ? [
    !t.locked || mod ? `<button class="w small" data-fo-quote="${p.id}">Reply</button>` : '',
    `<button class="w small fo-react-open" data-fo-react-open="${p.id}" title="${L('React', 'Реакция')}" aria-label="${L('React', 'Реакция')}">${emo('c_heart', 16)}</button>`,
    canAnswer ? `<button class="w small" data-fo-answer="${answer ? 0 : p.id}">${answer ? L('Not the answer', 'Это не ответ') : L('This is the answer', 'Это ответ')}</button>` : '',
    p.mine ? `<button class="w small" data-fo-edit="${p.id}">Edit</button><button class="w small" data-fdel="${p.id}">Delete</button>` : `<button class="w small" data-freport="post:${p.id}">Report</button>`,
    mod && !p.mine ? `<button class="w small" data-fhide="post:${p.id}">Hide</button><button class="w small" data-fo-staff="warn:${p.id}">${L('Warn', 'Предупредить')}</button><button class="w small" data-fo-staff="mute:${p.id}">${L('Mute', 'Мут')}</button>` : '',
  ].join('') : mod && p.state === 'hidden' ? `<button class="w small" data-funhide="post:${p.id}">Unhide</button>` : '';
  let inline = reporting ? inlineAsk('f-report-why', 'What is wrong with it?', 'Report it', 'post:' + p.id, 'freport-go') : hiding ? inlineAsk('f-hide-why', 'Why (its author sees this)', 'Hide it', 'post:' + p.id, 'fhide-go') : '';
  const [staffKind, staffPost] = FO.staff.split(':');
  if (Number(staffPost) === p.id) {
    inline = `<div class="form hide-form fo-staff"><input class="in" id="fo-staff-why" maxlength="300" placeholder="${staffKind === 'warn' ? L('What for (they see this)', 'За что (человек это увидит)') : L('Why (they see this)', 'Почему (человек это увидит)')}" value="${esc(FO.staffWhy)}">
      ${staffKind === 'mute' ? `<select class="in small-select" id="fo-staff-min" aria-label="${L('For how long', 'На сколько')}">${[[60, '1 hour', '1 час'], [360, '6 hours', '6 часов'], [1440, '1 day', '1 день'], [4320, '3 days', '3 дня'], [10080, '7 days', '7 дней'], [43200, '30 days', '30 дней']].map(([m, en, ru]) => `<option value="${m}" ${FO.staffMin === m ? 'selected' : ''}>${L(en, ru)}</option>`).join('')}</select>` : ''}
      <div class="acts"><button class="w small lead" data-fo-staff-go="${esc(p.author.login)}">${staffKind === 'warn' ? L('Warn', 'Предупредить') : L('Mute on the forum', 'Замутить на форуме')}</button><button class="w small" data-fo-staff-no="1">Cancel</button></div></div>`;
  }
  const edited = p.edited ? (p.mine || mod) && p.edits ? `<button class="fo-edited" data-fo-hist="${p.id}" title="${esc(new Date(p.edited * 1000).toLocaleString())}">${L('edited', 'изменено')}</button>` : `<span title="${esc(new Date(p.edited * 1000).toLocaleString())}">${L('edited', 'изменено')}</span>` : '';
  const hist = FO.hist === p.id ? `<div class="fo-hist">${!FO.history ? `<p class="ash">${L('Loading…', 'Загрузка…')}</p>` : FO.history.map((v) => `<div class="fo-ver"><span class="ash">${L('Before', 'До')} · ${esc(new Date(v.at * 1000).toLocaleString())}</span><div class="prose post-body" translate="no">${prose(v.body, p)}</div></div>`).join('') || `<p class="ash">${L('No earlier versions.', 'Других версий нет.')}</p>`}</div>` : '';
  return `<div class="review post ${p.new ? 'new' : ''} ${answer ? 'answer' : ''}" id="p${p.id}"${FO.rowStyle ? FO.rowStyle(n) : ''}>${head(p.author.login, 48)}<div>
      <div class="top">${nm(p.author, { status: true })}<span>${ago(p.created)}</span>${edited}${answer ? `<span class="st ok">${L('The answer', 'Ответ')}</span>` : ''}<a class="num" href="#/forum/t/${t.id}/${t.page}" data-jump="p${p.id}">#${n}</a></div>
      ${body}${reacts ? `<div class="fr-reacts">${reacts}</div>` : ''}${picker}<div class="acts post-acts">${acts}</div>${inline}${hist}</div></div>`;
}

function viewThread(id, page) {
  const c = ask(`forum/threads/${id}${page ? '?page=' + page : ''}`);
  const front = ask('forum'), cats = front.ok ? front.data.categories : [];
  if (waiting(c)) return `<div class="thread"><div class="crumb"><a href="#/forum">Forum</a></div><h1 class="big ghost-t">&nbsp;</h1></div>`;
  if (!c.ok) return `<div class="page-head"><h1 class="giant">Not found</h1><p class="ash">This thread is gone, hidden, or never was.</p><div><a class="w" href="#/forum">The forum</a></div></div>`;
  const t = c.data, cat = catOf(cats, t.category), mod = t.moderator, mineThread = state.user && t.author.uid === state.user.uid;
  const el = f3Enter('thread/' + t.id + '/' + t.page);
  FO.rowStyle = (n) => f3Row(n - (t.page - 1) * 30 - 1, el);
  const posts = t.posts.map((p, i) => foPost(t, p, (t.page - 1) * 30 + i + 1, mod, mineThread)).join('');
  FO.rowStyle = null;
  // Who took part (on this page), most posts first; the thread's author leads.
  const took = new Map();
  for (const p of t.posts) if (p.author && p.state !== 'deleted') { const k = p.author.login; const v = took.get(k) || { who: p.author, n: 0 }; v.n++; took.set(k, v); }
  const people = [...took.values()].sort((a, b) => (b.who.login === t.author.login) - (a.who.login === t.author.login) || b.n - a.n);
  const more = ask(`forum/threads?cat=${encodeURIComponent(t.category)}&page=1`);
  const others = more.ok ? more.data.items.filter((x) => x.id !== t.id).slice(0, 5) : [];
  const lastPost = t.posts.length ? t.posts[t.posts.length - 1].id : 0;
  const toLast = t.page < t.pages ? `#/forum/t/${t.id}/${t.pages}` : '';
  const side = `<aside class="th-side${f3Cls(el)}">
      <div class="side-block"><h3 class="side-h">${L('Started by', 'Автор темы')}</h3>
        <a class="side-author" href="${profHref(t.author.login)}" data-u="${esc(t.author.login)}">${head(t.author.login, 56)}<span>${pfx(t.author)}<b translate="no"${t.author.accent ? ` style="color:${esc(t.author.accent)}"` : ''}>${esc(t.author.login)}</b><span class="ash num">${ago(t.created)}</span></span></a></div>
      <div class="side-block side-facts"><div><b class="num">${t.replies}</b><span>${L(t.replies === 1 ? 'reply' : 'replies', plural(t.replies, 'ответ', 'ответа', 'ответов'))}</span></div>
        ${t.category === 'ideas' ? `<div><b class="num">${t.votes}</b><span>${L(t.votes === 1 ? 'vote' : 'votes', plural(t.votes, 'голос', 'голоса', 'голосов'))}</span></div>` : ''}
        <div><b class="num">${took.size}</b><span>${L(took.size === 1 ? 'member here' : 'members here', plural(took.size, 'участник', 'участника', 'участников'))}</span></div></div>
      ${people.length ? `<div class="side-block"><h3 class="side-h">${L('Took part', 'Участвуют')}</h3><div class="side-people">${people.slice(0, 12).map((v) => `<a href="${profHref(v.who.login)}" data-u="${esc(v.who.login)}" title="${esc(v.who.login)}">${head(v.who.login, 36)}<span class="num">${v.n}</span></a>`).join('')}</div></div>` : ''}
      ${others.length ? `<div class="side-block"><h3 class="side-h">${L('More in', 'Ещё в разделе')} <span>${esc(cat.name)}</span></h3>${others.map((x) => `<a class="side-topic" href="#/forum/t/${x.id}">${head(x.author.login, 22)}<span><b translate="no">${esc(x.title)}</b><span class="ash num">${x.replies} · ${ago(x.last.at)}</span></span></a>`).join('')}</div>` : ''}
    </aside>`;
  const pager = t.pages > 1 ? `<div class="acts pager">${t.page > 1 ? `<a class="w" href="#/forum/t/${t.id}/${t.page - 1}">Back</a>` : ''}<span class="ash num">${t.page} of ${t.pages}</span>${t.page < t.pages ? `<a class="w" href="#/forum/t/${t.id}/${t.page + 1}">More</a>` : ''}</div>` : '';
  const hidingThread = state.fhide === 'thread:' + t.id, reportingThread = state.freport && state.freport.kind === 'thread' && state.freport.id === t.id;
  const states = stOf(t.category);
  const own = [
    t.category === 'ideas' ? `<button class="w small ${t.voted ? 'on' : 'lead'}" data-fo-vote="1">${t.voted ? L('Voted', 'Голос отдан') : L('Vote for it', 'Голосовать')} · <span class="num">${t.votes}</span></button>` : '',
    `<button class="w small ${t.following ? 'on' : ''}" data-fo-follow="${t.following ? 0 : 1}" title="${t.following ? L('You hear of every reply. Click to stop.', 'Вы узнаёте о каждом ответе. Нажмите, чтобы отписаться.') : L('Hear of every reply', 'Узнавать о каждом ответе')}">${t.following ? L('Following', 'Вы подписаны') : L('Follow', 'Подписаться')}</button>`,
    mineThread || mod ? `<button class="w small" data-frename="1">Rename</button>` : '',
    !mineThread && !mod ? `<button class="w small" data-freport="thread:${t.id}">Report</button>` : '',
  ].join('');
  const staff = mod ? `${Object.keys(states).length ? `<label class="sr" for="fo-status">${L('Status', 'Статус')}</label><select class="in small-select" id="fo-status">${Object.entries(states).map(([k, v]) => `<option value="${k}" ${k === t.status ? 'selected' : ''}>${L(...v)}</option>`).join('')}</select>` : ''}
      <button class="w small" data-fpin="${t.pinned ? 0 : 1}">${t.pinned ? 'Unpin' : 'Pin'}</button><button class="w small" data-flock="${t.locked ? 0 : 1}">${t.locked ? 'Open' : 'Close'}</button>
      <label class="sr" for="f-move">Move to</label><select class="in small-select" id="f-move">${cats.map((x) => `<option value="${x.id}" ${x.id === t.category ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select>
      ${t.state === 'hidden' ? '<button class="w small" data-funhide="thread:' + t.id + '">Unhide</button>' : `<button class="w small" data-fhide="thread:${t.id}">Hide</button>`}` : '';
  const replyKey = 't:' + t.id;
  const chips = `${stChip(t)}${t.pinned ? '<span class="st cream">Pinned</span>' : ''}${t.locked ? '<span class="st warn">Closed</span>' : ''}${t.state === 'hidden' ? `<span class="st cream">Hidden by moderation${t.hidden_why ? ': ' + esc(t.hidden_why) : ''}</span>` : ''}`;
  return `<div class="thread-wrap"><div class="thread${f3Cls(el)}">
      <div class="crumb"><a href="#/forum">Forum</a> / <a href="#/forum/c/${cat.id}">${esc(cat.name)}</a></div>
      ${state.frename ? `<div class="form" style="max-width:760px"><input class="in" id="f-title" maxlength="120" value="${esc(state.frenametext)}"><div class="acts"><button class="w small lead" data-frename-go="1">Save</button><button class="w small" data-frename-no="1">Cancel</button></div></div>`
        : `<h1 class="big" translate="no">${esc(t.title)}</h1>`}
      <div class="by">${chips ? `<span>${chips}</span>` : ''}
        <span class="ash">${L('Started by', 'Автор —')} ${nm(t.author)} · ${ago(t.created)} · <span class="num">${t.replies}</span> ${L(t.replies === 1 ? 'reply' : 'replies', plural(t.replies, 'ответ', 'ответа', 'ответов'))}</span>
        ${t.replies > 2 ? `<a class="w small to-last" href="${toLast || '#/forum/t/' + t.id + '/' + t.page}" ${toLast ? '' : ` data-jump="p${lastPost}"`}>${L('To the last reply', 'К последнему ответу')}</a>` : ''}</div>
      <div class="acts thread-tools">${own}</div>
      ${staff ? `<div class="acts thread-tools fo-staff-tools"><span class="ash">${L('Staff', 'Персонал')}</span>${staff}</div>` : ''}
      ${hidingThread ? inlineAsk('f-hide-why', 'Why (its author sees this)', 'Hide it', 'thread:' + t.id, 'fhide-go') : ''}
      ${reportingThread ? inlineAsk('f-report-why', 'What is wrong with it?', 'Report it', 'thread:' + t.id, 'freport-go') : ''}
      ${state.fmsg && !state.freport ? `<p class="hint ${FO.bad ? 'bad' : 'ok'}">${esc(state.fmsg)}</p>` : ''}
      ${pager}<div class="posts">${posts}</div>${pager}
      ${t.locked && !mod ? '<p class="st warn" style="margin-top:28px">This thread is closed.</p>'
        : `<div class="form reply-box"><label class="lab" for="fo-reply">Your reply</label>${editor('fo-reply', foDraft(replyKey), 5)}
          <div class="acts"><button class="w menu lead" data-fo-post="${t.id}" data-submit-for="fo-reply">Post</button></div><p class="hint ${FO.bad ? 'bad' : ''}" id="f-msg" role="status">${esc(FO.msg)}</p></div>`}
      ${FO.pic ? `<div class="lightbox" id="fo-lightbox"><img src="${esc(FO.pic)}" alt=""><button class="w small lb-close" id="fo-lb-close">Close</button></div>` : ''}
    </div>${side}</div>`;
}

function viewNewThread(cat) {
  const front = ask('forum');
  const cats = front.ok ? front.data.categories.filter((c) => !c.closed || (state.user && (state.user.admin || (state.user.perms || []).includes('announce')))) : [];
  let category = foDraft('n:cat') || cat;
  if (cat && cat !== category) category = foDraft('n:cat', cat);
  if (!cats.some((c) => c.id === category) && cats[0]) category = cats.find((c) => c.id === 'help') ? 'help' : cats[0].id;
  const about = { bugs: L('What happens, what you expected, how to make it happen again. A screenshot helps. You hear when it is fixed.', 'Что происходит, чего вы ждали, как это повторить. Скриншот помогает. Когда исправят — придёт уведомление.'), ideas: L('One idea per thread: others vote for it.', 'Одна идея — одна тема: за неё голосуют.'), help: L('Ask: whoever answers best gets the answer marked.', 'Спрашивайте: лучший ответ можно отметить.') }[category] || '';
  return `<div class="thread"><div class="crumb"><a href="#/forum">Forum</a> / New thread</div><h1 class="big">New thread</h1>
    <div class="form" style="max-width:760px;margin-top:28px">
      <div><label class="lab" for="n-cat">Category</label><select class="in" id="n-cat" data-fo-n="cat">${cats.map((c) => `<option value="${c.id}" ${c.id === category ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select>${about ? `<p class="hint">${about}</p>` : ''}</div>
      <div><label class="lab" for="n-title">Title</label><input class="in" id="n-title" data-fo-n="title" maxlength="120" value="${esc(foDraft('n:title'))}"></div>
      <div><label class="lab" for="n-body">Text</label>${editor('n-body', foDraft('n:body'), 9)}</div>
      <div class="acts"><button class="w menu lead" id="fo-start" data-cat="${esc(category)}" data-submit-for="n-body">Post</button><a class="w menu" href="#/forum">Cancel</a></div>
      <p class="hint bad" id="n-msg" role="status">${esc(FO.msg)}</p></div></div>`;
}

// ---- what the forum says when it refuses

function foFault(r) {
  if (r.error === 'muted' && r.until) {
    const until = new Date(r.until * 1000).toLocaleString(LANG === 'ru' ? 'ru-RU' : 'en-GB', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' });
    const why = String(r.message || '').replace(/^.*?: /, '');
    return L(`You can’t post on the forum until ${until}: ${why}`, `Писать на форуме нельзя до ${until}: ${why}`);
  }
  if (r.error === 'slow') return L('Too fast: a post every 8 seconds, a thread every 30.', 'Слишком быстро: пост раз в 8 секунд, тема раз в 30.');
  if (r.error === 'locked') return L('This thread is closed.', 'Тема закрыта.');
  if (r.error === 'pictures') return L('Ten pictures in a post at most.', 'Не больше десяти картинок в посте.');
  if (r.error === 'quota') return L('Your uploads take all of your 300 MB: remove some in your profile first.', 'Ваши загрузки заняли все 300 МБ: сначала удалите что-нибудь в профиле.');
  return tr(r.message || SAY[r.error] || SAY.busy);
}

// ---- the editor at work

/** Text put into a box at its caret (or around what is selected), kept as its draft, the box left as it was. */
function foInsert(box, before, after, wholeLines) {
  if (!box) return;
  const a = box.selectionStart, b = box.selectionEnd, v = box.value;
  let sel = v.slice(a, b), start = a, end = b;
  if (wholeLines) {
    start = v.lastIndexOf('\n', a - 1) + 1;
    end = b === a ? (v.indexOf('\n', b) < 0 ? v.length : v.indexOf('\n', b)) : b;
    sel = v.slice(start, end);
    const quoted = sel.split('\n').map((l) => '> ' + l).join('\n');
    box.value = v.slice(0, start) + quoted + v.slice(end);
    box.setSelectionRange(start, start + quoted.length);
  } else {
    box.value = v.slice(0, start) + before + sel + after + v.slice(end);
    box.setSelectionRange(start + before.length, start + before.length + sel.length);
  }
  box.focus();
  box.dispatchEvent(new Event('input', { bubbles: true }));
}

/** A picture uploaded for a post: its token put in at the caret of the box it is for. */
async function foUpload(boxId, file) {
  const box = document.getElementById(boxId);
  if (!box || !file || !/^image\//.test(file.type || '')) return;
  const say = box.closest('.fo-editor') && box.closest('.fo-editor').querySelector('.fo-up');
  FO.uploading++;
  if (say) { say.textContent = L('Uploading the picture…', 'Загрузка картинки…'); say.className = 'hint fo-up'; }
  let r = null, data = {};
  try {
    r = await fetch('/api/forum/pictures' + (boxId.startsWith('tk-') ? '?for=ticket' : ''), { method: 'POST', credentials: 'same-origin', cache: 'no-store', headers: { 'Content-Type': file.type || 'application/octet-stream' }, body: file });
    try { data = await r.json(); } catch (e) { /* not JSON */ }
  } catch (e) { r = null; }
  FO.uploading--;
  const now = document.getElementById(boxId) || box;
  if (r && r.ok && data.picture) {
    FO.uploaded[data.picture.id] = data.picture;
    const v = now.value, at = now.selectionStart;
    const pre = at > 0 && v[at - 1] !== '\n' ? '\n' : '', post = v[at] === '\n' ? '' : '\n';
    now.setSelectionRange(at, at);
    foInsert(now, `${pre}[img:${data.picture.id}]${post}`, '');
    if (say) say.textContent = '';
  } else if (say) {
    say.textContent = r ? foFault({ error: data.error || (r.status === 429 ? 'slow' : 'busy'), message: data.message, until: data.until }) : SAY.offline;
    say.className = 'hint fo-up bad';
  }
}

/** The @ list under a box: logins starting with what is typed after the @ before its caret. */
let foFindTimer = 0;
function foMention(box) {
  const list = box.closest('.fo-editor') && box.closest('.fo-editor').querySelector('.fo-mention');
  if (!list) return;
  const m = box.value.slice(0, box.selectionStart).match(/(^|[\s(])@([A-Za-z0-9_]{1,16})$/);
  if (!m) { list.hidden = true; FO.mention = null; return; }
  const q = m[2];
  clearTimeout(foFindTimer);
  foFindTimer = setTimeout(async () => {
    const r = await api('people/find?q=' + encodeURIComponent(q));
    if (!r.ok || !r.data.people.length || box.value.slice(0, box.selectionStart).match(/@([A-Za-z0-9_]{1,16})$/)?.[1] !== q) { list.hidden = true; FO.mention = null; return; }
    FO.mention = { box: box.id, q, people: r.data.people, sel: 0 };
    foMentionDraw(list);
  }, 140);
}
function foMentionDraw(list) {
  const m = FO.mention;
  list.innerHTML = m.people.map((p, i) => `<button type="button" class="${i === m.sel ? 'on' : ''}" data-fo-at="${esc(p.login)}" role="option">${head(p.login, 22)}${pfx(p)}<b translate="no">${esc(p.login)}</b></button>`).join('');
  list.hidden = false;
  list.querySelectorAll('canvas[data-head]').forEach(drawHead);
  list.querySelectorAll('[data-fo-at]').forEach((b) => b.addEventListener('mousedown', (e) => { e.preventDefault(); foMentionPick(b.dataset.foAt); }));
}
function foMentionPick(login) {
  const m = FO.mention, box = m && document.getElementById(m.box);
  if (!box) return;
  const at = box.selectionStart, from = at - m.q.length, v = box.value;
  box.value = v.slice(0, from) + login + ' ' + v.slice(at);
  box.setSelectionRange(from + login.length + 1, from + login.length + 1);
  box.focus();
  box.dispatchEvent(new Event('input', { bubbles: true }));
  FO.mention = null;
  const list = box.closest('.fo-editor').querySelector('.fo-mention');
  if (list) list.hidden = true;
}

/** Selected words of a post quoted into the reply. */
function foQuote(login, text) {
  const t = foThread();
  if (!t) return;
  const key = 't:' + t.id;
  const quoted = text.trim().slice(0, 600).split('\n').map((l) => '> ' + l).join('\n');
  foDraft(key, `${foDraft(key) ? foDraft(key).replace(/\s*$/, '\n\n') : ''}> @${login}\n${quoted}\n\n`);
  render(true);
  const box = document.getElementById('fo-reply');
  if (box) { box.focus(); box.setSelectionRange(box.value.length, box.value.length); box.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
}

/** The editors of the screen at work: the @ list, Ctrl+B/I, Ctrl+Enter (its box's button), pictures pasted and
 *  dropped, the tools, the preview. The forum's and the tickets'. */
function foEditorsWire(on) {
  on('.fo-editor textarea', 'input', (el) => foMention(el));
  on('.fo-editor textarea', 'click', (el) => foMention(el));
  on('.fo-editor textarea', 'blur', (el) => setTimeout(() => { const l = el.closest('.fo-editor') && el.closest('.fo-editor').querySelector('.fo-mention'); if (l) l.hidden = true; FO.mention = null; }, 120));
  on('.fo-editor textarea', 'keydown', (el, e) => {
    const m = FO.mention;
    if (m && m.box === el.id) {
      const list = el.closest('.fo-editor').querySelector('.fo-mention');
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); m.sel = (m.sel + (e.key === 'ArrowDown' ? 1 : m.people.length - 1)) % m.people.length; foMentionDraw(list); return; }
      if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); foMentionPick(m.people[m.sel].login); return; }
      if (e.key === 'Escape') { list.hidden = true; FO.mention = null; return; }
    }
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && (e.key === 'b' || e.key === 'i')) { e.preventDefault(); foInsert(el, e.key === 'b' ? '**' : '*', e.key === 'b' ? '**' : '*'); }
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); const go = $app.querySelector(`[data-submit-for="${el.id}"]`); if (go) go.click(); }
  });
  on('.fo-editor textarea', 'paste', (el, e) => {
    const files = [...((e.clipboardData && e.clipboardData.files) || [])].filter((f) => /^image\//.test(f.type));
    if (!files.length) return;
    e.preventDefault();
    files.slice(0, 10).forEach((f) => foUpload(el.id, f));
  });
  on('.fo-editor', 'dragover', (el, e) => { if ([...e.dataTransfer.types].includes('Files')) { e.preventDefault(); el.classList.add('drop'); } });
  on('.fo-editor', 'dragleave', (el, e) => { if (!el.contains(e.relatedTarget)) el.classList.remove('drop'); });
  on('.fo-editor', 'drop', (el, e) => {
    const files = [...(e.dataTransfer.files || [])].filter((f) => /^image\//.test(f.type));
    el.classList.remove('drop');
    if (!files.length) return;
    e.preventDefault();
    files.slice(0, 10).forEach((f) => foUpload(el.dataset.editor, f));
  });
  on('[data-fo-tool]', 'mousedown', (b, e) => e.preventDefault());
  on('[data-fo-tool]', 'click', (b) => {
    const box = document.getElementById(b.dataset.for);
    if (!box) return;
    const sel = box.value.slice(box.selectionStart, box.selectionEnd);
    switch (b.dataset.foTool) {
      case 'bold': foInsert(box, '**', '**'); break;
      case 'italic': foInsert(box, '*', '*'); break;
      case 'spoiler': foInsert(box, '||', '||'); break;
      case 'code': if (sel.includes('\n')) foInsert(box, '```\n', '\n```'); else foInsert(box, '`', '`'); break;
      case 'quote': foInsert(box, '', '', true); break;
      case 'picture': {
        const pick = document.createElement('input');
        pick.type = 'file'; pick.accept = 'image/png,image/jpeg,image/webp,image/gif'; pick.multiple = true;
        pick.addEventListener('change', () => [...pick.files].slice(0, 10).forEach((f) => foUpload(box.id, f)));
        pick.click();
        break;
      }
    }
  });
  on('[data-fo-preview]', 'click', (b) => { FO.preview[b.dataset.foPreview] = !FO.preview[b.dataset.foPreview]; render(true); });
}

function forumWire() {
  if (state.route !== 'forum') return;
  const on = (sel, ev, fn) => $app.querySelectorAll(sel).forEach((el) => bindOnce(el, ev, 'w7|' + sel, (e) => fn(el, e)));
  const again = () => { forget('forum', 'reports'); render(true); };
  const said = (r, ok) => { FO.bad = !r.ok; FO.msg = r.ok ? ok || '' : foFault(r); };
  // Filters of a category.
  on('[data-fo-filter]', 'click', (b) => { const [cat, k] = b.dataset.foFilter.split(':'); FO.filter[cat] = k; render(true); });
  on('[data-fo-sort]', 'click', (b) => { FO.sort.ideas = b.dataset.foSort; render(true); });
  // The editors: drafts kept, the tools, pictures pasted and dropped, the @ list, the preview.
  on('#fo-reply', 'input', (el) => { const t = foThread(); if (t) foDraft('t:' + t.id, el.value); });
  on('#fo-edit', 'input', (el) => { FO.editText = el.value; });
  on('#n-body', 'input', (el) => { foDraft('n:body', el.value); });
  on('[data-fo-n]', 'input', (el) => { foDraft('n:' + el.dataset.foN, el.value); });
  on('[data-fo-n]', 'change', (el) => { foDraft('n:' + el.dataset.foN, el.value); if (el.dataset.foN === 'cat') render(true); });
  foEditorsWire(on);
  // Spoilers open on a click; pictures open large.
  on('.spoiler', 'click', (s) => s.classList.add('shown'));
  on('.spoiler', 'keydown', (s, e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); s.classList.add('shown'); } });
  on('[data-fo-pic]', 'click', (b) => { FO.pic = b.dataset.foPic; render(true); });
  on('#fo-lb-close', 'click', () => { FO.pic = null; render(true); });
  on('#fo-lightbox', 'click', (el, e) => { if (e.target === el) { FO.pic = null; render(true); } });
  // Posting.
  on('[data-fo-post]', 'click', async (b) => {
    if (FO.uploading) return;
    const id = Number(b.dataset.foPost), body = foDraft('t:' + id);
    b.disabled = true;
    const r = await api(`forum/threads/${id}/posts`, { body });
    if (!r.ok) { said(r); b.disabled = false; render(true); return; }
    foDraft('t:' + id, ''); FO.msg = ''; FO.preview['fo-reply'] = false;
    forget('forum');
    const to = `#/forum/t/${id}/${r.data.page}`;
    if (location.hash === to) render(true); else location.hash = to;
    setTimeout(() => { const el = document.getElementById('p' + r.data.id); if (el) el.scrollIntoView({ block: 'center', behavior: 'smooth' }); }, 400);
  });
  on('#fo-start', 'click', async (b) => {
    if (FO.uploading) return;
    b.disabled = true;
    const r = await api('forum/threads', { category: b.dataset.cat, title: foDraft('n:title'), body: foDraft('n:body') });
    if (!r.ok) { said(r); b.disabled = false; render(true); return; }
    foDraft('n:title', ''); foDraft('n:body', ''); foDraft('n:cat', ''); FO.msg = ''; FO.preview['n-body'] = false;
    forget('forum');
    location.hash = `#/forum/t/${r.data.id}`;
  });
  // A post: quoted (all of it, or the words selected in it), edited, its history, reactions, the answer.
  on('[data-fo-quote]', 'click', (b) => {
    const t = foThread(), p = t && t.posts.find((x) => x.id === Number(b.dataset.foQuote));
    if (!p) return;
    const el = document.getElementById('p' + p.id), s = window.getSelection(), picked = s && !s.isCollapsed && el && el.contains(s.anchorNode) ? s.toString() : '';
    foQuote(p.author.login, picked || p.body.split('\n').filter((l) => !l.startsWith('>') && !/^\[img:/.test(l.trim())).join('\n').trim().slice(0, 400));
  });
  on('[data-fo-edit]', 'click', (b) => { const t = foThread(), p = t && t.posts.find((x) => x.id === Number(b.dataset.foEdit)); FO.edit = Number(b.dataset.foEdit); FO.editText = p ? p.body : ''; render(true); const box = document.getElementById('fo-edit'); if (box) { box.focus(); box.setSelectionRange(box.value.length, box.value.length); } });
  on('[data-fo-cancel]', 'click', () => { FO.edit = 0; render(true); });
  on('[data-fo-save]', 'click', async (b) => { if (FO.uploading) return; const r = await api(`forum/posts/${b.dataset.foSave}`, { body: FO.editText }, 'PATCH'); if (r.ok) { FO.edit = 0; FO.msg = ''; } else said(r); FO.hist = 0; again(); });
  on('[data-fo-hist]', 'click', async (b) => {
    const id = Number(b.dataset.foHist);
    if (FO.hist === id) { FO.hist = 0; render(true); return; }
    FO.hist = id; FO.history = null; render(true);
    const r = await api(`forum/posts/${id}/history`);
    if (FO.hist === id) { FO.history = r.ok ? r.data.versions : []; render(true); }
  });
  on('[data-fo-react-open]', 'click', (b) => { const id = Number(b.dataset.foReactOpen); FO.react = FO.react === id ? 0 : id; render(true); });
  on('[data-fo-react]', 'click', async (b) => {
    const [id, e] = b.dataset.foReact.split(':');
    FO.react = 0;
    const r = await api(`forum/posts/${id}/react`, { emoji: e });
    const t = foThread(), p = t && t.posts.find((x) => x.id === Number(id));
    if (r.ok && p) p.reactions = r.data.reactions;
    render(true);
  });
  on('[data-fo-answer]', 'click', async (b) => { const t = foThread(); const post = Number(b.dataset.foAnswer); const r = await api(`forum/threads/${t.id}/solution`, { post: post || null }); said(r, post ? L('Marked as the answer: the question is solved.', 'Отмечено как ответ: вопрос решён.') : ''); again(); });
  // The thread: votes, following, its status.
  on('[data-fo-vote]', 'click', async () => { const t = foThread(); const r = await api(`forum/threads/${t.id}/vote`, {}); if (r.ok) { t.votes = r.data.votes; t.voted = r.data.voted; } else said(r); forget('forum/threads?'); render(true); });
  on('[data-fo-follow]', 'click', async (b) => { const t = foThread(); const r = await api(`forum/threads/${t.id}/follow`, { on: b.dataset.foFollow === '1' }); if (r.ok) t.following = r.data.following; render(true); });
  on('#fo-status', 'change', async (s) => { const t = foThread(); const r = await api(`forum/threads/${t.id}/status`, { status: s.value }); said(r, L('Status changed: its author is told.', 'Статус изменён: автор получит уведомление.')); again(); });
  // Staff: a warning, a mute.
  on('[data-fo-staff]', 'click', (b) => { FO.staff = FO.staff === b.dataset.foStaff ? '' : b.dataset.foStaff; FO.staffWhy = ''; render(true); const i = document.getElementById('fo-staff-why'); if (i) i.focus(); });
  on('#fo-staff-why', 'input', (i) => { FO.staffWhy = i.value; });
  on('#fo-staff-min', 'change', (s) => { FO.staffMin = Number(s.value); });
  on('[data-fo-staff-no]', 'click', () => { FO.staff = ''; render(true); });
  on('[data-fo-staff-go]', 'click', async (b) => {
    const kind = FO.staff.split(':')[0], login = b.dataset.foStaffGo;
    const r = kind === 'warn' ? await api('staff/warn', { login, why: FO.staffWhy }) : await api('staff/mute', { login, minutes: FO.staffMin, why: FO.staffWhy });
    said(r, kind === 'warn' ? L(`${login} is warned (${r.data && r.data.warnings} in all).`, `${login}: предупреждение выдано (всего: ${r.data && r.data.warnings}).`) : L(`${login} can’t post on the forum for now.`, `${login} пока не может писать на форуме.`));
    if (r.ok) FO.staff = '';
    state.fmsg = FO.msg; FO.msg = '';
    render(true);
  });
}

// Selected words of a post: a small "Quote" offered by them.
document.addEventListener('mouseup', (e) => {
  if (state.route !== 'forum') return;
  setTimeout(() => {
    let tip = document.getElementById('fo-quote-tip');
    const s = window.getSelection(), body = s && !s.isCollapsed && s.anchorNode && s.anchorNode.parentElement && s.anchorNode.parentElement.closest('.post .post-body');
    if (!body || !s.toString().trim() || e.target.closest('#fo-quote-tip')) { if (tip && !e.target.closest('#fo-quote-tip')) tip.remove(); return; }
    const post = body.closest('.post'), rect = s.getRangeAt(0).getBoundingClientRect();
    if (!tip) { tip = document.createElement('button'); tip.id = 'fo-quote-tip'; tip.className = 'w small lead'; document.body.appendChild(tip); }
    tip.textContent = L('Quote', 'Цитировать');
    tip.style.left = `${Math.max(8, rect.left + rect.width / 2 + window.scrollX - 44)}px`;
    tip.style.top = `${rect.top + window.scrollY - 40}px`;
    const text = s.toString(), t = foThread(), p = t && t.posts.find((x) => 'p' + x.id === post.id);
    tip.onclick = () => { tip.remove(); if (p) foQuote(p.author.login, text); };
  }, 0);
});

// ================================================================================================ forum 3.0 (07.10.2026)
// Her word: "the forum still looks raw, and members' profiles are awkward to get to — make it ten times better". What
// this adds to every screen of people: a member's card over any avatar or name held under the pointer (a click on it
// goes to the profile, even inside a thread's row); the screens coming in as the client's own do (each row in turn,
// once a screen: the redraws that follow each answer of the server do not start it again); a thread's side (its
// author, who took part, more of its category), the way up and the way to its last reply; a page for an address that
// leads nowhere.

// ---- a screen comes in once

const F3 = { key: '', at: 0 };
/** Whether the screen `key` is still coming in, and how far in it is (ms): a style for its rows, empty once it is in. */
function f3Enter(key) {
  const now = performance.now();
  if (key !== F3.key) { F3.key = key; F3.at = now; }
  return now - F3.at;
}
/** The style of the `i`th row of a screen `elapsed` ms in: its turn, minus the time gone (a redraw goes on, not over). */
const f3Row = (i, elapsed) => (elapsed > 900 || matchMedia('(prefers-reduced-motion: reduce)').matches ? '' : ` style="animation-delay:${Math.min(i, 14) * 38 - elapsed}ms"`);
const f3Cls = (elapsed) => (elapsed > 900 ? '' : ' f3-in');

// ---- a member's card

const HC = { cache: new Map(), el: null, login: '', anchor: null, show: 0, hide: 0 };

/** The member an element under the pointer stands for (an avatar, a name), or null. */
function hcWho(target) {
  if (!(target instanceof Element)) return null;
  const a = target.closest('[data-u], .who-name, img.head[data-login], canvas.head[data-head]');
  if (!a || a.closest('.hcard, .prof-av, .av-big, .site-head, header')) return null;
  let login = a.dataset.u || a.dataset.login || a.dataset.head || '';
  if (!login && a.classList.contains('who-name')) {
    const m = /#\/u\/([^/?#]+)/.exec(a.getAttribute('href') || '');
    login = m ? decodeURIComponent(m[1]) : '';
  }
  return login ? { el: a, login } : null;
}

function hcData(login) {
  const k = login.toLowerCase();
  let c = HC.cache.get(k);
  if (!c) {
    c = api('u/' + encodeURIComponent(login)).then((r) => {
      if (!r.ok) HC.cache.delete(k);
      else learnAv(r.data);
      return r;
    });
    HC.cache.set(k, c);
  }
  return c;
}

function hcHtml(p) {
  const who = p.person, pres = p.presence || {}, acc = who.accent || '#E9E9EB';
  const stats = [[p.stats.posts, L('posts', plural(p.stats.posts, 'пост', 'поста', 'постов'))], [p.stats.threads, L('threads', plural(p.stats.threads, 'тема', 'темы', 'тем'))]];
  if (p.stats.hours !== null && p.stats.hours !== undefined) stats.push([p.stats.hours, L('hours in Cursed', plural(p.stats.hours, 'час в Cursed', 'часа в Cursed', 'часов в Cursed'))]);
  const where = pres.online ? `<p class="hc-where">${dot(pres.online)}<span>${pres.online === 'game' ? tr('In the game') : tr('On the site')}</span>${pres.server ? `<span class="ash" translate="no">· ${esc(pres.server)}</span>` : ''}</p>` : '';
  const self = p.viewer && p.viewer.self;
  return `<div class="hc-top theme-${esc(p.theme || 'eclipse')}">${p.banner ? `<img src="${esc(p.banner.url)}" alt="" decoding="async" onerror="this.remove()">` : ''}</div>
    <div class="hc-body" style="--acc:${esc(acc)}">
      <div class="hc-av">${head(who.login, 64)}${dot(pres.online)}</div>
      <p class="hc-pre">${pfx(who)}<span class="ash num" translate="no">UID ${esc(String(who.uid_text || who.uid))}</span></p>
      <p class="hc-name" translate="no">${esc(who.login)}</p>
      ${who.status ? `<p class="status">${emo(who.status.emoji, 18)}<span translate="no">${esc(who.status.text || '')}</span></p>` : ''}
      ${where}
      <div class="hc-stats">${stats.map(([n, w]) => `<div><b class="num">${fmt(n || 0)}</b><span>${w}</span></div>`).join('')}</div>
      <p class="ash hc-since">${L('With Cursed since', 'В Cursed с')} ${when(p.since)}</p>
      <div class="acts"><a class="w small lead" href="${profHref(who.login)}">${L('Profile', 'Профиль')}</a>${self ? '' : `<a class="w small" href="${profHref(who.login)}" data-hc-write="1">${L('Message', 'Написать')}</a>`}</div>
    </div>`;
}

function hcPlace() {
  const el = HC.el, a = HC.anchor;
  if (!el || !a || !a.isConnected) return;
  const r = a.getBoundingClientRect(), w = el.offsetWidth, h = el.offsetHeight, m = 10;
  let x = r.left + r.width / 2 - w / 2;
  x = Math.max(m, Math.min(window.innerWidth - w - m, x));
  let y = r.bottom + 10;
  const up = y + h > window.innerHeight - m && r.top - 10 - h > m;
  if (up) y = r.top - 10 - h;
  el.style.left = Math.round(x + window.scrollX) + 'px';
  el.style.top = Math.round(y + window.scrollY) + 'px';
  el.classList.toggle('up', up);
}

async function hcOpen(anchor, login) {
  HC.login = login; HC.anchor = anchor;
  const r = await hcData(login);
  if (HC.login !== login || !anchor.isConnected || !r.ok) return;
  if (!HC.el) {
    HC.el = document.createElement('div');
    HC.el.className = 'hcard';
    HC.el.setAttribute('role', 'dialog');
    HC.el.addEventListener('mouseenter', () => clearTimeout(HC.hide));
    HC.el.addEventListener('mouseleave', () => hcLater());
    document.body.appendChild(HC.el);
  }
  HC.el.innerHTML = hcHtml(r.data);
  HC.el.style.setProperty('--acc', r.data.person.accent || '#E9E9EB');
  HC.el.querySelectorAll('canvas[data-head]').forEach(drawHead);
  HC.el.classList.remove('on');
  hcPlace();
  // The next frame: from its first place to its shown one, eased.
  requestAnimationFrame(() => HC.el && HC.el.classList.add('on'));
}

function hcClose() {
  clearTimeout(HC.show); clearTimeout(HC.hide);
  HC.login = ''; HC.anchor = null;
  if (HC.el) HC.el.classList.remove('on');
}
function hcLater() {
  clearTimeout(HC.hide);
  HC.hide = setTimeout(hcClose, 240);
}

// Only where a pointer hovers (a finger's tap goes to the profile instead).
if (matchMedia('(hover: hover)').matches) {
  document.addEventListener('mouseover', (e) => {
    const w = hcWho(e.target);
    if (!w) return;
    clearTimeout(HC.hide);
    if (HC.login === w.login && HC.anchor === w.el) return;
    clearTimeout(HC.show);
    HC.show = setTimeout(() => hcOpen(w.el, w.login), HC.el && HC.el.classList.contains('on') ? 60 : 380);
  });
  document.addEventListener('mouseout', (e) => {
    const w = hcWho(e.target);
    if (!w) return;
    clearTimeout(HC.show);
    if (HC.el && HC.el.contains(e.relatedTarget)) return;
    hcLater();
  });
  document.addEventListener('scroll', () => { if (HC.el && HC.el.classList.contains('on')) hcPlace(); }, { passive: true, capture: true });
}
window.addEventListener('hashchange', hcClose);

// A member's avatar or name inside a row that is itself a link (a thread's): their profile, not the thread.
document.addEventListener('click', (e) => {
  const u = e.target instanceof Element ? e.target.closest('a.topic [data-u], a.topic .head, a.cat [data-u]') : null;
  if (!u) return;
  const login = u.dataset.u || u.dataset.login || u.dataset.head;
  if (!login) return;
  e.preventDefault();
  e.stopPropagation();
  location.hash = profHref(login);
}, true);

// ---- the way up, and to a thread's last reply

let f3UpShown = false;
document.addEventListener('scroll', (e) => {
  const box = e.target && e.target.classList && e.target.classList.contains('r-wb') ? e.target : null;
  if (!box) return;
  const show = box.scrollTop > 900;
  if (show === f3UpShown) return;
  f3UpShown = show;
  let b = document.getElementById('f3-up');
  if (!b) {
    b = document.createElement('button');
    b.id = 'f3-up';
    b.className = 'f3-up';
    b.setAttribute('aria-label', L('Up', 'Наверх'));
    b.innerHTML = '<i></i>';
    b.addEventListener('click', () => toTop(true));
    document.body.appendChild(b);
  }
  b.classList.toggle('on', show);
}, { passive: true, capture: true });

// ---- an address that leads nowhere

function viewNotFound() {
  return `<div class="nf">
      <p class="nf-code num">404</p>
      <h1 class="giant">${L('Nothing here', 'Здесь ничего нет')}</h1>
      <p class="ash">${L('This address leads nowhere: mistyped, or the page is gone.', 'По этому адресу ничего нет: опечатка, или страница ушла.')}</p>
      <div class="acts"><a class="w lead" href="#/">${L('Home', 'На главную')}</a><a class="w" href="#/forum">${L('The forum', 'Форум')}</a><a class="w" href="#/market">${L('The market', 'Маркет')}</a><button class="w" onclick="history.back()">${L('Back', 'Назад')}</button></div>
    </div>`;
}

// ================================================================================================ support (03.10.2026)
// Tickets (site/server/src/tickets.rs): a member's own (opened, answered, closed, rated), and for the staff the queue
// with its states, who it is given to, notes the author never sees, ready answers, the author's computer freed. The
// text is written in the forum's editor (forum.js); a bug sent from the game shows what the game said of itself and
// its log.

MEMBERS_ONLY.add('support');
const TK = { view: 'mine', state: 'active', msg: '', bad: false, internal: false, rate: 0, rateNote: '', cat: '' };
const TK_CATS = {
  account: ['Account and computer', 'Аккаунт и компьютер', 'Signing in, the computer the account is bound to, a ban.', 'Вход, привязка к компьютеру, бан.'],
  bug: ['A bug', 'Баг', 'Something broken in Cursed. From the game it is quicker: the log and the system go with it.', 'Что-то сломалось в Cursed. Из игры быстрее: лог и система прикладываются сами.'],
  complaint: ['A complaint', 'Жалоба', 'About a member, a post, a pack. Say who and what; screenshots help.', 'На участника, пост, пак. Напишите, кто и что; скриншоты помогают.'],
  partner: ['Partnership', 'Партнёрство', 'Servers, projects, advertising.', 'Сервера, проекты, реклама.'],
  media: ['Media', 'Медиа', 'You make videos or stream: your channel and what you would like.', 'Вы снимаете видео или стримите: ваш канал и что хотели бы.'],
  other: ['Something else', 'Другое', 'Anything that fits nowhere above.', 'Всё, что не подошло выше.'],
};
const TK_STATES = { open: ['Open', 'Открыт', ''], working: ['In work', 'В работе', 'cream'], waiting: ['Waiting for you', 'Ждём ответа', 'ok'], closed: ['Closed', 'Закрыт', 'warn'] };
const TK_STATES_STAFF = { open: ['Open', 'Открыт'], working: ['In work', 'В работе'], waiting: ['Waiting for the author', 'Ждём автора'], closed: ['Closed', 'Закрыт'] };
const tkCat = (k) => (TK_CATS[k] ? L(TK_CATS[k][0], TK_CATS[k][1]) : k);
const tkState = (s, staffSide) => {
  const w = staffSide ? TK_STATES_STAFF[s] : TK_STATES[s];
  return w ? `<span class="st ${TK_STATES[s][2]}">${L(w[0], w[1])}</span>` : '';
};
const tkStaff = () => !!(state.user && (state.user.admin || (state.user.perms || []).includes('tickets.handle')));
const tkMeta = { build: ['Build', 'Сборка'], version: ['Version', 'Версия'], gpu: ['Video card', 'Видеокарта'], driver: ['Driver', 'Драйвер'], os: ['System', 'Система'], cpu: ['Processor', 'Процессор'], ram: ['Memory', 'Память'], java: ['Java', 'Java'], screen: ['Screen', 'Экран'], server: ['Server', 'Сервер'], fps: ['FPS', 'FPS'], modules: ['Modules on', 'Включённые модули'] };

function viewSupport(arg) {
  const [part, x] = String(arg || '').split('/');
  const body = part === 't' ? tkTicket(Number(x)) : part === 'new' ? tkNew(x || '') : tkList();
  return `<div class="dash">${rail('support')}<div><h1 class="sr">Support</h1>${body}</div></div>`;
}

function tkList() {
  const staffSide = tkStaff() && TK.view === 'queue';
  const q = staffSide ? `tickets?all=1${TK.state === 'mine' ? '&assignee=me&state=active' : TK.state === 'none' ? '&assignee=none&state=active' : '&state=' + TK.state}` : 'tickets';
  const c = ask(q);
  const counts = c.ok && c.data.counts;
  const tab = (k, en, ru, n) => `<button class="w small ${TK.state === k ? 'on' : ''}" data-tk-state="${k}">${L(en, ru)}${n ? ` · <span class="num">${n}</span>` : ''}</button>`;
  const list = waiting(c) ? '<div class="rows"><div>&nbsp;</div></div>' : !c.ok ? trouble(c) : c.data.items.length ? c.data.items.map((t) => `<a class="tk-row ${t.unread ? 'unread' : ''}" href="#/support/t/${t.id}">
      ${staffSide ? head(t.author.login, 36) : ''}<span class="tk-main"><b translate="no">${esc(t.title)}</b>
      <span class="ash">${tkCat(t.category)} · ${ago(t.updated)}${staffSide ? ` · ${pfx(t.author)}<span translate="no">${esc(t.author.login)}</span>` : ''}${t.assignee ? ` · ${L('with', 'у')} <span translate="no">${esc(t.assignee.login)}</span>` : ''}</span></span>
      ${tkState(t.state, staffSide)}</a>`).join('') : `<div class="empty">${staffSide ? L('Nothing here.', 'Здесь пусто.') : L('No tickets yet. Something wrong? Write to us.', 'Обращений пока нет. Что-то не так? Напишите нам.')}</div>`;
  return `<p class="sub">${L('Your account and computer, bugs, complaints, partnership: Cursed’s staff answer here.', 'Аккаунт и компьютер, баги, жалобы, партнёрство: здесь отвечает персонал Cursed.')}</p>
    <div class="acts" style="margin-top:22px"><a class="w lead" href="#/support/new">${L('New ticket', 'Новое обращение')}</a>
      ${tkStaff() ? `<span class="gap"></span><button class="w ${TK.view === 'mine' ? 'on' : ''}" data-tk-view="mine">${L('Mine', 'Мои')}</button><button class="w ${TK.view === 'queue' ? 'on' : ''}" data-tk-view="queue">${L('The queue', 'Очередь')}</button>` : ''}</div>
    ${staffSide ? `<div class="acts tk-filter">${tab('active', 'Active', 'Активные')}${tab('open', 'Open', 'Открытые', counts && counts.open)}${tab('working', 'In work', 'В работе', counts && counts.working)}${tab('waiting', 'Waiting for the author', 'Ждём автора', counts && counts.waiting)}${tab('none', 'Nobody’s', 'Ничьи', counts && counts.unassigned)}${tab('mine', 'Given to me', 'На мне')}${tab('closed', 'Closed', 'Закрытые')}</div>` : ''}
    <div class="sections"><div class="tk-list">${list}</div></div>`;
}

function tkNew(cat) {
  const chosen = TK.cat || (TK_CATS[cat] ? cat : '') || foDraft('tk:cat') || 'other';
  const c = TK_CATS[chosen] || TK_CATS.other;
  return `<div class="crumb"><a href="#/support">Support</a> / ${L('New ticket', 'Новое обращение')}</div><h2 class="big" style="margin-top:14px">${L('New ticket', 'Новое обращение')}</h2>
    <div class="form" style="max-width:760px;margin-top:24px">
      <div><span class="lab">${L('What it is about', 'О чём')}</span><div class="acts tk-cats">${Object.keys(TK_CATS).map((k) => `<button class="w small ${k === chosen ? 'on' : ''}" data-tk-cat="${k}">${tkCat(k)}</button>`).join('')}</div>
        <p class="hint">${L(c[2], c[3])}</p></div>
      <div><label class="lab" for="tk-title">Title</label><input class="in" id="tk-title" maxlength="120" value="${esc(foDraft('tk:title'))}"></div>
      <div><label class="lab" for="tk-body">Text</label>${editor('tk-body', foDraft('tk:body'), 8)}</div>
      <div class="acts"><button class="w menu lead" id="tk-start" data-cat="${chosen}" data-submit-for="tk-body">${L('Send', 'Отправить')}</button><a class="w menu" href="#/support">Cancel</a></div>
      <p class="hint ${TK.bad ? 'bad' : ''}" role="status">${esc(TK.msg)}</p></div>`;
}

function tkSystem(m) {
  const who = m.author ? `<b translate="no">${esc(m.author.login)}</b>` : '';
  const [k, v] = m.body.split(/:(.*)/s);
  const line = k === 'state' ? L(`${who} set it to “${esc((TK_STATES_STAFF[v] || [v])[0])}”`, `${who}: статус «${esc((TK_STATES_STAFF[v] || [v, v])[1])}»`)
    : k === 'assigned' ? (v ? L(`${who} gave it to <b translate="no">${esc(v)}</b>`, `${who} передаёт обращение: <b translate="no">${esc(v)}</b>`) : L(`${who} gave it back`, `${who} снимает обращение с себя`))
    : k === 'file' ? L(`${who} attached ${esc(v)}`, `${who} прикладывает ${esc(v)}`)
    : k === 'device-reset' ? L(`${who} freed the account’s computer`, `${who} сбрасывает привязку к компьютеру`) : esc(m.body);
  return `<div class="tk-sys">${line} · ${ago(m.created)}</div>`;
}

function tkTicket(id) {
  const c = ask(`tickets/${id}`);
  if (waiting(c)) return `<div class="crumb"><a href="#/support">Support</a></div><h2 class="big ghost-t">&nbsp;</h2>`;
  if (!c.ok) return `<div class="crumb"><a href="#/support">Support</a></div><p class="ash" style="margin-top:20px">${L('This ticket is gone, or not yours.', 'Такого обращения нет, или оно не ваше.')}</p>`;
  const t = c.data, staffSide = t.staff_view, perms = (state.user && state.user.perms) || [];
  const meta = t.meta ? `<div class="block tk-meta"><h2 class="sec">${L('From the game', 'Из игры')}</h2><div class="kv">${Object.keys(tkMeta).filter((k) => t.meta[k]).map((k) => `<div><span class="ash">${L(...tkMeta[k])}</span><span translate="no">${esc(t.meta[k])}</span></div>`).join('')}</div></div>` : '';
  const files = t.files.length ? `<div class="block"><h2 class="sec">${L('Files', 'Файлы')}</h2><div class="tk-files">${t.files.map((f) => `<a class="w small" href="/api/tickets/${t.id}/files/${f.id}" download="${esc(f.name)}" translate="no">${esc(f.name)} · ${mb(f.size)}</a>`).join('')}</div></div>` : '';
  const msgs = t.messages.map((m) => (m.kind === 'system' ? tkSystem(m) : `<div class="review post tk-msg ${m.internal ? 'internal' : ''} ${m.staff ? 'from-staff' : ''}">${head(m.author ? m.author.login : '?', 40)}<div>
      <div class="top">${nm(m.author)}${m.staff && !m.internal ? `<span class="cream">${L('Cursed’s staff', 'Персонал Cursed')}</span>` : ''}${m.internal ? `<span class="st cream">${L('A note for the staff', 'Заметка для персонала')}</span>` : ''}<span>${ago(m.created)}</span></div>
      <div class="prose post-body" translate="no">${prose(m.body, m)}</div></div></div>`)).join('');
  const staffTools = staffSide ? `<div class="acts thread-tools tk-tools"><span class="ash">${L('Staff', 'Персонал')}</span>
      ${Object.keys(TK_STATES_STAFF).map((s) => `<button class="w small ${t.state === s ? 'on' : ''}" data-tk-set="${s}">${L(...TK_STATES_STAFF[s])}</button>`).join('')}
      ${t.assignee && t.assignee.uid === state.user.uid ? `<button class="w small" data-tk-assign="">${L('Give it back', 'Снять с себя')}</button>` : `<button class="w small" data-tk-assign="${esc(state.user.login || me().name)}">${L('Take it', 'Взять себе')}</button>`}
      ${perms.includes('users.device') || state.user.admin ? `<button class="w small" data-tk-device="1">${L('Free their computer', 'Сбросить привязку к компьютеру')}</button>` : ''}</div>
      ${t.device ? `<p class="hint">${L('Their computer: bound', 'Компьютер: привязан')} ${when(t.device.bound)} · ${L('last seen', 'заходил(а)')} ${ago(t.device.seen)}</p>` : `<p class="hint">${L('No computer bound to the account.', 'К аккаунту не привязан компьютер.')}</p>`}` : '';
  const ready = staffSide ? ask('staff/replies') : null;
  const closed = t.state === 'closed';
  const rateBox = !staffSide && closed ? (t.rating ? `<p class="ash">${L('You rated the help', 'Ваша оценка помощи')}: <b class="cream">${t.rating} / 5</b>${t.rating_note ? ` · <span translate="no">${esc(t.rating_note)}</span>` : ''}</p>`
    : `<div class="block tk-rate"><h2 class="sec">${L('How was the help?', 'Как вам помогли?')}</h2><div class="acts">${[1, 2, 3, 4, 5].map((n) => `<button class="w small ${TK.rate === n ? 'on' : ''}" data-tk-rate="${n}">${n}</button>`).join('')}</div>
        <div class="fr-invite" style="margin-top:10px"><input class="in" id="tk-rate-note" maxlength="300" placeholder="${L('A few words, if you like', 'Пара слов, если хотите')}" value="${esc(TK.rateNote)}"><button class="w small lead" id="tk-rate-go" ${TK.rate ? '' : 'disabled'}>${L('Rate', 'Оценить')}</button></div></div>`) : '';
  const replyBox = closed && !staffSide ? `<p class="st warn" style="margin-top:22px">${L('This ticket is closed.', 'Обращение закрыто.')}</p><div class="acts"><button class="w small" data-tk-set="open">${L('Open it again', 'Открыть снова')}</button></div>`
    : `<div class="form reply-box"><label class="lab" for="tk-reply">${staffSide && TK.internal ? L('A note for the staff', 'Заметка для персонала') : L('Your answer', 'Ваш ответ')}</label>${editor('tk-reply', foDraft('tk:' + t.id), 5)}
        <div class="acts">${staffSide ? `<label class="tk-check"><input type="checkbox" id="tk-internal" ${TK.internal ? 'checked' : ''}> ${L('Only the staff see it', 'Видит только персонал')}</label>
          ${ready && ready.ok && ready.data.items.length ? `<select class="in small-select" id="tk-ready" aria-label="${L('A ready answer', 'Готовый ответ')}"><option value="">${L('A ready answer…', 'Готовый ответ…')}</option>${ready.data.items.map((r) => `<option value="${r.id}">${esc(r.title)}</option>`).join('')}</select>` : ''}
          <button class="w small" id="tk-ready-new">${L('Keep this as a ready answer', 'Сохранить как готовый ответ')}</button>` : ''}
          <span class="gap"></span>${!staffSide && !closed ? `<button class="w small" data-tk-set="closed">${L('Close the ticket', 'Закрыть обращение')}</button>` : ''}<button class="w menu lead" data-tk-send="${t.id}" data-submit-for="tk-reply">${L('Send', 'Отправить')}</button></div>
        <p class="hint ${TK.bad ? 'bad' : ''}" role="status">${esc(TK.msg)}</p></div>`;
  return `<div class="thread tk">
      <div class="crumb"><a href="#/support">Support</a> / <span class="num">#${t.id}</span></div>
      <h1 class="big" translate="no">${esc(t.title)}</h1>
      <div class="by"><span>${tkState(t.state, staffSide)}</span><span class="ash">${tkCat(t.category)} · ${staffSide ? `${nm(t.author)} · ` : ''}${L('opened', 'открыто')} ${ago(t.created)}${t.assignee ? ` · ${L('with', 'у')} ${nm(t.assignee)}` : ''}</span></div>
      ${staffTools}${meta}${files}
      <div class="posts">${msgs}</div>
      ${rateBox}${replyBox}
      ${FO.pic ? `<div class="lightbox" id="fo-lightbox"><img src="${esc(FO.pic)}" alt=""><button class="w small lb-close" id="fo-lb-close">Close</button></div>` : ''}
    </div>`;
}

function supportWire() {
  if (state.route !== 'support') return;
  const on = (sel, ev, fn) => $app.querySelectorAll(sel).forEach((el) => bindOnce(el, ev, 'w8|' + sel, (e) => fn(el, e)));
  const id = () => Number(String(state.arg).split('/')[1]);
  const said = (r, ok) => { TK.bad = !r.ok; TK.msg = r.ok ? ok || '' : r.error === 'many' ? L('Three tickets open at most: wait for an answer.', 'Не больше трёх открытых обращений: дождитесь ответа.') : r.error === 'slow' ? L('A new ticket once a minute.', 'Новое обращение — раз в минуту.') : r.error === 'closed' ? L('This ticket is closed: open it again or start a new one.', 'Обращение закрыто: откройте его снова или создайте новое.') : tr(r.message || SAY[r.error] || SAY.busy); };
  foEditorsWire(on);
  on('[data-tk-view]', 'click', (b) => { TK.view = b.dataset.tkView; TK.state = 'active'; render(true); });
  on('[data-tk-state]', 'click', (b) => { TK.state = b.dataset.tkState; render(true); });
  on('[data-tk-cat]', 'click', (b) => { TK.cat = b.dataset.tkCat; foDraft('tk:cat', TK.cat); render(true); });
  on('#tk-title', 'input', (el) => { foDraft('tk:title', el.value); });
  on('#tk-body', 'input', (el) => { foDraft('tk:body', el.value); });
  on('#tk-reply', 'input', (el) => { foDraft('tk:' + id(), el.value); });
  on('#tk-internal', 'change', (el) => { TK.internal = el.checked; render(true); });
  on('#tk-start', 'click', async (b) => {
    if (FO.uploading) return;
    b.disabled = true;
    const r = await api('tickets', { category: b.dataset.cat, title: foDraft('tk:title'), body: foDraft('tk:body') });
    if (!r.ok) { said(r); b.disabled = false; render(true); return; }
    foDraft('tk:title', ''); foDraft('tk:body', ''); foDraft('tk:cat', ''); TK.cat = ''; TK.msg = '';
    forget('tickets');
    location.hash = `#/support/t/${r.data.id}`;
  });
  on('[data-tk-send]', 'click', async (b) => {
    if (FO.uploading) return;
    const t = Number(b.dataset.tkSend);
    b.disabled = true;
    const r = await api(`tickets/${t}/messages`, { body: foDraft('tk:' + t), internal: TK.internal });
    if (r.ok) { foDraft('tk:' + t, ''); TK.msg = ''; FO.preview['tk-reply'] = false; } else said(r);
    forget('tickets'); render(true);
  });
  on('[data-tk-set]', 'click', async (b) => { const r = await api(`tickets/${id()}/state`, { state: b.dataset.tkSet }); said(r); forget('tickets'); render(true); });
  on('[data-tk-assign]', 'click', async (b) => { const r = await api(`tickets/${id()}/assign`, { login: b.dataset.tkAssign || null }); said(r); forget('tickets'); render(true); });
  on('[data-tk-device]', 'click', async (b) => {
    if (b.dataset.sure !== '1') { b.dataset.sure = '1'; b.textContent = L('Free it?', 'Сбросить?'); return; }
    const r = await api(`tickets/${id()}/device-reset`, {}); said(r, L('Freed: the next start of the loader binds the computer it runs on.', 'Сброшено: следующий запуск лоудера привяжет тот компьютер, на котором он запущен.')); forget('tickets'); render(true);
  });
  on('[data-tk-rate]', 'click', (b) => { TK.rate = Number(b.dataset.tkRate); render(true); });
  on('#tk-rate-note', 'input', (el) => { TK.rateNote = el.value; });
  on('#tk-rate-go', 'click', async () => { const r = await api(`tickets/${id()}/rate`, { rating: TK.rate, note: TK.rateNote }); said(r, L('Thank you.', 'Спасибо.')); TK.rate = 0; TK.rateNote = ''; forget('tickets'); render(true); });
  on('#tk-ready', 'change', (s) => {
    const c = got.get('staff/replies'), r = c && c.ok && c.data.items.find((x) => String(x.id) === s.value), box = document.getElementById('tk-reply');
    if (r && box) { box.value = (box.value ? box.value.replace(/\s*$/, '\n\n') : '') + r.body; box.dispatchEvent(new Event('input', { bubbles: true })); box.focus(); }
  });
  on('#tk-ready-new', 'click', async () => {
    const body = foDraft('tk:' + id()).trim();
    if (!body) { TK.bad = true; TK.msg = L('Write the answer first.', 'Сначала напишите ответ.'); render(true); return; }
    const title = await rPrompt(L('A name for this ready answer', 'Название готового ответа'), body.split('\n')[0].slice(0, 40));
    if (!title) return;
    const r = await api('staff/replies', { title, body }); said(r, L('Kept among the ready answers.', 'Сохранено в готовых ответах.')); forget('staff/replies'); render(true);
  });
  on('[data-fo-pic]', 'click', (b) => { FO.pic = b.dataset.foPic; render(true); });
  on('#fo-lb-close', 'click', () => { FO.pic = null; render(true); });
  on('#fo-lightbox', 'click', (el, e) => { if (e.target === el) { FO.pic = null; render(true); } });
  on('.spoiler', 'click', (s) => s.classList.add('shown'));
}

// ---- one's own computer (in Sessions)

function dashDevice() {
  const c = ask('me/device');
  if (waiting(c) || !c.ok) return '';
  const d = c.data, wait = d.reset_from > d.now;
  return `<div class="block"><h2 class="sec">${L('The computer you play on', 'Компьютер для игры')}</h2>
    <p class="ash">${d.bound ? `${L('Bound', 'Привязан')} ${when(d.bound)} · ${L('last start', 'последний запуск')} ${ago(d.seen)}` : L('None yet: the loader binds the computer it first starts on.', 'Пока никакого: лоудер привяжет компьютер при первом запуске.')}</p>
    <p class="hint">${L('One account plays on one computer. A new computer: free the old one here (once a day), then start the loader on the new one. More often — through support.', 'Один аккаунт — один компьютер. Новый компьютер: сбросьте привязку здесь (раз в сутки), потом запустите лоудер на новом. Чаще — через поддержку.')}</p>
    ${d.bound ? `<div class="acts"><button class="w ${wait ? '' : 'lead'}" id="dev-reset" ${wait ? 'disabled' : ''}>${wait ? `${L('Again from', 'Снова можно с')} ${esc(new Date(d.reset_from * 1000).toLocaleString(LANG === 'ru' ? 'ru-RU' : 'en-GB', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }))}` : L('Free the computer', 'Сбросить привязку')}</button></div>` : ''}
    <p class="hint" id="dev-msg" role="status"></p></div>`;
}

function deviceWire() {
  if (state.route !== 'dashboard') return;
  const b = document.getElementById('dev-reset');
  if (!b) return;
  bindOnce(b, 'click', 'dev', async () => {
    if (b.dataset.sure !== '1') { b.dataset.sure = '1'; b.textContent = L('Free it? The loader then binds the next computer it starts on', 'Сбросить? Лоудер привяжет следующий компьютер, где запустится'); return; }
    const r = await api('me/device/reset', {});
    const msg = document.getElementById('dev-msg');
    forget('me/device');
    if (msg) { msg.textContent = r.ok ? L('Freed. Start the loader on the computer you play on now.', 'Сброшено. Запустите лоудер на компьютере, где будете играть.') : r.error === 'wait' ? L('Once a day: try again later or write to support.', 'Раз в сутки: попробуйте позже или напишите в поддержку.') : tr(r.message || SAY[r.error] || SAY.busy); msg.className = 'hint ' + (r.ok ? 'ok' : 'bad'); }
    setTimeout(() => render(true), 1800);
  });
}

// ================================================================================================ the staff's panel (03.10.2026)
// site/server/src/admin.rs: the summary, reports and packs (the first moderation, build.py's adminModeration), members,
// crashes by cause, announcements, her switches, roles, the journal. Each tab for those whose roles allow it.

MEMBERS_ONLY.add('news');
const AD = { q: '', qLive: '', days: 7, open: '', msg: '', bad: false, note: '', banWhy: '', banFor: '7d', uid: '', sure: '', pin: { address: '', name: '' }, rcDays: 30, news: { title: '', body: '', site: true, forum: true, game: true, discord: true, everyone: false, telegram: true }, jAction: '', jActor: '' };
const adPerms = () => (state.user && state.user.perms) || [];
const adCan = (p) => !!(state.user && (state.user.admin || adPerms().includes(p)));
const adTabs = () => [
  ['summary', 'Summary', 'Сводка', adCan('staff.panel')],
  ['reports', 'Reports', 'Жалобы', adCan('reports.handle')],
  ['users', 'Members', 'Участники', adCan('users.view')],
  ['crashes', 'Crashes', 'Вылеты', adCan('users.view')],
  ['fps', 'FPS', 'FPS', !!(state.user && state.user.admin)],
  ['news', 'Announcements', 'Объявления', adCan('announce')],
  ['switches', 'Switches', 'Переключатели', !!(state.user && state.user.admin)],
  ['packs', 'Packs', 'Паки', adCan('market.moderate')],
  ['roles', 'Roles', 'Роли', adCan('staff.panel')],
  ['journal', 'Journal', 'Журнал', adCan('audit.view')],
].filter((t) => t[3]);
const adLen = (s) => ({ '1h': L('an hour', 'час'), '1d': L('a day', 'сутки'), '7d': L('a week', 'неделя'), '30d': L('a month', 'месяц'), '': L('for good', 'навсегда') }[s] || s);
const adWhen = (s) => (s ? new Date(s * 1000).toLocaleString(LANG === 'ru' ? 'ru-RU' : 'en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—');
const adNum = (n, label) => `<div class="ad-num"><b class="num">${fmt(n || 0)}</b><span class="ash">${label}</span></div>`;

function viewAdmin(arg) {
  const [tab0, x] = String(arg || '').split('/');
  const tabs = adTabs();
  const tab = tab0 === 'user' ? 'users' : tabs.some((t) => t[0] === tab0) ? tab0 : (tabs[0] || ['summary'])[0];
  let body;
  if (tab0 === 'user' && x) body = adUser(decodeURIComponent(x));
  else body = { summary: adSummary, reports: () => adminModeration('reports'), packs: () => adminModeration(x === 'hidden' ? 'hidden' : 'new'), users: adUsers, crashes: adCrashes, fps: adFps, news: adNews, switches: adSwitches, roles: adRoles, journal: adJournal }[tab]();
  return `<div class="dash">${rail('admin')}<div><h1 class="sr">${L('Staff', 'Персонал')}</h1>
    <div class="acts ad-tabs">${tabs.map((t) => `<a class="w ${t[0] === tab ? 'on' : ''}" href="#/admin/${t[0]}">${L(t[1], t[2])}</a>`).join('')}</div>
    <div class="ad-body">${body}</div>
    <p class="hint ${AD.bad ? 'bad' : 'ok'}" id="ad-msg" role="status">${esc(AD.msg)}</p></div></div>`;
}

function adSummary() {
  const c = ask('admin/summary');
  if (waiting(c)) return ghosts(1);
  if (!c.ok) return trouble(c);
  const d = c.data;
  const builds = d.builds.length ? d.builds.map((b) => `<span class="st ${b.current ? 'ok' : 'cream'}">${b.build ? L('build ', 'сборка ') + b.build : L('unknown build', 'сборка ?')} · <span class="num">${b.people}</span></span>`).join('') : `<span class="ash">${L('Nobody in the game now.', 'Сейчас в игре никого.')}</span>`;
  return `<div class="ad-grid">
      ${adNum(d.accounts, L('accounts', 'аккаунтов'))}${adNum(d.new_day, L('new today', 'новых за сутки'))}${adNum(d.new_week, L('new this week', 'за неделю'))}
      ${adNum(d.online.game, L('in the game now', 'сейчас в игре'))}${adNum(d.online.site, L('on the site now', 'сейчас на сайте'))}${adNum(d.bans, L('banned', 'забанено'))}
    </div>
    <div class="block"><h2 class="sec">${L('Builds in the game', 'Сборки в игре')}${d.current_build ? ` <span class="ash">· ${L('current', 'текущая')} ${d.current_build}</span>` : ''}</h2><div class="acts ad-builds">${builds}</div></div>
    <div class="block"><h2 class="sec">${L('Registration', 'Регистрация')}</h2><p>${d.registration === 'open' ? L('Open', 'Открыта') : L('Closed', 'Закрыта')} · <span class="num">${d.taken} / ${d.limit}</span> ${L('places taken', 'мест занято')}</p></div>
    <div class="ad-grid">
      <a class="ad-num" href="#/support">${'<b class="num">' + fmt(d.tickets.open) + '</b>'}<span class="ash">${L('tickets open', 'тикетов открыто')}</span></a>
      ${adNum(d.tickets.unassigned, L('tickets nobody’s', 'тикетов ничьих'))}${adNum(d.tickets.waiting, L('waiting for authors', 'ждут авторов'))}
      <a class="ad-num" href="#/admin/reports"><b class="num">${fmt(d.reports)}</b><span class="ash">${L('reports', 'жалоб')}</span></a>
      ${adNum(d.chat_reports, L('reports of messages', 'жалоб на сообщения'))}
      <a class="ad-num" href="#/admin/crashes"><b class="num">${fmt(d.crashes_day)}</b><span class="ash">${L('crashes today', 'вылетов за сутки')} · ${fmt(d.crashes_week)} ${L('this week', 'за неделю')}</span></a>
    </div>`;
}

function adUsers() {
  const c = ask('admin/users' + (AD.qLive ? '?q=' + encodeURIComponent(AD.qLive) : ''));
  const rows = waiting(c) ? '<div class="rows"><div>&nbsp;</div></div>' : !c.ok ? trouble(c) : c.data.items.length ? c.data.items.map((u) => `<a class="tk-row" href="#/admin/user/${encodeURIComponent(u.login)}">${head(u.login, 36)}
      <span class="tk-main"><b translate="no">${pfx(u.card)}${esc(u.login)}</b><span class="ash">UID <span class="num" translate="no">${esc(String((u.card && u.card.uid_text) || u.uid))}</span> · ${L('since', 'с')} ${when(u.since)}${u.seen ? ` · ${L('seen', 'был(а)')} ${ago(u.seen)}` : ''}${u.crashes ? ` · ${L('crashes', 'вылетов')} ${u.crashes}` : ''}</span></span>
      ${u.ban ? `<span class="st warn">${L('Banned', 'Бан')}</span>` : u.online ? `<span class="st ok">${L('Online', 'В сети')}</span>` : ''}</a>`).join('') : `<div class="empty">${L('Nobody found.', 'Никого не нашлось.')}</div>`;
  return `<div class="fr-invite ad-search"><input class="in" id="ad-q" type="search" placeholder="${L('Login, #UID or e-mail', 'Логин, #UID или почта')}" value="${esc(AD.q)}"></div><div class="tk-list">${rows}</div>`;
}

function adUser(login) {
  const c = ask('admin/users/' + encodeURIComponent(login));
  if (waiting(c)) return ghosts(1);
  if (!c.ok) return trouble(c);
  const u = c.data, owner = state.user && state.user.admin;
  const kv = (k, v) => `<div><span class="ash">${k}</span><span>${v}</span></div>`;
  const section = (title, inner) => (inner ? `<div class="block"><h2 class="sec">${title}</h2>${inner}</div>` : '');
  // Recode: only hers and the role «Ключи»'s come with it (recode.rs card; theirs lists what they gave); given by hand =
  // a key of its own among the keys (her word, 19.10)
  const rc = u.recode;
  const rcNow = !rc ? '' : rc.forever ? L('Forever', 'Навсегда') + (rc.owner ? L(' (yours)', ' (твоя)') : '') : rc.active ? L('Until ', 'До ') + adWhen(rc.until) : rc.until ? L('Ended ', 'Кончилась ') + adWhen(rc.until) : L('None', 'Нет');
  const recode = rc ? section('Recode', `<p>${rcNow}${rc.keys ? ` <span class="ash">· ${L('keys on it', 'ключей на аккаунте')}: <span class="num">${rc.keys}</span></span>` : ''}</p>
      ${rc.given.map((g) => `<p class="ad-line">${rkTerm(g.days)} <span class="ash">— ${L('given', 'выдано')} ${adWhen(g.at)}, ${g.by ? `<span translate="no">${esc(g.by.login)}</span>` : L('from the console', 'из консоли')} · <span class="num" translate="no">…${esc(g.key)}</span></span></p>`).join('')}
      <div class="acts ad-acts"><select class="in small-select" id="ad-rc-days">${RK_TERMS.map((t) => `<option value="${t}" ${AD.rcDays === t ? 'selected' : ''}>${rkTerm(t)}</option>`).join('')}</select><button class="w small" data-ad-rc-give="1">${L('Give', 'Выдать')}</button>
        ${rc.given.length ? `<button class="w small bad" data-ad-rc-take="1">${AD.sure === 'rc-take' ? L('Take it all back?', 'Забрать всё выданное?') : L('Take back what was given', 'Забрать выданное')}</button>` : ''}</div>
      ${rc.can_revoke_all && rc.keys ? `<div class="acts"><button class="w small bad" data-ad-rc-revoke-all="1">${AD.sure === 'rc-revoke-all:' + login ? L('Revoke all purchases and gifts?', 'Отозвать все покупки и выдачи?') : L('Revoke subscription', 'Отозвать подписку')}</button></div>` : ''}
      <p class="hint">${L('What is given here is a key of its own among the keys. Taking back takes only what was given by hand: keys bought stay.', 'Выданное здесь — отдельный ключ в «Ключах». «Забрать» снимает только выданное вручную, купленные ключи остаются.')}</p>`) : '';
  const ban = u.ban ? `<p class="st warn">${L('Banned', 'Забанен(а)')}: <span translate="no">${esc(u.ban.reason)}</span> · ${u.ban.until ? L('until ', 'до ') + adWhen(u.ban.until) : L('for good', 'навсегда')}</p>` : '';
  const actions = `<div class="acts ad-acts">
      ${adCan('users.ban') ? (u.ban ? `<button class="w small" data-ad-unban="1">${L('Lift the ban', 'Снять бан')}</button>` : `<span class="ad-ban"><input class="in" id="ad-ban-why" maxlength="200" placeholder="${L('Why (they see it)', 'Причина (человек увидит)')}" value="${esc(AD.banWhy)}">
        <select class="in small-select" id="ad-ban-for">${['1h', '1d', '7d', '30d', ''].map((k) => `<option value="${k}" ${AD.banFor === k ? 'selected' : ''}>${adLen(k)}</option>`).join('')}</select><button class="w small" data-ad-ban="1">${L('Ban', 'Забанить')}</button></span>`) : ''}
      ${adCan('users.ban') ? `<button class="w small" data-ad-reset="1">${L('Password reset link', 'Ссылка для сброса пароля')}</button>` : ''}
      ${adCan('users.device') && u.device ? `<button class="w small" data-ad-device="1">${AD.sure === 'device' ? L('Free it?', 'Сбросить?') : L('Free the computer', 'Сбросить привязку')}</button>` : ''}
      ${owner ? `<span class="ad-uid"><input class="in num" id="ad-uid" maxlength="16" autocomplete="off" spellcheck="false" placeholder="${L('UID or text', 'UID или текст')}" title="${L('A number moves the account; text is shown instead of it; a dash brings the number back.', 'Число переносит аккаунт; текст показывается вместо номера; прочерк возвращает номер.')}" value="${esc(AD.uid)}" style="max-width:150px"><button class="w small" data-ad-uid="1">${L('Give this UID', 'Сменить UID')}</button></span>` : ''}
      ${owner ? `<button class="w small bad" data-ad-delete="1">${AD.sure === 'delete' ? L('Delete for good?', 'Удалить насовсем?') : L('Delete the account', 'Удалить аккаунт')}</button>` : ''}
    </div>${AD.resetLink && AD.resetFor === u.login ? `<div class="ad-reset"><input class="in" readonly value="${esc(AD.resetLink)}" aria-label="${L('Reset link', 'Ссылка для сброса')}"><button class="w small lead" data-copy="${esc(AD.resetLink)}">${L('Copy', 'Скопировать')}</button>
      <p class="hint">${L('Works once, for a day. Give it to them yourself; it is in the journal.', 'Сработает один раз, действует сутки. Передайте человеку сами — это записано в журнал.')}</p></div>` : ''}`;
  return `<div class="crumb"><a href="#/admin/users">${L('Members', 'Участники')}</a> / <span translate="no">${esc(u.login)}</span></div>
    <div class="ad-user-head">${head(u.login, 64)}<div><h2 class="big" translate="no">${pfx(u.card)}${esc(u.login)}</h2>
      <p class="ash">UID <span class="num" translate="no">${esc(String((u.card && u.card.uid_text) || u.uid))}</span>${u.card && u.card.uid_text ? ` <span class="num">(${u.uid})</span>` : ''} · ${L('since', 'с')} ${when(u.since)}${u.email ? ` · <span translate="no">${esc(u.email)}</span>` : ''} · <a href="${profHref(u.login)}">${L('Profile', 'Профиль')}</a></p></div></div>
    ${ban}${u.mute ? `<p class="st cream">${L('Muted on the forum until', 'Мут на форуме до')} ${adWhen(u.mute.until)}: <span translate="no">${esc(u.mute.why)}</span></p>` : ''}
    ${actions}
    <div class="block"><div class="kv ad-kv">
      ${kv(L('Roles', 'Роли'), esc((u.roles || []).join(', ') || '—'))}
      ${kv(L('Computer', 'Компьютер'), u.device ? `${L('bound', 'привязан')} ${when(u.device.bound)} · ${ago(u.device.seen)}` : L('none', 'нет'))}
      ${kv(L('Online', 'В сети'), u.online ? L('now', 'сейчас') : u.seen ? ago(u.seen) : '—')}
      ${kv(L('Sessions', 'Входов'), u.sessions)}${kv(L('Posts', 'Постов'), u.posts)}${kv(L('Hours in the game', 'Часов в игре'), u.game_hours)}
      ${kv(L('Tester', 'Тестер'), u.tester ? L('yes', 'да') : L('no', 'нет'))}
    </div></div>
    ${recode}
    ${section(L('The staff’s notes', 'Заметки персонала'), `<div class="fr-invite"><input class="in" id="ad-note" maxlength="2000" placeholder="${L('Something to remember about them', 'Что стоит помнить о человеке')}" value="${esc(AD.note)}"><button class="w small" data-ad-note="1">${L('Keep', 'Сохранить')}</button></div>
      ${u.notes.map((n) => `<p class="ad-line"><span translate="no">${esc(n.text)}</span> <span class="ash">— ${esc(n.by && n.by.login || '?')}, ${ago(n.at)}</span></p>`).join('')}`)}
    ${section(L('Warnings', 'Предупреждения'), u.warnings.map((w) => `<p class="ad-line"><span translate="no">${esc(w.why)}</span> <span class="ash">— ${esc(w.by && w.by.login || '?')}, ${ago(w.at)}</span></p>`).join(''))}
    ${section(L('Bans', 'Баны'), (u.bans || []).map((b) => `<p class="ad-line"><span translate="no">${esc(b.reason)}</span> <span class="ash">— ${esc(b.by)}, ${adWhen(b.at)}${b.until ? ' → ' + adWhen(b.until) : ''}${b.lifted ? ` · ${L('lifted', 'снят')} ${adWhen(b.lifted)}` : ''}</span></p>`).join(''))}
    ${section(L('Tickets', 'Тикеты'), u.tickets.map((t) => `<p class="ad-line"><a href="#/support/t/${t.id}" translate="no">${esc(t.title)}</a> <span class="ash">· ${t.state} · ${ago(t.updated)}</span></p>`).join(''))}
    ${section(L('Crashes', 'Вылеты'), u.crash_list.map((k) => `<p class="ad-line"><a href="/api/admin/crashes/${k.id}" target="_blank" rel="noopener">${esc(k.cause)}</a> <span class="ash">· ${k.build ? L('build ', 'сборка ') + k.build + ' · ' : ''}${ago(k.at)}</span></p>`).join(''))}
    ${section(L('What the staff did', 'Что делал персонал'), u.history.map((h) => `<p class="ad-line"><b>${esc(h.action)}</b> <span class="ash">— ${esc(h.by && h.by.login || '?')}, ${ago(h.at)}</span></p>`).join(''))}`;
}

function adCrashes() {
  const c = ask(`admin/crashes?days=${AD.days}`);
  const days = [1, 7, 30, 90].map((d) => `<button class="w small ${AD.days === d ? 'on' : ''}" data-ad-days="${d}">${d === 1 ? L('a day', 'сутки') : d + L(' days', ' дн.')}</button>`).join('');
  if (waiting(c)) return `<div class="acts">${days}</div>${ghosts(1)}`;
  if (!c.ok) return trouble(c);
  const g = c.data.groups;
  return `<div class="acts">${days}<span class="gap"></span><span class="ash">${L('crashes', 'вылетов')}: <span class="num">${c.data.total}</span></span></div>
    <div class="tk-list">${g.length ? g.map((x, i) => `<div class="ad-crash"><button class="ad-crash-head" data-ad-open="${i}"><b class="num">${x.count}</b><span class="tk-main"><b translate="no">${esc(x.cause)}</b>
        <span class="ash">${x.people} ${L('people', 'чел.')} · ${x.builds.length ? L('builds ', 'сборки ') + x.builds.join(', ') : L('build ?', 'сборка ?')} · ${ago(x.last)}</span>
        ${x.gpus.length ? `<span class="ash" translate="no">${esc(x.gpus.join(' · '))}</span>` : ''}</span></button>
        ${AD.open === String(i) ? `<div class="acts ad-crash-list">${x.crashes.map((id) => `<a class="w small" href="/api/admin/crashes/${id}" target="_blank" rel="noopener">#${id}</a>`).join('')}</div>` : ''}</div>`).join('') : `<div class="empty">${L('No crashes. Good.', 'Вылетов нет.')}</div>`}</div>`;
}

// The players' frame rate (fps.rs, her word 19.10): each player once, their own median first. Hers alone.
function adFps() {
  const c = ask(`admin/fps?days=${Math.min(AD.days, 30)}`);
  const days = [1, 7, 30].map((d) => `<button class="w small ${Math.min(AD.days, 30) === d ? 'on' : ''}" data-ad-days="${d}">${d === 1 ? L('a day', 'сутки') : d + L(' days', ' дн.')}</button>`).join('');
  if (waiting(c)) return `<div class="acts">${days}</div>${ghosts(1)}`;
  if (!c.ok) return trouble(c);
  const d = c.data;
  if (!d.reports) return `<div class="acts">${days}</div><div class="empty">${L('No reports yet: the game sends one in four minutes of play, from the build with them on.', 'Отчётов пока нет: игра присылает их каждые 4 минуты игры, начиная со сборки, где это есть.')}</div>`;
  const fig = (f) => `<span class="num">${f.players}</span> ${L('players', 'игр.')} · ${L('FPS', 'FPS')} <b class="num">${f.avg}</b> · 1% low <span class="num">${f.low}</span> · ${L('under 60', 'ниже 60')}: <span class="num">${f.under60}</span> · ${L('under 30', 'ниже 30')}: <span class="num">${f.under30}</span>`;
  const row = (label, f) => (f.players ? `<p class="ad-line"><b>${label}</b> <span class="ash">· ${fig(f)}</span></p>` : '');
  const tier = { integrated: L('integrated graphics', 'встроенная графика'), old: L('old and small cards', 'старые и слабые карты'), middle: L('middle (GTX 1060–1660, RX 580)', 'средние (GTX 1060–1660, RX 580)'), modern: L('modern (RTX, RX 6600+)', 'современные (RTX, RX 6600+)'), unknown: L('unknown', 'неизвестно') };
  const light = [L('weak PC, no light settings', 'слабый ПК, без лёгкого режима'), L('weak PC, light settings on', 'слабый ПК, лёгкий режим'), L('weak PC, put back', 'слабый ПК, вернули как было')];
  const slow = d.slowest.map((p) => `<p class="ad-line"><b translate="no">${pfx(p.card)}${esc(p.card.login || '')}</b> <span class="ash">· FPS <b class="num">${p.avg}</b> · 1% low <span class="num">${p.low}</span> · ${L('hitches an hour', 'рывков в час')} <span class="num">${p.hitches_hour}</span></span><br>
      <span class="ash" translate="no">${esc((p.gpu || '?').replace('/PCIe/SSE2', ''))} · ${esc(p.cpu || '?')} · ${p.threads} ${L('threads', 'пот.')} · ${p.ram} ${L('GB', 'ГБ')} · ${L('the game gets', 'игре дано')} ${Math.round(p.xmx / 102.4) / 10} ${L('GB', 'ГБ')} · ${p.screen} · ${L('distance', 'дальн.')} ${p.rd}${p.shaders ? ' · ' + L('shaders', 'шейдеры') : ''}${p.optimization ? ' · Optimization' : ''}${p.light === 1 ? ' · ' + L('light', 'лёгкий') : p.light === 2 ? ' · ' + L('put back', 'вернул') : ''} · ${esc(p.server || L('single player', 'одиночная'))} · ${L('build ', 'сборка ')}${p.build} · ${ago(p.at)}</span></p>`).join('');
  return `<div class="acts">${days}<span class="gap"></span><span class="ash">${L('reports', 'отчётов')}: <span class="num">${fmt(d.reports)}</span> · ${L('hours', 'часов')}: <span class="num">${d.hours}</span></span></div>
    <div class="ad-grid">${adNum(d.all.players, L('players', 'игроков'))}${adNum(d.all.avg, L('median FPS', 'медиана FPS'))}${adNum(d.all.low, L('median 1% low', 'медиана 1% low'))}${adNum(d.all.under60, L('under 60 FPS', 'ниже 60 FPS'))}${adNum(d.all.under30, L('under 30 FPS', 'ниже 30 FPS'))}</div>
    <div class="block"><h2 class="sec">${L('By build', 'По сборкам')}</h2>${d.builds.map((b) => row(L('build ', 'сборка ') + b.build, b.figures)).join('')}</div>
    <div class="block"><h2 class="sec">${L('By video card', 'По видеокартам')}</h2>${d.tiers.map((x) => row(tier[x.tier], x.figures)).join('')}</div>
    <div class="block"><h2 class="sec">${L('Light settings', 'Лёгкий режим')}</h2>${d.light.map((x) => row(light[x.light], x.figures)).join('') || `<p class="ash">${L('No weak PCs reported yet.', 'Слабых ПК в отчётах пока нет.')}</p>`}</div>
    <div class="block"><h2 class="sec">${L('By memory', 'По памяти')}</h2>${d.ram.map((x) => row(x.ram + L(' GB', ' ГБ'), x.figures)).join('')}</div>
    <div class="block"><h2 class="sec">${L('Cards', 'Видеокарты')}</h2>${d.gpus.map((x) => row(`<span translate="no">${esc(x.gpu || '?')}</span>`, x.figures)).join('')}</div>
    <div class="block"><h2 class="sec">${L('Slowest players', 'Самые низкие FPS')}</h2>${slow}</div>`;
}

function adNews() {
  const n = AD.news, c = ask('admin/announcements');
  const box = (k, en, ru) => `<label class="tk-check"><input type="checkbox" data-ad-to="${k}" ${n[k] ? 'checked' : ''}> ${L(en, ru)}</label>`;
  const list = !c.ok ? '' : c.data.items.map((a) => `<div class="ad-line ad-news-row"><b translate="no">${esc(a.title)}</b> <span class="ash">· ${adWhen(a.at)} · ${esc(a.by && a.by.login || '')}</span>
      <span class="ad-where">${[a.targets.site && L('site', 'сайт'), a.targets.forum && (a.thread ? `<a href="#/forum/t/${a.thread}">${L('forum', 'форум')}</a>` : L('forum', 'форум')), a.targets.game && L('game', 'игра'),
        a.targets.discord && (a.discord_at ? 'Discord ✓' : L('Discord: the bot has not taken it yet', 'Discord: бот ещё не взял')), a.targets.telegram && (a.telegram_at ? 'Telegram ✓' : L('Telegram: waiting for the bot', 'Telegram: ждёт бота'))].filter(Boolean).join(' · ')}${a.error ? ` · <span class="bad">${esc(a.error)}</span>` : ''}</span></div>`).join('');
  return `<div class="form" style="max-width:760px">
      <div><label class="lab" for="ad-n-title">${L('Title', 'Заголовок')}</label><input class="in" id="ad-n-title" maxlength="120" value="${esc(n.title)}"></div>
      <div><label class="lab" for="ad-n-body">${L('Text', 'Текст')}</label>${editor('ad-n-body', n.body, 8)}</div>
      <div class="acts ad-to">${box('site', 'The site’s news', 'Новости сайта')}${box('forum', 'The forum’s announcements', 'Форум: объявления')}${box('game', 'Everyone in the client (a notification)', 'Всем в клиенте (уведомление)')}
        ${box('discord', 'Three Discord servers', 'Три Discord-сервера')}${n.discord ? box('everyone', '…with @everyone', '…с @everyone') : ''}${box('telegram', 'Telegram (to you, to forward)', 'Telegram (тебе, переслать)')}</div>
      <div class="acts"><button class="w menu lead" id="ad-announce" data-submit-for="ad-n-body">${L('Announce', 'Опубликовать')}</button></div></div>
    <div class="block" style="margin-top:34px"><h2 class="sec">${L('Announced', 'Опубликованные')}</h2>${list || `<p class="ash">${L('Nothing yet.', 'Пока ничего.')}</p>`}</div>`;
}

function adSwitches() {
  const reg = ask('admin/switch/registration'), pins = ask('admin/pinned'), builds = ask('admin/builds');
  const r = reg.ok ? reg.data : null;
  return `<div class="block"><h2 class="sec">${L('Registration', 'Регистрация')}</h2>${r ? `<p>${r.state === 'open' ? L('Open', 'Открыта') : L('Closed', 'Закрыта')} · <span class="num">${r.taken} / ${r.limit}</span></p>
      <div class="acts"><button class="w small" data-ad-reg="${r.state === 'open' ? 'closed' : 'open'}">${r.state === 'open' ? L('Close', 'Закрыть') : L('Open', 'Открыть')}</button>
      <span class="fr-invite"><input class="in num" id="ad-limit" type="number" min="0" value="${r.limit}" style="max-width:110px"><button class="w small" data-ad-limit="1">${L('Set the limit', 'Поставить лимит')}</button></span></div>` : trouble(reg)}</div>
    <div class="block"><h2 class="sec">${L('Partners pinned in the client’s servers', 'Партнёры наверху списка серверов')}</h2>
      ${pins.ok ? pins.data.items.filter((p) => !p.gone).map((p) => `<p class="ad-line"><b translate="no">${esc(p.name)}</b> <span class="ash" translate="no">${esc(p.address)}</span> <button class="w small" data-ad-unpin="${esc(p.address)}">${L('Unpin', 'Убрать')}</button></p>`).join('') || `<p class="ash">${L('None.', 'Нет.')}</p>` : ''}
      <div class="fr-invite"><input class="in" id="ad-pin-address" placeholder="mc.server.net" value="${esc(AD.pin.address)}"><input class="in" id="ad-pin-name" placeholder="${L('Its name', 'Название')}" value="${esc(AD.pin.name)}"><button class="w small" data-ad-pin="1">${L('Pin', 'Закрепить')}</button></div>
      <p class="hint">${L('It reaches every player with the blocklist, within a quarter of an hour.', 'Доходит до всех игроков вместе с чёрным списком, в течение четверти часа.')}</p></div>
    <div class="block"><h2 class="sec">${L('Builds', 'Сборки')}</h2>${builds.ok ? builds.data.items.map((b) => `<p class="ad-line">${b.current ? '<span class="st ok">' + L('current', 'текущая') + '</span> ' : ''}<b>${L('build', 'сборка')} ${b.build}</b> <span class="ash">· ${esc(b.version)} · ${adWhen(b.at)} · ${b.files} ${L('files', 'файлов')} · ${mb(b.bytes)}</span></p>`).join('') || `<p class="ash">${L('None yet.', 'Пока нет.')}</p>` : ''}
      ${builds.ok && builds.data.items.length > 1 ? `<div class="acts"><button class="w small bad" data-ad-rollback="1">${AD.sure === 'rollback' ? L('Roll back for everyone?', 'Откатить у всех?') : L('Roll back to the build before', 'Откатить на прошлую сборку')}</button></div>` : ''}
      <p class="hint">${L('New builds are published from the computer (tools/Release.java), after the list of changes is agreed.', 'Новые сборки выкладываются с компьютера (tools/Release.java), после согласования списка изменений.')}</p></div>`;
}

function adRoles() {
  const c = ask('admin/roles');
  if (waiting(c)) return ghosts(1);
  if (!c.ok) return trouble(c);
  const roles = c.data.roles.filter((r) => r.staff || ['media', 'partner'].includes(r.id));
  const has = (r, p) => r.perms.includes('*') || r.perms.includes(p);
  return `<div class="scroll-x"><table class="np ad-roles"><thead><tr><th></th>${roles.map((r) => `<th><span class="pfx" style="--c:${esc(r.colour)}">${esc(r.prefix)}</span></th>`).join('')}</tr></thead><tbody>
      ${c.data.perms.map((p) => `<tr><td translate="no">${esc(p)}</td>${roles.map((r) => `<td>${has(r, p) ? '<span class="cream">●</span>' : '<span class="ash">·</span>'}</td>`).join('')}</tr>`).join('')}
    </tbody></table></div>
    ${roles.map((r) => `<div class="block"><h2 class="sec"><span class="pfx" style="--c:${esc(r.colour)}">${esc(r.prefix)}</span> ${L(r.en, r.ru)} <span class="ash num">${r.id === 'creator' ? 1 : r.count}</span></h2>
      <p>${r.people.map((p) => nm(p)).join(' · ') || `<span class="ash">${L('Nobody.', 'Никого.')}</span>`}</p></div>`).join('')}
    <p class="hint">${L('Roles are given on a member’s profile.', 'Роли выдаются на странице профиля участника.')}</p>`;
}

function adJournal() {
  const q = [AD.jAction && 'action=' + encodeURIComponent(AD.jAction), AD.jActor && 'actor=' + encodeURIComponent(AD.jActor)].filter(Boolean).join('&');
  const c = ask('admin/journal' + (q ? '?' + q : ''));
  const rows = waiting(c) ? '<div class="rows"><div>&nbsp;</div></div>' : !c.ok ? trouble(c) : c.data.items.map((x) => `<p class="ad-line"><span class="ash">${adWhen(x.at)}</span> ${nm(x.by)} <b translate="no">${esc(x.action)}</b>
      ${x.person ? nm(x.person) : x.target ? `<span class="ash" translate="no">${esc(x.target)}</span>` : ''}${x.details && (x.details.reason || x.details.why || x.details.title) ? ` <span class="ash" translate="no">· ${esc(x.details.reason || x.details.why || x.details.title)}</span>` : ''}</p>`).join('') || `<p class="ash">${L('Nothing.', 'Пусто.')}</p>`;
  return `<div class="fr-invite ad-search"><input class="in" id="ad-j-action" placeholder="${L('Action: user., forum., ticket.…', 'Действие: user., forum., ticket.…')}" value="${esc(AD.jAction)}"><input class="in" id="ad-j-actor" placeholder="${L('Who: a login', 'Кто: логин')}" value="${esc(AD.jActor)}"><button class="w small" id="ad-j-go">${L('Show', 'Показать')}</button></div><div class="ad-journal">${rows}</div>`;
}

// The site's news (what was announced for it).
function viewNews() {
  const c = ask('news');
  const items = waiting(c) ? ghosts(1) : !c.ok ? trouble(c) : c.data.items.map((a) => `<article class="ad-article"><p class="ash">${when(a.at)}</p><h2 class="big" translate="no">${esc(a.title)}</h2>
      <div class="prose post-body" translate="no">${prose(a.body)}</div>${a.thread ? `<div class="acts"><a class="w small" href="#/forum/t/${a.thread}">${L('Discuss on the forum', 'Обсудить на форуме')}</a></div>` : ''}</article>`).join('') || `<div class="empty">${L('No news yet.', 'Новостей пока нет.')}</div>`;
  return `<div class="page-head"><h1 class="giant">${L('News', 'Новости')}</h1></div><div class="ad-news">${items}</div>`;
}

function adminWire() {
  if (state.route !== 'admin' && state.route !== 'news') return;
  const on = (sel, ev, fn) => $app.querySelectorAll(sel).forEach((el) => bindOnce(el, ev, 'w9|' + sel, (e) => fn(el, e)));
  const login = () => decodeURIComponent(String(state.arg).split('/')[1] || '');
  const said = (r, ok) => { AD.bad = !r.ok; AD.msg = r.ok ? ok || '' : tr(r.message || SAY[r.error] || (r.error === 'owner' ? 'Only she may.' : r.error === 'staff' ? 'Your role does not allow it.' : SAY.busy)); };
  const again = (...p) => { forget(...p); render(true); };
  foEditorsWire(on);
  let timer = 0;
  on('#ad-q', 'input', (el) => { AD.q = el.value; clearTimeout(timer); timer = setTimeout(() => { AD.qLive = AD.q.trim(); render(true); }, 300); });
  on('#ad-note', 'input', (el) => { AD.note = el.value; });
  on('#ad-ban-why', 'input', (el) => { AD.banWhy = el.value; });
  on('#ad-ban-for', 'change', (el) => { AD.banFor = el.value; });
  on('#ad-uid', 'input', (el) => { AD.uid = el.value; });
  on('#ad-rc-days', 'change', (el) => { AD.rcDays = Number(el.value); });
  on('[data-ad-rc-give]', 'click', async () => {
    const r = await api(`admin/users/${encodeURIComponent(login())}/recode`, { days: AD.rcDays });
    said(r, r.ok ? (r.data.forever ? L('Given: Recode forever.', 'Выдано: Recode навсегда.') : L(`Given: Recode until ${adWhen(r.data.until)}.`, `Выдано: Recode до ${adWhen(r.data.until)}.`)) : '');
    again('admin/users', 'admin/keys');
  });
  on('[data-ad-rc-revoke-all]', 'click', async () => {
    const target = login(), confirmation = 'rc-revoke-all:' + target;
    if (AD.sure !== confirmation) { AD.sure = confirmation; render(true); return; }
    AD.sure = '';
    const r = await api(`admin/users/${encodeURIComponent(target)}/recode/all`, null, 'DELETE');
    said(r, r.ok ? L('Subscription revoked.', 'Подписка отозвана.') : '');
    again('admin/users', 'admin/keys');
  });
  on('[data-ad-rc-take]', 'click', async () => {
    if (AD.sure !== 'rc-take') { AD.sure = 'rc-take'; render(true); return; }
    AD.sure = '';
    const r = await api(`admin/users/${encodeURIComponent(login())}/recode`, null, 'DELETE');
    said(r, r.ok ? L(`Taken back: ${r.data.taken}.`, `Забрано: ${r.data.taken}.`) : '');
    again('admin/users', 'admin/keys');
  });
  on('[data-ad-note]', 'click', async () => { const r = await api(`admin/users/${encodeURIComponent(login())}/notes`, { text: AD.note }); if (r.ok) AD.note = ''; said(r); again('admin/users'); });
  on('[data-ad-ban]', 'click', async () => { const r = await api(`admin/users/${encodeURIComponent(login())}/ban`, { reason: AD.banWhy, length: AD.banFor }); if (r.ok) AD.banWhy = ''; said(r, L('Banned: it works from their next start.', 'Забанен(а): действует со следующего запуска.')); again('admin/users'); });
  on('[data-ad-unban]', 'click', async () => { const r = await api(`admin/users/${encodeURIComponent(login())}/ban`, null, 'DELETE'); said(r, L('The ban is lifted.', 'Бан снят.')); again('admin/users'); });
  on('[data-ad-reset]', 'click', async () => {
    const r = await api(`admin/users/${encodeURIComponent(login())}/reset-link`, {});
    if (r.ok) { AD.resetLink = r.data.link; AD.resetFor = login(); AD.msg = ''; render(true); } else { said(r); render(true); }
  });
  on('[data-ad-device]', 'click', async () => {
    if (AD.sure !== 'device') { AD.sure = 'device'; render(true); return; }
    AD.sure = '';
    const r = await api(`admin/users/${encodeURIComponent(login())}/device`, {}); said(r, L('Freed.', 'Привязка сброшена.')); again('admin/users');
  });
  on('[data-ad-uid]', 'click', async () => { const v = AD.uid.trim(), text = !/^\d+$/.test(v); const r = await api(`admin/users/${encodeURIComponent(login())}/uid`, text ? { text: v === '-' ? '' : v } : { to: Number(v) }); if (r.ok) AD.uid = ''; said(r, r.ok ? (text ? L(`UID ${r.data.from} is shown as ${r.data.uid_text || r.data.from}.`, `UID ${r.data.from} теперь показывается как ${r.data.uid_text || r.data.from}.`) : L(`UID ${r.data.from} → ${r.data.to}.`, `UID ${r.data.from} → ${r.data.to}.`)) : ''); again('admin/users', 'u/'); });
  on('[data-ad-delete]', 'click', async () => {
    if (AD.sure !== 'delete') { AD.sure = 'delete'; render(true); return; }
    AD.sure = '';
    const r = await api(`admin/users/${encodeURIComponent(login())}`, null, 'DELETE'); said(r, L('Deleted: the place is free.', 'Удалён: место свободно.'));
    forget('admin/users'); if (r.ok) location.hash = '#/admin/users'; else render(true);
  });
  on('[data-ad-days]', 'click', (b) => { AD.days = Number(b.dataset.adDays); AD.open = ''; render(true); });
  on('[data-ad-open]', 'click', (b) => { AD.open = AD.open === b.dataset.adOpen ? '' : b.dataset.adOpen; render(true); });
  on('#ad-n-title', 'input', (el) => { AD.news.title = el.value; });
  on('#ad-n-body', 'input', (el) => { AD.news.body = el.value; });
  on('[data-ad-to]', 'change', (el) => { AD.news[el.dataset.adTo] = el.checked; if (el.dataset.adTo === 'discord') render(true); });
  on('#ad-announce', 'click', async (b) => {
    if (AD.sure !== 'announce') { AD.sure = 'announce'; b.textContent = L('Send it everywhere checked?', 'Отправить везде, где отмечено?'); return; }
    AD.sure = '';
    const n = AD.news;
    const r = await api('admin/announcements', { title: n.title, body: n.body, site: n.site, forum: n.forum, game: n.game, discord: n.discord, everyone: n.everyone, telegram: n.telegram });
    if (r.ok) { n.title = ''; n.body = ''; }
    said(r, L('Announced. The bot takes Discord and Telegram within a minute.', 'Опубликовано. Discord и Telegram бот заберёт в течение минуты.'));
    again('admin/announcements', 'news', 'forum');
  });
  on('[data-ad-reg]', 'click', async (b) => { const r = await api('admin/switch/registration', { state: b.dataset.adReg }); said(r); again('admin/'); });
  on('[data-ad-limit]', 'click', async () => { const r = await api('admin/switch/registration', { limit: Number((document.getElementById('ad-limit') || {}).value) }); said(r); again('admin/'); });
  on('#ad-pin-address', 'input', (el) => { AD.pin.address = el.value; });
  on('#ad-pin-name', 'input', (el) => { AD.pin.name = el.value; });
  on('[data-ad-pin]', 'click', async () => { const r = await api('admin/pinned', AD.pin); if (r.ok) AD.pin = { address: '', name: '' }; said(r, L('Pinned.', 'Закреплён.')); again('admin/pinned'); });
  on('[data-ad-unpin]', 'click', async (b) => { const r = await api(`admin/pinned/${encodeURIComponent(b.dataset.adUnpin)}`, null, 'DELETE'); said(r); again('admin/pinned'); });
  on('[data-ad-rollback]', 'click', async () => {
    if (AD.sure !== 'rollback') { AD.sure = 'rollback'; render(true); return; }
    AD.sure = '';
    const r = await api('admin/builds/rollback', { channel: 'beta' }); said(r, r.ok ? L(`Everyone is on build ${r.data.build} again.`, `Все снова на сборке ${r.data.build}.`) : ''); again('admin/builds');
  });
  on('#ad-j-action', 'input', (el) => { AD.jAction = el.value; });
  on('#ad-j-actor', 'input', (el) => { AD.jActor = el.value; });
  on('#ad-j-go', 'click', () => render(true));
}


// ================================================================================================ referral links (09.10.2026)
// site/server/src/refs.rs. Media, partners and admins: their links (the personal one, their login; and their own, one
// for each place they put a link up), what each brought — the people who opened it, the accounts made by it, who of
// them started the game, played this week, is in it now — by the hour today or by the day, and who came. Admins:
// everyone's, against the accounts made without a link. A visitor's code is kept for 30 days (refCatch) and handed in
// with the registration; the registration page shows the owner of a personal link ("an invitation from …").

const RF = { days: 30, link: 0, make: false, name: '', code: '', codeTouched: false, msg: '', bad: false, edit: 0, editName: '', sure: 0, more: null, moreKey: '', moreLeft: false, drawn: '', shown: {}, fresh: 0 };
const REF_KEY = 'cursed.ref';
const REF_DAYS = 30;
const RF_PERIODS = [[1, 'Today', 'Сегодня'], [7, '7 days', '7 дней'], [30, '30 days', '30 дней'], [0, 'All time', 'Всё время']];
const rfCan = () => !!(state.user && (state.user.admin || (state.user.perms || []).includes('refs.own') || (state.user.perms || []).includes('refs.all')));
const rfAll = () => !!(state.user && (state.user.admin || (state.user.perms || []).includes('refs.all')));
/** The dashboard's rail: the page, for those who have links. */
const refsRail = (link) => (rfCan() ? link('refs', L('Referrals', 'Рефералы')) : '');

// ---- the visitor: the code kept, given with the registration

/** /?ref=<code> (nginx sends /r/<code> here): the visit counted, the code kept for the registration, the address cleaned. */
function refCatch() {
  let code = '';
  try { code = new URLSearchParams(location.search).get('ref') || ''; } catch (e) { return; }
  if (!code) return;
  try { history.replaceState(null, '', location.pathname + location.hash); } catch (e) { /* the address stays */ }
  code = code.trim().toLowerCase().slice(0, 24);
  api('ref/hit', { code }).then((r) => {
    if (!r.ok) return;
    try { localStorage.setItem(REF_KEY, JSON.stringify({ code: r.data.code, at: Date.now(), by: r.data.by || null })); } catch (e) { /* not kept */ }
    if (state.route === 'register') render(true);
  });
}
function refStored() {
  try {
    const r = JSON.parse(localStorage.getItem(REF_KEY) || 'null');
    return r && r.code && Date.now() - r.at < REF_DAYS * 864e5 ? r : null;
  } catch (e) { return null; }
}
const refCode = () => (refStored() || {}).code || '';
function refDone() { try { localStorage.removeItem(REF_KEY); } catch (e) { /* nothing kept */ } }
/** Above the registration form: whose personal link brought them. */
function refInvite() {
  const r = refStored();
  if (!r || !r.by) return '';
  const p = r.by;
  learnAv(p);
  return `<p class="rf-invite">${head(p.login, 34)}<span><span class="ash">${L('An invitation from', 'Приглашение от')}</span> ${pfx(p)}<b translate="no"${p.accent ? ` style="color:${esc(p.accent)}"` : ''}>${esc(p.login)}</b></span></p>`;
}

// ---- pieces

const rfPct = (a, b) => (b ? Math.min(100, Math.round((100 * a) / b)) + '%' : '—');
const rfHost = (base) => String(base || '').replace(/^https?:\/\//, '');
const rfName = (l) => (l.main ? L('Personal', 'Личная') : esc(l.name));
const rfMsk = { timeZone: 'Europe/Moscow' };
const rfDay = (t, o) => new Date(t * 1000).toLocaleDateString(L('en-GB', 'ru-RU'), { ...rfMsk, ...o });
const rfWhen = (t) => new Date(t * 1000).toLocaleString(L('en-GB', 'ru-RU'), { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
/** A number tile: the value counts up to itself the first time it shows or changes. */
const rfNum = (key, n, label, sub, lead, unit) => `<div class="rf-num ${lead ? 'lead' : ''}"><b class="num" data-rf-to="${n}" data-rf-key="${key}" data-rf-unit="${unit || ''}">${fmt(RF.shown[key] === undefined ? 0 : RF.shown[key])}${unit || ''}</b><span>${label}</span>${sub ? `<span class="ash s">${sub}</span>` : ''}</div>`;
const rfCopy = (url, word) => `<button class="w small ${word ? 'lead' : ''}" data-rf-copy="${esc(url)}">${word || L('Copy', 'Копировать')}</button>`;
const rfPeriods = () => `<div class="acts rf-days" role="group" aria-label="${L('Period', 'Период')}">${RF_PERIODS.map(([d, en, ru]) => `<button class="w small ${RF.days === d ? 'on' : ''}" data-rf-days="${d}">${L(en, ru)}</button>`).join('')}</div>`;
const rfTop = (scope) => `<div class="rf-top">${rfAll() ? `<nav class="acts rf-scope" aria-label="${L('Whose links', 'Чьи ссылки')}"><a class="w ${scope === 'mine' ? 'on' : ''}" href="#/dashboard/refs">${L('My links', 'Мои ссылки')}</a><a class="w ${scope === 'mine' ? '' : 'on'}" href="#/dashboard/refs/all">${L('Everyone', 'Все')}</a></nav>` : '<span></span>'}${rfPeriods()}</div>`;
const rfGhost = (scope) => `<h1 class="sr">${L('Referrals', 'Рефералы')}</h1><div class="rf">${rfTop(scope)}<div class="ghost-rows"><div></div><div></div><div></div></div></div>`;
/** A row's numbers; on a phone each says what it is (the table's head is hidden there). */
const rfCells = (n) => [[n.people, L('Opened', 'Открыли')], [n.regs, L('Registered', 'Регистрации')], [n.played, L('Played', 'Играли')]].map(([v, l]) => `<td class="r num" data-l="${l}">${fmt(v)}</td>`).join('')
  + `<td class="r num ash" data-l="${L('Conversion', 'Конверсия')}">${rfPct(n.regs, n.people)}</td>`;
const rfSum = (lists) => { const out = []; for (const a of lists) a.forEach((v, i) => { out[i] = (out[i] || 0) + v; }); return out; };

/** Russian letters in Latin, for a code made of a link's name ("Пост в TG" → "post-v-tg"). */
function rfSlug(s) {
  const T = { а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'e', ж: 'zh', з: 'z', и: 'i', й: 'y', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'h', ц: 'c', ч: 'ch', ш: 'sh', щ: 'sch', ъ: '', ы: 'y', ь: '', э: 'e', ю: 'yu', я: 'ya' };
  return [...String(s).toLowerCase()].map((ch) => (T[ch] !== undefined ? T[ch] : ch)).join('').replace(/[^a-z0-9_]+/g, '-').replace(/^[-_]+|[-_]+$/g, '').slice(0, 24).replace(/[-_]+$/, '');
}
const rfCodeOk = (s) => /^[a-z0-9](?:[a-z0-9_-]{1,22})[a-z0-9]$/.test(s);

// ---- the chart: small multiples on one time axis (people who opened, accounts made), a column a slot

/**
 * `lanes`: [{ key, name, parts: [{ cls, name, values }] }] — a lane of one part is plain columns; of more, they stack
 * (the first at the baseline). Hovering a slot tells all its values.
 */
function rfChart(ch, lanes) {
  const n = ch.n, hourly = ch.step === 3600;
  const totals = lanes.map((ln) => Array.from({ length: n }, (_, i) => ln.parts.reduce((s, p) => s + (p.values[i] || 0), 0)));
  const tops = totals.map((t) => Math.max(1, ...t) * 1.22);
  const peaks = totals.map((t) => { const m = Math.max(...t); return m > 0 ? t.indexOf(m) : -1; });
  const now = Date.now() / 1000;
  const slots = [];
  for (let i = 0; i < n; i++) {
    const cells = lanes.map((ln, k) => {
      const total = totals[k][i];
      if (!total) return '<div class="rf-cell"></div>';
      const h = `height:${((100 * total) / tops[k]).toFixed(2)}%`;
      if (ln.parts.length === 1) return `<div class="rf-cell"><i class="${ln.parts[0].cls}" style="${h}"></i></div>`;
      return `<div class="rf-cell"><span class="rf-stack" style="${h}">${ln.parts.map((p) => (p.values[i] ? `<i class="${p.cls}" style="flex:${p.values[i]}"></i>` : '')).join('')}</span></div>`;
    }).join('');
    const later = ch.since + i * ch.step > now;
    slots.push(`<div class="rf-slot ${later ? 'later' : ''}" data-i="${i}" style="--d:${Math.min(i * (n > 60 ? 3 : 14), 420)}ms">${cells}</div>`);
  }
  const at = (i) => `calc(${((i + 0.5) * 100) / n}% )`;
  const laneMarks = lanes.map((ln, k) => {
    const p = peaks[k];
    const legend = ln.parts.length > 1 ? `<span class="rf-keys">${ln.parts.map((x) => `<span><i class="${x.cls}"></i>${x.name}</span>`).join('')}</span>` : '';
    const peak = p >= 0 ? `<em class="rf-peak ${p < n * 0.12 ? 'start' : p > n * 0.88 ? 'end' : ''}" style="left:${at(p)};bottom:calc(${((100 * totals[k][p]) / tops[k]).toFixed(2)}% + 6px)">${fmt(totals[k][p])}</em>` : '';
    return `<div class="rf-lane" style="--row:${k}"><span class="rf-lname">${ln.name}${legend}</span>${peak}</div>`;
  }).join('');
  // A label every few slots: the hours of today, or days (and "today" at the end).
  const every = hourly ? 3 : n <= 8 ? 1 : n <= 31 ? Math.ceil(n / 7) : Math.ceil(n / 8);
  // Hours from midnight; days back from today, so today always has its word.
  const ticks = [];
  const marks = hourly ? Array.from({ length: 8 }, (_, k) => k * 3) : Array.from({ length: Math.ceil(n / every) }, (_, k) => n - 1 - k * every);
  for (const i of marks) {
    const t = ch.since + i * ch.step;
    const word = hourly ? `${String(i).padStart(2, '0')}:00` : i === n - 1 ? L('today', 'сегодня') : rfDay(t, { day: 'numeric', month: 'short' }).replace('.', '');
    const cls = [i === 0 ? 'start' : i === n - 1 ? 'end' : i > n - 1 - every / 2 ? 'end' : '', !hourly && i === n - 1 ? 'now' : ''].join(' ');
    ticks.push(`<span class="${cls}" style="left:${at(i)}">${word}</span>`);
  }
  const head = hourly ? L('Hour (Moscow)', 'Час (МСК)') : L('Day', 'День');
  const table = `<table class="sr"><caption>${lanes.map((l) => l.name).join(', ')}</caption><thead><tr><th>${head}</th>${lanes.flatMap((l) => l.parts.map((p) => `<th>${p.name}</th>`)).join('')}</tr></thead><tbody>${Array.from({ length: n }, (_, i) => `<tr><td>${hourly ? `${String(i).padStart(2, '0')}:00` : rfDay(ch.since + i * ch.step, { day: 'numeric', month: 'long' })}</td>${lanes.flatMap((l) => l.parts.map((p) => `<td>${p.values[i] || 0}</td>`)).join('')}</tr>`).join('')}</tbody></table>`;
  RF.chart = { ch, lanes };
  const empty = totals.every((t) => t.every((x) => !x)) ? `<p class="rf-empty">${L('Nothing yet: the columns rise with the first visits.', 'Пока пусто: столбики вырастут с первыми переходами.')}</p>` : '';
  return `<figure class="rf-chart" style="--n:${n};--lanes:${lanes.length}" aria-label="${L('Chart', 'График')}">
      <div class="rf-plot">${laneMarks}${empty}<div class="rf-slots">${slots.join('')}</div></div>
      <div class="rf-axis" aria-hidden="true">${ticks.join('')}</div>
      <div class="rf-tip" role="tooltip" hidden></div>${table}</figure>`;
}
/** What a slot of the chart says, under the pointer. */
function rfChartWire(fig) {
  const tip = fig.querySelector('.rf-tip'), plot = fig.querySelector('.rf-plot'), data = RF.chart;
  if (!tip || !plot || !data) return;
  const { ch, lanes } = data;
  const show = (slot) => {
    fig.querySelectorAll('.rf-slot.on').forEach((s) => s.classList.remove('on'));
    if (!slot) { tip.hidden = true; return; }
    slot.classList.add('on');
    const i = Number(slot.dataset.i), t = ch.since + i * ch.step;
    const when = ch.step === 3600 ? `${String(i).padStart(2, '0')}:00–${String((i + 1) % 24).padStart(2, '0')}:00 ${L('Moscow', 'МСК')}` : rfDay(t, { weekday: 'short', day: 'numeric', month: 'long' });
    tip.innerHTML = `<b>${when}</b>${lanes.flatMap((l) => l.parts.map((p) => `<span><i class="${p.cls}"></i>${p.name}<b class="num">${fmt(p.values[i] || 0)}</b></span>`)).join('')}`;
    tip.hidden = false;
    const box = fig.getBoundingClientRect(), s = slot.getBoundingClientRect();
    const x = s.left - box.left + s.width / 2, w = tip.offsetWidth;
    tip.style.left = Math.max(0, Math.min(box.width - w, x - w / 2)) + 'px';
  };
  bindOnce(plot, 'pointermove', 'rf', (e) => { const s = e.target.closest('.rf-slot'); if (s && !s.classList.contains('on')) show(s); });
  bindOnce(plot, 'pointerleave', 'rf', () => show(null));
}

// ---- a member's page

function viewRefs(arg) {
  const a = String(arg || '');
  if (!state.user) return rfGhost('mine');
  if (!rfCan()) return `<h1 class="sr">${L('Referrals', 'Рефералы')}</h1><div class="empty">${L('Referral links are for media, partners and admins.', 'Реферальные ссылки — для медиа, партнёров и админов.')}</div>`;
  if (a === 'all' && rfAll()) return rfEveryone();
  if (a.startsWith('u/') && rfAll()) return rfPage(Number(a.slice(2)));
  return rfPage(null);
}

function rfPage(uid) {
  const someone = uid !== null && !Number.isNaN(uid);
  const path = `refs?days=${RF.days}${someone ? '&uid=' + uid : ''}`;
  const c = ask(path);
  if (waiting(c)) return rfGhost(someone ? 'all' : 'mine');
  if (!c.ok) return `<div class="rf">${rfTop(someone ? 'all' : 'mine')}${trouble(c)}</div>`;
  const d = c.data;
  if (RF.link && !d.links.some((l) => l.id === RF.link)) RF.link = 0;
  const focus = RF.link ? d.links.find((l) => l.id === RF.link) : null;
  const main = d.links.find((l) => l.main) || d.links[0];
  const shownLink = focus || main;
  const host = rfHost(d.base);
  const t = focus || d.total;
  const key = path + '#' + RF.link;
  const animate = RF.drawn !== key;
  RF.drawn = key;
  RF.page = { uid: someone ? uid : null, d };

  // The chart of the links shown: one link, or all of them summed.
  const ids = focus ? [String(focus.id)] : Object.keys(d.chart.links);
  const v = rfSum(ids.map((id) => d.chart.links[id].v)), r = rfSum(ids.map((id) => d.chart.links[id].r));
  const chart = rfChart(d.chart, [
    { key: 'v', name: L('Opened the site', 'Открыли сайт'), parts: [{ cls: 'v', name: L('Opened the site', 'Открыли сайт'), values: v }] },
    { key: 'r', name: L('Registered', 'Зарегистрировались'), parts: [{ cls: 'r', name: L('Registered', 'Зарегистрировались'), values: r }] },
  ]);

  const owner = d.owner || {};
  const title = d.mine ? `<h1 class="giant">${L('Referrals', 'Рефералы')}</h1>`
    : `<div class="crumb"><a href="#/dashboard/refs/all">${L('Everyone', 'Все')}</a> / <span translate="no">${esc(owner.login || '')}</span></div>
       <div class="rf-who">${head(owner.login || '?', 64)}<h1 class="giant" translate="no">${pfx(owner)}${esc(owner.login || '')}</h1></div>`;
  const url = shownLink ? d.base + shownLink.code : '';
  const linkLine = shownLink ? `<div class="rf-link"><span class="rf-url" translate="no"><span class="host">${esc(host)}</span><b>${esc(shownLink.code)}</b></span>${rfCopy(url, L('Copy the link', 'Скопировать ссылку'))}</div>
      <p class="hint">${focus ? `${rfName(focus)}${focus.archived ? ' · ' + L('put away: takes nobody new', 'в архиве: новых не засчитывает') : ''} · <button class="w small" data-rf-focus="0">${L('All links', 'Все ссылки')}</button>`
        : d.mine ? L('Whoever opens it and registers within 30 days counts as yours. Make a link of its own for each place you post it, to see which one works.', 'Кто откроет её и зарегистрируется в течение 30 дней — засчитается вам. Для каждого места, где публикуете, сделайте свою ссылку — будет видно, какая работает.')
        : L('Their personal link.', 'Личная ссылка.')}</p>` : '';

  const nums = `<div class="rf-nums">
      ${rfNum('people', t.people, L('opened the site', 'открыли сайт'), t.opened > t.people ? L(`${fmt(t.opened)} visits`, `${fmt(t.opened)} ${plural(t.opened, 'переход', 'перехода', 'переходов')}`) : '')}
      ${rfNum('regs', t.regs, L('registered', 'зарегистрировались'), t.people ? L(`${rfPct(t.regs, t.people)} of them`, `${rfPct(t.regs, t.people)} от открывших`) : '', true)}
      ${rfNum('played', t.played, L('started the game', 'запустили игру'), t.regs ? L(`${rfPct(t.played, t.regs)} of the registered`, `${rfPct(t.played, t.regs)} от зарегистрированных`) : '')}
      ${rfNum('week', t.week, L('played this week', 'играли на этой неделе'))}
      ${rfNum('hours', t.hours, L('hours in the game', 'часов в игре'))}
      ${rfNum('now', t.now, `${t.now ? '<i class="here game"></i>' : ''}${L('in the game now', 'сейчас в игре')}`)}
    </div>`;

  return `<h1 class="sr">${L('Referrals', 'Рефералы')}</h1><div class="rf ${animate ? 'anim' : ''}">
    ${rfTop(d.mine ? 'mine' : 'all')}
    <header class="rf-head">${title}${linkLine}${RF.msg ? `<p class="hint rf-msg ${RF.bad ? 'bad' : 'ok'}" id="rf-msg" role="status">${esc(RF.msg)}</p>` : ''}</header>
    ${nums}
    ${chart}
    ${rfLinks(d)}
    ${rfPeople(d)}
  </div>`;
}

function rfLinks(d) {
  const own = d.links.filter((l) => !l.main).length;
  const row = (l) => {
    const url = d.base + l.code;
    const edit = RF.edit === l.id ? `<tr class="rf-edit"><td colspan="6"><form class="fr-invite" id="rf-edit-form" data-id="${l.id}">
        <input class="in" id="rf-edit-name" maxlength="40" value="${esc(RF.editName)}" aria-label="${L('Name', 'Название')}">
        <button class="w small lead" type="submit">${L('Save', 'Сохранить')}</button>
        <button class="w small" type="button" data-rf-archive="${l.id}" data-on="${l.archived ? 0 : 1}">${l.archived ? L('Bring back', 'Вернуть из архива') : RF.sure === l.id ? L('Put it away?', 'Точно в архив?') : L('Put away', 'В архив')}</button>
        <button class="w small" type="button" data-rf-cancel="1">${L('Cancel', 'Отмена')}</button></form>
        <p class="hint">${L('A link put away takes nobody new; what it brought stays.', 'Ссылка в архиве не засчитывает новых; то, что она привела, остаётся.')}</p></td></tr>` : '';
    return `<tr class="${RF.link === l.id ? 'on' : ''} ${l.archived ? 'off' : ''}">
        <td class="who"><button class="rf-lname-b" data-rf-focus="${l.id}" title="${L('Show this link only', 'Показать только её')}"><b>${rfName(l)}${l.archived ? ` <span class="ash">· ${L('put away', 'в архиве')}</span>` : ''}</b><span class="mono ash" translate="no">/r/${esc(l.code)}</span></button></td>
        ${rfCells(l)}
        <td class="acts-c">${rfCopy(url)}${!l.main && (d.mine || d.all) ? `<button class="w small" data-rf-edit="${l.id}">${L('Edit', 'Изменить')}</button>` : ''}</td></tr>${edit}`;
  };
  const form = RF.make ? `<form class="form rf-form" id="rf-form" novalidate>
      <div><label class="lab" for="rf-name">${L('Where it goes', 'Где будет ссылка')}</label><input class="in" id="rf-name" maxlength="40" placeholder="${L('A Telegram post, a video…', 'Пост в Telegram, видео на YouTube…')}" value="${esc(RF.name)}"></div>
      <div><label class="lab" for="rf-code">${L('The link', 'Ссылка')}</label><div class="rf-code-in"><span class="ash mono" translate="no">${esc(rfHost(d.base))}</span><input class="in mono" id="rf-code" maxlength="24" autocomplete="off" spellcheck="false" value="${esc(RF.code)}" translate="no"></div>
        <p class="hint" id="rf-code-h">${L('3–24 of a–z, 0–9, _ and -', '3–24 символа: a–z, 0–9, _ и -')}</p></div>
      <div class="acts"><button class="w lead" type="submit">${L('Make the link', 'Создать ссылку')}</button><button class="w" type="button" id="rf-new-no">${L('Cancel', 'Отмена')}</button></div></form>` : '';
  return `<section class="block rf-links"><div class="rf-sec"><h2 class="sec">${L('Links', 'Ссылки')} <span class="ash num">${d.links.length}</span></h2>
      ${d.mine && own < d.limit ? `<button class="w small ${RF.make ? 'on' : 'lead'}" id="rf-new">${L('A new link', 'Новая ссылка')}</button>` : ''}</div>
    ${form}
    <div class="scroll-x"><table class="rf-table"><thead><tr><th>${L('Link', 'Ссылка')}</th><th class="r">${L('Opened', 'Открыли')}</th><th class="r">${L('Registered', 'Регистрации')}</th><th class="r">${L('Played', 'Играли')}</th><th class="r">${L('Conversion', 'Конверсия')}</th><th></th></tr></thead>
      <tbody>${d.links.map(row).join('')}</tbody></table></div></section>`;
}

function rfPeople(d) {
  const uid = RF.page && RF.page.uid !== null ? RF.page.uid : null;
  const mk = `${uid}|${RF.link}`;
  if (RF.moreKey !== mk) { RF.more = null; RF.moreKey = mk; }
  let list = d.people, left = d.more;
  if (RF.link) {
    const c = ask(`refs/people?before=9000000000000&link=${RF.link}${uid !== null ? '&uid=' + uid : ''}`);
    if (waiting(c)) return `<section class="block"><h2 class="sec">${L('Who came', 'Кто пришёл')}</h2><div class="ghost-rows"><div></div><div></div></div></section>`;
    list = c.ok ? c.data.people : [];
    left = c.ok && c.data.more;
  }
  if (RF.more) { list = list.concat(RF.more); left = RF.moreLeft; }
  const names = Object.fromEntries(d.links.map((l) => [l.id, l.main ? L('personal link', 'личная ссылка') : l.name]));
  const status = (p) => (p.week ? `<span class="st ok">${L('Plays', 'Играет')}</span>` : p.played ? `<span class="st">${L('Not lately', 'Давно не играет')}</span>` : `<span class="st off">${L('Not in the game yet', 'Ещё не играет')}</span>`);
  const row = (p) => `<div class="rf-person">${head(p.card.login, 36)}<span class="tk-main"><b>${nm(p.card)}</b>
      <span class="ash">${esc(names[p.link] || '')} · ${rfWhen(p.at)}${p.hours !== undefined ? ` · ${p.hours} ${L('h in the game', 'ч в игре')}` : ''}</span></span>${status(p)}</div>`;
  return `<section class="block"><h2 class="sec">${L('Who came', 'Кто пришёл')}</h2>
    ${list.length ? `<div class="rf-people">${list.map(row).join('')}</div>${left ? `<div class="acts"><button class="w small" id="rf-more">${L('More', 'Ещё')}</button></div>` : ''}`
      : `<p class="ash">${L('Nobody yet. Whoever registers by your links shows up here.', 'Пока никого. Здесь появятся те, кто зарегистрируется по вашим ссылкам.')}</p>`}</section>`;
}

// ---- everyone's (admins)

function rfEveryone() {
  const c = ask(`refs/all?days=${RF.days}`);
  if (waiting(c)) return rfGhost('all');
  if (!c.ok) return `<div class="rf">${rfTop('all')}${trouble(c)}</div>`;
  const d = c.data, t = d.total;
  const key = 'all#' + RF.days;
  const animate = RF.drawn !== key;
  RF.drawn = key;
  const made = t.regs + d.organic;
  const chart = rfChart(d.chart, [
    { key: 'v', name: L('Opened the site by a link', 'Открыли сайт по ссылке'), parts: [{ cls: 'v', name: L('Opened by a link', 'Открыли по ссылке'), values: d.chart.v }] },
    { key: 'r', name: L('Registered', 'Зарегистрировались'), parts: [{ cls: 'r', name: L('By a link', 'По ссылке'), values: d.chart.r }, { cls: 'o', name: L('Without one', 'Без ссылки'), values: d.chart.o }] },
  ]);
  const row = (o, i) => {
    const p = o.card, n = o.total, active = o.links.filter((l) => !l.archived).length;
    return `<tr><td class="rank ash num">${i + 1}</td>
      <td class="who"><a class="rf-owner" href="#/dashboard/refs/u/${p.uid}">${head(p.login, 32)}<span><b translate="no"${p.accent ? ` style="color:${esc(p.accent)}"` : ''}>${pfx(p)}${esc(p.login)}</b><span class="ash">${active} ${L(active === 1 ? 'link' : 'links', plural(active, 'ссылка', 'ссылки', 'ссылок'))}</span></span></a></td>
      ${rfCells(n)}
      <td class="acts-c"><a class="w small" href="#/dashboard/refs/u/${p.uid}">${L('Open', 'Открыть')}</a></td></tr>`;
  };
  return `<h1 class="sr">${L('Referrals', 'Рефералы')}</h1><div class="rf ${animate ? 'anim' : ''}">
    ${rfTop('all')}
    <header class="rf-head"><h1 class="giant">${L('Everyone’s links', 'Все ссылки')}</h1>
      <p class="hint">${L('Media, partners and admins. An admin’s own links are for adverts: make one in “My links” for each.', 'Медиа, партнёры и админы. Свои ссылки админа — для рекламы: на каждую закупку своя, в «Моих ссылках».')}</p></header>
    <div class="rf-nums">
      ${rfNum('a-people', t.people, L('opened the site by a link', 'открыли сайт по ссылке'))}
      ${rfNum('a-regs', t.regs, L('registered by a link', 'зарегистрировались по ссылке'), t.people ? L(`${rfPct(t.regs, t.people)} of them`, `${rfPct(t.regs, t.people)} от открывших`) : '', true)}
      ${rfNum('a-organic', d.organic, L('registered without one', 'зарегистрировались без ссылки'))}
      ${rfNum('a-share', made ? Math.round((100 * t.regs) / made) : 0, L('of all registrations came by links', 'всех регистраций — по ссылкам'), '', false, '%')}
      ${rfNum('a-played', t.played, L('of them started the game', 'из них запустили игру'), t.regs ? rfPct(t.played, t.regs) : '')}
      ${rfNum('a-hours', t.hours, L('hours in the game', 'часов в игре'))}
    </div>
    ${chart}
    <section class="block"><h2 class="sec">${L('Who brings people', 'Кто приводит')}</h2>
      ${d.owners.length ? `<div class="scroll-x"><table class="rf-table"><thead><tr><th></th><th>${L('Member', 'Участник')}</th><th class="r">${L('Opened', 'Открыли')}</th><th class="r">${L('Registered', 'Регистрации')}</th><th class="r">${L('Played', 'Играли')}</th><th class="r">${L('Conversion', 'Конверсия')}</th><th></th></tr></thead>
        <tbody>${d.owners.map(row).join('')}</tbody></table></div>` : `<p class="ash">${L('Nobody has links yet.', 'Ссылок пока ни у кого нет.')}</p>`}
    </section>
  </div>`;
}

// ---- the page's hands

function rfCount() {
  const els = $app.querySelectorAll('[data-rf-to]');
  const still = matchMedia('(prefers-reduced-motion: reduce)').matches;
  els.forEach((el) => {
    const key = el.dataset.rfKey, to = Number(el.dataset.rfTo), from = RF.shown[key] === undefined ? 0 : RF.shown[key], unit = el.dataset.rfUnit || '';
    RF.shown[key] = to;
    if (from === to || still) { el.textContent = fmt(to) + unit; return; }
    const t0 = performance.now(), dur = 900;
    const step = (now) => {
      const k = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - k, 3);
      if (!el.isConnected) return;
      el.textContent = fmt(Math.round(from + (to - from) * e)) + unit;
      if (k < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  });
}

async function rfCopyText(btn) {
  const text = btn.dataset.rfCopy;
  let ok = false;
  try { await navigator.clipboard.writeText(text); ok = true; } catch (e) {
    const ta = document.createElement('textarea');
    ta.value = text; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;opacity:0';
    document.body.appendChild(ta); ta.select();
    try { ok = document.execCommand('copy'); } catch (e2) { ok = false; }
    ta.remove();
  }
  const was = btn.dataset.word || btn.textContent;
  btn.dataset.word = was;
  btn.textContent = ok ? L('Copied', 'Скопировано') : L('Copy it by hand', 'Скопируйте вручную');
  btn.classList.add('done');
  clearTimeout(btn._t);
  btn._t = setTimeout(() => { btn.textContent = was; btn.classList.remove('done'); }, 1600);
}

function refsWire() {
  if (state.route !== 'dashboard' || !String(state.arg).startsWith('refs')) return;
  const on = (sel, ev, fn) => $app.querySelectorAll(sel).forEach((el) => bindOnce(el, ev, 'w10|' + sel, (e) => fn(el, e)));
  const said = (r, ok) => { RF.bad = !r.ok; RF.msg = r.ok ? ok || '' : r.message ? tr(r.message) : r.error === 'staff' ? L('Your role does not allow it.', 'Ваша роль этого не позволяет.') : SAY[r.error] || SAY.busy; };
  const codeHint = () => {
    const h = document.getElementById('rf-code-h'); if (!h) return;
    const ok = !RF.code || rfCodeOk(RF.code);
    h.classList.toggle('bad', !ok);
  };
  rfCount();
  $app.querySelectorAll('.rf-chart').forEach(rfChartWire);
  on('[data-rf-days]', 'click', (b) => { RF.days = Number(b.dataset.rfDays); RF.msg = ''; render(true); });
  on('[data-rf-focus]', 'click', (b) => { const id = Number(b.dataset.rfFocus); RF.link = RF.link === id ? 0 : id; RF.msg = ''; render(true); });
  on('[data-rf-copy]', 'click', (b) => rfCopyText(b));
  on('#rf-new', 'click', () => {
    RF.make = !RF.make; RF.msg = '';
    if (RF.make) { RF.name = ''; RF.code = ''; RF.codeTouched = false; }
    render(true);
    const i = document.getElementById('rf-name'); if (i) i.focus();
  });
  on('#rf-new-no', 'click', () => { RF.make = false; render(true); });
  on('#rf-name', 'input', (el) => {
    RF.name = el.value;
    if (!RF.codeTouched) { RF.code = rfSlug(el.value); const ci = document.getElementById('rf-code'); if (ci) ci.value = RF.code; codeHint(); }
  });
  on('#rf-code', 'input', (el) => { RF.codeTouched = true; RF.code = el.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''); if (el.value !== RF.code) el.value = RF.code; codeHint(); });
  on('form#rf-form', 'submit', async (f, e) => {
    e.preventDefault();
    if (!RF.name.trim()) { said({ ok: false, message: L('Give it a name: where it goes.', 'Дайте ссылке название — где она будет.') }); render(true); return; }
    if (!rfCodeOk(RF.code)) { said({ ok: false, message: L('The link: 3–24 of a–z, 0–9, _ and -, a letter or a digit at both ends.', 'Ссылка: 3–24 символа a–z, 0–9, _ и -, по краям буква или цифра.') }); render(true); return; }
    const r = await api('refs', { name: RF.name.trim(), code: RF.code });
    said(r, L('The link is made: copy it and put it up.', 'Ссылка создана — скопируйте и публикуйте.'));
    if (r.ok) { RF.make = false; RF.link = r.data.id; forget('refs'); }
    render(true);
  });
  on('[data-rf-edit]', 'click', (b) => {
    const id = Number(b.dataset.rfEdit), l = RF.page && RF.page.d.links.find((x) => x.id === id);
    RF.edit = RF.edit === id ? 0 : id; RF.editName = l ? l.name : ''; RF.sure = 0;
    render(true);
    const i = document.getElementById('rf-edit-name'); if (i) i.focus();
  });
  on('#rf-edit-name', 'input', (el) => { RF.editName = el.value; });
  on('[data-rf-cancel]', 'click', () => { RF.edit = 0; RF.sure = 0; render(true); });
  on('form#rf-edit-form', 'submit', async (f, e) => {
    e.preventDefault();
    const r = await api(`refs/${f.dataset.id}`, { name: RF.editName }, 'PATCH');
    said(r, L('Saved.', 'Сохранено.'));
    if (r.ok) { RF.edit = 0; forget('refs'); }
    render(true);
  });
  on('[data-rf-archive]', 'click', async (b) => {
    const id = Number(b.dataset.rfArchive), put = b.dataset.on === '1';
    if (put && RF.sure !== id) { RF.sure = id; render(true); return; }
    RF.sure = 0;
    const r = await api(`refs/${id}`, { archived: put }, 'PATCH');
    said(r, put ? L('Put away.', 'Ссылка в архиве.') : L('It works again.', 'Ссылка снова работает.'));
    if (r.ok) { RF.edit = 0; forget('refs'); }
    render(true);
  });
  on('#rf-more', 'click', async (b) => {
    const p = RF.page; if (!p) return;
    const who = p.uid !== null ? '&uid=' + p.uid : '';
    // The last one shown: of the page's own forty, or of the one link's list, or of what came after them.
    const first = RF.link ? ((got.get(`refs/people?before=9000000000000&link=${RF.link}${who}`) || {}).data || {}).people || [] : p.d.people;
    const all = first.concat(RF.more || []), last = all[all.length - 1];
    if (!last) return;
    b.disabled = true;
    const r = await api(`refs/people?before=${last.at}&before_uid=${last.uid}${RF.link ? '&link=' + RF.link : ''}${who}`);
    if (r.ok) { RF.more = (RF.more || []).concat(r.data.people); RF.moreLeft = r.data.more; }
    render(true);
  });
}
// Leaving the page: its message and open forms are not waiting there next time.
window.addEventListener('hashchange', () => { if (!/^#\/dashboard\/refs/.test(location.hash)) Object.assign(RF, { msg: '', make: false, edit: 0, sure: 0 }); });


window.addEventListener('beforeunload', (e) => { if (UP.phase === 'sending') { e.preventDefault(); e.returnValue = ''; } });
document.documentElement.lang = LANG;
refCatch();
// (The shell, its views of the menu, the window and the boot: shell.js, after this file.)
