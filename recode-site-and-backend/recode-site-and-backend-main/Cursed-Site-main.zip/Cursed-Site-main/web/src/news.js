"use strict";
/* ================================================================================================ what's new (23.10.2026)
   The builds' notes as they were published (/api/changes: each release's notes, kept by the server since the release),
   Recode's and Cursed's, the newest first; the site's own announcements in the tab beside them. Loaded after app.js:
   its viewNews stays, as the second tab. */

const NW = { tab: 'builds', channel: '' };
const NW_CHANNEL = { recode: 'Cursed Recode', beta: 'Cursed 1.21.11' };

/** A release's notes as written: a line alone is a heading ("Новое", "Исправлено"), a line with a bullet is a point (its
   name before a colon set apart), anything else a paragraph. */
function nwNotes(text) {
  const out = []; let list = [];
  const flush = () => { if (list.length) { out.push(`<ul class="nw-list">${list.join('')}</ul>`); list = []; } };
  for (const raw of String(text || '').split('\n')) {
    const line = raw.trim();
    if (!line) { flush(); continue; }
    const bullet = line.match(/^[•\-–*]\s*(.*)$/);
    if (bullet) {
      const t = bullet[1], k = t.indexOf(': ');
      list.push(k > 0 && k < 40 ? `<li><b>${esc(t.slice(0, k))}</b>${esc(t.slice(k))}</li>` : `<li>${esc(t)}</li>`);
      continue;
    }
    flush();
    if (line.length <= 32 && !/[.!?]$/.test(line)) out.push(`<h3 class="nw-h">${esc(line)}</h3>`);
    else out.push(`<p class="nw-p">${esc(line)}</p>`);
  }
  flush();
  return out.join('');
}
const nwDate = (s) => new Date(s * 1000).toLocaleDateString(L('en-GB', 'ru-RU'), { day: 'numeric', month: 'long', year: 'numeric' });

const viewNewsBase = viewNews;
viewNews = function () {
  const tab = (k, en, ru) => `<button class="w small ${NW.tab === k ? 'on' : ''}" data-nw-tab="${k}">${L(en, ru)}</button>`;
  const tabs = `<div class="nw-top"><div class="nw-tabs">${tab('builds', 'Updates', 'Обновления')}${tab('site', 'Announcements', 'Объявления')}</div>${NW.tab === 'builds' ? `<div class="nw-chans">${[['', 'All', 'Все'], ['recode', 'Recode', 'Recode'], ['beta', 'Cursed 1.21.11', 'Cursed 1.21.11']].map(([k, en, ru]) => `<button class="w small ${NW.channel === k ? 'on' : ''}" data-nw-ch="${k}">${L(en, ru)}</button>`).join('')}</div>` : ''}</div>`;
  if (NW.tab === 'site') return tabs + viewNewsBase();
  const c = ask('changes' + (NW.channel ? '?channel=' + NW.channel : ''));
  if (waiting(c)) return tabs + `<div class="nw-feed">${ghosts(2)}</div>`;
  if (!c.ok) return tabs + trouble(c);
  const items = c.data.items;
  if (!items.length) return tabs + `<div class="empty">${L('Nothing yet.', 'Пока ничего.')}</div>`;
  return tabs + `<div class="nw-feed">${items.map((r, i) => `<article class="nw-rel${i === 0 ? ' nw-new' : ''}" data-key="nw-${esc(r.channel)}-${r.build}">
      <div class="nw-side"><span class="nw-ch">${esc(NW_CHANNEL[r.channel] || r.channel)}</span><b class="nw-b num">${r.build}</b><span class="nw-at">${nwDate(r.at)}</span>${i === 0 ? `<span class="nw-last">${L('the latest', 'последняя')}</span>` : ''}</div>
      <div class="nw-notes" translate="no">${nwNotes(r.notes)}</div></article>`).join('')}</div>`;
};
document.addEventListener('click', (e) => {
  const b = e.target.closest && e.target.closest('[data-nw-tab],[data-nw-ch]');
  if (!b || !b.closest('.r-win')) return;
  if (b.dataset.nwTab) NW.tab = b.dataset.nwTab;
  if (b.dataset.nwCh !== undefined) NW.channel = b.dataset.nwCh;
  render(true);
});
