"use strict";
/* ================================================================================================ the shell (10.10.2026)
   The site lives in the world of Recode's main menu (world.js, the client's own shaders). The front, the door, Recode and
   the free client are that menu over the world: words rising out of lines of light, white fire under the word the hand
   is on, the camera gliding to each page's own place in the valley. Everything else is the window of the modules' menu:
   glass over the world blurred, the sections on its left, tiles on its right. app.js keeps every screen's own work; this
   file draws around it, adds the menu's screens and boots the site. Loaded after app.js: a function named here as one of
   app.js's takes its place. */

/* ---- line icons, 16 × 16 (the modules' menu's hand) ---- */
const ICO = {
  grid: 'M2.5 2.5h4.5v4.5H2.5zM9 2.5h4.5v4.5H9zM2.5 9h4.5v4.5H2.5zM9 9h4.5v4.5H9z',
  user: 'M8 8.2a2.8 2.8 0 1 0 0-5.6 2.8 2.8 0 0 0 0 5.6zM2.8 13.8c.6-2.6 2.7-4 5.2-4s4.6 1.4 5.2 4',
  page: 'M3 3.5h10v9H3zM5.5 6.5h5M5.5 9h3',
  layers: 'M8 2.2 14 5.4 8 8.6 2 5.4zM2 8.2l6 3.2 6-3.2M2 11l6 3.2 6-3.2',
  link: 'M6.6 9.4l2.8-2.8M7 4.6l1.2-1.2a2.8 2.8 0 0 1 4 4L11 8.6M9 11.4l-1.2 1.2a2.8 2.8 0 0 1-4-4L5 7.4',
  bell: 'M4 11V7.2a4 4 0 0 1 8 0V11l1.2 1.4H2.8zM6.6 13.8a1.5 1.5 0 0 0 2.8 0',
  monitor: 'M2.2 3h11.6v7.6H2.2zM5.5 13.5h5M8 10.6v2.9',
  news: 'M2.5 6.4v3.2h2.2l5.3 3.1V3.3L4.7 6.4zM12.2 5.6c1 .8 1 4 0 4.8',
  medal: 'M8 9.8a3.6 3.6 0 1 0 0-7.2 3.6 3.6 0 0 0 0 7.2zM5.8 9.2 5 14l3-1.6 3 1.6-.8-4.8',
  chat: 'M2.5 3.2h11v7.3H7.2l-3.2 2.7v-2.7H2.5z',
  doc: 'M4 2h5.5L12.5 5v9H4zM9.5 2v3h3M6 8h4.5M6 10.5h4.5',
  forum: 'M2 3h8v5.5H5.5L3 10.5V8.5H2zM12 6h2v5h-1v2l-2.5-2H7.5V10',
  bag: 'M3 5.5h10l-.8 8.5H3.8zM5.5 5.5V4a2.5 2.5 0 0 1 5 0v1.5',
  users: 'M6 7.5a2.3 2.3 0 1 0 0-4.6 2.3 2.3 0 0 0 0 4.6zM1.8 13c.5-2.2 2.1-3.4 4.2-3.4s3.7 1.2 4.2 3.4M10.8 7.4a2 2 0 1 0-.6-3.9M12 9.8c1.2.4 2 1.4 2.3 3',
  shield: 'M8 1.8 13.2 3.8v4.1c0 3-2.2 5.3-5.2 6.3-3-1-5.2-3.3-5.2-6.3V3.8z',
  up: 'M8 13V3.5M4.5 7 8 3.5 11.5 7M3 14h10',
  box: 'M8 1.8 13.5 4.9v6.2L8 14.2 2.5 11.1V4.9zM2.5 4.9 8 8l5.5-3.1M8 8v6.2',
  flame: 'M8 14c-2.6 0-4.4-1.8-4.4-4.2C3.6 6.5 7 5.6 6.6 2c2.8 1.4 3.6 4 3.2 5.6.6-.4 1-1.1 1.1-2 1.2 1 1.9 2.6 1.9 4.2C12.8 12.2 10.7 14 8 14z',
  down: 'M8 2.5v8M4.8 7.6 8 10.8l3.2-3.2M3 13.5h10',
  x: 'M4 4l8 8M12 4l-8 8',
  back: 'M9.5 3.5 5 8l4.5 4.5',
  out: 'M6.5 3H3.5v10h3M10 5l3 3-3 3M13 8H6.5',
  sliders: 'M3 4.5h6M12 4.5h1M3 11.5h1M7 11.5h6M9 3v3M5 10v3',
  key: 'M5.2 11.2a2.8 2.8 0 1 1 0-5.6 2.8 2.8 0 0 1 0 5.6zM8 8.4h6M11.6 8.4v2.3M13.6 8.4v1.7',
  trophy: 'M5 2.5h6v3.4a3 3 0 0 1-6 0zM5 3.6H2.8c0 1.9.9 3 2.5 3.3M11 3.6h2.2c0 1.9-.9 3-2.5 3.3M8 8.9v2.4M5.6 13.5h4.8M6.4 11.3h3.2v2.2H6.4z',
  shirt: 'M5.6 2.6 2.4 4.4l1.2 3 1.6-.7v6.7h5.6V6.7l1.6.7 1.2-3-3.2-1.8C9.9 3.6 9 4.2 8 4.2s-1.9-.6-2.4-1.6z',
};
const ic = (k, cls) => `<svg viewBox="0 0 16 16" class="${cls || ''}" aria-hidden="true"><path d="${ICO[k]}" fill="none" stroke="currentColor" stroke-width="1.45" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
const LOGO_HEAT = '/img/logo-heat.png';

/* ================================================================================================ the menu over the world
   An item rises out of its line when its screen comes (`.entering`); drawn again with the same screen, it simply is. */
const mItem = (text, href, o = {}) => {
  const tag = o.tag ? `<em class="r-tag">${esc(o.tag)}</em>` : '';
  const cls = `r-item r-fl r-rv${o.main ? ' r-main' : ''}${o.quit ? ' r-quit' : ''}${o.mid ? ' r-mid' : ''}${o.dis ? ' r-dis' : ''}`;
  const inner = `<span class="r-shift"><span class="r-mask"><span class="r-in">${esc(text)}${tag}</span></span></span><i class="r-rl"></i><i class="r-hl"></i>`;
  if (o.button) return `<button class="${cls}" type="${o.submit ? 'submit' : 'button'}" style="--o:${o.o || 0}"${o.id ? ` id="${o.id}"` : ''}${o.data ? ' ' + o.data : ''}>${inner}</button>`;
  return `<a class="${cls}" href="${href}" style="--o:${o.o || 0}"${o.id ? ` id="${o.id}"` : ''}${o.data ? ' ' + o.data : ''}${o.download ? ' download' : ''}>${inner}</a>`;
};
const mCap = (cap, srv, o = 0) => `<div class="r-last r-rv" style="--o:${o}"><i class="r-rl"></i><span class="r-mask"><span class="r-in"><span class="r-cap">${esc(cap)}</span></span></span>${srv ? `<span class="r-mask"><span class="r-in" style="--i:1"><span class="r-srv">${esc(srv)}</span></span></span>` : ''}</div>`;
const mLine = (html, o, cls) => `<div class="${cls || 'r-hint'} r-rv" style="--o:${o}"><span class="r-mask"><span class="r-in">${html}</span></span></div>`;
const plu = (n, a, b, c) => plural(n, a, b, c);
const daysW = (n) => `${n} ${L(n === 1 ? 'day' : 'days', plural(n, 'день', 'дня', 'дней'))}`;
const grp3 = (n) => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
const rub = (n) => `${grp3(n)} ₽`;

/* ---- the front ---- */
function viewHome() {
  const u = state.user;
  return `<nav class="r-menu" aria-label="${L('Main menu', 'Главное меню')}">
    ${mCap('Cursed Recode', L('a new era of minecraft clients', 'новая эра клиентов minecraft'), 0)}
    ${mItem(L('Buy', 'Купить'), '#/buy', { main: true, o: 1, tag: saleTag() })}
    ${mItem(L('Forum', 'Форум'), '#/forum', { o: 2 })}
    ${mItem(L('Wardrobe', 'Гардероб'), '#/wardrobe', { o: 3, tag: '3D' })}
    ${mItem(L('Market', 'Маркет'), '#/market', { o: 4 })}
    ${u ? mItem(L('Account', 'Кабинет'), '#/dashboard/overview', { o: 5 }) : mItem(L('Sign in', 'Войти'), '#/signin', { o: 5 })}
    ${mItem(L('Download free', 'Скачать бесплатно'), '#/free', { o: 6, quit: true, tag: 'Cursed 1.21.11' })}
  </nav>`;
}

/* ---- Recode: the prices (hers, 20.10.2026: cut, three terms and no other). `was` is the price before the cut (11.10),
   struck through with how much it came down; `p` to pay. ---- */
const TERMS = [{ d: 30, was: 359, p: 299 }, { d: 90, was: 899, p: 499 }, { d: 0, was: 2399, p: 699 }];
const off = (t) => Math.round((1 - t.p / t.was) * 100);
const saleTag = () => L(`new prices · from ${rub(TERMS[0].p)}`, `новые цены · от ${rub(TERMS[0].p)}`);
const termName = (d) => (d === 0 ? L('Forever', 'Навсегда') : daysW(d));
const perDay = (d, p) => (d ? L(`${rub(Math.round(p / d))} a day`, `${rub(Math.round(p / d))} в день`) : L('pay once', 'один платёж'));
const BUY = { term: 30, method: 'sbp', agree: false };
const METHODS = () => [['sbp', L('SBP', 'СБП')], ['crypto', L('Crypto', 'Криптовалюта')], ['xrocket', 'xrocket']];
const chosen = () => TERMS.find((x) => x.d === BUY.term) || TERMS[0];
const bigRub = (n) => `${grp3(n)}<small class="r-cur">₽</small>`;
function viewBuy() {
  const u = state.user, c = chosen();
  const rows = TERMS.map((t, i) => `<button class="r-term r-fl r-rv${BUY.term === t.d ? ' r-sel' : ''}" data-term="${t.d}" role="radio" aria-checked="${BUY.term === t.d}" style="--o:${i + 1}">
      <span class="r-wd"><span class="r-shift"><span class="r-mask"><span class="r-in">${esc(termName(t.d))}</span></span></span><i class="r-hl"></i></span>
      <span class="r-mask"><span class="r-in" style="--i:1"><span class="r-pr"><s class="r-was">${rub(t.was)}</s><span>${rub(t.p)}</span><span class="r-pd">${t.d >= 7 ? esc(perDay(t.d, t.p)) : t.d === 0 ? L('once', 'разово') : ''}</span></span></span></span><i class="r-rl"></i></button>`).join('');
  const acct = u ? `<span class="r-acct" translate="no">${esc(u.login)}${head(u.login, 26)}</span>` : `<a class="r-opt" href="#/signin" data-back="buy">${L('Sign in first', 'Сначала войди')}</a>`;
  return `<nav class="r-menu r-terms" role="radiogroup" aria-label="${L('Term', 'Срок')}">${mCap('Cursed Recode', L('subscription · new prices', 'подписка · новые цены'), 0)}${rows}${pcRow(5)}</nav>
    <aside class="r-check" aria-label="${L('Checkout', 'Оплата')}">
      ${mCap(L('Your choice', 'Выбрано'), termName(c.d), 2)}
      <div class="r-sale r-rv" style="--o:3"><span class="r-mask"><span class="r-in"><s class="r-was" id="ck-was">${rub(c.was)}</s><b class="r-off" id="ck-off">−${off(c)}%</b></span></span></div>
      <div class="r-bigp r-rv" style="--o:3"><span class="r-mask"><span class="r-in" id="ck-price">${bigRub(c.p)}</span></span></div>
      <div class="r-per r-rv" style="--o:3"><span class="r-mask"><span class="r-in" style="--i:1" id="ck-per">${esc(perDay(c.d, c.p))}</span></span></div>
      <div class="r-krow r-rv" style="--o:4"><i class="r-rl"></i><span class="r-mask"><span class="r-in"><span class="r-k">${L('Pay with', 'Оплата')}</span></span></span><span class="r-mask"><span class="r-in" style="--i:1"><span class="r-opts">${METHODS().map(([k, n]) => `<button class="r-opt${BUY.method === k ? ' r-on' : ''}" data-method="${k}" type="button">${esc(n)}</button>`).join('')}</span></span></span></div>
      <div class="r-krow r-rv" style="--o:5"><i class="r-rl"></i><span class="r-mask"><span class="r-in"><span class="r-k">${L('To account', 'На аккаунт')}</span></span></span><span class="r-mask"><span class="r-in" style="--i:1">${acct}</span></span></div>
      <div class="r-krow r-rv" style="--o:6"><span class="r-mask"><span class="r-in"><button class="r-agree${BUY.agree ? ' r-on' : ''}" id="agree" type="button" role="checkbox" aria-checked="${BUY.agree}"><span class="r-box"></span><span>${L('I accept the <a href="#/docs/offer">offer</a>', 'С <a href="#/docs/offer">офертой</a> согласен')}</span></button></span></span></div>
      ${mItem(L('Pay', 'Оплатить'), '#/buy', { main: true, o: 7, id: 'pay', dis: !BUY.agree, button: true })}
      ${mLine(L('secure payment via RollyPay', 'оплата через RollyPay'), 8)}
      ${mLine(L('the subscription starts after payment confirmation', 'подписка начнётся после подтверждения оплаты'), 9)}
      ${mLine(L('before buying, check the <a href="#/docs/reqs">requirements</a>', 'перед покупкой проверьте <a href="#/docs/reqs">требования</a>'), 10)}
    </aside>`;
}
/* ---- the computer's check (pccheck.js): the card this browser draws with, held up against what Recode needs ---- */
function pcRow(o) {
  const p = pcLines();
  return `<div class="r-krow r-pc r-pc-${p.verdict} r-rv" style="--o:${o}"><i class="r-rl"></i><span class="r-mask"><span class="r-in"><span class="r-k">${L('Your PC', 'Ваш ПК')}</span></span></span><span class="r-mask"><span class="r-in" style="--i:1"><span class="r-pcv" translate="no">${esc(p.card)}</span><b class="r-pcw">${esc(p.word)}</b></span></span></div>
      ${mLine(`${esc(p.why)} <a href="#/docs/reqs">${L('requirements', 'требования')}</a>`, o + 1, 'r-hint r-pcwhy')}`;
}
function syncBuy(swap) {
  const c = chosen();
  document.querySelectorAll('.r-term').forEach((el) => { const on = Number(el.dataset.term) === BUY.term; el.classList.toggle('r-sel', on); el.setAttribute('aria-checked', on); });
  World.select(document.querySelector('.r-term.r-sel'));
  const cap = document.querySelector('.r-check .r-last .r-srv'); if (cap) cap.textContent = termName(c.d);
  const price = document.getElementById('ck-price'), per = document.getElementById('ck-per');
  if (price) { if (swap) swapIn(price, bigRub(c.p)); else price.innerHTML = bigRub(c.p); }
  if (per) per.textContent = perDay(c.d, c.p);
  const was = document.getElementById('ck-was'), cut = document.getElementById('ck-off');
  if (was && was.textContent !== rub(c.was)) {
    const put = () => { const n = chosen(); was.textContent = rub(n.was); if (cut) cut.textContent = `−${off(n)}%`; };
    if (swap) { was.style.opacity = '0'; if (cut) cut.style.opacity = '0'; setTimeout(() => { put(); was.style.opacity = ''; if (cut) cut.style.opacity = ''; }, 260); } else put();
  }
  const pay = document.getElementById('pay'); if (pay) pay.classList.toggle('r-dis', !BUY.agree);
}
function swapIn(el, html) {
  if (el.innerHTML === html) return;
  el.classList.add('r-out');
  setTimeout(() => { el.innerHTML = html; el.classList.remove('r-out'); el.classList.add('r-below'); void el.offsetWidth; el.classList.remove('r-below'); }, 260);
}

/* ---- the free client: Cursed 1.21.11, its loader (to a member: the server hands it out to an account) ---- */
function viewFree() {
  const u = state.user;
  const get = u ? (u.tester ? mItem(L('Download', 'Скачать'), '/api/dist/loader', { main: true, o: 1, tag: 'Windows 10 · 11', download: true, id: 'get-loader' })
    : mItem(L('Download', 'Скачать'), '#/support', { main: true, o: 1, tag: L('ask support', 'через поддержку') }))
    : mItem(L('Download', 'Скачать'), '#/signin', { main: true, o: 1, tag: L('sign in first', 'сначала войди'), data: 'data-back="free"' });
  return `<nav class="r-menu">
    ${mCap('Cursed · 1.21.11', L('free, forever', 'бесплатно и навсегда'), 0)}
    ${get}
    ${mLine(esc(L('The loader signs in with your site account and keeps the client up to date.', 'Лоудер входит аккаунтом сайта и сам обновляет клиент.')), 2, 'r-say')}
    ${mItem(L('What\'s new', 'Что нового'), '#/news', { o: 3, mid: true })}
    ${mItem('Cursed Recode', '#/buy', { o: 4, mid: true, tag: saleTag() })}
    ${mItem(L('Back', 'Назад'), '#/home', { o: 5, quit: true })}
  </nav>`;
}

/* ---- the door: the same forms as before (app.js's enter() and wireRegister() read these ids) ---- */
const mField = (id, label, type, o, ac, hint, hid, extra) => `<label class="r-field r-rv" style="--o:${o}" for="${id}"><span class="r-mask"><span class="r-in"><span class="r-lab">${esc(label)}</span></span></span><span class="r-mask"><span class="r-in" style="--i:1"><input id="${id}" type="${type}" autocomplete="${ac}" spellcheck="false" autocapitalize="off"${extra || ''}></span></span><i class="r-u"></i><i class="r-uf"></i><i class="r-rl"></i>${hint ? `<span class="r-mask r-fhm"><span class="r-in" style="--i:2"><span class="r-fh" id="${hid || ''}">${esc(hint)}</span></span></span>` : ''}</label>`;
function viewSignin() {
  return `<form class="r-menu" id="signin" novalidate>
    ${mCap(L('Sign in', 'Вход'), state.gate ? L('members only', 'только для участников') : L('with your login or e-mail', 'логином или почтой'), 0)}
    ${mField('s-login', L('Login or e-mail', 'Логин или почта'), 'text', 1, 'username')}
    ${mField('s-pass', L('Password', 'Пароль'), 'password', 2, 'current-password')}
    <p class="r-err" id="signin-msg" role="status"></p>
    ${mItem(L('Sign in', 'Войти'), '', { main: true, o: 3, button: true, submit: true })}
    ${mItem(L('Forgot the password?', 'Забыли пароль?'), '#/forgot', { o: 4, mid: true })}
    ${mItem(L('Create an account', 'Создать аккаунт'), '#/register', { o: 5, quit: true })}
  </form>`;
}
function viewRegister() {
  return `<form class="r-menu" id="reg" novalidate>
    ${mCap(L('New account', 'Новый аккаунт'), L('takes a minute', 'это минута'), 0)}${refInvite()}
    ${mField('login', L('Login', 'Логин'), 'text', 1, 'username', '3–16: a–z, 0–9, _', 'login-h', ' maxlength="16"')}
    ${mField('email', L('E-mail', 'Почта'), 'email', 2, 'email', L('never shown to anyone', 'никому не показывается'))}
    ${mField('pass', L('Password', 'Пароль'), 'password', 3, 'new-password', '10+ characters', 'pass-h')}
    <div class="r-rv" style="--o:4"><span class="r-mask"><span class="r-in"><label class="r-agree" for="t-terms"><input type="checkbox" id="t-terms" class="sr"><span class="r-box"></span><span>${L('I accept the <a href="#/docs/rules">rules</a>', 'С <a href="#/docs/rules">правилами</a> согласен')}</span></label></span></span></div>
    <p class="r-err" id="reg-msg" role="status"></p>
    ${mItem(L('Create', 'Создать'), '', { main: true, o: 5, button: true, submit: true, id: 'reg-go' })}
    ${mItem(L('I have an account', 'Уже есть аккаунт'), '#/signin', { o: 6, quit: true })}
  </form>`;
}
/* ---- letters (11.10.2026): a forgotten password comes back through the e-mail; the e-mail is confirmed by a link ---- */
const MAILS = { sent: false, reset: { token: '', state: '', login: '' }, confirm: { token: '', state: '', email: '' } };
function viewForgot() {
  if (MAILS.sent) return `<nav class="r-menu">
    ${mCap(L('Forgot the password', 'Забыли пароль'), L('the letter is on its way', 'письмо в пути'), 0)}
    ${mLine(esc(L('If such an account exists, a letter with a link is already on its way to its e-mail. The link works once, for half an hour. Look in spam too.', 'Если такой аккаунт есть, письмо со ссылкой уже летит на его почту. Ссылка сработает один раз и действует полчаса. Загляните и в спам.')), 1, 'r-say')}
    ${mItem(L('To sign in', 'Ко входу'), '#/signin', { main: true, o: 2 })}
    ${mItem(L('Send again', 'Отправить ещё раз'), '', { o: 3, mid: true, button: true, id: 'forgot-again' })}
  </nav>`;
  return `<form class="r-menu" id="forgot" novalidate>
    ${mCap(L('Forgot the password', 'Забыли пароль'), L('a link comes to your e-mail', 'ссылка придёт на почту'), 0)}
    ${mField('f-login', L('Login or e-mail', 'Логин или почта'), 'text', 1, 'username')}
    <p class="r-err" id="forgot-msg" role="status"></p>
    ${mItem(L('Send the letter', 'Отправить письмо'), '', { main: true, o: 2, button: true, submit: true, id: 'forgot-go' })}
    ${mItem(L('Back to sign in', 'Назад ко входу'), '#/signin', { o: 3, quit: true })}
  </form>`;
}
async function forgotGo() {
  const msg = document.getElementById('forgot-msg'), go = document.getElementById('forgot-go'), v = document.getElementById('f-login').value.trim();
  msg.textContent = '';
  if (!v) { msg.textContent = L('Write your login or e-mail.', 'Впишите логин или почту.'); return; }
  go.disabled = true;
  const r = await api('reset/ask', { login: v, lang: LANG });
  go.disabled = false;
  if (!r.ok) {
    msg.textContent = r.error === 'mail' ? L('Letters do not go out right now. Write to the support on Discord.', 'Письма сейчас не отправляются. Напишите в поддержку в Discord.') : tr(SAY[r.error] || SAY.busy);
    return;
  }
  MAILS.sent = true;
  render(true);
}
function viewReset(arg) {
  const t = String(arg || '').split('/')[0], R = MAILS.reset;
  if (R.token !== t) { R.token = t; R.state = 'check'; R.login = ''; resetCheck(t); }
  const cap = (s) => mCap(L('A new password', 'Новый пароль'), s, 0);
  if (R.state === 'check' || R.state === 'done') return `<nav class="r-menu">${cap(R.state === 'done' ? L('saved', 'сохранён') : L('checking the link…', 'проверяю ссылку…'))}</nav>`;
  if (R.state === 'gone') return `<nav class="r-menu">${cap(L('the link no longer works', 'ссылка больше не работает'))}
    ${mLine(esc(L('It was used already, or its time has passed. Ask for a new letter.', 'Ею уже воспользовались, или её время вышло. Запросите новое письмо.')), 1, 'r-say')}
    ${mItem(L('Ask again', 'Запросить снова'), '#/forgot', { main: true, o: 2 })}
    ${mItem(L('To sign in', 'Ко входу'), '#/signin', { o: 3, quit: true })}
  </nav>`;
  return `<form class="r-menu" id="reset" novalidate>
    ${cap(R.login)}
    ${mField('r-pass', L('New password', 'Новый пароль'), 'password', 1, 'new-password', L('10 characters or more', 'от 10 символов'), 'r-pass-h')}
    ${mField('r-pass2', L('Once more', 'Ещё раз'), 'password', 2, 'new-password')}
    <p class="r-err" id="reset-msg" role="status"></p>
    ${mItem(L('Save and sign in', 'Сохранить и войти'), '', { main: true, o: 3, button: true, submit: true, id: 'reset-go' })}
  </form>`;
}
async function resetCheck(t) {
  const r = await api('reset/check', { token: t });
  if (MAILS.reset.token !== t) return;
  MAILS.reset.state = r.ok ? 'ok' : 'gone';
  MAILS.reset.login = r.ok ? r.data.login : '';
  if (state.route === 'reset') render(true);
}
async function resetGo() {
  const msg = document.getElementById('reset-msg'), go = document.getElementById('reset-go');
  const p1 = document.getElementById('r-pass').value, p2 = document.getElementById('r-pass2').value;
  msg.textContent = '';
  if ([...p1].length < 10) { msg.textContent = L('10 characters or more.', 'Нужно от 10 символов.'); return; }
  if (p1 !== p2) { msg.textContent = L('The two are not the same.', 'Пароли не совпадают.'); return; }
  go.disabled = true;
  const r = await api('reset/set', { token: MAILS.reset.token, password: p1 });
  go.disabled = false;
  if (!r.ok) {
    if (r.error === 'token') { MAILS.reset.state = 'gone'; render(true); return; }
    msg.textContent = r.error === 'banned' ? bannedWords(r) : tr(SAY[r.error] || SAY.busy);
    return;
  }
  MAILS.reset.state = 'done';
  const who = await api('me');
  signIn(who.ok ? who.data : r.data);
  location.hash = '#/dashboard/overview';
}
function viewConfirm(arg) {
  const t = String(arg || '').split('/')[0], C = MAILS.confirm;
  if (C.token !== t) { C.token = t; C.state = 'wait'; C.email = ''; confirmGo(t); }
  const cap = (s) => mCap(L('E-mail', 'Почта'), s, 0);
  const next = state.user ? mItem(L('Account', 'Кабинет'), '#/dashboard/overview', { main: true, o: 2 }) : mItem(L('Sign in', 'Войти'), '#/signin', { main: true, o: 2 });
  if (C.state === 'wait') return `<nav class="r-menu">${cap(L('confirming…', 'подтверждаю…'))}</nav>`;
  if (C.state === 'ok') return `<nav class="r-menu">${cap(L('confirmed', 'подтверждена'))}
    ${mLine(esc(L(`${C.email} is yours: if you ever forget the password, it comes back through it.`, `${C.email} — ваша. Если забудете пароль, он вернётся через неё.`)), 1, 'r-say')}
    ${next}${mItem(L('Home', 'На главную'), '#/home', { o: 3, quit: true })}</nav>`;
  return `<nav class="r-menu">${cap(L('the link does not work', 'ссылка не работает'))}
    ${mLine(esc(C.state === 'stale' ? L('The account has another e-mail now.', 'У аккаунта теперь другая почта.') : L('It was used already, or three days have passed. Send a new letter from the account.', 'Ею уже воспользовались, или прошло три дня. Отправьте новое письмо из кабинета.')), 1, 'r-say')}
    ${next}</nav>`;
}
async function confirmGo(t) {
  const r = await api('email/confirm', { token: t });
  if (MAILS.confirm.token !== t) return;
  MAILS.confirm.state = r.ok ? 'ok' : r.error === 'stale' ? 'stale' : 'gone';
  MAILS.confirm.email = r.ok ? r.data.email : '';
  if (r.ok && state.user) state.user.email_confirmed = true;
  if (state.route === 'confirm') render(true);
}
/** Under the account's rows: an e-mail not confirmed says so, with the letter at hand. */
function emailNote() {
  const u = state.user;
  if (!u || u.email_confirmed || !u.mail) return '';
  if (state.emSent) return `<p class="hint ok r-emnote">${esc(L(`The letter is on its way to ${masked(u.email)}. Look in spam too.`, `Письмо летит на ${masked(u.email)}. Загляните и в спам.`))}</p>`;
  return `<div class="r-emnote"><p class="hint">${L('The e-mail is not confirmed: without it a forgotten password cannot come back.', 'Почта не подтверждена — без этого забытый пароль не вернуть.')}</p>
    <button class="r-btn r-sm" id="em-confirm">${L('Confirm', 'Подтвердить')}</button></div>`;
}
async function emailConfirmSend() {
  const r = await api('email/confirm/send', { lang: LANG });
  if (r.ok && r.data.confirmed) state.user.email_confirmed = true;
  else if (r.ok) state.emSent = true;
  else if (r.error === 'slow') { state.emSent = true; }
  render(true);
}

function viewLost() {
  return `<nav class="r-menu">
    ${mCap('404', L('there\'s no such page', 'такой страницы нет'), 0)}
    ${mItem(L('Home', 'На главную'), '#/home', { main: true, o: 1 })}
    ${mItem(L('Forum', 'Форум'), '#/forum', { o: 2 })}
    ${mItem(L('Market', 'Маркет'), '#/market', { o: 3 })}
  </nav>`;
}

/* ================================================================================================ the window
   The sections down its left, as the modules' menu has them; the screen itself on the right, under its title. */
function rail() { return ''; }
const canStaff = () => !!(state.user && (state.user.admin || (state.user.perms || []).includes('staff.panel')));
function sidebar() {
  const u = state.user, r = state.route, a = String(state.arg || '').split('/')[0], me_ = u ? u.login : '';
  const n = (x) => (x ? (x > 99 ? '99+' : String(x)) : '');
  const nav = (href, icon, name, on, count, cls) => `<a class="r-nav ${on ? 'r-on' : ''} ${cls || ''}" href="${href}">${ic(icon)}<span>${name}</span>${count !== undefined ? `<span class="r-n">${count}</span>` : ''}</a>`;
  const brand = `<a class="r-brand" href="#/home" aria-label="${L('To the menu', 'В меню')}"><span class="r-lg" style="background-image:url(${LOGO_HEAT})"></span><span><b>Cursed</b><small>cursedclient.xyz</small></span></a>`;
  const lang = `<span class="r-lng" translate="no"><button class="${LANG === 'ru' ? 'r-on' : ''}" data-lang="ru">RU</button><button class="${LANG === 'en' ? 'r-on' : ''}" data-lang="en">EN</button></span>`;
  if (!u) {
    return `${brand}
      <p class="r-grp">${L('Cursed', 'Cursed')}</p>
      ${nav('#/news', 'news', L("What's new", 'Что нового'), r === 'news')}
      ${nav('#/docs/rules', 'doc', L('Documents', 'Документы'), r === 'docs')}
      ${nav('#/home', 'back', L('To the menu', 'В меню'), false)}
      <span class="r-sp"></span>
      <div class="r-side-foot"><a class="r-btn r-pri" href="#/signin">${L('Sign in', 'Войти')}</a>${lang}</div>`;
  }
  const dash = r === 'dashboard', sub = a || 'overview';
  return `${brand}
    <p class="r-grp">${L('Community', 'Сообщество')}</p>
    ${nav('#/forum', 'forum', L('Forum', 'Форум'), r === 'forum')}
    ${nav('#/market', 'bag', L('Market', 'Маркет'), r === 'market' || r === 'pack' || r === 'author' || r === 'upload')}
    ${nav('#/wardrobe', 'shirt', L('Wardrobe', 'Гардероб'), false)}
    ${nav('#/friends', 'users', L('Friends', 'Друзья'), r === 'friends', n(FR.unread), 'r-nav-fr')}
    ${nav('#/news', 'news', L("What's new", 'Что нового'), r === 'news')}
    ${nav('#/badges', 'medal', L('Badges', 'Значки'), r === 'badges')}
    ${nav('#/top', 'trophy', L('The best', 'Лучшие'), r === 'top')}
    <p class="r-grp">${L('Account', 'Кабинет')}</p>
    ${nav('#/dashboard/overview', 'grid', L('Overview', 'Обзор'), dash && sub === 'overview')}
    ${nav('#/dashboard/recode', 'flame', 'Recode', dash && sub === 'recode')}
    ${nav('#/u/' + encodeURIComponent(me_), 'page', L('My page', 'Моя страница'), r === 'u' && decodeURIComponent(a).toLowerCase() === me_.toLowerCase())}
    ${nav('#/dashboard/profile', 'user', L('Profile', 'Профиль'), dash && sub === 'profile')}
    ${nav('#/notifications', 'bell', L('Notifications', 'Уведомления'), r === 'notifications' || (dash && sub === 'notify'), n(SOC.unread), 'r-nav-notes')}
    ${nav('#/dashboard/configs', 'layers', L('Configs', 'Конфиги'), dash && sub === 'configs')}
    ${nav('#/dashboard/packs', 'box', L('My packs', 'Мои паки'), dash && sub === 'packs')}
    ${rfCan() ? nav('#/dashboard/refs', 'link', L('Referrals', 'Рефералы'), dash && sub === 'refs') : ''}
    ${nav('#/dashboard/sessions', 'monitor', L('Sessions', 'Входы'), dash && sub === 'sessions')}
    <p class="r-grp">${L('Help', 'Помощь')}</p>
    ${nav('#/support', 'chat', L('Support', 'Поддержка'), r === 'support')}
    ${nav('#/docs/rules', 'doc', L('Documents', 'Документы'), r === 'docs')}
    ${nav('#/buy', 'bag', L('Recode prices', 'Цены Recode'), false)}
    ${canStaff() || rkCan() ? `<p class="r-grp">${L('Staff', 'Персонал')}</p>${canStaff() ? nav('#/admin', 'shield', L('Staff panel', 'Панель персонала'), r === 'admin') : ''}${rkCan() ? nav('#/keys', 'key', L('Keys', 'Ключи'), r === 'keys') : ''}${u.admin ? nav('#/watch', 'shield', L('Watch', 'Подозрительные'), r === 'watch') : ''}` : ''}
    <span class="r-sp"></span>
    <div class="r-side-foot"><a class="r-me" href="#/u/${encodeURIComponent(me_)}">${head(me_, 32)}<span><b translate="no">${esc(me_)}</b><small translate="no">${u.card ? pfx(u.card) : ''}uid ${esc(String(u.uid_text || u.uid))}</small></span></a>
      <span class="r-side-row">${lang}<button class="r-out" id="signout" aria-label="${L('Sign out', 'Выйти')}" title="${L('Sign out', 'Выйти')}">${ic('out')}</button></span></div>`;
}
/** The window's title and the line under it, by the screen. */
function winTitle() {
  const r = state.route, a = String(state.arg || '').split('/');
  const T = (en, ru, sen, sru) => [L(en, ru), sen ? L(sen, sru) : ''];
  switch (r) {
    case 'forum': return a[0] === 't' ? T('Forum', 'Форум') : a[0] === 'new' ? T('Forum', 'Форум') : T('Forum', 'Форум', 'Bugs, ideas, help and everything else', 'Баги, идеи, помощь и всё остальное');
    case 'market': return T('Market', 'Маркет', 'Packs and shaders made by members', 'Паки и шейдеры от участников');
    case 'pack': return T('Market', 'Маркет');
    case 'author': return T('Author', 'Автор');
    case 'upload': return T('Upload', 'Загрузка', 'A resource pack or a shader pack', 'Ресурспак или шейдерпак');
    case 'friends': return T('Friends', 'Друзья', 'Conversations, friends, groups', 'Переписки, друзья, группы');
    case 'news': return T("What's new", 'Что нового', 'Every build of Recode and Cursed, the newest first', 'Каждая сборка Recode и Cursed, сначала новые');
    case 'badges': return T('Badges', 'Значки');
    case 'top': return T('The best', 'Лучшие', 'Who plays, collects and writes the most', 'Кто больше всех играет, собирает и пишет');
    case 'notifications': return T('Notifications', 'Уведомления');
    case 'u': return T('Member', 'Участник');
    case 'support': return T('Support', 'Поддержка');
    case 'admin': return T('Staff panel', 'Панель персонала');
    case 'watch': return T('Watch', 'Подозрительные', 'What Recode’s rules saw', 'Что заметили правила Recode');
    case 'link': return T('The loader', 'Лоудер', 'Signing in to Recode’s loader', 'Вход в лоудер Recode');
    case 'keys': return T('Keys', 'Ключи', 'Recode keys: issued here and activated in the cabinet', 'Ключи Recode: выпуск здесь, активация в кабинете');
    case 'docs': case 'license': return T('Documents', 'Документы');
    case 'dashboard': {
      const t = { overview: ['Overview', 'Обзор'], profile: ['Profile', 'Профиль'], configs: ['Configs', 'Конфиги'], packs: ['My packs', 'Мои паки'], notify: ['Notifications', 'Уведомления'], sessions: ['Sessions', 'Входы'], refs: ['Referrals', 'Рефералы'], recode: ['Recode', 'Recode'] }[a[0] || 'overview'] || ['Account', 'Кабинет'];
      return [L(...t), a[0] === 'overview' || !a[0] ? L(`Hi, ${state.user ? state.user.login : ''}`, `Привет, ${state.user ? state.user.login : ''}`) : ''];
    }
    default: return ['Cursed', ''];
  }
}

/* ---- the overview, as the modules' menu would show it ---- */
function dashOverview() {
  const u = state.user, rs = u && u.recode;
  if (u) ask('look/' + encodeURIComponent(u.login));
  const recode = `<div class="r-hero"><div class="r-shot ${SHOT ? '' : 'r-shotbg'}" ${SHOT ? `style="background-image:url(${SHOT})"` : ''}></div>
      <span class="r-k">Cursed Recode · 26.3</span>
      ${rs && rs.active ? `<h2>${rs.forever ? L('Forever', 'Навсегда') : L('Active', 'Активна')}</h2><p>${rs.forever ? L('Recode is yours for good.', 'Recode у вас навсегда.') : `${L('Subscription until', 'Подписка до')} ${rkDate(rs.until)} · ${rkLeft(rs.until)}.`}</p>`
        : `<h2>${L('Soon', 'Скоро')}</h2>
      <p>${L('New prices', 'Новые цены')}: ${TERMS.map((t) => `${t.d ? daysW(t.d) : L('forever', 'навсегда')} — ${rub(t.p)}`).join(', ')}. ${L('Buy a subscription on the website. Support: @paster_era.', 'Подписку можно купить на сайте. Поддержка: @paster_era в Telegram.')}</p>`}
      <div class="acts"><a class="r-btn r-pri" href="#/dashboard/recode">${rs && rs.active ? L('Subscription', 'Подписка') : L('Activate a key', 'Активировать ключ')}</a><a class="r-btn" href="#/buy">${L('Prices', 'Цены')}</a><a class="r-btn" href="#/news">${L("What's new", 'Что нового')}</a></div></div>`;
  const free = u && u.tester ? `<a class="r-btn r-pri" href="/api/dist/loader" id="get-loader" download>${ic('down')}${L('Download', 'Скачать')}</a>` : `<a class="r-btn" href="#/support">${L('Ask support', 'Через поддержку')}</a>`;
  return `<h1 class="sr">${L('Overview', 'Обзор')}</h1>
    ${recode}
    <div class="r-grid r-g3">
      <div class="r-tile"><h3>Cursed <span class="r-pill">${L('free', 'бесплатно')}</span></h3><p>${L('Minecraft 1.21.11 · for Windows 10 and 11', 'Minecraft 1.21.11 · для Windows 10 и 11')}</p><div class="acts">${free}<a class="r-btn r-ghost" href="#/news">${L('What\'s new', 'Что нового')}</a></div></div>
      <div class="r-tile"><h3>${L('Account', 'Аккаунт')}</h3>${kv(account())}${emailNote()}
        <div class="acts"><button class="r-btn r-sm ${state.pwOpen ? 'r-on' : ''}" id="pw-open">${L('Change password', 'Сменить пароль')}</button><button class="r-btn r-sm r-ghost" id="signout">${L('Sign out', 'Выйти')}</button></div>${state.pwOpen ? pwForm() : ''}${state.emOpen ? emForm() : ''}${state.emDone ? `<p class="hint ok" style="margin-top:14px">${L('E-mail changed.', 'Почта изменена.')}</p>` : ''}</div>
      <div class="r-tile r-look"><h3>${L('Your look', 'Ваш образ')}</h3><canvas class="ov-cv" id="ov-cv" data-login="${esc(u ? u.login : '')}" aria-hidden="true"></canvas>
        <div class="acts"><a class="r-btn r-pri" href="#/wardrobe">${L('Wardrobe', 'Гардероб')}</a><a class="r-btn r-ghost" href="#/u/${encodeURIComponent(u ? u.login : '')}">${L('My page', 'Моя страница')}</a></div></div>
    </div>
    ${avatarBlock()}`;
}

/* ---- Recode: the account's subscription and its keys (server: recode.rs). Sold as keys only (FunPay); a key is
   activated here, in the cabinet, and adds its days, «forever» over all. Making and revoking keys is hers alone. ---- */
const RK_TERMS = [1, 2, 7, 14, 30, 90, 180, 0];
const RK = { msg: '', bad: false, busy: false, made: null, state: '', q: '', qLive: '', qTimer: 0, page: 0, batch: 0, sure: '', sureTimer: 0, copied: '', days: 30, count: 10, note: '', beta: false, for: '' };
const rkTerm = (d) => (d === 0 ? L('forever', 'навсегда') : LANG === 'ru' ? `${d} ${plural(d, 'день', 'дня', 'дней')}` : `${d} day${d === 1 ? '' : 's'}`);
const rkDate = (s) => new Date(s * 1000).toLocaleString(L('en-GB', 'ru-RU'), { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
const rkDay = (s) => new Date(s * 1000).toLocaleDateString(L('en-GB', 'ru-RU'), { day: 'numeric', month: 'short', year: 'numeric' });
const rkLeft = (until) => { const d = Math.max(1, Math.ceil((until - Date.now() / 1000) / 86400)); return LANG === 'ru' ? `осталось ${d} ${plural(d, 'день', 'дня', 'дней')}` : `${d} day${d === 1 ? '' : 's'} left`; };
const RK_SAY = {
  'key-wrong': ['There is no such key.', 'Такого ключа нет.'],
  'key-used': ['This key has already been activated.', 'Этот ключ уже активирован.'],
  'key-yours': ['You have already activated this key.', 'Вы уже активировали этот ключ.'],
  'key-revoked': ['This key has been revoked.', 'Этот ключ отозван.'],
  'key-tries': ['Too many wrong keys. Try again in an hour.', 'Слишком много неверных ключей. Попробуйте через час.'],
  term: ['No such term.', 'Такого срока нет.'], owner: ['Keys are not yours to make.', 'Выпускать ключи вам нельзя.'],
};
/** Keys: hers all of them; the role «Ключи»'s their own batches, ten keys at a time (her word, 23.10). */
const rkCan = () => !!(state.user && (state.user.admin || (state.user.perms || []).includes('recode.keys')));
const rkMost = () => (state.user && state.user.admin ? 500 : 10);
const rkSay = (r) => (r.error === 'count' ? L(`From 1 to ${rkMost()} keys at once.`, `От 1 до ${rkMost()} ключей за раз.`) : RK_SAY[r.error] ? L(...RK_SAY[r.error]) : tr(SAY[r.error] || SAY.busy));
/** The account's Recode in two lines. */
function rkStatus(s) {
  if (s && s.forever) return [L('Forever', 'Навсегда'), L('Recode is yours for good.', 'Recode у вас навсегда.')];
  if (s && s.active) return [L('Active', 'Активна'), `${L('until', 'до')} ${rkDate(s.until)} · ${rkLeft(s.until)}`];
  if (s && s.until) return [L('Ended', 'Закончилась'), `${rkDate(s.until)}`];
  return [L('None', 'Нет'), L('Activate a key to get Recode.', 'Активируйте ключ, чтобы получить Recode.')];
}
/** A key as it is typed: capitals, the dashes put in (RCD-XXXXX-XXXXX-XXXXX). */
function rkShape(v) {
  let s = String(v || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (s.startsWith('RCD')) s = s.slice(3);
  s = s.slice(0, 15);
  return s ? 'RCD-' + (s.match(/.{1,5}/g) || []).join('-') : '';
}

function dashRecode() {
  const c = ask('recode');
  const s = c.ok ? c.data : state.user && state.user.recode;
  const [big, small] = rkStatus(s);
  const keys = c.ok ? c.data.keys : [];
  return `<h1 class="sr">Recode</h1><div class="sections">
    <div class="block rk-now ${s && s.active ? 'rk-on' : ''}"><h2 class="sec">${L('Subscription', 'Подписка')}</h2>
      <p class="rk-big">${esc(big)}</p><p class="ash">${esc(small)}</p>
      ${s && s.active ? `<div class="acts">${c.ok && c.data.loader ? `<a class="r-btn r-pri" href="/api/dist/recode/loader" download>${ic('down')}${L('Download Recode', 'Скачать Recode')}</a><span class="ash">Windows 10 · 11 · <a href="#/docs/reqs">${L('requirements', 'требования')}</a></span>` : `<span class="ash">${L('The download opens with Recode’s release.', 'Скачивание откроется с выходом Recode.')}</span>`}</div>` : ''}</div>
    <div class="block"><h2 class="sec">${L('Activate a key', 'Активировать ключ')}</h2>
      <form class="rk-form" id="rk-activate" autocomplete="off" novalidate>
        <input class="in rk-key" id="rk-key" maxlength="40" spellcheck="false" autocapitalize="characters" placeholder="RCD-XXXXX-XXXXX-XXXXX" aria-label="${L('Key', 'Ключ')}" value="${esc(RK.for)}">
        <button class="r-btn r-pri" type="submit" ${RK.busy ? 'disabled' : ''}>${L('Activate', 'Активировать')}</button>
      </form>
      <p class="hint ${RK.bad ? 'bad' : 'ok'}" id="rk-msg" role="status">${esc(RK.msg)}</p>
      <p class="hint">${L('A key adds its days to the subscription; a key «forever» makes it forever.', 'Ключ добавляет свои дни к подписке, ключ «навсегда» делает её бессрочной.')}</p></div>
    ${keys.length ? `<div class="block"><h2 class="sec">${L('Your keys', 'Ваши ключи')}</h2><div class="rows rk-mine">${keys.map((k) => `<div><b class="num" translate="no">${esc(k.code)}</b><span class="st ${k.revoked ? 'warn' : 'ok'}">${k.revoked ? L('revoked', 'отозван') : rkTerm(k.days)}</span><span class="d ash">${rkDate(k.at)}</span></div>`).join('')}</div></div>` : ''}
  </div>`;
}

/** Her keys (the role «Ключи»'s: their own): new ones made, the batches, every key with where it went; revoked. */
function viewKeys() {
  if (!rkCan()) return `<div class="empty">${L(...RK_SAY.owner)}</div>`;
  const qs = new URLSearchParams();
  if (RK.state) qs.set('state', RK.state);
  if (RK.qLive) qs.set('q', RK.qLive);
  if (RK.batch) qs.set('batch', RK.batch);
  if (RK.page) qs.set('page', RK.page);
  const c = ask('admin/keys' + (String(qs) ? '?' + qs : ''));
  const made = RK.made;
  const make = `<div class="block"><h2 class="sec">${L('New keys', 'Выпустить ключи')}</h2>
      <form class="rk-make" id="rk-make" autocomplete="off" novalidate>
        <label><span class="ash">${L('Term', 'Срок')}</span><select class="in" id="rk-days">${RK_TERMS.map((t) => `<option value="${t}" ${RK.days === t ? 'selected' : ''}>${rkTerm(t)}</option>`).join('')}</select></label>
        <label><span class="ash">${L('How many', 'Сколько')}</span><input class="in num rk-count" id="rk-count" type="number" min="1" max="${rkMost()}" value="${Math.min(RK.count, rkMost())}"></label>
        <label><span class="ash">${L('Kind', 'Вид')}</span><select class="in" id="rk-kind"><option value="" ${RK.beta ? '' : 'selected'}>${L('Plain', 'Обычные')}</option><option value="beta" ${RK.beta ? 'selected' : ''}>${L('Beta: a tester', 'Бета: даёт «Бета-тестер»')}</option></select></label>
        <label class="rk-note"><span class="ash">${L('Note', 'Пометка')}</span><input class="in" id="rk-note" maxlength="80" placeholder="${L('Where they go: a giveaway, a partner…', 'Куда пойдут: розыгрыш, партнёр…')}" value="${esc(RK.note)}"></label>
        <button class="r-btn r-pri" type="submit" ${RK.busy ? 'disabled' : ''}>${L('Make', 'Выпустить')}</button>
      </form>
      ${made ? `<div class="rk-made"><p class="ash">${L('Batch', 'Пачка')} <span class="num">#${made.batch}</span> · ${rkTerm(made.days)}${made.beta ? ' · ' + L('beta', 'бета') : ''} · <span class="num">${made.codes.length}</span> ${L('keys', plural(made.codes.length, 'ключ', 'ключа', 'ключей'))}${made.note ? ' · ' + esc(made.note) : ''}</p>
        <textarea class="in rk-codes" readonly rows="${Math.min(8, made.codes.length)}" aria-label="${L('The keys', 'Ключи')}" translate="no">${esc(made.codes.join('\n'))}</textarea>
        <div class="acts"><button class="r-btn r-sm" data-rk-copy="made">${RK.copied === 'made' ? L('Copied', 'Скопировано') : L('Copy all', 'Скопировать все')}</button><a class="r-btn r-sm" href="/api/admin/keys/batch/${made.batch}.txt" download>${L('Download .txt', 'Скачать .txt')}</a><button class="r-btn r-sm r-ghost" data-rk-hide="1">${L('Hide', 'Скрыть')}</button></div></div>` : ''}
      <p class="hint ${RK.bad ? 'bad' : 'ok'}" id="rk-msg" role="status">${esc(RK.msg)}</p></div>`;
  if (waiting(c)) return `<h1 class="sr">${L('Keys', 'Ключи')}</h1><div class="sections">${make}<div class="block">${ghosts(1)}</div></div>`;
  if (!c.ok) return `<h1 class="sr">${L('Keys', 'Ключи')}</h1><div class="sections">${make}<div class="block">${trouble(c)}</div></div>`;
  const d = c.data;
  const nums = `<div class="rk-nums"><span><b class="num">${fmt(d.counts.free)}</b><span class="ash">${L('free', 'свободных')}</span></span><span><b class="num">${fmt(d.counts.used)}</b><span class="ash">${L('activated', 'активировано')}</span></span><span><b class="num">${fmt(d.counts.revoked)}</b><span class="ash">${L('revoked', 'отозвано')}</span></span></div>`;
  const batches = d.batches.length ? `<div class="block"><h2 class="sec">${L('Batches', 'Пачки')}</h2><div class="rows rk-batches">${d.batches.map((b) => `<div class="${RK.batch === b.batch ? 'rk-sel' : ''}">
      <b class="num">#${b.batch}</b><span class="st cream">${rkTerm(b.days)}${b.beta ? ' · ' + L('beta', 'бета') : ''}</span><span class="d ash">${rkDay(b.made)}${b.note ? ' · ' + esc(b.note) : ''}</span>
      <span class="ash"><span class="num">${b.free}</span> ${L('free of', 'свободно из')} <span class="num">${b.count}</span></span>
      <span class="rk-acts"><button class="r-btn r-sm r-ghost" data-rk-batch="${RK.batch === b.batch ? 0 : b.batch}">${RK.batch === b.batch ? L('All', 'Все') : L('Show', 'Показать')}</button>${b.free ? `<a class="r-btn r-sm r-ghost" href="/api/admin/keys/batch/${b.batch}.txt" download>.txt</a>` : ''}</span></div>`).join('')}</div></div>` : '';
  const tab = (v, en, ru) => `<button class="r-btn r-sm ${RK.state === v ? 'r-on' : 'r-ghost'}" data-rk-state="${v}">${L(en, ru)}</button>`;
  const status = (k) => (k.revoked ? `<span class="st warn">${L('revoked', 'отозван')} ${rkDay(k.revoked)}</span>`
    : k.used ? `<span class="rk-who"><a href="#/admin/user/${encodeURIComponent(k.used.login || '')}" translate="no">${esc(k.used.login || '#' + k.used.uid)}</a><span class="ash"> · ${k.used.at ? rkDate(k.used.at) : ''}</span></span>`
      : `<span class="st ok">${L('free', 'свободен')}</span>`);
  const rows = d.items.length ? d.items.map((k) => `<div class="rk-row">
      <b class="num rk-code" translate="no">${esc(k.code)}</b><span class="ash">${rkTerm(k.days)} · #${k.batch}</span>${status(k)}
      <span class="rk-acts">${!k.used && !k.revoked ? `<button class="r-btn r-sm r-ghost" data-rk-copy="${esc(k.code)}">${RK.copied === k.code ? L('Copied', 'Скопировано') : L('Copy', 'Копировать')}</button>` : ''}${k.revoked ? '' : `<button class="r-btn r-sm ${RK.sure === k.code ? 'rk-bad' : 'r-ghost'}" data-rk-revoke="${esc(k.code)}">${RK.sure === k.code ? L('Revoke?', 'Отозвать?') : L('Revoke', 'Отозвать')}</button>`}</span></div>`).join('')
    : `<div class="empty">${L('No keys here.', 'Ключей нет.')}</div>`;
  const pages = d.page || d.more ? `<div class="acts">${d.page ? `<button class="r-btn r-sm" data-rk-page="${d.page - 1}">${L('Back', 'Назад')}</button>` : ''}${d.more ? `<button class="r-btn r-sm" data-rk-page="${d.page + 1}">${L('Next', 'Дальше')}</button>` : ''}</div>` : '';
  return `<h1 class="sr">${L('Keys', 'Ключи')}</h1><div class="sections">
    ${make}
    ${batches}
    <div class="block"><h2 class="sec">${d.own ? L('Your keys', 'Ваши ключи') : L('All keys', 'Все ключи')}${RK.batch ? ` <span class="ash">· ${L('batch', 'пачка')} #${RK.batch}</span>` : ''}</h2>${nums}
      <div class="rk-filter">${tab('', 'All', 'Все')}${tab('free', 'Free', 'Свободные')}${tab('used', 'Activated', 'Активированные')}${tab('revoked', 'Revoked', 'Отозванные')}
        <input class="in" id="rk-q" type="search" placeholder="${L('A key or a login', 'Ключ или логин')}" value="${esc(RK.q)}" spellcheck="false"></div>
      <div class="rows rk-list">${rows}</div>${pages}</div>
  </div>`;
}

document.addEventListener('submit', async (e) => {
  const f = e.target;
  if (f.id === 'rk-activate') {
    e.preventDefault();
    const key = document.getElementById('rk-key').value;
    if (!key.trim() || RK.busy) return;
    Object.assign(RK, { busy: true, msg: '', bad: false, for: key });
    render(true);
    const r = await api('recode/activate', { key });
    RK.busy = false;
    if (r.ok) {
      const s = r.data;
      RK.msg = s.forever && r.data.days === 0 ? L('Done: Recode is yours for good.', 'Готово: Recode у вас навсегда.') : `${L('Done', 'Готово')}: +${rkTerm(r.data.days)}. ${s.forever ? L('The subscription is forever.', 'Подписка навсегда.') : `${L('Subscription until', 'Подписка до')} ${rkDate(s.until)}.`}`;
      RK.bad = false; RK.for = '';
      if (state.user) state.user.recode = { active: s.active, forever: s.forever, until: s.until };
      forget('recode');
      World.Snd.tick(0.8);
    } else { RK.msg = rkSay(r); RK.bad = true; }
    render(true);
  } else if (f.id === 'rk-make') {
    e.preventDefault();
    if (RK.busy) return;
    const days = Number(document.getElementById('rk-days').value), count = Math.max(1, Math.min(rkMost(), Math.round(Number(document.getElementById('rk-count').value) || 0))), note = document.getElementById('rk-note').value.trim();
    const beta = document.getElementById('rk-kind').value === 'beta';
    Object.assign(RK, { busy: true, msg: '', bad: false, days, count, note, beta });
    render(true);
    const r = await api('admin/keys', { days, count, note, beta });
    RK.busy = false;
    if (r.ok) { RK.made = r.data; RK.msg = ''; forget('admin/keys'); } else { RK.msg = rkSay(r); RK.bad = true; }
    render(true);
  }
});
document.addEventListener('input', (e) => {
  const t = e.target;
  if (t.id === 'rk-key') {
    const v = rkShape(t.value);
    if (v !== t.value && (t.selectionStart === t.value.length)) t.value = v;
    RK.for = t.value;
  } else if (t.id === 'rk-q') {
    RK.q = t.value;
    clearTimeout(RK.qTimer);
    RK.qTimer = setTimeout(() => { RK.qLive = RK.q.trim(); RK.page = 0; render(true); }, 300);
  } else if (t.id === 'rk-count') RK.count = Number(t.value) || RK.count;
  else if (t.id === 'rk-note') RK.note = t.value;
});
document.addEventListener('change', (e) => { if (e.target.id === 'rk-days') RK.days = Number(e.target.value); });
document.addEventListener('click', async (e) => {
  const b = e.target.closest && e.target.closest('[data-rk-copy],[data-rk-state],[data-rk-batch],[data-rk-page],[data-rk-revoke],[data-rk-hide]');
  if (!b) return;
  const ds = b.dataset;
  if (ds.rkCopy !== undefined) {
    const text = ds.rkCopy === 'made' ? (RK.made ? RK.made.codes.join('\n') : '') : ds.rkCopy;
    try { await navigator.clipboard.writeText(text); } catch (err) { const ta = document.getElementById('rk-codes'); if (ta) { ta.select(); document.execCommand('copy'); } }
    RK.copied = ds.rkCopy; render(true);
    setTimeout(() => { if (RK.copied === ds.rkCopy) { RK.copied = ''; render(true); } }, 1600);
  } else if (ds.rkState !== undefined) { RK.state = ds.rkState; RK.page = 0; render(true); }
  else if (ds.rkBatch !== undefined) { RK.batch = Number(ds.rkBatch) || 0; RK.page = 0; render(true); }
  else if (ds.rkPage !== undefined) { RK.page = Math.max(0, Number(ds.rkPage) || 0); render(true); }
  else if (ds.rkHide !== undefined) { RK.made = null; render(true); }
  else if (ds.rkRevoke !== undefined) {
    const code = ds.rkRevoke;
    clearTimeout(RK.sureTimer);
    if (RK.sure !== code) {
      RK.sure = code; render(true);
      RK.sureTimer = setTimeout(() => { if (RK.sure === code) { RK.sure = ''; render(true); } }, 4000);
      return;
    }
    RK.sure = '';
    const r = await api(`admin/keys/${encodeURIComponent(code)}/revoke`, {});
    if (r.ok) { RK.msg = L(`Revoked: ${code}.`, `Отозван: ${code}.`); RK.bad = false; forget('admin/keys'); } else { RK.msg = rkSay(r); RK.bad = true; }
    render(true);
  }
});
MEMBERS_ONLY.add('keys');
const viewDashboardBase = viewDashboard;
// (the cabinet's Recode, beside app.js's own sections)
viewDashboard = function (tab) {
  if (String(tab || '').split('/')[0] === 'recode') return `<div class="dash">${rail('recode')}<div>${dashRecode()}</div></div>`;
  return viewDashboardBase(tab);
};

/* ---- the loader's sign-in (recode.rs): the loader shows a code and opens this page; here it is allowed, or not ---- */
const LK = { busy: false, msg: '', bad: false };
function viewLink(arg) {
  const code = String(arg || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  const c = ask('loader/link/' + code);
  const page = (inner) => `<h1 class="sr">${L('The loader', 'Лоудер')}</h1><div class="sections"><div class="block lk">${inner}</div></div>`;
  if (waiting(c)) return page(ghosts(1));
  if (!c.ok) return page(`<h2 class="sec">${L('This code has expired', 'Код устарел')}</h2><p class="ash">${L('It was used already, or more than ten minutes passed. Press «Sign in» in the loader again.', 'Его уже использовали или прошло больше десяти минут. Нажмите «Войти» в лоудере ещё раз.')}</p>`);
  const d = c.data;
  if (d.state === 'allowed') return page(`<p class="lk-code num" translate="no">${esc(d.code)}</p><h2 class="sec">${L('Done', 'Готово')}</h2><p class="ash">${L('The loader is signed in. You can go back to it.', 'Лоудер вошёл в аккаунт. Можно вернуться к нему.')}</p>`);
  if (d.state === 'denied') return page(`<p class="lk-code num" translate="no">${esc(d.code)}</p><h2 class="sec">${L('Refused', 'Отклонено')}</h2><p class="ash">${L('The loader was not let in.', 'Лоудер не впущен.')}</p>`);
  const left = Math.max(0, Math.round((d.expires - Date.now() / 1000) / 60));
  return page(`<p class="ash">${L('The Recode loader asks to sign in to', 'Лоудер Recode просит войти в аккаунт')} <b translate="no">${esc(d.login)}</b></p>
    <p class="lk-code num" translate="no">${esc(d.code)}</p>
    <p class="ash">${L('Check that the loader shows the same code.', 'Проверьте, что лоудер показывает тот же код.')}${left ? ` ${L(`It is good for ${left} more min.`, `Код действует ещё ${left} мин.`)}` : ''}</p>
    ${d.recode && d.recode.active ? '' : `<p class="hint">${L('This account has no Recode yet: the loader will show how to get it.', 'У этого аккаунта пока нет Recode — лоудер покажет, как его получить.')}</p>`}
    <div class="acts"><button class="r-btn r-pri" data-lk="allow" ${LK.busy ? 'disabled' : ''}>${L('Allow', 'Разрешить')}</button><button class="r-btn r-ghost" data-lk="deny" ${LK.busy ? 'disabled' : ''}>${L('It wasn’t me', 'Это не я')}</button></div>
    <p class="hint ${LK.bad ? 'bad' : ''}" role="status">${LK.msg ? esc(LK.msg) : L('Allow it only if you have just opened the loader yourself, on your computer.', 'Разрешайте, только если вы сами только что открыли лоудер на своём компьютере.')}</p>`);
}
document.addEventListener('click', async (e) => {
  const b = e.target.closest && e.target.closest('[data-lk]');
  if (!b || LK.busy) return;
  const code = String(state.arg || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  LK.busy = true; LK.msg = ''; LK.bad = false; render(true);
  const r = await api(`loader/link/${code}/${b.dataset.lk === 'allow' ? 'allow' : 'deny'}`, {});
  LK.busy = false;
  if (!r.ok) { LK.msg = r.error === 'link-gone' ? L('This code has expired.', 'Код устарел.') : tr(SAY[r.error] || SAY.busy); LK.bad = true; }
  else World.Snd.tick(0.8);
  forget('loader/link/');
  render(true);
});
MEMBERS_ONLY.add('link');

/* ---- her watch over Recode (recode.rs flags): what the rules saw, a ban made by them; all right, or banned ---- */
const WT = { all: false, msg: '', bad: false, busy: 0, open: 0, reason: {}, length: {} };
const WT_KIND = {
  autoban: ['Banned by the rules', 'Забанен правилами'],
  'tpm-changed': ['The TPM changed, the rest the same', 'Сменился TPM, остальное железо то же'],
  'tpm-off': ['The TPM switched off, the rest the same', 'TPM выключен, остальное железо то же'],
  'second-game': ['Tried a second game at once', 'Пытался запустить вторую игру'],
  resets: ['Frees the computer often', 'Часто сбрасывает привязку ПК'],
  protect: ['Noticed by the guard', 'Замечено защитой'],
  sight: ['What was beside the game', 'Что было рядом с игрой'],
  'touch-unverified': ['Touched the game, not confirmed', 'Коснулось игры, не подтверждено'],
};
const wtWhy = (x) => {
  const d = x.detail || {}, times = d.times > 1 ? ` · ${L(`${d.times} times`, `${d.times} ${plural(d.times, 'раз', 'раза', 'раз')}`)}` : '';
  if (x.kind === 'autoban') return esc(d.reason || '') + times;
  if (x.kind === 'resets') return L(`${d.week} in a week`, `${d.week} за неделю`) + times;
  if (x.kind === 'tpm-changed') return L('A TPM reset in the BIOS does this honestly; a spoofer too.', 'Так бывает честно (сброс TPM в BIOS) — и при подмене.') + times;
  if (x.kind === 'tpm-off') return L('A BIOS reset does this honestly; so does one who switches it off to get round a ban (a ban on the computer stands all the same).', 'Так бывает честно (сброс BIOS) — и когда выключают нарочно, чтобы обойти бан (бан на этот ПК всё равно действует).') + times;
  if (x.kind === 'sight') return (d.sights || []).map((s) => esc(s.kind || '') + (s.name ? ': ' + esc(s.name) : '')).join(' · ') + times;
  return esc(d.why || '') + times;
};
/* What the check actually saw, under the one line above: its own words (`found`), or the note as it
   came when nothing was written under `why:` yet. The name of the log goes on the line whenever
   there is one — that name is the handle to the whole note beside the database, and a row filled
   from it would otherwise show the sentence and not where the sentence is from.
   A ban's own line is what the player was told (`reason`), so what the check saw goes here too:
   that is the part that tells a false ban from a real one. */
const wtSeen = (x) => {
  const d = x.detail || {};
  const name = d.file && !String(d.file).includes('\n') ? String(d.file) : '';
  const log = name ? `${L('Log', 'Журнал')} <span translate="no">${esc(name)}</span>` : '';
  if (x.kind === 'touch-unverified' && d.file && !name) return `<p class="ash wt-seen">${esc(String(d.file).replace(/\s+/g, ' ').trim())}</p>`;
  const why = x.kind === 'autoban' ? esc(d.why || '') : '';
  const parts = [why, d.found ? esc(d.found) : '', log].filter(Boolean);
  return parts.length ? `<p class="ash wt-seen">${parts.join(' · ')}</p>` : '';
};
function viewWatch() {
  if (!state.user || !state.user.admin) return `<div class="empty">${L('This is the owner’s alone.', 'Это только для владельца.')}</div>`;
  const c = ask('admin/recode/flags' + (WT.all ? '?all=1' : ''));
  const head = `<div class="rk-filter"><button class="r-btn r-sm ${WT.all ? 'r-ghost' : 'r-on'}" data-wt-all="0">${L('To look at', 'К рассмотрению')}</button><button class="r-btn r-sm ${WT.all ? 'r-on' : 'r-ghost'}" data-wt-all="1">${L('All', 'Все')}</button></div>`;
  if (waiting(c)) return `<h1 class="sr">${L('Watch', 'Подозрительные')}</h1><div class="sections"><div class="block">${head}${ghosts(1)}</div></div>`;
  if (!c.ok) return `<h1 class="sr">${L('Watch', 'Подозрительные')}</h1><div class="sections"><div class="block">${head}${trouble(c)}</div></div>`;
  const items = c.data.items;
  const row = (x) => {
    const open = !x.verdict;
    const st = x.kind === 'autoban' ? ''
      : x.verdict === 'ok' ? `<span class="st">${L('all right', 'нормально')}${x.by ? ' · ' + esc(x.by) : ''}</span>`
        : x.verdict === 'ban' ? `<span class="st cream">${L('banned', 'забанен')}${x.by ? ' · ' + esc(x.by) : ''}</span>` : '';
    return `<div class="wt-row ${open ? 'wt-open' : ''}">
      <div class="wt-top"><a class="wt-who" href="#/admin/user/${encodeURIComponent(x.login)}" translate="no">${esc(x.login)}</a>
        <span>${L(...(WT_KIND[x.kind] || [x.kind, x.kind]))}</span>${st}<span class="ash wt-at">${rkDate(x.at)}</span></div>
      <p class="ash">${wtWhy(x)}${x.recode && x.recode.active ? ` · Recode ${x.recode.forever ? L('forever', 'навсегда') : L('until ', 'до ') + rkDay(x.recode.until)}` : ''}${x.banned && x.kind !== 'autoban' ? ' · ' + L('banned now', 'сейчас в бане') : ''}</p>
      ${wtSeen(x)}
      ${open ? `<div class="wt-acts"><button class="r-btn r-sm" data-wt-ok="${x.id}" ${WT.busy ? 'disabled' : ''}>${L('All right', 'Нормально')}</button>
        <input class="in" data-wt-reason="${x.id}" maxlength="200" placeholder="${L('The ban’s reason', 'Причина бана')}" value="${esc(WT.reason[x.id] || '')}">
        <input class="in wt-len" data-wt-length="${x.id}" maxlength="8" placeholder="${L('7d · empty: for good', '7d · пусто: навсегда')}" value="${esc(WT.length[x.id] || '')}">
        <button class="r-btn r-sm r-pri" data-wt-ban="${x.id}" ${WT.busy ? 'disabled' : ''}>${L('Ban', 'Бан')}</button></div>` : ''}
    </div>`;
  };
  return `<h1 class="sr">${L('Watch', 'Подозрительные')}</h1><div class="sections"><div class="block">
    ${head}
    <p class="hint">${L('The rules ban by themselves only an account on a banned account’s computer; the rest waits for you here.', 'Сами правила банят только аккаунт с компьютера забаненного — остальное ждёт тебя здесь.')}</p>
    ${WT.msg ? `<p class="hint ${WT.bad ? 'bad' : 'ok'}" role="status">${esc(WT.msg)}</p>` : ''}
    <div class="rows wt-list">${items.length ? items.map(row).join('') : `<div class="empty">${L('Nothing to look at.', 'Смотреть не на что.')}</div>`}</div></div></div>`;
}
document.addEventListener('input', (e) => {
  const t = e.target;
  if (t.dataset && t.dataset.wtReason) WT.reason[t.dataset.wtReason] = t.value;
  else if (t.dataset && t.dataset.wtLength) WT.length[t.dataset.wtLength] = t.value;
});
document.addEventListener('click', async (e) => {
  const b = e.target.closest && e.target.closest('[data-wt-all],[data-wt-ok],[data-wt-ban]');
  if (!b) return;
  const ds = b.dataset;
  if (ds.wtAll !== undefined) { WT.all = ds.wtAll === '1'; WT.msg = ''; render(true); return; }
  const id = ds.wtOk || ds.wtBan, ban = ds.wtBan !== undefined;
  WT.busy = 1; WT.msg = ''; render(true);
  const r = await api(`admin/recode/flags/${id}`, ban ? { verdict: 'ban', reason: WT.reason[id] || '', length: WT.length[id] || '' } : { verdict: 'ok' });
  WT.busy = 0;
  if (r.ok) { WT.msg = ban ? L('Banned.', 'Забанен.') : L('Marked all right.', 'Отмечено: нормально.'); WT.bad = false; forget('admin/recode/flags'); }
  else { WT.msg = r.message || tr(SAY[r.error] || SAY.busy); WT.bad = true; }
  render(true);
});
MEMBERS_ONLY.add('watch');

/* ---- the documents: the rules, and the offer the payments stand on ---- */
DOCS.offer = { title: 'Offer', version: 'Last updated 26 / 10 / 2026', sections: [
  ['What is sold', ['Access to Cursed Recode for one account, for the selected subscription term.']],
  ['Keys', ['Pay for a subscription on cursedclient.xyz via RollyPay. After payment confirmation, access is added automatically to the account used at checkout. Previously issued keys can still be activated in the cabinet; each key works once for one account.']],
  ['The term', ['The term starts when payment is confirmed, or when an issued key is activated. Additional days extend the current subscription. Lifetime access lasts for as long as the project exists.']],
  ['One computer', ['Recode runs on one computer per account. The computer can be changed once a day.']],
  ['Requirements', ['Recode runs only on a computer that meets the requirements (Documents → Requirements): Windows 10 or 11 and a video card with Vulkan 1.3. Check them before buying.']],
  ['Refunds', ['For payment errors and refund requests, contact support on the site and provide the order number. Never send card details or banking verification codes.']],
  ['Bans', ['Bypassing the protection, reselling or handing over the account, or taking the payment back after activating a key bans the account and the computer, without a refund; the key’s days are taken back.']],
  ['Contacts', ['Support: https://t.me/paster_era.']],
] };
// The profiles' first backdrop is the valley of Recode's menu now (a real frame of it): the eclipse belonged to the old site.
THEME_NAMES.eclipse = ['Valley', 'Долина'];
RU.Offer = 'Оферта'; RU.Rules = RU.Rules || 'Правила';
DOCS_RU.offer = { title: 'Оферта', version: 'Обновлено 26 / 10 / 2026', sections: [
  ['Что продаётся', ['Доступ к Cursed Recode для одного аккаунта на выбранный срок подписки.']],
  ['Ключи', ['Подписка оплачивается на cursedclient.xyz через RollyPay. После подтверждения платежа доступ автоматически начисляется на аккаунт, с которого оформлена покупка. Ранее выданные ключи по-прежнему можно активировать в кабинете; каждый ключ действует один раз для одного аккаунта.']],
  ['Срок', ['Срок начинается после подтверждения оплаты или активации выданного ключа. Дополнительные дни продлевают действующую подписку. Доступ «навсегда» действует, пока существует проект.']],
  ['Один компьютер', ['Recode работает на одном компьютере на аккаунт. Сменить компьютер можно раз в сутки.']],
  ['Требования', ['Recode работает только на компьютере, который подходит под требования (Документы → Требования): Windows 10 или 11 и видеокарта с Vulkan 1.3. Проверьте их до покупки.']],
  ['Возврат', ['По вопросам ошибочных платежей и возврата обратитесь в поддержку на сайте, указав номер заказа. Не отправляйте реквизиты карты и банковские коды подтверждения.']],
  ['Блокировка', ['За обход защиты, перепродажу или передачу аккаунта, возврат денег после активации ключа аккаунт и компьютер блокируются без возврата, дни ключа снимаются.']],
  ['Контакты', ['Поддержка: https://t.me/paster_era.']],
] };
/* What Recode needs (21.10.2026): its own renderer draws with Vulkan from the loader's window on (vk/device.rs: 1.2 with
   dynamic rendering, synchronization2, push descriptors). The cards are checked against vulkan.gpuinfo.org's Windows
   reports: Kepler, GCN 1–3 and Intel before Skylake lack them under any driver. */
DOCS.reqs = { title: 'Requirements', version: 'Last updated 21 / 10 / 2026', sections: [
  ['System', ['Windows 10 or 11, 64-bit.', 'The internet: to sign in and to check the subscription.']],
  ['Video card', ['A card with Vulkan 1.3: Recode draws with it, the loader’s window too. These work:', [
    'NVIDIA GeForce GTX 750, GTX 900 and newer (GTX 10, GTX 16, RTX, MX)',
    'AMD Radeon RX 400 and newer, Ryzen’s built-in graphics (Vega, Radeon Graphics)',
    'Intel HD and UHD Graphics 500 and 600 (Core 6th generation and newer), UHD 700, Iris Xe, Arc',
  ], 'These do not, under any driver: NVIDIA GT 710, GT 730, GTX 600, GTX 760–780 and laptop GT 600M / 700M; AMD Radeon HD 7000, R5, R7, R9 (R9 390 and Fury too); Intel HD Graphics 4000, 4600, 5500 and older.', 'The driver from the NVIDIA, AMD or Intel site, of 2022 or newer.']],
  ['Memory and disk', ['Memory from 4 GB, better 8: the game gets 4 GB by default, never less than 2.', 'About 1 GB free on the disk.']],
  ['How to check', ['Task Manager → Performance → GPU shows the card’s name. Not sure? Ask support before buying.']],
] };
RU.Requirements = 'Требования';
DOCS_RU.reqs = { title: 'Требования', version: 'Обновлено 21 / 10 / 2026', sections: [
  ['Система', ['Windows 10 или 11, 64 бита.', 'Интернет — для входа и проверки подписки.']],
  ['Видеокарта', ['Нужна видеокарта с Vulkan 1.3: Recode рисует через него, и окно лоудера тоже. Подходят:', [
    'NVIDIA GeForce GTX 750, GTX 900 и новее (GTX 10, GTX 16, RTX, MX)',
    'AMD Radeon RX 400 и новее, встроенная графика Ryzen (Vega, Radeon Graphics)',
    'Intel HD и UHD Graphics 500 и 600 (Core 6-го поколения и новее), UHD 700, Iris Xe, Arc',
  ], 'Не подходят ни с каким драйвером: NVIDIA GT 710, GT 730, GTX 600, GTX 760–780 и ноутбучные GT 600M / 700M; AMD Radeon HD 7000, R5, R7, R9 (и R9 390, и Fury); Intel HD Graphics 4000, 4600, 5500 и более старые.', 'Драйвер — с сайта NVIDIA, AMD или Intel, 2022 года или новее.']],
  ['Память и диск', ['Оперативная память — от 4 ГБ, лучше 8: игре по умолчанию отдаётся 4 ГБ, меньше 2 нельзя.', 'Около 1 ГБ свободного места на диске.']],
  ['Как проверить', ['Диспетчер задач → Производительность → Графический процессор: там название видеокарты. Сомневаетесь — спросите в поддержке до покупки.']],
] };

/* ================================================================================================ around the screens
   The account (top right), the signature line (bottom left) and the music (bottom right) live on the menu's screens only. */
const $top = document.getElementById('top'), $foot = document.getElementById('foot'), $music = document.getElementById('music');
function drawTop() {
  const u = state.user;
  $top.innerHTML = u
    ? `<button class="r-who r-rv" id="who" aria-expanded="false" aria-controls="alts"><span class="r-nick r-mask"><span class="r-in" translate="no">${esc(u.login)}</span></span>${head(u.login, 30)}${SOC.unread ? `<span class="r-nb num">${SOC.unread > 99 ? '99+' : SOC.unread}</span>` : ''}<i class="r-rl"></i></button><div class="r-alts" id="alts" hidden></div>`
    : `<a class="r-who r-rv" href="#/signin"><span class="r-mask"><span class="r-in">${L('Sign in', 'Войти')}</span></span><i class="r-rl"></i></a><a class="r-alt r-add r-rv" href="#/register" style="--o:1"><span class="r-mask"><span class="r-in">${L('or create an account', 'или создать аккаунт')}</span></span></a>`;
  $top.querySelectorAll('canvas[data-head]').forEach(drawHead);
}
function buildAlts() {
  const alts = document.getElementById('alts'); if (!alts || !state.user) return;
  const rows = [[L('Account', 'Кабинет'), '#/dashboard/overview'], [L('My page', 'Моя страница'), '#/u/' + encodeURIComponent(state.user.login)], [L('Wardrobe', 'Гардероб'), '#/wardrobe'], [L('Friends', 'Друзья'), '#/friends', FR.unread], [L('Notifications', 'Уведомления'), '#/notifications', SOC.unread]];
  if (canStaff()) rows.push([L('Staff panel', 'Панель персонала'), '#/admin']);
  alts.innerHTML = rows.map(([t, href, nn], i) => `<a class="r-alt" href="${href}"><span style="--d:${(i * 0.06).toFixed(2)}s">${esc(t)}${nn ? `<span class="r-n">${nn}</span>` : ''}</span></a>`).join('')
    + `<button class="r-alt" id="signout"><span style="--d:${(rows.length * 0.06).toFixed(2)}s">${L('Sign out', 'Выйти')}</span></button>`;
  alts.querySelector('#signout').addEventListener('click', doSignOut);
}
let altsTimer = 0;
function toggleAlts(open) {
  const alts = document.getElementById('alts'), who = document.getElementById('who'); if (!alts || !who) return;
  const o = open === undefined ? alts.hidden : open;
  who.setAttribute('aria-expanded', String(o)); clearTimeout(altsTimer);
  if (o) { alts.hidden = false; alts.classList.remove('r-closing'); buildAlts(); World.Snd.tick(0.6); }
  else if (!alts.hidden) { alts.classList.add('r-closing'); altsTimer = setTimeout(() => { alts.hidden = true; alts.innerHTML = ''; }, 360); }
}
function drawFoot() {
  $foot.innerHTML = `<span class="r-build r-mask"><span class="r-in">Cursed · 26.3</span></span>
    <span class="r-mask"><span class="r-in" style="--i:1"><a class="r-link" href="#/news">${L('What\'s new', 'Что нового')}</a></span></span>
    <span class="r-mask"><span class="r-in" style="--i:2"><a class="r-link" href="#/docs/rules">${L('Rules', 'Правила')}</a></span></span>
    <span class="r-mask"><span class="r-in" style="--i:3"><span class="r-lng" translate="no"><button data-lang="ru" class="${LANG === 'ru' ? 'r-on' : ''}">RU</button><button data-lang="en" class="${LANG === 'en' ? 'r-on' : ''}">EN</button></span></span></span>`;
}
const TRACK = { title: 'Blank Shell', artist: 'Mike Klubnika', len: 128, src: '/music/blank-shell.mp3' };
function drawMusic() {
  $music.innerHTML = `<div class="r-disc" style="background-image:url(/img/disc-pigstep.png)" role="img" aria-label="${L('Music disc', 'Пластинка')}"></div>
    <div class="r-track r-mask"><span class="r-in" translate="no">${TRACK.title}</span></div>
    <div class="r-artist r-mask"><span class="r-in" style="--i:1" translate="no">${TRACK.artist}</span></div>
    <div class="r-bar" id="mbar"><i></i></div>
    <div class="r-ctl r-mask"><span class="r-in" style="--i:2;display:flex;justify-content:space-between;align-items:center;width:100%"><span id="mtime" class="num">0:00 / 2:08</span>
      <span class="r-btns">
        <button id="m-prev" aria-label="${L('From the start', 'Сначала')}"><svg viewBox="0 0 16 16"><path d="M4 3v10M13 3 6 8l7 5z" fill="currentColor" stroke="currentColor" stroke-width="1.2"/></svg></button>
        <button id="m-play" aria-label="${L('Play', 'Играть')}"><svg viewBox="0 0 16 16"><path id="m-ico" d="M4 2.5l9 5.5-9 5.5z" fill="currentColor"/></svg></button>
        <button id="m-next" aria-label="${L('From the start', 'Сначала')}"><svg viewBox="0 0 16 16"><path d="M12 3v10M3 3l7 5-7 5z" fill="currentColor" stroke="currentColor" stroke-width="1.2"/></svg></button>
      </span></span></div>`;
}
const fmtT = (s) => Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');
function tickMusic() {
  const S = World.Snd, len = S.musicLen() || TRACK.len, p = S.musicPos();
  const bar = document.getElementById('mbar'); if (bar) bar.style.setProperty('--t', Math.min(1, p / len).toFixed(4));
  const t = document.getElementById('mtime'); if (t) t.textContent = fmtT(p) + ' / ' + fmtT(len);
  const on = S.musicPlaying() || S.musicWanted();
  if ($music.classList.contains('r-playing') !== S.musicPlaying()) $music.classList.toggle('r-playing', S.musicPlaying());
  const ico = document.getElementById('m-ico');
  if (ico) { const d = on ? 'M5 3v10M11 3v10' : 'M4 2.5l9 5.5-9 5.5z'; if (ico.getAttribute('d') !== d) { ico.setAttribute('d', d); ico.setAttribute('fill', on ? 'none' : 'currentColor'); ico.setAttribute('stroke', on ? 'currentColor' : 'none'); ico.setAttribute('stroke-width', '2.2'); } }
}
// The music comes in softly on the first click or key (browsers start no sound before that), unless it was switched off.
const MUSIC_KEY = 'cursed.sound';
const musicWanted = () => { try { return localStorage.getItem(MUSIC_KEY) !== 'off'; } catch (e) { return true; } };
const musicRemember = (on) => { try { localStorage.setItem(MUSIC_KEY, on ? 'on' : 'off'); } catch (e) { /* not kept */ } };
let heardOnce = false;
function firstHeard() {
  World.Snd.init();
  if (heardOnce) return;
  heardOnce = true;
  if (musicWanted() && !World.Snd.musicPlaying()) World.Snd.musicToggle();
}

/* ================================================================================================ drawing a screen
   app.js's screens draw into #app as before; around them, the menu or the window. A screen changed: what was there
   sinks into its lines (the menu) or closes (the window), and the new one rises out of its own. */
const MENU_ROUTES = new Set(['home', 'signin', 'register', 'buy', 'free', 'forgot', 'reset', 'confirm', 'wardrobe']);
const STATIONS = { home: 'home', buy: 'buy', free: 'free', wardrobe: 'wardrobe', signin: 'auth', register: 'auth', forgot: 'auth', reset: 'auth', confirm: 'auth', lost: 'lost' };
const DOORS = new Set(['signin', 'register', 'forgot', 'reset']);
const $ghost = document.getElementById('ghost');
let MODE = '', SCREEN = '', INTRO = false;
const VIEWS = () => ({ home: viewHome, buy: viewBuy, free: viewFree, wardrobe: viewWardrobe, market: viewMarket, pack: viewPack, author: viewProfile, register: viewRegister, signin: viewSignin, forgot: viewForgot, reset: viewReset, confirm: viewConfirm,
  dashboard: viewDashboard, upload: viewUpload, forum: viewForum, admin: viewAdmin, keys: viewKeys, link: viewLink, watch: viewWatch, docs: viewDocs, license: viewDocs, u: viewProfile, notifications: viewNotifications, badges: viewBadges, friends: viewFriends, support: viewSupport, news: viewNews, top: viewTop });
function toTop(smooth) { const wb = document.querySelector('#app .r-wb'); if (wb) wb.scrollTo({ top: 0, behavior: smooth ? 'smooth' : 'auto' }); else window.scrollTo(0, 0); }
function sink(node, cls, ms) {
  if (!node) return;
  const g = node.cloneNode(true);
  g.classList.remove('r-entering', 'r-opening', 'r-held');
  g.classList.add(cls);
  g.querySelectorAll('[id]').forEach((el) => el.removeAttribute('id'));
  $ghost.appendChild(g);
  setTimeout(() => g.remove(), ms);
}
/* ================================================================================================ changing in place
   A screen drawn again (an answer came, a tab was pressed, a switch) is not thrown away: what is the same stays as it is
   (its scroll, its focus, its pictures), what changed changes — so its CSS transitions run — and what is new comes in
   softly. Another screen in the window: the window and its sections stay, only the page crossfades. */
const BOUND = new WeakMap();
/** One handler per element, event and place: the newest. (app.js hands its handlers out after every drawing.) */
function bindOnce(el, ev, key, h) {
  let m = BOUND.get(el);
  if (!m) { m = new Map(); BOUND.set(el, m); }
  const k = ev + '\u0001' + key, old = m.get(k);
  if (old) el.removeEventListener(ev, old);
  el.addEventListener(ev, h);
  m.set(k, h);
}
// Classes put on by the hand or by an animation under way, not by the drawing: kept through it.
const TRANSIENT = new Set(['r-opening', 'r-entering', 'r-after', 'r-held', 'r-enter', 'r-fresh', 'r-gone', 'r-focus', 'r-pulse', 'r-out', 'r-below', 'r-swap', 'r-holdall', 'r-holdseg', 'r-dd-native', 'r-open', 'over', 'lit']);
const keepsClass = (a, c) => TRANSIENT.has(c) || (c === 'r-on' && a.classList.contains('r-fl'));
const keyOf = (n) => (n.nodeType !== 1 ? '' : n.id ? '#' + n.id : n.getAttribute('data-key') || (n.tagName === 'A' ? n.getAttribute('href') || '' : ''));
function syncAttrs(a, b) {
  const focused = a === document.activeElement;
  for (const at of [...a.attributes]) {
    if (b.hasAttribute(at.name) || (focused && at.name === 'value')) continue;
    // a pill's place is the hand's, not the drawing's: it glides from where it stands
    if (at.name === 'style' && (a.classList.contains('r-ind') || a.classList.contains('r-sind'))) continue;
    if (at.name === 'class') {
      const keep = [...a.classList].filter((c) => keepsClass(a, c));
      if (keep.length) a.className = keep.join(' '); else a.removeAttribute('class');
      continue;
    }
    a.removeAttribute(at.name);
  }
  for (const at of [...b.attributes]) {
    if (at.name === 'class') {
      const keep = [...a.classList].filter((c) => keepsClass(a, c) && !b.classList.contains(c));
      const v = keep.length ? at.value + ' ' + keep.join(' ') : at.value;
      if (a.getAttribute('class') !== v) a.setAttribute('class', v);
      continue;
    }
    if (a.getAttribute(at.name) !== at.value) a.setAttribute(at.name, at.value);
  }
}
function morphNode(a, b, fresh) {
  if (a.nodeType === 3 || a.nodeType === 8) { if (a.nodeValue !== b.nodeValue) a.nodeValue = b.nodeValue; return a; }
  if (a.tagName !== b.tagName) { a.replaceWith(b); if (fresh) b.classList.add('r-fresh'); return b; }
  syncAttrs(a, b);
  const focused = a === document.activeElement;
  switch (a.tagName) {
    case 'INPUT':
      if (!focused) {
        if (a.type === 'checkbox' || a.type === 'radio') a.checked = b.hasAttribute('checked');
        else if (a.type !== 'file') { const v = b.getAttribute('value') || ''; if (a.value !== v) a.value = v; }
      }
      return a;
    case 'TEXTAREA': if (!focused && a.value !== b.value) a.value = b.value; return a;
    case 'SELECT': { morphChildren(a, b, false); const o = b.querySelector('option[selected]'); if (o && a.value !== o.value) a.value = o.value; return a; }
    case 'CANVAS': case 'IFRAME': case 'VIDEO': case 'AUDIO': return a;
    default: break;
  }
  morphChildren(a, b, fresh);
  return a;
}
// A block pushed by what opened or closed above it does not jump: it is drawn where it was and glides (FLIP). Not inside
// a chat's own scroll (it scrolls itself after a drawing), not when the hand asks for less motion.
const FLIP_SEL = '.r-pg :is(.block, .r-tile, .r-hero, .post, .topic, .cat, .nrow, .tk-row, .card, .feature, .ad-line, .ad-crash, .ad-num, .rf-num, .report, .side-block, .acts, .form, .tools, .r-grid, .rows > *)';
const LESS_MOTION = matchMedia('(prefers-reduced-motion: reduce)');
function flipFirst() {
  if (LESS_MOTION.matches || MODE !== 'win') return null;
  const els = [...$app.querySelectorAll(FLIP_SEL)].filter((el) => !el.closest('.fr-msgs, .fr-list, .r-stand, .r-pg-ghost')).slice(0, 160);
  return els.map((el) => [el, el.getBoundingClientRect().top]);
}
function flipPlay(first) {
  if (!first) return;
  const wb = $app.querySelector('.r-wb'), box = wb ? wb.getBoundingClientRect() : null, moved = new Map();
  for (const [el, top] of first) if (el.isConnected && !el.classList.contains('r-fresh')) moved.set(el, [top - el.getBoundingClientRect().top, el.getBoundingClientRect()]);
  for (const [el, [dy, r]] of moved) {
    // a block inside a block that moves is carried by it: only its own part of the move is played
    let up = el.parentElement, base = 0;
    while (up && !up.classList.contains('r-pg')) { if (moved.has(up)) { base = moved.get(up)[0]; break; } up = up.parentElement; }
    const d = dy - base;
    if (Math.abs(d) < 1 || Math.abs(d) > 700) continue;
    if (box && (r.bottom + Math.max(0, dy) < box.top || r.top + Math.min(0, dy) > box.bottom)) continue;   // only what can be seen
    el.animate([{ transform: `translateY(${d}px)` }, { transform: 'translateY(0)' }], { duration: 420, easing: 'cubic-bezier(.2, .8, .2, 1)', composite: 'add' });
  }
}
// A block that came (a form opened, a reply arrived) grows from nothing to its height, opening its own room: what is
// under it is pushed along smoothly instead of jumping (and then needs no gliding of its own).
function growFresh() {
  for (const el of $app.querySelectorAll('.r-pg .r-fresh')) {
    if (el.closest('.fr-msgs, .r-stand, .r-pg-ghost') || el.parentElement.closest('.r-fresh')) continue;
    const cs = getComputedStyle(el), pcs = getComputedStyle(el.parentElement);
    if (!/^(block|flex|grid|flow-root|list-item)$/.test(cs.display) || cs.position === 'absolute' || cs.position === 'fixed') continue;
    if (/flex/.test(pcs.display) && !/column/.test(pcs.flexDirection)) continue;
    const h = el.offsetHeight;
    if (h < 8 || h > 900) continue;
    const ov = el.style.overflow;
    el.style.overflow = 'hidden';
    const mt = cs.marginTop, mb = cs.marginBottom;
    el.animate([{ height: '0px', marginTop: '0px', marginBottom: '0px' }, { height: h + 'px', marginTop: mt, marginBottom: mb }], { duration: 400, easing: 'cubic-bezier(.2, .8, .2, 1)' })
      .finished.then(() => { el.style.overflow = ov; }, () => { el.style.overflow = ov; });
  }
}
// A picture drawn anew (a page coming in is new from the root) is decoded aside: a big cover never stops the motion.
function asyncImages(root) { for (const im of root.querySelectorAll('img:not([decoding])')) im.setAttribute('decoding', 'async'); }
// Layers laid over a page for a moment (the page leaving, a row held still): not the drawing's, so left alone by it.
const foreign = (c) => c.nodeType === 1 && (c.classList.contains('r-pg-ghost') || c.classList.contains('r-stand') || c.classList.contains('r-dd'));
function morphChildren(from, to, fresh) {
  const keyed = new Map();
  for (let c = from.firstChild; c; c = c.nextSibling) { const k = keyOf(c); if (k && !foreign(c) && !keyed.has(k)) keyed.set(k, c); }
  let cur = from.firstChild, n = to.firstChild;
  while (n) {
    while (cur && foreign(cur)) cur = cur.nextSibling;
    const next = n.nextSibling, k = keyOf(n);
    let m = null;
    if (k && keyed.has(k)) { m = keyed.get(k); keyed.delete(k); }
    else if (!k && cur && !keyOf(cur) && cur.nodeType === n.nodeType && (cur.nodeType !== 1 || (cur.tagName === n.tagName && (cur.type || '') === (n.type || '')))) m = cur;
    if (m) {
      if (m !== cur) from.insertBefore(m, cur); else cur = cur.nextSibling;
      morphNode(m, n, fresh);
    } else {
      from.insertBefore(n, cur);
      if (fresh && n.nodeType === 1) n.classList.add('r-fresh');
    }
    n = next;
  }
  while (cur) { const nx = cur.nextSibling; if (!foreign(cur)) from.removeChild(cur); cur = nx; }
}
/** Its insides to this HTML, changed in place (translated first, so the words compare as they will be shown). */
function morphInner(el, html, fresh) {
  const t = document.createElement('div');
  t.innerHTML = html;
  translate(t);
  segMark(t, !!el.closest('.r-win'));
  asyncImages(t);
  unbrowse(t);
  morphChildren(el, t, fresh);
  placeSegs(el);
  dressSelects(el);
}
document.addEventListener('animationend', (e) => {
  const t = e.target;
  if (t.classList && (e.animationName === 'freshIn' || e.animationName === 'pgIn' || e.animationName === 'titleIn')) t.classList.remove('r-fresh', 'r-enter', 'r-swap');
});

/** The selection in the window's sections: one pill gliding to the section open. */
function placeIndicator(now) {
  const side = $app.querySelector('.r-side'); if (!side) return;
  const ind = side.querySelector('.r-ind'), on = side.querySelector('.r-nav.r-on');
  if (!ind) return;
  if (!on) { ind.style.opacity = '0'; return; }
  if (now) ind.classList.add('r-now');
  ind.style.opacity = '1';
  ind.style.width = on.offsetWidth + 'px'; ind.style.height = on.offsetHeight + 'px';
  ind.style.transform = `translate(${on.offsetLeft}px, ${on.offsetTop}px)`;
  if (now) { void ind.offsetWidth; ind.classList.remove('r-now'); }
}

/* Choices in a row (tabs, filters, periods): the one chosen is marked by a pill gliding to the next one chosen. A row:
   two or more buttons of one kind side by side (links, or buttons with the same data- attribute), exactly one of them on. */
const segKey = (el) => (el.tagName === 'A' ? 'href' : ([...el.attributes].find((a) => a.name.startsWith('data-')) || {}).name || '');
function segMark(root, all) {
  for (const on of root.querySelectorAll(all ? '.w.on' : '.r-win .w.on')) {
    const p = on.parentElement, k = segKey(on);
    if (!p || !k) continue;
    const run = [...p.children].filter((c) => c.classList.contains('w') && segKey(c) === k);
    if (run.length < 2 || run.some((c) => (c !== on && c.classList.contains('on')) || c.classList.contains('lead'))) continue;
    for (const c of run) c.classList.add('r-sg');
    p.classList.add('r-seg');
    if (!p.querySelector(`:scope > .r-sind[data-key="sind-${k}"]`)) p.insertAdjacentHTML('afterbegin', `<i class="r-sind" data-key="sind-${k}" aria-hidden="true"></i>`);
  }
}
// a choice changing its width (the font came late, the words changed) moves the pill with it
const SEG_RO = typeof ResizeObserver === 'function' ? new ResizeObserver(() => placeSegs()) : null, SEG_SEEN = new Set();
function placeSegs(root) {
  if (SEG_RO) for (const c of SEG_SEEN) if (!c.isConnected) { SEG_RO.unobserve(c); SEG_SEEN.delete(c); }
  for (const ind of (root || $app).querySelectorAll('.r-sind')) {
    if (SEG_RO) for (const c of ind.parentElement.children) if (c.classList.contains('r-sg') && !SEG_SEEN.has(c)) { SEG_SEEN.add(c); SEG_RO.observe(c); }
    const p = ind.parentElement, k = ind.dataset.key.slice(5);
    const on = [...p.children].find((c) => c.classList.contains('on') && c.classList.contains('r-sg') && segKey(c) === k);
    if (!on || !on.offsetWidth) { ind.style.opacity = '0'; continue; }
    const first = !ind.style.transform || ind.style.opacity === '0';
    if (first) ind.classList.add('r-now');
    ind.style.opacity = '';
    ind.style.width = on.offsetWidth + 'px'; ind.style.height = on.offsetHeight + 'px';
    ind.style.borderRadius = getComputedStyle(on).borderRadius;
    ind.style.transform = `translate(${on.offsetLeft}px, ${on.offsetTop}px)`;
    if (first) { void ind.offsetWidth; ind.classList.remove('r-now'); }
  }
}
// The same row on the page leaving and on the page coming (the forum's tabs, the staff's sections): it is held still over
// both while the page under it changes, and its pill glides; then the new page's own row takes its place.
const segSig = (el) => [...el.children].filter((c) => c.classList.contains('r-sg')).map((c) => segKey(c) + '=' + c.getAttribute(segKey(c))).join(' ');
let HELD = [];
function unhold() {
  for (const h of HELD) { clearTimeout(h.t); h.stand.remove(); h.n.classList.remove('r-holdall', 'r-holdseg'); }
  HELD = [];
}
function holdRows(pairs, mainsec) {
  const m = mainsec.getBoundingClientRect();
  for (const pr of pairs) {
    const r = pr.n.getBoundingClientRect();
    if (Math.abs(r.top - pr.r.top) > 2 || Math.abs(r.left - pr.r.left) > 2 || Math.abs(r.width - pr.r.width) > 2 || r.top < m.top) continue;
    // the whole row when it says the same; else only its choices and the pill (the rest changes with the page)
    const hold = pr.same ? 'r-holdall' : 'r-holdseg';
    const stand = pr.n.cloneNode(true);
    stand.querySelectorAll('[id]').forEach((el) => el.removeAttribute('id'));
    stand.classList.add('r-stand');
    if (!pr.same) stand.classList.add('r-standseg');
    stand.style.cssText += `;position:absolute;left:${r.left - m.left}px;top:${r.top - m.top}px;width:${r.width}px;height:${r.height}px;margin:0;`;
    mainsec.appendChild(stand);
    const ind = stand.querySelector(':scope > .r-sind');
    if (ind && pr.ind) {
      ind.classList.add('r-now');
      ind.style.cssText = pr.ind;
      void ind.offsetWidth;
      ind.classList.remove('r-now');
      placeSegs(stand);
    }
    if (pr.g) pr.g.classList.add(hold);
    pr.n.classList.add(hold);
    const h = { stand, n: pr.n };
    h.t = setTimeout(() => { stand.remove(); pr.n.classList.remove(hold); HELD = HELD.filter((x) => x !== h); }, 540);
    HELD.push(h);
  }
}

// A choice that shows another list (the market's kinds, the tickets' states, a period): the page crossfades under it, as
// another section would. (The app's handlers draw at once, in the same click; the mark lives only through it.)
let SWAP = false;
const SWAPS = '[data-kind],[data-res],[data-fits],[data-page],[data-fo-filter],[data-fo-sort],[data-tk-view],[data-tk-state],[data-ad-days],[data-rf-days]';
document.addEventListener('click', (e) => {
  const b = e.target.closest && e.target.closest(SWAPS);
  if (!b || !b.closest('.r-pg') || (b.classList.contains('on') && !b.matches('[data-res],[data-fits]'))) return;
  SWAP = true;
  setTimeout(() => { SWAP = false; }, 0);
}, true);

function render(keepScroll) {
  const [route, ...rest] = (location.hash.replace(/^#\/?/, '') || 'home').split('/');
  const changed = route !== state.route || rest.join('/') !== state.arg || !SCREEN;
  state.route = route; state.arg = rest.join('/');
  const views = VIEWS();
  state.gate = false;
  if (RANK[state.role] < RANK[need(route, state.arg)]) {
    if (state.jump) state.role = 'member';
    else if (state.role === 'guest') { state.gate = true; state.back = route + (state.arg ? '/' + state.arg : ''); }
  }
  state.jump = false;
  if (route === 'admin' && state.signedIn && !canStaff()) { location.hash = '#/dashboard/overview'; return; }
  if (state.signedIn && state.user && ((route === 'keys' && !rkCan()) || (route === 'watch' && !state.user.admin))) { location.hash = '#/dashboard/overview'; return; }
  if (changed) state.shot = 0;
  const lost = !views[route];
  const menu = state.gate || lost || MENU_ROUTES.has(route);
  const screen = menu ? (state.gate ? 'signin' : lost ? 'lost' : route) : 'win:' + route + '/' + state.arg;
  const was = document.activeElement, keep = was && was.id && $app.contains(was) ? [was.id, was.selectionStart, was.selectionEnd] : null;
  const mode = menu ? 'menu' : 'win', before = MODE, moved = changed && screen !== SCREEN;
  const swap = SWAP && !moved && mode === 'win' && before === 'win';
  SWAP = false;
  const inner = (state.gate ? viewSignin : lost ? viewLost : views[route])(state.arg);
  const key = state.gate ? 'signin' : lost ? 'lost' : route;
  let html;
  if (mode === 'menu') {
    html = `<div class="r-scene r-s-${key} ${DOORS.has(key) ? 'r-door' : ''} ${moved ? 'r-entering' : ''} ${moved && before ? 'r-after' : ''} ${INTRO ? 'r-held' : ''}" data-screen="${key}">${inner}</div>`;
  } else {
    const [title, sub] = winTitle();
    html = `<div class="r-win ${before !== 'win' ? 'r-opening' : ''}" data-r="${esc(route)}" data-a="${esc(String(state.arg).split('/')[0])}" role="dialog" aria-label="Cursed">
        <nav class="r-side" aria-label="${L('Sections', 'Разделы')}"><i class="r-ind" aria-hidden="true"></i>${sidebar()}</nav>
        <section class="r-mainsec"><header class="r-wh"><div class="r-wt"><h1>${esc(title)}</h1>${sub ? `<p>${esc(sub)}</p>` : ''}</div></header>
          <div class="r-wb"><div class="r-pg ${moved || swap ? 'r-enter' : ''}">${inner}</div></div>
          <a class="r-x" href="#/home" aria-label="${L('Close', 'Закрыть')}" title="${L('To the menu', 'В меню')}">${ic('x')}</a></section></div>`;
  }
  const tmp = document.createElement('div');
  tmp.innerHTML = html;
  translate(tmp);
  segMark(tmp);
  asyncImages(tmp);
  unbrowse(tmp);
  const next = tmp.firstElementChild, cur = $app.firstElementChild;
  if (cur && !moved && !swap && mode === before) {
    // The same screen, drawn again: changed in place; what moved for it glides to its new place.
    const flip = flipFirst();
    morphNode(cur, next, true);
    if (flip) growFresh();
    flipPlay(flip);
  } else if (cur && mode === 'win' && before === 'win') {
    // Another page in the window: the frame stays (the selection glides, the title rises), the page crossfades.
    unhold();
    const oldTitle = cur.querySelector('.r-wt').textContent;
    syncAttrs(cur, next);
    morphNode(cur.querySelector('.r-side'), next.querySelector('.r-side'), false);
    morphNode(cur.querySelector('.r-wh'), next.querySelector('.r-wh'), false);
    const wt = cur.querySelector('.r-wt');
    if (wt.textContent !== oldTitle) { wt.classList.remove('r-swap'); void wt.offsetWidth; wt.classList.add('r-swap'); }
    const wb = cur.querySelector('.r-wb'), oldPg = wb.querySelector('.r-pg'), newPg = next.querySelector('.r-pg');
    const pairs = [];
    if (oldPg) {
      const olds = [...oldPg.querySelectorAll('.r-seg')];
      for (const n of newPg.querySelectorAll('.r-seg')) {
        const sig = segSig(n), i = sig ? olds.findIndex((x) => segSig(x) === sig) : -1;
        if (i < 0) continue;
        const oi = olds[i].querySelector(':scope > .r-sind');
        pairs.push({ i, n, r: olds[i].getBoundingClientRect(), ind: oi ? oi.style.cssText : '', same: olds[i].textContent.trim() === n.textContent.trim() });
      }
    }
    if (oldPg) {
      // the page leaving: a copy where it stood, fading up and away over the new one coming in
      const g = oldPg.cloneNode(true);
      g.querySelectorAll('[id]').forEach((el) => el.removeAttribute('id'));
      g.classList.remove('r-enter');
      g.classList.add('r-pg-out');
      const box = document.createElement('div');
      box.className = 'r-pg-ghost';
      box.style.top = wb.offsetTop + 'px'; box.style.height = wb.clientHeight + 'px';
      g.style.marginTop = (oldPg.offsetTop - wb.scrollTop) + 'px';
      box.appendChild(g);
      const gs = g.querySelectorAll('.r-seg');
      for (const pr of pairs) pr.g = gs[pr.i];
      wb.parentNode.insertBefore(box, wb.nextSibling);
      setTimeout(() => box.remove(), 280);
      wb.replaceChild(newPg, oldPg);
    } else wb.appendChild(newPg);
    if (!keepScroll) wb.scrollTop = 0;
    if (pairs.length) {
      // measured where the new page will stand, not where its coming in starts
      const ent = newPg.classList.contains('r-enter');
      newPg.classList.remove('r-enter');
      holdRows(pairs, cur.querySelector('.r-mainsec'));
      if (ent) newPg.classList.add('r-enter');
    }
  } else {
    // The menu sinks into its lines, the window closes; the new one comes.
    unhold();
    if (cur && before === 'menu') sink(cur, 'r-leaving', 420);
    if (cur && before === 'win' && mode === 'menu') sink(cur, 'r-closing', 320);
    $app.replaceChildren(next);
  }
  if (mode === 'menu') {
    World.station(STATIONS[key] || 'home', !before);
    // on a phone Recode's page scrolls: the RECODE signature at the bottom would lie over the payment
    World.lockup((key === 'buy' || key === 'wardrobe') && innerWidth <= 760 ? 0 : 1);
  } else World.station('app', !before);
  if (moved) { World.calm(); World.select(null); }
  MODE = mode; SCREEN = screen;
  document.body.classList.toggle('mode-menu', mode === 'menu');
  document.body.classList.toggle('mode-win', mode === 'win');
  document.body.dataset.screen = menu ? screen : 'win';
  $app.querySelectorAll('canvas[data-head]').forEach(drawHead);
  wire();
  socialWire();
  refsWire();
  shellWire();
  wardrobeWire();
  profileFigureWire();
  if (keep) {
    const el = document.getElementById(keep[0]);
    if (el && el !== document.activeElement) { el.focus({ preventScroll: true }); try { el.setSelectionRange(keep[1], keep[2]); } catch (e) { /* not a text field */ } }
  }
  placeIndicator(before !== 'win');
  placeSegs();
  dressSelects();
  if (moved) World.layoutLockup();
}
function light() { /* the world draws itself (world.js) */ }
function shell(inner) { return inner; }

/* ---- what the shell's own screens do ---- */
function shellWire() {
  const route = state.route;
  if (route === 'buy' && MODE === 'menu') {
    syncBuy(false);
  }
  // The door: the agreement is a box drawn here, the checkbox under it is the one app.js reads.
  const terms = document.getElementById('t-terms');
  if (terms) { const box = terms.closest('.r-agree'); const sync = () => box.classList.toggle('r-on', terms.checked); terms.addEventListener('change', sync); sync(); }
  if (route !== 'forgot') MAILS.sent = false;
  const fg = document.getElementById('forgot');
  if (fg) bindOnce(fg, 'submit', 'forgot', (e) => { e.preventDefault(); forgotGo(); });
  const fa = document.getElementById('forgot-again');
  if (fa) bindOnce(fa, 'click', 'again', (e) => { e.preventDefault(); MAILS.sent = false; render(true); });
  const rs = document.getElementById('reset');
  if (rs) bindOnce(rs, 'submit', 'reset', (e) => { e.preventDefault(); resetGo(); });
  const ec = document.getElementById('em-confirm');
  if (ec) bindOnce(ec, 'click', 'emc', () => { ec.disabled = true; emailConfirmSend(); });
  const signout = document.querySelector('.r-win #signout'); if (signout && !signout.dataset.wired) { signout.dataset.wired = '1'; }
}
async function doSignOut() { await api('logout', {}); signOut(); got.clear(); drawTop(); location.hash = '#/home'; }

/* ================================================================================================ nothing of the browser's own
   What the browser would draw in its own way (a select's list, a prompt, the grey note of a title, a form's warnings) is
   drawn here, in the window's glass and motion. */
const CHEV = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4.5 6.5 8 10l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const CHECK = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 8.4l2.7 2.6L12 5.4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>';

/** After a drawing: titles become our notes, forms say nothing of their own. (Before the drawing reaches the screen.) */
function unbrowse(root) {
  for (const el of root.querySelectorAll('[title]')) tipOf(el);
  for (const f of root.querySelectorAll('form:not([novalidate])')) f.setAttribute('novalidate', '');
}

/* ---- a select: it stays (the app reads it and hears it), hidden; a button stands in its place and opens our list ---- */
let POP = null;
function dressSelects(root) {
  root = root || $app;
  for (const b of root.querySelectorAll('.r-dd')) if (!b._sel || !b._sel.isConnected || b.previousElementSibling !== b._sel) b.remove();
  for (const s of root.querySelectorAll('select')) {
    let b = s.nextElementSibling;
    if (!b || !b.classList.contains('r-dd')) {
      b = document.createElement('button');
      b.type = 'button';
      b.addEventListener('click', () => (POP && POP.btn === b ? closePop() : openPop(b)));
      b.addEventListener('keydown', (e) => {
        if (POP || !['ArrowDown', 'ArrowUp', 'Enter', ' '].includes(e.key)) return;
        e.preventDefault(); e.stopPropagation(); openPop(b);
      });
      s.after(b);
    }
    b._sel = s;
    s.classList.add('r-dd-native');
    s.tabIndex = -1;
    const cls = 'r-dd ' + [...s.classList].filter((c) => c !== 'r-dd-native').join(' ') + (POP && POP.btn === b ? ' r-open' : '');
    if (b.className !== cls) b.className = cls;
    const st = s.getAttribute('style') || '';
    if ((b.getAttribute('style') || '') !== st) b.setAttribute('style', st);
    b.disabled = s.disabled;
    const o = s.options[s.selectedIndex], label = o ? o.text : '';
    if (b._label !== label) { b.innerHTML = `<span class="r-dd-v">${esc(label)}</span>${CHEV}`; b._label = label; }
    const lab = s.getAttribute('aria-label') || (s.id && document.querySelector(`label[for="${s.id}"]`) || {}).textContent || '';
    b.setAttribute('aria-haspopup', 'listbox');
    b.setAttribute('aria-expanded', POP && POP.btn === b ? 'true' : 'false');
    b.setAttribute('aria-label', (lab ? lab + ': ' : '') + label);
  }
  if (POP && !POP.btn.isConnected) closePop(true);
}
function openPop(b) {
  closePop(true);
  const s = b._sel;
  if (!s || s.disabled) return;
  const el = document.createElement('div');
  el.className = 'r-pop';
  el.setAttribute('role', 'listbox');
  const opts = [...s.options];
  const one = (o) => `<button type="button" class="r-pop-o${o.selected ? ' r-on' : ''}" role="option" aria-selected="${o.selected}" data-i="${opts.indexOf(o)}" style="--k:${Math.min(opts.indexOf(o), 12)}"${o.disabled ? ' disabled' : ''}><span>${esc(o.text)}</span>${CHECK}</button>`;
  el.innerHTML = [...s.children].map((n) => (n.tagName === 'OPTGROUP' ? `<div class="r-pop-cap">${esc(n.label)}</div>${[...n.children].map(one).join('')}` : one(n))).join('');
  document.body.appendChild(el);
  POP = { el, btn: b, sel: s, act: null };
  b.classList.add('r-open');
  b.setAttribute('aria-expanded', 'true');
  placePop();
  popAct(el.querySelector('.r-pop-o.r-on') || el.querySelector('.r-pop-o:not([disabled])'));
  // the trigger keeps the focus (the keys go on reaching it); the list is chosen from by the pointer or the keys
  el.addEventListener('pointerdown', (e) => e.preventDefault());
  el.addEventListener('click', (e) => { const o = e.target.closest('.r-pop-o'); if (o && !o.disabled) popChoose(+o.dataset.i); });
  el.addEventListener('pointermove', (e) => { const o = e.target.closest('.r-pop-o'); if (o && !o.disabled && POP && POP.act !== o) popAct(o, true); });
  requestAnimationFrame(() => el.classList.add('r-in'));
}
function placePop() {
  const { el, btn } = POP, r = btn.getBoundingClientRect();
  el.style.minWidth = Math.round(r.width) + 'px';
  const w = el.offsetWidth, h = el.offsetHeight;
  const below = r.bottom + 6 + h <= innerHeight - 8 || r.top - 6 - h < 8;
  el.style.left = Math.round(Math.max(8, Math.min(r.left, innerWidth - w - 8))) + 'px';
  el.style.top = Math.round(below ? r.bottom + 6 : r.top - 6 - h) + 'px';
  el.classList.toggle('r-up', !below);
}
function popAct(o, byPointer) {
  if (!POP || !o) return;
  if (POP.act) POP.act.classList.remove('r-act');
  POP.act = o;
  o.classList.add('r-act');
  if (!byPointer) o.scrollIntoView({ block: 'nearest' });
}
function popChoose(i) {
  const { sel, btn } = POP;
  closePop();
  if (sel.selectedIndex !== i) {
    sel.selectedIndex = i;
    sel.dispatchEvent(new Event('input', { bubbles: true }));
    sel.dispatchEvent(new Event('change', { bubbles: true }));
  }
  if (btn.isConnected) dressSelects(btn.parentElement);
}
function closePop(now) {
  if (!POP) return;
  const { el, btn } = POP;
  POP = null;
  btn.classList.remove('r-open');
  btn.setAttribute('aria-expanded', 'false');
  if (now) { el.remove(); return; }
  el.classList.remove('r-in');
  el.classList.add('r-gone');
  setTimeout(() => el.remove(), 170);
}
document.addEventListener('pointerdown', (e) => { if (POP && !POP.el.contains(e.target) && !POP.btn.contains(e.target)) closePop(); }, true);
document.addEventListener('scroll', (e) => { if (POP && !POP.el.contains(e.target)) closePop(); }, true);
addEventListener('resize', () => closePop(true));
document.addEventListener('keydown', (e) => {
  if (!POP) return;
  const all = [...POP.el.querySelectorAll('.r-pop-o:not([disabled])')], i = all.indexOf(POP.act);
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); popAct(all[Math.max(0, Math.min(all.length - 1, i + (e.key === 'ArrowDown' ? 1 : -1)))]); }
  else if (e.key === 'Home' || e.key === 'End') { e.preventDefault(); popAct(all[e.key === 'Home' ? 0 : all.length - 1]); }
  else if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); if (POP.act) popChoose(+POP.act.dataset.i); }
  else if (e.key === 'Escape') { e.preventDefault(); const b = POP.btn; closePop(); b.focus({ preventScroll: true }); }
  else if (e.key === 'Tab') closePop();
});

/* ---- a question with a word to write (the browser's prompt, ours) ---- */
function rPrompt(title, value, okWord) {
  return new Promise((done) => {
    closePop(true);
    const wrap = document.createElement('div');
    wrap.className = 'r-modal';
    wrap.innerHTML = `<div class="r-modal-card" role="dialog" aria-modal="true" aria-label="${esc(title)}"><h3>${esc(title)}</h3>
      <input class="r-input" type="text" maxlength="120" spellcheck="false">
      <div class="r-modal-acts"><button type="button" class="r-btn r-ghost" data-x>${L('Cancel', 'Отмена')}</button><button type="button" class="r-btn r-pri" data-ok>${esc(okWord || L('Save', 'Сохранить'))}</button></div></div>`;
    document.body.appendChild(wrap);
    const was = document.activeElement, inp = wrap.querySelector('input');
    inp.value = value || '';
    const end = (v) => {
      document.removeEventListener('keydown', key, true);
      wrap.classList.remove('r-in');
      wrap.classList.add('r-gone');
      setTimeout(() => wrap.remove(), 220);
      if (was && was.isConnected) was.focus({ preventScroll: true });
      done(v);
    };
    const key = (e) => {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); end(null); }
      else if (e.key === 'Enter' && e.target === inp) { e.preventDefault(); end(inp.value.trim() || null); }
    };
    document.addEventListener('keydown', key, true);
    wrap.addEventListener('pointerdown', (e) => { if (e.target === wrap) end(null); });
    wrap.querySelector('[data-x]').addEventListener('click', () => end(null));
    wrap.querySelector('[data-ok]').addEventListener('click', () => end(inp.value.trim() || null));
    requestAnimationFrame(() => { wrap.classList.add('r-in'); inp.focus(); inp.select(); });
  });
}

/* ---- a title: not the browser's grey note but ours, after the pointer rests a moment ---- */
function tipOf(el) {
  const t = el.getAttribute('title');
  el.removeAttribute('title');
  if (!t) return;
  el.setAttribute('data-tip', t);
  if (!el.hasAttribute('aria-label') && !el.textContent.trim()) el.setAttribute('aria-label', t);
}
let TIP = null, tipFor = null, tipTimer = 0;
function hideTip() {
  clearTimeout(tipTimer);
  tipFor = null;
  if (TIP) TIP.classList.remove('r-in');
}
function showTip(el) {
  if (!el.isConnected || !el.dataset.tip) return;
  if (!TIP) { TIP = document.createElement('div'); TIP.className = 'r-tip'; TIP.setAttribute('role', 'tooltip'); document.body.appendChild(TIP); }
  TIP.textContent = el.dataset.tip;
  TIP.style.left = '0px'; TIP.style.top = '0px';
  const r = el.getBoundingClientRect(), w = TIP.offsetWidth, h = TIP.offsetHeight;
  const up = r.top - h - 10 >= 6;
  TIP.style.left = Math.round(Math.max(6, Math.min(r.left + r.width / 2 - w / 2, innerWidth - w - 6))) + 'px';
  TIP.style.top = Math.round(up ? r.top - h - 8 : r.bottom + 8) + 'px';
  TIP.classList.toggle('r-up', up);
  TIP.classList.add('r-in');
}
document.addEventListener('pointerover', (e) => {
  if (e.pointerType === 'touch' || !e.target.closest) return;
  const raw = e.target.closest('[title]');
  if (raw) tipOf(raw);
  const el = e.target.closest('[data-tip]');
  if (el === tipFor) return;
  hideTip();
  if (!el) return;
  tipFor = el;
  tipTimer = setTimeout(() => showTip(el), TIP && TIP.classList.contains('r-in') ? 0 : 420);
});
document.addEventListener('pointerout', (e) => { if (tipFor && !(e.relatedTarget && tipFor.contains(e.relatedTarget))) hideTip(); });
['pointerdown', 'keydown', 'wheel'].forEach((ev) => document.addEventListener(ev, hideTip, true));
document.addEventListener('scroll', hideTip, true);

/* ---- the counts in the window's sections and the account up top follow the live line ---- */
const _setUnread = setUnread;
setUnread = function (n) { _setUnread(n); syncCounts(); };
const _frUnread = frUnread;
frUnread = function (n) { _frUnread(n); syncCounts(); };
function syncCounts() {
  const n = (x) => (x ? (x > 99 ? '99+' : String(x)) : '');
  document.querySelectorAll('.r-nav-notes .r-n').forEach((el) => { el.textContent = n(SOC.unread); });
  document.querySelectorAll('.r-nav-fr .r-n').forEach((el) => { el.textContent = n(FR.unread); });
  const nb = document.querySelector('#who .r-nb');
  if (state.user && (SOC.unread ? !nb || nb.textContent !== n(SOC.unread) : nb)) drawTop();
}
const _signIn = signIn, _signOut = signOut;
signIn = function (u) { _signIn(u); drawTop(); };
signOut = function () { _signOut(); drawTop(); };

/* ================================================================================================ the hand
   Over a word of the menu: the line under it catches white fire, the word brightens, the world answers with glow. */
let hov = null;
document.addEventListener('pointerover', (e) => {
  const f = e.target.closest('.r-fl');
  if (f === hov) return;
  if (hov) leaveFl(hov);
  if (f && !f.classList.contains('r-dis') && !INTRO) {
    hov = f;
    f.classList.remove('r-gone'); f.classList.add('r-on');
    const box = f.closest('.r-menu'); if (box) box.classList.add('r-focus');
    World.hover(f); World.Snd.tick();
  } else hov = null;
});
function leaveFl(f) {
  f.classList.remove('r-on'); f.classList.add('r-gone');
  const box = f.closest('.r-menu'); if (box) box.classList.remove('r-focus');
  World.leave(f);
  setTimeout(() => { if (!f.classList.contains('r-on')) f.classList.remove('r-gone'); }, 750);
}
document.addEventListener('click', (e) => {
  const lang = e.target.closest('[data-lang]');
  if (lang && !$app.contains(lang)) { if (lang.dataset.lang !== LANG) setLang(lang.dataset.lang); return; }
  const back = e.target.closest('[data-back]'); if (back) state.back = back.dataset.back;
  const it = e.target.closest('.r-item');
  if (it && !it.classList.contains('r-dis')) { it.classList.remove('r-pulse'); void it.offsetWidth; it.classList.add('r-pulse'); World.pulse(0.7); }
  if (it && it.id === 'pay' && !it.classList.contains('r-dis')) { e.preventDefault(); checkoutRollyPay(it); return; }
  if (it && it.id === 'pay') { e.preventDefault(); const a = document.getElementById('agree'); if (a) a.animate([{ transform: 'translateX(0)' }, { transform: 'translateX(-6px)' }, { transform: 'translateX(5px)' }, { transform: 'translateX(0)' }], { duration: 360, easing: 'ease-out' }); return; }
  const term = e.target.closest('.r-term');
  if (term && !e.target.closest('input')) { BUY.term = Number(term.dataset.term); syncBuy(true); World.Snd.tick(0.8); return; }
  const m = e.target.closest('[data-method]'); if (m) { BUY.method = m.dataset.method; document.querySelectorAll('[data-method]').forEach((x) => x.classList.toggle('r-on', x === m)); World.Snd.tick(0.6); return; }
  const ag = e.target.closest('#agree'); if (ag && !e.target.closest('a')) { BUY.agree = !BUY.agree; ag.classList.toggle('r-on', BUY.agree); ag.setAttribute('aria-checked', BUY.agree); syncBuy(false); return; }
  if (e.target.closest('#who')) { toggleAlts(); return; }
  if (e.target.closest('.r-win #signout')) { doSignOut(); return; }
  if (e.target.closest('#m-play')) { World.Snd.init(); heardOnce = true; const on = World.Snd.musicToggle(); musicRemember(on); tickMusic(); return; }
  if (e.target.closest('#m-prev, #m-next')) { World.Snd.init(); heardOnce = true; World.Snd.musicRestart(); musicRemember(true); return; }
  const alts = document.getElementById('alts'); if (alts && !alts.hidden && !e.target.closest('#top')) toggleAlts(false);
});
document.addEventListener('pointerdown', () => { firstHeard(); }, { passive: true });
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    const alts = document.getElementById('alts'); if (alts && !alts.hidden) { toggleAlts(false); return; }
    if (MODE === 'win' && !document.querySelector('.lightbox, #lightbox') && !/^(INPUT|TEXTAREA|SELECT)$/.test((document.activeElement || {}).tagName || '')) location.hash = '#/home';
  } else firstHeard();
});

/* ================================================================================================ the coming
   (23.10.2026: the client's launch film is gone, she did not like coming in through it.) The world's shaders take seconds
   to build on a first visit (eleven, measured on a fresh browser): a still of the valley (/img/valley.jpg, the front as
   the world draws it) is there at once and comes closer by itself, the menu rises over it at once, and the live world
   comes up through it when it is ready. Nothing to wait through or to skip. */
let SHOT = '';
function showSides() { [$top, $foot, $music].forEach((x) => x.classList.add('r-show')); }
let loadedAt = 0, shotTries = 0, shotAt = 0, lastMove = 0;
addEventListener('hashchange', () => { lastMove = performance.now() / 1000; });
World.onTick = (t) => {
  const TL = World.TL;
  // A frame of the world, for the overview's card: once, from the front, after the world has come in.
  const now = performance.now() / 1000;
  if (World.loaded && !loadedAt) loadedAt = now;
  if (!SHOT && shotTries < 8 && loadedAt && now - loadedAt > 1.8 && now - shotAt > 1.5 && World.stationName === 'home' && t > TL.settle + 1.2 && MODE === 'menu' && now - lastMove > 2.4) { shotAt = now; takeShot(); }
  if ((tickMusic.n = (tickMusic.n || 0) + 1) % 6 === 0) tickMusic();
};
function takeShot() {
  World.snap((cv) => {
    const w = 1200, h = 330, c = document.createElement('canvas'); c.width = w; c.height = h;
    const sw = cv.width * 0.8, sh = Math.min(sw * h / w, cv.height * 0.6), sx = cv.width * 0.1, sy = Math.max(0, cv.height * 0.43 - sh / 2);
    const x = c.getContext('2d'); x.filter = 'brightness(1.55) contrast(1.06)';
    x.drawImage(cv, sx, sy, sw, sh, 0, 0, w, h);
    const px = x.getImageData(0, 0, w, h).data; let sum = 0; for (let i = 0; i < px.length; i += 4 * 97) sum += px[i];
    if (sum / (px.length / (4 * 97)) < 6) { shotTries++; return; }
    try { SHOT = c.toDataURL('image/jpeg', 0.86); } catch (e) { shotTries = 99; }
  });
}

/* ================================================================================================ the boot */
(() => {
  const ok = World.init(document.getElementById('bg'), LOGO_HEAT, false, null);
  if (!ok) document.body.classList.add('nogl');
  showSides();
  drawTop(); drawFoot(); drawMusic();
  if (ok) World.arrive(false, () => document.body.classList.add('live'), true);
  World.Snd.prefetch(TRACK.src);
  const hintedIn = hinted();
  if (!hintedIn) render();
  api('me').then((r) => {
    if (r.ok) signIn(r.data); else if (r.error !== 'offline') signOut();
    if (hintedIn || r.ok) render(true);
    drawTop(); if (!INTRO) $top.classList.add('r-show');
  });
  window.addEventListener('hashchange', () => render());
  window.addEventListener('resize', () => World.layoutLockup());
  // the world's frames for the backdrops and the overview's card: decoded ahead, so their first showing costs no frame
  setTimeout(() => ['/img/world-wide.jpg', '/img/world-banner.jpg'].forEach((u) => { const i = new Image(); i.decoding = 'async'; i.src = u; if (i.decode) i.decode().catch(() => {}); }), 2500);
  addEventListener('resize', () => { placeIndicator(true); placeSegs(); });
})();
// The language: the shell's own words are drawn again with the screen.
const _setLang = setLang;
// Another language: the words fade out, change, and come back (not swapped under the eye).
let LFLIP = 0;
setLang = function (l) {
  if (LFLIP) return;
  document.body.classList.add('r-lflip');
  LFLIP = setTimeout(() => {
    _setLang(l); drawTop(); drawFoot(); drawMusic(); [$top, $foot, $music].forEach((x) => x.classList.add('r-show'));
    placeIndicator(true); placeSegs();
    requestAnimationFrame(() => { document.body.classList.remove('r-lflip'); LFLIP = 0; });
  }, 135);
};

async function checkoutRollyPay(button) {
  if (!BUY.agree || button.disabled) return;
  if (!state.user) { location.hash = '#/signin'; return; }
  button.disabled = true;
  try {
    const r = await api('pay/rollypay/create', { days: BUY.term, method: BUY.method, agree: true });
    if (r.ok && /^https:\/\/pay\.rollypay\.io\/pay\/[A-Za-z0-9_-]+$/.test(r.data.url || '')) { location.assign(r.data.url); return; }
    const text = r.error === 'already-forever' ? L('Your subscription is already lifetime.', 'У тебя уже есть подписка навсегда.')
      : r.error === 'payment-unavailable' ? L('Payments are being connected. Please try later.', 'Подключаем оплату. Попробуй чуть позже.')
      : r.error === 'slow' ? L('Too many attempts. Please try later.', 'Слишком много попыток. Попробуй позже.')
      : L('Could not open payment. Please try later.', 'Не удалось открыть оплату. Попробуй позже.');
    toast({ kind: 'text', data: { text } });
  } finally { button.disabled = false; }
}
