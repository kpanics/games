"use strict";
/* ================================================================================================ the wardrobe (23.10.2026)
   Everything Cursed can put on a player, tried on a figure in the valley: their skin (a Minecraft name, Mojang's or
   Ely.by's, or their own file), the cosmetics' whole pack (figure.js poses it as the game does), standing, walking,
   running or waving. Over a thing: it is tried on, the camera goes to where it sits; a click: worn. Saved, the look is on
   the member's page, where others see it in 3D and can try it on themselves. Loaded before shell.js (its view is one of
   the menu's screens); everything of the shell's it uses is used once the page runs. */

const WR_GROUPS = [
  { id: 'cloaks', name: ['Cloaks', 'Плащи'], kinds: ['cloak'], look: 'back' },
  { id: 'head', name: ['Head', 'Голова'], kinds: ['hat', 'mask', 'glasses', 'bandanna'], look: 'face' },
  { id: 'body', name: ['Body', 'Тело'], kinds: ['suits', 'bodywear', 'neckwear', 'belts', 'wristwear', 'shoes'], look: 'body' },
  { id: 'back', name: ['Back and wings', 'Спина и крылья'], kinds: ['backpack', 'dragon_wings'], look: 'back' },
  { id: 'pets', name: ['Pets', 'Питомцы'], kinds: ['pet', 'companion'], look: 'wide' },
  { id: 'hand', name: ['In hand', 'В руке'], kinds: ['shields', 'sword', 'shovel', 'hand'], look: 'body' },
  { id: 'auras', name: ['Auras', 'Ауры'], kinds: ['auras'], look: 'wide' },
  { id: 'emotes', name: ['Emotes', 'Эмоции'], kinds: [], look: 'wide' },
  { id: 'people', name: ['Looks', 'Образы'], kinds: [], look: 'all' },
];
const WR_KINDS = {
  cloak: ['Cloaks', 'Плащи'], hat: ['Hats', 'Шапки'], mask: ['Masks', 'Маски'], glasses: ['Glasses', 'Очки'], bandanna: ['Bandannas', 'Банданы'],
  suits: ['Suits', 'Костюмы'], bodywear: ['Clothes', 'Одежда'], neckwear: ['Necklaces', 'На шее'], belts: ['Belts', 'Пояса'], wristwear: ['Wrists', 'На запястье'], shoes: ['Shoes', 'Обувь'],
  backpack: ['Backpacks', 'Рюкзаки'], dragon_wings: ['Wings', 'Крылья'], pet: ['On the shoulder', 'На плече'], companion: ['Beside you', 'Рядом'],
  shields: ['Shields', 'Щиты'], sword: ['Swords', 'Мечи'], shovel: ['Shovels', 'Лопаты'], hand: ['Wands', 'Жезлы'], auras: ['Auras', 'Ауры'],
};
const WR_LOOKS = { shoes: 'feet', belts: 'body', wristwear: 'body', pet: 'face', companion: 'wide' };
/* The pack's colours (each item names its own), as words: picked, only those of that colour are shown. */
const WR_COLORS = [['WHITE', ['White', 'Белые']], ['BLACK', ['Black', 'Чёрные']], ['GREY', ['Grey', 'Серые']], ['BLUE', ['Blue', 'Синие']], ['RED', ['Red', 'Красные']],
  ['GREEN', ['Green', 'Зелёные']], ['YELLOW', ['Yellow', 'Жёлтые']], ['PINK', ['Pink', 'Розовые']], ['ORANGE', ['Orange', 'Оранжевые']], ['PURPLE', ['Purple', 'Фиолетовые']],
  ['BROWN', ['Brown', 'Коричневые']], ['GOLD', ['Gold', 'Золотые']], ['SILVER', ['Silver', 'Серебряные']], ['CHROMA', ['Shifting', 'Переливы']]];
/* Things starred: this browser's own (a list to come back to among thousands). */
const WR_FAV_KEY = 'cursed.wardrobe.stars';
const wrFavs = (() => { try { return new Set(JSON.parse(localStorage.getItem(WR_FAV_KEY) || '[]')); } catch (e) { return new Set(); } })();
const wrFavSave = () => { try { localStorage.setItem(WR_FAV_KEY, JSON.stringify([...wrFavs].slice(-500))); } catch (e) { /* not kept */ } };
const WR_POSES = [['idle', ['Stand', 'Стоит']], ['walk', ['Walk', 'Идёт']], ['run', ['Run', 'Бежит']], ['wave', ['Wave', 'Машет']]];
const WR = {
  cat: null, catErr: false, group: 'cloaks', kind: '', q: '', qLive: '', qTimer: 0, shown: 48,
  worn: {}, skin: '', skinName: '', skinFrom: '', skinState: '', file: null, fileUrl: '', game: null,
  pose: 'idle', trying: null, tryTimer: 0, saving: false, saved: '', dirty: false, loadedFor: '', from: '',
  stage: null, canvas: null, thumbs: new Map(), queue: [], busy: false, io: null, emotes: null, emote: null, color: '', peopleSort: 'new', specs: new Map(),
};
/* An item's own settings (its file's "cosmetic_options": the wings' size, a pet's platform), kept with the look as the
   game keeps them: "opt:<item>:option.<name>" (cosmetics/mod.rs, the name as the item's file has it). */
const WR_OPT_NAMES = { size: ['Size', 'Размер'], height: ['Height', 'Высота'], 'hide platform': ['No platform', 'Без платформы'] };
const wrOptKey = (id, name) => `opt:${id}:${name}`;
/** A kept look's worn, its settings under the game's keys (a look of the night of 23.10 kept "opt:<item>:size"). */
function wrWornOf(w) {
  const out = {};
  for (const [k, v] of Object.entries(w || {})) {
    const m = k.match(/^opt:([^:]+):(.+)$/);
    out[m && !m[2].startsWith('option.') ? `opt:${m[1]}:option.${m[2]}` : k] = v;
  }
  return out;
}
function wrOptValues(id) {
  const specs = WR.specs.get(id) || [];
  return specs.map((sp) => { const v = WR.worn[wrOptKey(id, sp.name)]; return [sp.name, v === undefined ? sp.def : Number(v)]; });
}
/** The settings' row under the figure: one control a setting of what is worn. */
function wrOptsRow() {
  const rows = [];
  for (const [slot, id] of Object.entries(WR.worn)) {
    if (slot.startsWith('opt:') || slot === 'emote') continue;
    if (!WR.specs.has(id)) { WR.specs.set(id, []); Figure.model(id).then((m) => { if (m.specs && m.specs.length) { WR.specs.set(id, m.specs); render(true); wrApplyOpts(id); } }, () => {}); continue; }
    const it = WR.cat && WR.cat.byId.get(id);
    for (const sp of WR.specs.get(id)) {
      const n = WR_OPT_NAMES[sp.label.toLowerCase()] || [sp.label, sp.label], key = wrOptKey(id, sp.name), v = WR.worn[key] === undefined ? sp.def : Number(WR.worn[key]);
      const what = it ? (WR_KINDS[it.kind] || [it.kind, it.kind]) : ['', ''];
      rows.push(sp.range
        ? `<label class="wr-opt"><span class="r-lab">${esc(L(...what))} · ${esc(L(...n))}</span><input type="range" min="${sp.range[0]}" max="${sp.range[1]}" step="${(sp.range[1] - sp.range[0]) / 100}" value="${v}" data-wr-opt="${esc(key)}" data-wr-optid="${esc(id)}"></label>`
        : `<button class="r-opt wr-sm${v ? ' r-on' : ''}" data-wr-optb="${esc(key)}" data-wr-optid="${esc(id)}">${esc(L(...n))}</button>`);
    }
  }
  return rows.length ? `<div class="wr-opts r-mask"><span class="r-in" style="--i:2">${rows.join('')}</span></div>` : '';
}
function wrApplyOpts(id) { if (WR.stage) WR.stage.setOptions(id, wrOptValues(id)); }
const WR_HEART = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 13.6S2.2 10.2 2.2 6.1A3 3 0 0 1 8 4.6a3 3 0 0 1 5.8 1.5C13.8 10.2 8 13.6 8 13.6z"/></svg>';
const wrCount = (n) => `${grp3(n)} ${L(n === 1 ? 'item' : 'items', plural(n, 'вещь', 'вещи', 'вещей'))}`;
const wrSlot = (kind) => Figure.slotOf(kind);
const wrGroupOf = (kind) => WR_GROUPS.find((g) => g.kinds.includes(kind));
function wrItems() {
  if (!WR.cat) return [];
  if (WR.group === 'emotes') { const q = WR.qLive.toLowerCase(); return (WR.emotes || []).filter((e) => !q || e.title.toLowerCase().includes(q)); }
  if (WR.group === 'people') { const q = WR.qLive.toLowerCase(); return (WR.people || []).filter((x) => !q || x.login.toLowerCase().includes(q)); }
  const g = WR_GROUPS.find((x) => x.id === WR.group) || WR_GROUPS[0];
  const q = WR.qLive.toLowerCase();
  const kindOk = WR.kind === 'stars' ? (it) => wrFavs.has(it.id) && g.kinds.includes(it.kind) : WR.kind ? (it) => it.kind === WR.kind : (it) => g.kinds.includes(it.kind);
  return WR.cat.items.filter((it) => kindOk(it) && (!WR.color || (it.colors || []).includes(WR.color)) && (!q || it.name.toLowerCase().includes(q)));
}
function wrLabel() {
  if (WR.tryingLook) return `<span class="wr-lk">${L('A member\'s look', 'Образ участника')} · ${L('click to take it', 'клик — забрать себе')}</span><span class="wr-ln" translate="no">${esc(WR.tryingLook)}</span>`;
  if (!WR.trying && WR.emote && WR.emotes) { const e = WR.emotes.find((x) => x.id === WR.emote); if (e) return `<span class="wr-lk">${L('Emote', 'Эмоция')}${WR.emoteBusy ? ' · ' + L('loading', 'загрузка') : ''}</span><span class="wr-ln" translate="no">${esc(e.title)}</span>`; }
  const id = WR.trying || null;
  const it = id && WR.cat ? WR.cat.byId.get(id) : null;
  if (!it) return '';
  const k = WR_KINDS[it.kind] || [it.kind, it.kind];
  const on = Object.values(WR.worn).includes(it.id);
  return `<span class="wr-lk">${esc(L(...k))}${on ? ` · ${L('worn', 'надето')}` : ''}</span><span class="wr-ln" translate="no">${esc(it.name)}</span>`;
}

function viewWardrobe(arg) {
  wrEnter(arg);
  const total = WR.cat ? WR.cat.items.length : 0;
  const counts = {};
  if (WR.cat) for (const it of WR.cat.items) { const g = wrGroupOf(it.kind); if (g) counts[g.id] = (counts[g.id] || 0) + 1; }
  if (WR.emotes) counts.emotes = WR.emotes.length;
  if (WR.group === 'people' && !WR.people && !WR.peopleAsked) { WR.peopleAsked = true; const sort = WR.peopleSort; api('looks' + (sort === 'top' ? '?sort=top' : '')).then((r) => { if (WR.peopleSort !== sort) return; WR.people = r.ok ? r.data.items : []; WR.peopleEnd = !r.ok || r.data.items.length < 30; render(true); }); }
  if (WR.group === 'emotes' && !WR.emotes && WR.cat && !WR.emotesAsked) { WR.emotesAsked = true; Figure.emotes().then((l) => { WR.emotes = l; render(true); }, () => { WR.emotesAsked = false; }); }
  const groups = WR_GROUPS.map((g, i) => `<button class="r-term wr-g r-fl r-rv${WR.group === g.id ? ' r-sel' : ''}" data-wr-group="${g.id}" style="--o:${i + 1}">
      <span class="r-wd"><span class="r-shift"><span class="r-mask"><span class="r-in">${esc(L(...g.name))}</span></span></span><i class="r-hl"></i></span>
      <span class="r-mask"><span class="r-in" style="--i:1"><span class="r-pr">${counts[g.id] ? grp3(counts[g.id]) : ''}</span></span></span><i class="r-rl"></i></button>`).join('');
  const wornN = Object.keys(WR.worn).filter((k) => !k.startsWith('opt:') && k !== 'emote').length;
  const g = WR_GROUPS.find((x) => x.id === WR.group) || WR_GROUPS[0];
  const items = wrItems(), shown = items.slice(0, WR.shown);
  const wornIds = new Set(Object.values(WR.worn));
  const cards = !WR.cat ? (WR.catErr ? `<p class="wr-empty">${L('The wardrobe did not open. Try again in a minute.', 'Гардероб не открылся. Попробуйте через минуту.')}</p>` : Array.from({ length: 12 }, (_, i) => `<span class="wr-card wr-ghost" style="--k:${i}"></span>`).join(''))
    : WR.group === 'people' ? (!WR.people ? Array.from({ length: 8 }, (_, i) => `<span class="wr-card wr-look wr-ghost" style="--k:${i}"></span>`).join('')
      : shown.length ? shown.map((x, i) => wrLookCard(x, i)).join('') + (!WR.peopleEnd && items.length <= shown.length ? `<span class="wr-more" data-key="wr-more-p" id="wr-more"></span>` : '') + (items.length > shown.length ? `<span class="wr-more" data-key="wr-more" id="wr-more"></span>` : '')
        : `<p class="wr-empty">${L('No looks yet. Save yours: it will be the first.', 'Образов пока нет. Сохраните свой — он будет первым.')}</p>`)
    : WR.group === 'emotes' && !WR.emotes ? Array.from({ length: 12 }, (_, i) => `<span class="wr-card wr-ghost" style="--k:${i}"></span>`).join('')
    : WR.group === 'emotes' ? shown.map((e, i) => `<button class="wr-card wr-emo${WR.emote === e.id ? ' wr-on' : ''}" data-key="wr-e${e.id}" data-wr-emote="${e.id}" style="--k:${Math.min(i, 24)}" aria-label="${esc(e.title)}">${e.icon ? `<img src="/cos/f/${e.icon.slice(0, 2)}/${e.icon}" alt="" loading="lazy" decoding="async">` : ''}<span class="wr-et" translate="no">${esc(e.title)}</span><i class="wr-dot"></i></button>`).join('') + (items.length > shown.length ? `<span class="wr-more" data-key="wr-more" id="wr-more"></span>` : '')
    : shown.length ? shown.map((it, i) => {
      const thumb = it.cloak && it.cloak.thumb ? `<img src="/cos/f/${it.cloak.thumb.slice(0, 2)}/${it.cloak.thumb}" alt="" loading="lazy" decoding="async">` : `<canvas width="160" height="160" data-wr-th="${esc(it.id)}"></canvas>`;
      return `<button class="wr-card${wornIds.has(it.id) ? ' wr-on' : ''}${wrFavs.has(it.id) ? ' wr-fav' : ''}" data-key="wr-${esc(it.id)}" data-wr-item="${esc(it.id)}" style="--k:${Math.min(i, 24)}" aria-label="${esc(it.name)}">${thumb}<i class="wr-dot"></i><span class="wr-star" data-wr-star="${esc(it.id)}" role="button" aria-label="${L('Star it', 'В избранное')}"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1.8l1.9 3.9 4.3.6-3.1 3 .7 4.3L8 11.6l-3.8 2 .7-4.3-3.1-3 4.3-.6z"/></svg></span></button>`;
    }).join('') + (items.length > shown.length ? `<span class="wr-more" data-key="wr-more" id="wr-more"></span>` : '')
      : `<p class="wr-empty">${L('Nothing by that name.', 'Ничего не нашлось.')}</p>`;
  const starred = WR.cat && g.kinds.length ? WR.cat.items.filter((it) => wrFavs.has(it.id) && g.kinds.includes(it.kind)).length : 0;
  const kindList = [...(g.kinds.length > 1 ? [['', ['All', 'Все']], ...g.kinds.map((k) => [k, WR_KINDS[k]])] : g.kinds.length ? [['', ['All', 'Все']]] : []), ...(starred ? [['stars', [`Starred ${starred}`, `Избранное ${starred}`]]] : [])];
  const kinds = WR.group === 'people' ? `<div class="wr-kinds">${[['new', ['Newest', 'Новые']], ['top', ['Most liked', 'Популярные']]].map(([k, n]) => `<button class="r-opt${WR.peopleSort === k ? ' r-on' : ''}" data-wr-sort="${k}">${esc(L(...n))}</button>`).join('')}</div>`
    : kindList.length > 1 ? `<div class="wr-kinds">${kindList.map(([k, n]) => `<button class="r-opt${WR.kind === k ? ' r-on' : ''}" data-wr-kind="${k}">${esc(L(...n))}</button>`).join('')}</div>` : '';
  const present = new Set(); if (WR.cat && g.kinds.length) for (const it of WR.cat.items) if (g.kinds.includes(it.kind)) for (const c of it.colors || []) present.add(c);
  const colors = present.size > 1 ? `<div class="wr-colors"><span class="wr-ck">${L('Colour', 'Цвет')}</span>${[['', ['Any', 'Любой']], ...WR_COLORS.filter(([c]) => present.has(c))].map(([c, n]) => `<button class="wr-c${WR.color === c ? ' wr-con' : ''}" data-wr-color="${c}">${esc(L(...n))}</button>`).join('')}</div>` : '';
  const skinSay = WR.skinState === 'busy' ? L('looking…', 'ищу…') : WR.skinState === 'none' ? L('no such skin', 'скин не найден') : WR.skinState === 'slow' ? L('too many at once, a minute', 'слишком часто, минуту') : WR.skinState === 'bad' ? L('a skin is a png 64 × 64', 'скин — png 64 × 64')
    : WR.skin === 'file' ? L('your file', 'свой файл') : WR.skinFrom ? (WR.skinFrom === 'ely' ? 'Ely.by' : 'Mojang') : L('a Minecraft name', 'ник Minecraft');
  const poses = WR_POSES.map(([k, n]) => `<button class="r-opt${WR.pose === k ? ' r-on' : ''}" data-wr-pose="${k}">${esc(L(...n))}</button>`).join('');
  return `<nav class="r-menu r-terms wr-menu" aria-label="${L('Wardrobe', 'Гардероб')}">
      ${mCap(L('Wardrobe', 'Гардероб'), total ? wrCount(total) + ' · 3D' : L('opening…', 'открываю…'), 0)}
      ${groups}
      <div class="wr-acts">
        ${mItem(WR.saving ? L('Saving…', 'Сохраняю…') : L('Save the look', 'Сохранить образ'), '#/wardrobe', { o: 9, mid: true, button: true, id: 'wr-save', tag: WR.saved === 'ok' ? L('on your page', 'на вашей странице') : WR.saved === 'err' ? L('did not save', 'не сохранилось') : WR.dirty ? '' : '' })}
        ${mItem(L('A random look', 'Случайный образ'), '#/wardrobe', { o: 10, quit: true, button: true, id: 'wr-random', dis: !WR.cat })}
        ${mItem(L('Take a picture', 'Сделать кадр'), '#/wardrobe', { o: 11, quit: true, button: true, id: 'wr-photo' })}
        ${mItem(L('Take everything off', 'Снять всё'), '#/wardrobe', { o: 12, quit: true, button: true, id: 'wr-clear', dis: !wornN && !WR.emote })}
        ${mLine(L('in the game: Cursed 1.21.11 → Cosmetics', 'в игре: Cursed 1.21.11 → Cosmetics'), 13, 'r-hint wr-where')}
      </div>
    </nav>
    <div class="wr-stage"><canvas class="wr-fig" id="wr-fig" aria-label="${L('Your figure: drag to turn it, the wheel brings it closer', 'Ваша фигура: тяните, чтобы повернуть, колесом — ближе')}"></canvas>
      <div class="wr-label" id="wr-label" aria-live="polite">${wrLabel()}</div>
      <div class="wr-bottom r-rv" style="--o:4">
        <div class="wr-poses r-mask"><span class="r-in">${poses}</span></div>
        ${wrOptsRow()}
        <div class="wr-skin r-mask"><span class="r-in" style="--i:1">
          <label class="wr-nick"><span class="r-lab">${L('Skin', 'Скин')}</span><input id="wr-nick" maxlength="16" spellcheck="false" autocomplete="off" placeholder="${L('nickname', 'ник')}" value="${esc(WR.skinName)}"><i class="r-u"></i><i class="r-uf"></i></label>
          <span class="wr-ss" id="wr-ss">${esc(skinSay)}</span>
          <button class="r-opt wr-sm" id="wr-file-b" type="button">${L('File', 'Файл')}</button><input type="file" id="wr-file" accept="image/png" hidden>
          ${WR.game ? `<button class="r-opt wr-sm" id="wr-game" type="button">${L('As in the game', 'Как в игре')}</button>` : ''}
        </span></div>
      </div>
    </div>
    <aside class="wr-shelf r-rv" style="--o:2" aria-label="${L('Things to wear', 'Вещи')}">
      <div class="wr-head"><div class="r-last"><span class="r-cap">${esc(L(...g.name))}</span><span class="r-srv">${WR.group === 'people' ? (WR.people ? (WR.peopleSort === 'top' ? L('most liked first', 'сначала популярные') : L('the newest first', 'сначала новые')) : '') : WR.group === 'emotes' ? (WR.emotes ? `${grp3(items.length)} ${L(items.length === 1 ? 'emote' : 'emotes', plural(items.length, 'эмоция', 'эмоции', 'эмоций'))}` : '') : WR.cat ? wrCount(items.length) + (wornN ? ` · ${L('worn', 'надето')} ${wornN}` : '') : ''}</span></div>
        <label class="wr-find"><input id="wr-q" type="search" placeholder="${L('Search by name', 'Поиск по названию')}" value="${esc(WR.q)}" spellcheck="false" autocomplete="off"><i class="r-u"></i><i class="r-uf"></i></label></div>
      ${kinds}${colors}
      <div class="wr-grid" id="wr-grid">${cards}</div>
    </aside>`;
}

/** Coming into the wardrobe: the catalog, and the member's look (their own, or another's to try on: wardrobe/from/<login>). */
function wrEnter(arg) {
  const parts = String(arg || '').split('/');
  const from = parts[0] === 'from' && parts[1] ? decodeURIComponent(parts[1]) : '';
  if (WR.catErr && performance.now() - WR.catErr > 8000) WR.catErr = false;
  if (!WR.cat && !WR.catErr && !WR.catAsked) {
    WR.catAsked = true;
    Figure.catalog().then((c) => { WR.cat = c; render(true); }, () => { WR.catErr = performance.now(); WR.catAsked = false; render(true); });
  }
  const me_ = state.user ? state.user.login : '';
  const want = from || me_;
  if (want && WR.loadedFor !== want) {
    WR.loadedFor = want; WR.from = from;
    api('look/' + encodeURIComponent(want)).then((r) => {
      if (!r.ok || !r.data || WR.loadedFor !== want) return;
      const d = r.data;
      if (!from) WR.game = d.game || null;
      if (d.from) {
        WR.worn = wrWornOf(d.worn);
        const s = String(d.skin || '');
        if (from && s) wrSkinOf(from);
        else if (s.startsWith('name:')) wrSkinByName(s.slice(5));
        else if (s === 'file') wrSkinFile(d.login);
        else { WR.skin = ''; WR.skinName = ''; if (WR.stage) WR.stage.setSkin(null); }
        WR.dirty = !!from;
        wrWear();
        if (d.worn && d.worn.emote) Figure.emotes().then((list) => { const e = list.find((x) => String(x.id) === String(d.worn.emote)); if (e && WR.stage && !WR.emote) { WR.emotes = WR.emotes || list; WR.emote = e.id; WR.stage.emote(e); render(true); wrLabelNow(); } }, () => {});
      }
      render(true);
    });
  }
}
async function wrSkinByName(name) {
  name = String(name || '').trim();
  WR.skinName = name;
  if (!name) { WR.skin = ''; WR.skinFrom = ''; WR.skinState = ''; if (WR.stage) { WR.stage.setSkin(null); WR.stage.setCape(null); } wrSay(); return; }
  if (!/^[A-Za-z0-9_]{1,16}$/.test(name)) { WR.skinState = 'none'; wrSay(); return; }
  WR.skinState = 'busy'; wrSay();
  const job = (async () => {
    let r;
    try { r = await fetch('/api/skin/' + encodeURIComponent(name), { credentials: 'same-origin' }); } catch (e) { r = null; }
    if (WR.skinName !== name) return;
    if (!r || !r.ok) { WR.skinState = r && r.status === 429 ? 'slow' : 'none'; wrSay(); return; }
    let img = null;
    try { img = await createImageBitmap(await r.blob()); } catch (e) { img = null; }
    if (WR.skinName !== name) return;
    if (!img) { WR.skinState = 'none'; wrSay(); return; }
    const slim = r.headers.get('x-skin-model') === 'slim', cape = r.headers.get('x-skin-cape') === '1';
    WR.skin = 'name:' + name; WR.skinFrom = r.headers.get('x-skin-from') || ''; WR.skinState = ''; WR.file = null;
    WR.skinImg = { img, slim };
    if (WR.stage) WR.stage.setSkin(img, slim);
    let c = null;
    if (cape) { try { c = await Figure.loadImage('/api/skin/' + encodeURIComponent(name) + '/cape'); } catch (e) { c = null; } }
    if (WR.skinName !== name) return;
    WR.capeImg = c; if (WR.stage) WR.stage.setCape(c);
    wrSay();
  })();
  WR.skinJob = job;
  return job;
}
/** Another member's skin, taken as one's own file (saved with the look, it is kept as a copy). */
async function wrSkinOf(login) {
  WR.skinState = 'busy'; wrSay();
  let k = null; try { k = await lookSkin(login); } catch (e) { k = null; }
  if (!k) { WR.skinState = 'none'; wrSay(); return; }
  WR.skin = 'file'; WR.file = k.blob.size <= 64 * 1024 ? k.blob : null; WR.skinName = ''; WR.skinFrom = ''; WR.skinState = '';
  WR.skinImg = { img: k.img, slim: k.slim }; WR.capeImg = k.cape;
  if (WR.stage) { WR.stage.setSkin(k.img, k.slim); WR.stage.setCape(k.cape); }
  const inp = document.getElementById('wr-nick'); if (inp) inp.value = '';
  wrSay();
}
async function wrSkinFile(login) {
  try {
    const img = await Figure.loadImage('/api/look/' + encodeURIComponent(login) + '/skin');
    WR.skin = 'file'; WR.skinName = ''; WR.skinFrom = ''; WR.skinImg = { img, slim: null };
    if (WR.stage) WR.stage.setSkin(img);
  } catch (e) { /* none kept */ }
  wrSay();
}
/** Only the skin's line changes (not the whole screen: the field may have the focus). */
function wrSay() {
  const el = document.getElementById('wr-ss'); if (!el) return;
  const s = WR.skinState === 'busy' ? L('looking…', 'ищу…') : WR.skinState === 'none' ? L('no such skin', 'скин не найден') : WR.skinState === 'slow' ? L('too many at once, a minute', 'слишком часто, минуту') : WR.skinState === 'bad' ? L('a skin is a png 64 × 64', 'скин — png 64 × 64')
    : WR.skin === 'file' ? L('your file', 'свой файл') : WR.skinFrom ? (WR.skinFrom === 'ely' ? 'Ely.by' : 'Mojang') : L('a Minecraft name', 'ник Minecraft');
  if (el.textContent !== s) { el.textContent = s; el.classList.remove('wr-flash'); void el.offsetWidth; el.classList.add('wr-flash'); }
}
function wrWear() {
  if (!WR.stage) return;
  for (const id of Object.values(WR.worn)) if (WR.specs.get(id) && WR.specs.get(id).length) wrApplyOpts(id);
  const worn = { ...WR.worn };
  if (WR.trying && WR.cat) { const it = WR.cat.byId.get(WR.trying); if (it) worn[wrSlot(it.kind)] = it.id; }
  const slots = {};
  for (const [k, v] of Object.entries(worn)) if (!k.startsWith('opt:') && k !== 'emote') slots[k] = v;
  WR.stage.wear(slots);
}
function wrLook(id) {
  if (!WR.stage) return;
  const it = id && WR.cat ? WR.cat.byId.get(id) : null;
  if (!it) { WR.stage.look('all'); return; }
  const g = wrGroupOf(it.kind);
  WR.stage.look(WR_LOOKS[it.kind] || (g ? g.look : 'all'));
}
function wrLabelNow() { const el = document.getElementById('wr-label'); if (!el) return; const html = wrLabel(); if (el.innerHTML !== html) { el.classList.remove('wr-in'); void el.offsetWidth; el.innerHTML = html; if (html) el.classList.add('wr-in'); } }

/* ---- the members' looks: a card each (their login, what they wear in small); over it their things are tried on this
   figure, a click takes the whole look (their skin as a copy of one's own) ---- */
function wrLookCard(x, i) {
  const ids = Object.entries(x.worn || {}).filter(([k]) => !k.startsWith('opt:') && k !== 'emote').map(([, v]) => v).slice(0, 4);
  const mini = ids.map((id) => {
    const it = WR.cat && WR.cat.byId.get(id); if (!it) return '';
    return it.cloak && it.cloak.thumb ? `<span class="wr-mini"><img src="/cos/f/${it.cloak.thumb.slice(0, 2)}/${it.cloak.thumb}" alt="" loading="lazy"></span>` : `<span class="wr-mini"><canvas width="160" height="160" data-wr-th="${esc(id)}"></canvas></span>`;
  }).join('');
  const when = `<span class="wr-when">${esc(new Date(x.updated * 1000).toLocaleDateString(L('en-GB', 'ru-RU'), { day: 'numeric', month: 'short' }))}</span>`;
  const mine = state.user && state.user.login === x.login;
  const heart = `<span class="wr-like${x.liked ? ' wr-liked' : ''}${mine ? ' wr-mine' : ''}${x.busy ? ' wr-wait' : ''}"${mine ? '' : ` data-wr-like="${esc(x.login)}" role="button" aria-label="${L('Like', 'Нравится')}"`}>${WR_HEART}<b class="num">${x.likes || 0}</b></span>`;
  return `<button class="wr-card wr-look" data-key="wr-l-${esc(x.login)}" data-wr-look="${esc(x.login)}" style="--k:${Math.min(i, 24)}"><span class="wr-lname" translate="no">${esc(x.login)}</span>${when}${heart}<span class="wr-minis">${mini}</span></button>`;
}
function wrLookOf(login) { return (WR.people || []).find((x) => x.login === login); }

/* ---- a random look: a cloak most of the time, something on the head, now and then wings or a pet ---- */
function wrRandom() {
  const pick = (kinds) => { const all = WR.cat.items.filter((it) => kinds.includes(it.kind)); return all.length ? all[Math.floor(Math.random() * all.length)] : null; };
  const worn = {};
  const put = (it) => { if (it) worn[wrSlot(it.kind)] = it.id; };
  if (Math.random() < .75) put(pick(['cloak']));
  put(pick(['hat', 'mask', 'glasses', 'bandanna']));
  if (Math.random() < .45) put(pick(['dragon_wings', 'backpack']));
  if (Math.random() < .5) put(pick(['pet']));
  if (Math.random() < .3) put(pick(['suits', 'bodywear', 'neckwear', 'shoes']));
  WR.worn = worn; WR.dirty = true; WR.saved = '';
  World.Snd.tick(1); World.pulse(.4);
  if (WR.stage) WR.stage.turnTo(Math.random() < .5 ? -24 : 150);
  wrWear(); render(true);
}
/* ---- a picture of the look: the valley behind as it is now, the figure over it, the site's name small; saved as PNG ---- */
function wrPhoto() {
  if (!WR.stage) return;
  World.Snd.tick(1);
  WR.stage.photo((live) => {
    // the figure's pixels are there only now (the canvas keeps none past its frame): copied before the valley is asked
    const fig = document.createElement('canvas'); fig.width = live.width; fig.height = live.height; fig.getContext('2d').drawImage(live, 0, 0);
    World.snap((bg) => {
      const W = 1600, H = 1000, c = document.createElement('canvas'); c.width = W; c.height = H;
      const x = c.getContext('2d');
      // the valley, covering, a little darker; the figure in the middle, as tall as it stands on the screen
      // only the valley's middle: the menu's words and their fire, the signature in the corner stay out
      const sw = bg.width * .5, sh = Math.min(bg.height * .78, sw * H / W), sx = bg.width * .25, sy = (bg.height - sh) * .42;
      x.filter = 'brightness(.8)'; x.drawImage(bg, sx, sy, sw, sh, 0, 0, W, H); x.filter = 'none';
      const g = x.createRadialGradient(W / 2, H * .55, H * .1, W / 2, H * .55, H * .8); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,.55)'); x.fillStyle = g; x.fillRect(0, 0, W, H);
      const fh = H * .94, fw = fig.width * fh / fig.height;
      x.drawImage(fig, (W - fw) / 2, H - fh - H * .02, fw, fh);
      x.fillStyle = 'rgba(255,255,255,.55)'; x.font = '400 15px "Martian Mono", monospace'; x.textBaseline = 'bottom';
      const who = state.user ? state.user.login.toUpperCase() : '';
      x.fillText(`CURSED${who ? ' · ' + who : ''}`, 36, H - 30);
      x.textAlign = 'right'; x.fillText('CURSEDCLIENT.XYZ', W - 36, H - 30);
      c.toBlob((b) => {
        if (!b) return;
        const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = `cursed-${(state.user && state.user.login) || 'look'}.png`;
        document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
      }, 'image/png');
    });
  });
}

/* ---- the drawing of each card's item: one at a time, on the figure's own canvas, as the cards come into view ---- */
function wrThumbs() {
  const grid = document.getElementById('wr-grid'); if (!grid || !WR.stage) return;
  if (!WR.io || WR.io.root !== grid) {
    if (WR.io) WR.io.disconnect();
    WR.io = new IntersectionObserver((es) => {
      for (const e of es) {
        if (e.target.id === 'wr-more') {
          if (!e.isIntersecting) continue;
          if (e.target.dataset.key === 'wr-more-p' && WR.people && !WR.peopleBusy) {
            WR.peopleBusy = true;
            const last = WR.people[WR.people.length - 1];
            api(WR.peopleSort === 'top' ? 'looks?sort=top&skip=' + WR.people.length : 'looks?before=' + (last ? last.updated : 0)).then((r) => { WR.peopleBusy = false; if (r.ok) { WR.people = WR.people.concat(r.data.items.filter((x) => !WR.people.some((y) => y.login === x.login))); WR.peopleEnd = r.data.items.length < 30; WR.shown += 48; render(true); } });
          } else if (e.target.dataset.key !== 'wr-more-p') { WR.shown += 48; render(true); }
          continue;
        }
        if (e.isIntersecting) { const id = e.target.dataset.wrTh; if (id && !WR.thumbs.has(id) && !WR.queue.includes(id)) { WR.queue.push(id); wrPump(); } }
      }
    }, { root: grid, rootMargin: '200px 0px' });
  }
  for (const c of grid.querySelectorAll('canvas[data-wr-th]')) {
    const id = c.dataset.wrTh, have = WR.thumbs.get(id);
    if (have === 'none') { if (c.dataset.drawn !== id) { c.dataset.drawn = id; c.classList.add('wr-none'); } }
    else if (have && c.dataset.drawn !== id) { const x = c.getContext('2d'); x.clearRect(0, 0, 160, 160); x.drawImage(have, 0, 0, 160, 160); c.dataset.drawn = id; c.classList.add('wr-drawn'); }
    else if (!have && c.dataset.watched !== id) { c.dataset.watched = id; WR.io.observe(c); }
  }
  const more = document.getElementById('wr-more'); if (more && !more.dataset.watched) { more.dataset.watched = '1'; WR.io.observe(more); }
}
async function wrPump() {
  if (WR.busy || !WR.stage) return;
  WR.busy = true;
  while (WR.queue.length && WR.stage) {
    // the next few items' files come meanwhile (the drawing itself is one at a time)
    for (const ahead of WR.queue.slice(0, 10)) Figure.model(ahead).catch(() => {});
    const id = WR.queue.shift(), st = WR.stage;
    let pic = null;
    try { pic = await st.snapshot(id, 160); } catch (e) { pic = null; }
    if (WR.stage !== st) break;
    WR.thumbs.set(id, pic || 'none');
    if (WR.thumbs.size > 600) for (const k of [...WR.thumbs.keys()].slice(0, 100)) WR.thumbs.delete(k);
    for (const c of document.querySelectorAll(`canvas[data-wr-th="${CSS.escape(id)}"]`)) {
      if (pic) { const x = c.getContext('2d'); x.clearRect(0, 0, 160, 160); x.drawImage(pic, 0, 0, 160, 160); c.classList.add('wr-drawn'); }
      else c.classList.add('wr-none');
      c.dataset.drawn = id;
    }
  }
  WR.busy = false;
}

/** After every drawing: the figure on its canvas (made once a visit), the cards' pictures, the skin. */
function wardrobeWire() {
  const cv = document.getElementById('wr-fig');
  if (WR.stage && (!WR.canvas || !WR.canvas.isConnected) && WR.canvas !== cv) { WR.stage.destroy(); WR.stage = null; WR.canvas = null; WR.queue = []; if (WR.io) { WR.io.disconnect(); WR.io = null; } }
  if (cv && !WR.stage) {
    WR.stage = Figure.stage(cv, { dist: 6.3, yaw: -24, target: 1.0 });
    WR.canvas = cv;
    if (WR.stage) {
      WR.stage.mode = WR.pose;
      if (WR.skinImg) WR.stage.setSkin(WR.skinImg.img, WR.skinImg.slim);
      if (WR.capeImg) WR.stage.setCape(WR.capeImg);
      wrWear();
    }
  }
  if (cv) {
    wrThumbs();
    const sel = document.querySelector('.wr-g.r-sel'); if (sel) World.select(sel);
  }
}

document.addEventListener('click', (e) => {
  const like = e.target.closest && e.target.closest('[data-wr-like]');
  if (like && like.closest('.r-s-wardrobe')) {
    e.preventDefault(); e.stopPropagation();
    // the wait kept on the look itself: the card is drawn anew under the click
    const x = wrLookOf(like.dataset.wrLike); if (!x || x.busy) return;
    x.busy = true;
    const on = !x.liked; x.liked = on; x.likes = Math.max(0, (x.likes || 0) + (on ? 1 : -1));
    World.Snd.tick(on ? 1 : .6); like.classList.remove('wr-pop'); void like.offsetWidth; like.classList.add('wr-pop');
    render(true);
    api('look/' + encodeURIComponent(x.login) + '/like', { on }).then((r) => { x.busy = false; if (r.ok) { x.likes = r.data.likes; x.liked = r.data.liked; } else { x.liked = !on; x.likes = Math.max(0, x.likes + (on ? -1 : 1)); } render(true); });
    return;
  }
  const ob = e.target.closest && e.target.closest('[data-wr-optb]');
  if (ob && ob.closest('.r-s-wardrobe')) {
    e.preventDefault();
    const key = ob.dataset.wrOptb, id = ob.dataset.wrOptid, sp = (WR.specs.get(id) || []).find((x) => wrOptKey(id, x.name) === key);
    const now = WR.worn[key] === undefined ? (sp ? sp.def : 0) : Number(WR.worn[key]);
    WR.worn[key] = now ? '0' : '1'; WR.dirty = true; WR.saved = '';
    World.Snd.tick(.7); wrApplyOpts(id); render(true);
    return;
  }
  const sort = e.target.closest && e.target.closest('[data-wr-sort]');
  if (sort && sort.closest('.r-s-wardrobe')) {
    e.preventDefault();
    if (WR.peopleSort !== sort.dataset.wrSort) { WR.peopleSort = sort.dataset.wrSort; WR.people = null; WR.peopleAsked = false; WR.peopleEnd = false; WR.shown = 48; const grid = document.getElementById('wr-grid'); if (grid) grid.scrollTop = 0; World.Snd.tick(.6); render(true); }
    return;
  }
  const star = e.target.closest && e.target.closest('[data-wr-star]');
  if (star && star.closest('.r-s-wardrobe')) {
    e.preventDefault(); e.stopPropagation();
    const id = star.dataset.wrStar;
    if (wrFavs.has(id)) wrFavs.delete(id); else wrFavs.add(id);
    wrFavSave(); World.Snd.tick(.7);
    const card = star.closest('.wr-card'); if (card) { card.classList.toggle('wr-fav', wrFavs.has(id)); star.classList.remove('wr-pop'); void star.offsetWidth; star.classList.add('wr-pop'); }
    if (WR.kind === 'stars' && !wrFavs.has(id)) render(true); else setTimeout(() => render(true), 0);
    return;
  }
  const t = e.target.closest && e.target.closest('[data-wr-group],[data-wr-kind],[data-wr-color],[data-wr-item],[data-wr-emote],[data-wr-look],[data-wr-pose],#wr-save,#wr-clear,#wr-random,#wr-photo,#wr-file-b,#wr-game');
  if (!t || !t.closest('.r-s-wardrobe')) return;
  e.preventDefault();
  const ds = t.dataset;
  if (ds.wrGroup) { if (WR.group !== ds.wrGroup) { WR.group = ds.wrGroup; WR.kind = ''; WR.color = ''; WR.shown = 48; const grid = document.getElementById('wr-grid'); if (grid) grid.scrollTop = 0; World.Snd.tick(.8); render(true); } return; }
  if (ds.wrColor !== undefined) { WR.color = WR.color === ds.wrColor ? '' : ds.wrColor; WR.shown = 48; const grid = document.getElementById('wr-grid'); if (grid) grid.scrollTop = 0; World.Snd.tick(.6); render(true); return; }
  if (ds.wrKind !== undefined) { WR.kind = ds.wrKind; WR.shown = 48; const grid = document.getElementById('wr-grid'); if (grid) grid.scrollTop = 0; World.Snd.tick(.6); render(true); return; }
  if (ds.wrLook) {
    const x = wrLookOf(ds.wrLook); if (!x) return;
    WR.worn = wrWornOf(x.worn); WR.dirty = true; WR.saved = ''; WR.tryingLook = null;
    World.Snd.tick(1); World.pulse(.4); t.classList.remove('wr-pop'); void t.offsetWidth; t.classList.add('wr-pop');
    if (x.skin) wrSkinOf(x.login);
    if (x.worn && x.worn.emote) Figure.emotes().then((list) => { const em = list.find((y) => String(y.id) === String(x.worn.emote)); if (em && WR.stage) { WR.emotes = WR.emotes || list; WR.emote = em.id; WR.stage.emote(em); render(true); } }, () => {});
    else if (WR.emote) { WR.emote = null; if (WR.stage) WR.stage.emote(null); }
    wrWear(); render(true); wrLabelNow();
    return;
  }
  if (ds.wrEmote) {
    const id = Number(ds.wrEmote), info = (WR.emotes || []).find((x) => x.id === id); if (!info || !WR.stage) return;
    World.Snd.tick(1); t.classList.remove('wr-pop'); void t.offsetWidth; t.classList.add('wr-pop');
    if (WR.emote === id) { WR.emote = null; WR.stage.emote(null); WR.stage.look('all'); render(true); wrLabelNow(); return; }
    WR.emote = id; WR.emoteBusy = true; WR.stage.look('wide');
    WR.stage.emote(info).then(() => { if (WR.emote === id) { WR.emoteBusy = false; wrLabelNow(); } }, () => { if (WR.emote === id) { WR.emote = null; WR.emoteBusy = false; WR.stage && WR.stage.emote(null); render(true); wrLabelNow(); } });
    render(true); wrLabelNow();
    return;
  }
  if (ds.wrPose) { WR.pose = ds.wrPose; if (WR.emote) { WR.emote = null; if (WR.stage) WR.stage.emote(null); render(true); wrLabelNow(); } if (WR.stage) WR.stage.mode = WR.pose; document.querySelectorAll('[data-wr-pose]').forEach((b) => b.classList.toggle('r-on', b === t)); World.Snd.tick(.6); return; }
  if (ds.wrItem) {
    const it = WR.cat && WR.cat.byId.get(ds.wrItem); if (!it) return;
    const slot = wrSlot(it.kind);
    if (WR.worn[slot] === it.id) delete WR.worn[slot]; else { const was = WR.worn[slot]; WR.worn[slot] = it.id; if (was) for (const k of Object.keys(WR.worn)) if (k.startsWith(`opt:${was}:`)) delete WR.worn[k]; }
    for (const k of Object.keys(WR.worn)) if (k.startsWith('opt:') && !Object.values(WR.worn).includes(k.split(':')[1])) delete WR.worn[k];
    wrApplyOpts(it.id);
    WR.dirty = true; WR.saved = '';
    World.Snd.tick(1); t.classList.remove('wr-pop'); void t.offsetWidth; t.classList.add('wr-pop');
    wrWear(); render(true); wrLabelNow();
    return;
  }
  if (t.id === 'wr-clear') { WR.worn = {}; WR.dirty = true; WR.saved = ''; if (WR.emote) { WR.emote = null; if (WR.stage) WR.stage.emote(null); } wrWear(); render(true); wrLabelNow(); return; }
  if (t.id === 'wr-random' && WR.cat) { wrRandom(); return; }
  if (t.id === 'wr-photo') { wrPhoto(); return; }
  if (t.id === 'wr-file-b') { document.getElementById('wr-file').click(); return; }
  if (t.id === 'wr-game' && WR.game) {
    WR.worn = wrWornOf(WR.game.worn); WR.dirty = true; WR.saved = '';
    const s = String(WR.game.skin || ''); if (s.startsWith('name:')) { const inp = document.getElementById('wr-nick'); if (inp) inp.value = s.slice(5); wrSkinByName(s.slice(5)); }
    wrWear(); render(true); return;
  }
  if (t.id === 'wr-save') wrSave();
});
async function wrSave() {
  if (WR.saving || !state.user) return;
  WR.saving = true; WR.saved = ''; render(true);
  // a name typed a moment ago (its field just let go): its skin first
  const nick = document.getElementById('wr-nick');
  if (nick && nick.value.trim() && nick.value.trim() !== WR.skinName) wrSkinByName(nick.value);
  if (WR.skinJob) { try { await WR.skinJob; } catch (e) { /* the old skin stays */ } }
  let ok = true;
  if (WR.skin === 'file' && WR.file) {
    try { const r = await fetch('/api/look-skin', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'image/png' }, body: WR.file }); ok = r.ok; } catch (e) { ok = false; }
    if (ok) WR.file = null;
  }
  const worn = { ...WR.worn }; delete worn.emote;
  if (WR.emote) worn.emote = String(WR.emote);
  const r = ok ? await api('look', { skin: WR.skin, worn }) : { ok: false };
  if (r.ok) WR.worn = worn;
  WR.saving = false; WR.saved = r.ok ? 'ok' : 'err';
  if (r.ok) { WR.dirty = false; WR.from = ''; forget('look/' + state.user.login); World.Snd.tick(1); World.pulse(.5); }
  render(true);
}
document.addEventListener('change', async (e) => {
  if (e.target.id !== 'wr-file') return;
  const f = e.target.files && e.target.files[0]; e.target.value = '';
  if (!f) return;
  const bytes = new Uint8Array(await f.arrayBuffer());
  let img = null;
  try { img = await createImageBitmap(new Blob([bytes], { type: 'image/png' })); } catch (err) { img = null; }
  if (!img || img.width !== 64 || (img.height !== 64 && img.height !== 32) || bytes.length > 64 * 1024) { WR.skinState = 'bad'; wrSay(); return; }
  WR.file = new Blob([bytes], { type: 'image/png' }); WR.skin = 'file'; WR.skinName = ''; WR.skinFrom = ''; WR.skinState = ''; WR.skinImg = { img, slim: null }; WR.dirty = true; WR.saved = '';
  const inp = document.getElementById('wr-nick'); if (inp) inp.value = '';
  if (WR.stage) { WR.stage.setSkin(img); WR.stage.setCape(null); }
  wrSay();
});
document.addEventListener('keydown', (e) => {
  if (e.target.id === 'wr-nick' && e.key === 'Enter') { e.preventDefault(); WR.dirty = true; WR.saved = ''; wrSkinByName(e.target.value); }
});
document.addEventListener('focusout', (e) => {
  if (e.target.id === 'wr-nick' && e.target.value.trim() !== (WR.skin.startsWith('name:') ? WR.skin.slice(5) : '') && e.target.value.trim()) { WR.dirty = true; WR.saved = ''; wrSkinByName(e.target.value); }
});
document.addEventListener('input', (e) => {
  const o = e.target.dataset && e.target.dataset.wrOpt;
  if (o) { WR.worn[o] = String(Math.round(Number(e.target.value) * 1000) / 1000); WR.dirty = true; WR.saved = ''; wrApplyOpts(e.target.dataset.wrOptid); return; }
  if (e.target.id !== 'wr-q') return;
  WR.q = e.target.value;
  clearTimeout(WR.qTimer);
  WR.qTimer = setTimeout(() => { WR.qLive = WR.q.trim(); WR.shown = 48; render(true); }, 220);
});
// Over a card: it is tried on (and the camera goes to it); off the shelf a moment: what is worn again.
document.addEventListener('pointerover', (e) => {
  const lk = e.target.closest && e.target.closest('[data-wr-look]');
  if (lk) {
    clearTimeout(WR.tryTimer);
    if (WR.tryingLook === lk.dataset.wrLook) return;
    WR.tryingLook = lk.dataset.wrLook; WR.trying = null;
    const x = wrLookOf(WR.tryingLook);
    if (x && WR.stage) { const slots = {}; for (const [k, v] of Object.entries(x.worn || {})) if (!k.startsWith('opt:') && k !== 'emote') slots[k] = v; WR.stage.wear(slots); WR.stage.look('all'); }
    wrLabelNow();
    return;
  }
  const c = e.target.closest && e.target.closest('[data-wr-item]');
  if (!c) return;
  clearTimeout(WR.tryTimer);
  if (WR.trying === c.dataset.wrItem) return;
  WR.trying = c.dataset.wrItem; wrWear(); wrLook(WR.trying); wrLabelNow();
});
document.addEventListener('pointerout', (e) => {
  const c = e.target.closest && e.target.closest('[data-wr-item],[data-wr-look]');
  if (!c || (e.relatedTarget && e.relatedTarget.closest && e.relatedTarget.closest('[data-wr-item],[data-wr-look]'))) return;
  clearTimeout(WR.tryTimer);
  WR.tryTimer = setTimeout(() => { WR.trying = null; WR.tryingLook = null; wrWear(); wrLook(null); wrLabelNow(); }, 420);
});

/* ---- a member's page: their look in 3D at the top of its side, and a way to try it on ---- */
function profileFigure(login, own) {
  const c = ask('look/' + encodeURIComponent(login));
  if (waiting(c) || !c.ok) return '';
  const d = c.data;
  if (!d.from && !own) return '';
  const heart = d.from === 'site' ? (own ? `<span class="pf-like pf-mine" data-tip="${L('Likes on your look', 'Оценки вашего образа')}">${WR_HEART}<b class="num">${d.likes || 0}</b></span>`
    : `<button class="pf-like${d.liked ? ' pf-liked' : ''}" data-pf-like="${esc(login)}"${d.busy ? ' disabled' : ''} aria-label="${L('Like', 'Нравится')}">${WR_HEART}<b class="num">${d.likes || 0}</b></button>`) : '';
  const acts = (own ? `<a class="w small" href="#/wardrobe">${d.from ? L('Change the look', 'Изменить образ') : L('Make your look', 'Собрать образ')}</a>`
    : `<a class="w small" href="#/wardrobe/from/${encodeURIComponent(login)}">${L('Try it on', 'Примерить образ')}</a>`) + heart;
  return `<div class="pf-fig${d.from ? '' : ' pf-none'}" data-key="pf-fig"><canvas class="pf-cv" id="pf-cv" data-login="${esc(login)}"></canvas>
    <div class="pf-cap"><span class="ash">${d.from === 'game' ? L('as in the game', 'как в игре') : d.from === 'site' ? L('the look', 'образ') : L('no look yet', 'образа пока нет')}</span>${acts}</div></div>`;
}
/** A member's figure on a canvas of a page (their page: #pf-cv, the cabinet's overview: #ov-cv): made when the canvas
   comes, let go when it leaves, dressed again when their look changes. */
const FIGS = { pf: { stage: null, canvas: null, key: '' }, ov: { stage: null, canvas: null, key: '' } };
function figureWire(slot, id, opts) {
  const P = FIGS[slot], cv = document.getElementById(id);
  if (P.stage && P.canvas !== cv) { P.stage.destroy(); P.stage = null; P.canvas = null; P.key = ''; }
  if (!cv) return;
  const login = cv.dataset.login, c = got.get('look/' + encodeURIComponent(login));
  if (!c || !c.ok) return;
  const d = c.data, key = login + ':' + JSON.stringify(d.worn || {}) + ':' + d.skin;
  if (!P.stage) { P.stage = Figure.stage(cv, opts); P.canvas = cv; }
  if (!P.stage || P.key === key) return;
  P.key = key;
  const st = P.stage;
  const slots = {}; for (const [k, v] of Object.entries(d.worn || {})) if (!k.startsWith('opt:') && k !== 'emote') slots[k] = v;
  st.wear(slots);
  // the look's settings of its things ("opt:<item>:<name>")
  const settings = {};
  for (const [k, v] of Object.entries(d.worn || {})) { if (!k.startsWith('opt:')) continue; const [, item, name] = k.split(':'); (settings[item] = settings[item] || []).push([name.startsWith('option.') ? name : 'option.' + name, Number(v)]); }
  for (const [item, list] of Object.entries(settings)) st.setOptions(item, list);
  if (d.worn && d.worn.emote) Figure.emotes().then((list) => { const e = list.find((x) => String(x.id) === String(d.worn.emote)); if (e && P.stage === st) st.emote(e); }, () => {});
  else st.emote(null);
  if (d.skin) lookSkin(login).then((k) => { if (P.stage !== st || !k) return; st.setSkin(k.img, k.slim); st.setCape(k.cape); }, () => {});
}
function profileFigureWire() {
  figureWire('pf', 'pf-cv', { dist: 4.6, yaw: -20, target: 1.02, zoom: false, auto: true });
  figureWire('ov', 'ov-cv', { dist: 4.4, yaw: -24, target: 1.02, zoom: false, auto: true });
}
/** A member's skin as their look has it, through the site (their game's name stays there): the picture, slim or not
   (null: not known), the cape, the bytes (to keep a copy of it as one's own). */
async function lookSkin(login) {
  const r = await fetch('/api/look/' + encodeURIComponent(login) + '/skin', { credentials: 'same-origin' });
  if (!r.ok) return null;
  const blob = await r.blob(), img = await createImageBitmap(blob), model = r.headers.get('x-skin-model');
  let cape = null;
  if (r.headers.get('x-skin-cape') === '1') { try { cape = await Figure.loadImage('/api/look/' + encodeURIComponent(login) + '/cape'); } catch (e) { cape = null; } }
  return { img, slim: model ? model === 'slim' : null, cape, blob };
}
const viewProfileBase = viewProfile;
viewProfile = function (arg) {
  const html = viewProfileBase(arg);
  const login = decodeURIComponent(String(arg || '').split('/')[0] || (state.user ? state.user.login : ''));
  const own = !!(state.user && state.user.login.toLowerCase() === login.toLowerCase());
  return html.replace('<div class="prof-side">', `<div class="prof-side">${profileFigure(login, own)}`);
};
MEMBERS_ONLY.add('wardrobe');
document.addEventListener('click', (e) => {
  const b = e.target.closest && e.target.closest('[data-pf-like]');
  if (!b || b.disabled) return;
  const login = b.dataset.pfLike, c = got.get('look/' + encodeURIComponent(login));
  if (!c || !c.ok || c.data.busy) return;
  const on = !c.data.liked;
  c.data.liked = on; c.data.likes = Math.max(0, (c.data.likes || 0) + (on ? 1 : -1)); c.data.busy = true;
  World.Snd.tick(on ? 1 : .6); render(true);
  api('look/' + encodeURIComponent(login) + '/like', { on }).then((r) => { c.data.busy = false; if (r.ok) { c.data.likes = r.data.likes; c.data.liked = r.data.liked; } else { c.data.liked = !on; c.data.likes = Math.max(0, c.data.likes + (on ? -1 : 1)); } render(true); });
});
// the owner told of a like (notify.rs: "look")
const _noteWords = noteWords;
noteWords = function (n) {
  if (n.kind !== 'look') return _noteWords(n);
  const a = n.actor ? `<b translate="no">${esc(n.actor.login)}</b>` : L('Someone', 'Кто-то');
  return [L(`${a} likes your look`, `${a} — нравится ваш образ`), (n.data && n.data.href) || '#/wardrobe', 'c_heart'];
};
const _signOutWr = signOut;
signOut = function () {
  _signOutWr();
  Object.assign(WR, { worn: {}, skin: '', skinName: '', skinFrom: '', skinState: '', file: null, skinImg: null, capeImg: null, game: null, loadedFor: '', from: '', dirty: false, saved: '', emote: null, trying: null, tryingLook: null, people: null, peopleAsked: false });
  if (WR.stage) { WR.stage.setSkin(null); WR.stage.setCape(null); WR.stage.emote(null); }
};
