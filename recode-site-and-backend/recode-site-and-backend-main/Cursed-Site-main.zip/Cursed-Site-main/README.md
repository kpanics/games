# Cursed Site

Сайт Cursed (cursedclient.xyz).

## Сборка

- `python src/build.py` — главная
- `python web/build.py` — остальные страницы

## Лицензия

MIT с указанием автора — см. [LICENSE](LICENSE). Можно всё, включая форки и продажу; единственное условие — [Lunuca](https://github.com/Lunuca) в авторах каждого форка и продукта из него.
